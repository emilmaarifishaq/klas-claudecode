# Ad Studio — Claude Code Skill

Turn any product photo into a finished, cut-ready 15-second video ad.

## What it does

Full autonomous pipeline from a product photo to a delivered MP4:

1. **Brand + ICP research** — scrapes brand, competitors, and where buyers hang out
2. **3 concepts + visual styles** — photoreal cinematic, iPhone UGC, comic book, cartoon, etc.
3. **Hero casting** — generates or uses your provided hero photo
4. **Visual DNA** — 6-line consistency spec appended to every render prompt
5. **8–12 shot storyboard** — rendered in parallel, self-critiqued before you see it
6. **15-second Seedance 2.0 video** — single timestamped render, not stitched clips
7. **Music** — Higgsfield Sonilo or any connected music tool, muxed with ffmpeg

Three check-ins (concept pick, hero pick, storyboard approval). Everything else is autonomous.

## Requirements

- **Claude Code** with the skill system (`~/.claude/skills/`)
- **Higgsfield** — either the MCP connector (via claude.ai) or the CLI (`higgsfield` on PATH)
- **ffmpeg** — for muxing audio into the final MP4

## Install

```bash
# Copy the skill into your Claude skills directory
cp -r "ad-studio" ~/.claude/skills/

# Restart Claude Code (or it will auto-pick up on next session)
```

## Usage

```
/ad-studio product-photo.jpg
/ad-studio product-photo.jpg hero.jpg "Red Bull energy drink, extreme sports angle"
```

Or just say "make an ad for this" and attach a product photo — the skill triggers automatically.

## Output folder

```
ad-studio/<brand-slug>/
  brief.html        # living design brief — grows with every phase, final ad embedded
  research.md
  concepts.md
  dna.md
  shotlist.md
  moodboard/
  casting/
  storyboard/
  ad-final.mp4
  music-prompt.txt
```

## Notes

- The `brief.html` is a deliverable on its own — send it to a client as the campaign brief
- Aspect ratio is asked once, up front — applies to all storyboard frames and the final video
- No Higgsfield account? Install the CLI: `curl -fsSL https://raw.githubusercontent.com/higgsfield-ai/cli/main/install.sh | sh && higgsfield auth login`
