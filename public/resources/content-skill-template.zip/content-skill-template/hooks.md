# Hook Library

<!-- SETUP: This file is your hook swipe file. Claude pulls from it when generating
     video hooks and content openers. Add as many hooks as you want — templates,
     real hooks that performed well, examples from your niche.

     The more examples you add, the better Claude gets at matching your style.

     FORMAT: Each hook can be a fill-in-the-blank template or a real example.
     Label templates clearly so you know what to fill in. -->

---

## Result Hooks
<!-- Opens with a specific outcome. No setup, no warm-up. -->

- "I [RESULT] in [TIMEFRAME]. Here's exactly how."
- "I went from [BEFORE STATE] to [AFTER STATE] in [TIMEFRAME]."

<!-- Add your own examples below: -->


---

## Problem/Enemy Hooks
<!-- Names the villain — the wrong advice, the broken system, the false belief. -->

- "The reason [AUDIENCE] can't [RESULT] has nothing to do with [WRONG DIAGNOSIS]."
- "Everyone says [COMMON ADVICE]. That's wrong."

<!-- Add your own examples below: -->


---

## Confession Hooks
<!-- Opens with something that sounds like an admission. Creates curiosity. -->

- "I spent [TIME/MONEY] on [WRONG THING] before I figured this out."
- "I [SURPRISING ACTION]. Here's what happened."

<!-- Add your own examples below: -->


---

## If-Then Hooks
<!-- Addresses the viewer's exact situation. Feels personal. -->

- "If you're [AUDIENCE STATE] and you want [RESULT], stop doing [WRONG MOVE]."
- "If I were starting over with [CONSTRAINT], here's the first thing I would do."

<!-- Add your own examples below: -->


---

## Proof Challenge Hooks
<!-- Opens with a number that sounds too good. Creates a pattern interrupt. -->

- "[SPECIFIC RESULT]. Not from [EXPECTED SOURCE]. From [ACTUAL METHOD]."
- "[NUMBER]. [SHORT CONTEXT LINE]. Here's what changed."

<!-- Add your own examples below: -->


---

<!-- TIP: Your best hooks will come from real things you've said that got a reaction.
     When someone says "wait, what? tell me more" — write that down here. -->
