---
name: content
description: Generate a full copy bank — LinkedIn posts, email subject lines, and video hooks from a single topic input. Use when you say /content, "write copy for X", "build a copy bank", "generate content for X", or any multi-format content generation request.
---

<!-- ============================================================
     SETUP — Do this once before using the skill.

     1. Replace every instance of [YOUR_PROJECT_PATH] in this file
        and in all three agent files with the absolute path to your
        content-skill-template folder.

        Example:
        [YOUR_PROJECT_PATH] → /Users/yourname/projects/content-skill-template

     2. Copy this entire .claude/ folder into ~/.claude/
        (merge, don't replace — you may have other skills already)

     3. Type /content in Claude Code to test it.
     ============================================================ -->

# Content Copy Bank — Orchestrator

Generates a structured copy bank from a single topic input.
Outputs: 3–5 LinkedIn post variations, 5–10 email subject lines, 5+ video hooks.

---

## Step 1: Input Collection

Ask for exactly two inputs — nothing else:

1. **Topic/angle** — What is this content about? (One sentence. Could be a claim, a story beat, a result, a lesson, or a contrarian take.)
2. **Performance notes** — Any data points, results, or numbers to anchor the copy? (Optional — say "none" to skip.)

Say this:
> "What's the topic? And any numbers or results to anchor it with?"

Wait for a response before proceeding.

---

## Step 2: Context Load

Read both files before generating anything:
- `[YOUR_PROJECT_PATH]/context/brand-voice.md`
- `[YOUR_PROJECT_PATH]/context/context-packet.md`

Pull and note:
- Which content pillar this topic falls under
- Any matching proof points or numbers
- Relevant phrase bank entries

---

## Step 3: Run Sub-Agents in Parallel

Spawn all three sub-agents simultaneously, passing each:
- The topic/angle provided
- Any performance notes provided
- The matching proof points pulled from the context packet

Sub-agents to run:
- `[YOUR_PROJECT_PATH]/.claude/agents/linkedin-posts.md`
- `[YOUR_PROJECT_PATH]/.claude/agents/email-subjects.md`
- `[YOUR_PROJECT_PATH]/.claude/agents/video-hooks.md`

---

## Step 4: Assemble and Output Copy Bank

Compile all sub-agent outputs into this exact format. No editorializing. No extra headers. No explanations.

```
COPY BANK — [TOPIC IN ALL CAPS]
Generated: [date]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
LINKEDIN POSTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[POST 1 — TYPE LABEL]
[full post]

---

[POST 2 — TYPE LABEL]
[full post]

---

[POST 3 — TYPE LABEL]
[full post]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EMAIL SUBJECT LINES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. [subject line]
2. [subject line]
3. [subject line]
4. [subject line]
5. [subject line]
6. [subject line]
7. [subject line]
8. [subject line]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
VIDEO HOOKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. [HOOK TYPE] Hook text here.
2. [HOOK TYPE] Hook text here.
3. [HOOK TYPE] Hook text here.
4. [HOOK TYPE] Hook text here.
5. [HOOK TYPE] Hook text here.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

End with this line exactly:
> Say `riff linkedin`, `riff email`, or `riff hooks` to generate more variations. Say `rewrite [N]` to push a specific piece harder.

---

## Refinement Loop

Handle these commands without asking for confirmation:

- `riff linkedin` → generate 3 additional LinkedIn post variations
- `riff email` → generate 5 additional email subject lines
- `riff hooks` → generate 3 additional video hooks
- `rewrite [N]` → take that numbered piece and produce 2 alternative versions
- `shorter` → apply a compression pass to whatever is flagged
- `more proof` → rewrite flagged pieces with harder numbers from the context packet

Do not re-run the full pipeline for refinement requests. Target only what was asked.
