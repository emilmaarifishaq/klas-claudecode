# Brand Voice

<!-- SETUP: Fill in each section below with your own voice rules.
     Be specific. Vague rules produce vague output.
     The more concrete your examples, the better Claude follows them. -->

---

## Core Principles

<!-- List 4–8 rules that govern how you write. Name each one.
     Example format:

     **Compression First** — Every draft gets shorter. Cut anything that can be cut without losing the point.
     **Proof Over Persuasion** — Every claim needs a number, result, or timeline. No adjectives standing alone.
     **No Filler** — No motivational language. No warm-up sentences. First line states the point.
-->

1. **[PRINCIPLE NAME]** — [What it means and why it matters]
2. **[PRINCIPLE NAME]** — [What it means and why it matters]
3. **[PRINCIPLE NAME]** — [What it means and why it matters]
4. **[PRINCIPLE NAME]** — [What it means and why it matters]

---

## Sentence-Level Style Rules

<!-- List your hard writing rules. Examples:
     - Sentences under 15 words
     - Active voice only
     - No semicolons (use periods)
     - No hedging words: "might," "could," "perhaps"
     - Numbers are always numerals, not words
-->

- [RULE]
- [RULE]
- [RULE]
- [RULE]
- [RULE]

---

## Words and Phrases I Use

<!-- List your signature vocabulary — the words and phrases that sound like you.
     Examples: "ship," "systems," "close," "build," "no theory," "make money today"
-->

- [PHRASE OR WORD]
- [PHRASE OR WORD]
- [PHRASE OR WORD]
- [PHRASE OR WORD]

---

## What to Avoid

<!-- List patterns that break your voice. Examples:
     - Coaching-speak ("hold space," "unpack," "lean into")
     - Corporate tone ("synergy," "leverage," "paradigm")
     - Passive income framing
     - Affirmations and validation
     - Hype words ("game-changing," "incredible," "mind-blowing")
-->

- [ANTI-PATTERN]
- [ANTI-PATTERN]
- [ANTI-PATTERN]
- [ANTI-PATTERN]

---

## Pre-Finalization Checklist

<!-- List the questions you run through before publishing anything.
     Claude will apply this to every piece it writes for you. Examples:
     - Does the first sentence state the point, problem, or claim?
     - Can any sentence be cut without losing the point?
     - Is there any hedging that should be declarative?
     - Does the last sentence resolve to an action, question, or sharp close?
-->

1. [CHECKLIST ITEM]
2. [CHECKLIST ITEM]
3. [CHECKLIST ITEM]
4. [CHECKLIST ITEM]
5. [CHECKLIST ITEM]
