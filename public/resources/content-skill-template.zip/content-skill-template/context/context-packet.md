# Context Packet

<!-- SETUP: This is your AI identity file. Fill it in once and Claude will use it
     to anchor every piece of content to your real story, results, and positioning.
     The more specific your proof points, the better the output. -->

---

## Who I Am

<!-- 3–5 sentences. What you do, who you serve, what makes you different.
     Write it the way you'd say it to a stranger at a conference — not a bio, not a pitch.
     Example: "I'm a [title] who [what you do] for [who]. I've [proof point]. I [differentiator]."
-->

[YOUR DESCRIPTION HERE]

---

## My Business

<!-- What you sell, who buys it, what it costs, what results it gets.
     Example:
     - [Product/Service name] — [price] — [who it's for] — [result it delivers]
-->

- [PRODUCT/SERVICE] — $[PRICE] — [WHO IT'S FOR] — [RESULT]
- [PRODUCT/SERVICE] — $[PRICE] — [WHO IT'S FOR] — [RESULT]

---

## Proof Points and Results

<!-- Specific numbers, timelines, and outcomes you can reference in content.
     These anchor your claims. Be exact. "A lot" is useless. "$47K in 60 days" is powerful.
     Examples:
     - Grew LinkedIn from 0 to 12K followers in 8 months
     - Closed a $15K/month retainer from a single DM
     - Helped 200+ members publish their first AI-powered workflow
-->

- [RESULT WITH NUMBER AND TIMEFRAME]
- [RESULT WITH NUMBER AND TIMEFRAME]
- [RESULT WITH NUMBER AND TIMEFRAME]
- [RESULT WITH NUMBER AND TIMEFRAME]

---

## Content Pillars

<!-- The 3–5 topics you own. Everything you publish connects back to one of these.
     Examples: AI automation, personal brand, performance marketing, community building
-->

1. [PILLAR]
2. [PILLAR]
3. [PILLAR]
4. [PILLAR]

---

## Audience

<!-- Who reads your content. What they want. What's holding them back.
     The more specifically you describe them, the more the content will speak directly to them.
-->

**Who they are:** [DESCRIPTION]
**What they want:** [GOAL]
**What's stopping them:** [REAL OBSTACLE — not the surface one, the actual one]

---

## Phrase Bank

<!-- 8–12 phrases that sound like you. These will get recycled into your content.
     Examples: "No theory," "Ship," "Systems, not vibes," "Make money today"
-->

- "[PHRASE]"
- "[PHRASE]"
- "[PHRASE]"
- "[PHRASE]"
- "[PHRASE]"
- "[PHRASE]"
