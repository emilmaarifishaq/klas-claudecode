# IG Channel Remix — Claude Code skill

Mine any Instagram channel's viral format, twist the premise, and render new videos in that
format with Higgsfield Seedance 2.0. Point it at one IG handle; it ranks the account's top 10
reels by real view count, watches each opening 3 seconds frame-by-frame, distills the
mechanical "Format DNA" (camera / pacing / realism / action), then renders finished remix
videos that keep those mechanics but swap the subject (e.g. animal rescue → mythological
creature rescue). Output is video, not a spec document.

## Install

Copy this folder into your Claude Code skills directory:

```bash
cp -r ig-channel-remix-skill ~/.claude/skills/ig-channel-remix
```

Then run it in Claude Code with:

```
/ig-channel-remix @somehandle
```

## Prerequisites

1. **Claude Code** — https://claude.com/claude-code
2. **ffmpeg + ffprobe** — `brew install ffmpeg`
3. **yt-dlp** — `brew install yt-dlp`
4. **Python 3** with `requests` and `browser_cookie3` — the discovery script auto-installs
   `browser_cookie3` on first run; `pip3 install requests browser_cookie3` to do it up front.
5. **Higgsfield CLI** — install and authenticate:
   ```bash
   npm install -g @higgsfield/cli
   higgsfield auth login
   ```
   Rendering uses paid Higgsfield credits (Seedance 2.0 video + optional Nano Banana stills).
6. **The `/watch` plugin (claude-video)** — the skill shells out to its `watch.py` to extract
   frames and transcripts. Install it in Claude Code via the plugin marketplace (`/plugin`),
   plugin name `claude-video`. The skill locates it under `~/.claude/plugins/cache/claude-video`.
7. **Chrome logged into instagram.com** — reel discovery reads your own logged-in Chrome
   session cookies at runtime via `browser_cookie3` to query Instagram's private API for real
   per-post view counts. Nothing is stored; it only works with accounts your session can see.
8. **Optional: vidIQ MCP connector** — used only as a discovery fallback (max 6 reels) when
   the cookie method fails. The skill works without it.

## What's in this folder

```
ig-channel-remix-skill/
├── SKILL.md                     # the skill definition Claude Code executes
├── scripts/
│   └── fetch_top_reels.py       # ranks an account's reels by real play_count
└── README.md
```

The skill also creates, at runtime:
- `~/.claude/skills/ig-channel-remix/library/<handle>/` — persistent per-channel Format DNA,
  so "make more variations of @handle" skips re-mining.
- `~/Desktop/ig-channel-remix/<handle>/` — per-run output (frames, analysis, finished clips).

## Notes and disclaimers

- Discovery uses Instagram's private web API with your own browser session. Use it on your
  own account or content you have the right to analyze; heavy use can trip Instagram
  rate limits. This is for research/inspiration — don't re-upload other people's footage.
- Renders cost real money. The skill has exactly one required check-in (twist choice + video
  count) before any spend begins.
- Render spec is fixed: Seedance 2.0, 9:16, 720p, 15-second clips, stitched with ffmpeg for
  longer sources.
