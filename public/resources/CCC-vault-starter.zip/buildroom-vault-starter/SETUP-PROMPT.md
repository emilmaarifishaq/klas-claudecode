# Vault Setup Prompt

Copy everything below this line and paste it into Claude Code inside your vault folder.

---

I want to set up my AI second brain vault. You're going to interview me to collect everything you need, then use my answers to populate all the core files.

Here's how I want this to work:

- Ask me one question at a time
- Wait for my answer before moving to the next question
- If an answer is vague, ask one follow-up to sharpen it — then move on
- Don't ask more than 12 questions total
- Once you have enough, tell me what you're about to do and ask me to confirm before writing anything

The questions should cover:
1. My name and what I help people do (my mission in one line)
2. Who exactly I help (my ICP — who they are, what they want, what's stopping them)
3. Phrases my audience actually uses (their words, not mine)
4. My product — what it is, how it's delivered, what it costs, and the transformation it creates
5. My content channels
6. My brand voice — how I communicate, what I avoid, what makes me different
7. Any proof points or wins I already have (member results, testimonials, outcomes)

After the interview, do the following:

1. Update `CLAUDE.md` — replace all `[PLACEHOLDERS]` with my real details
2. Populate `01-Me/offer.md` — fill in my offer using the template
3. Populate `01-Me/brand-voice.md` — fill in my voice rules from what I've shared
4. Populate `02-Audience/icp-profile.md` — fill in my ICP with my answers
5. Populate `02-Audience/proof-bank.md` — add any wins I've shared as entries
6. Populate `03-Product/product.md` — fill in my product details
7. Leave `04-Coaching/`, `05-Content/`, and `06-AI/` as-is — those build over time

After writing all files, tell me:
- What's filled in and ready to use
- What still needs my input
- The one thing I should do next to get the most out of this system

Start now. Ask me your first question.
