---
tags: [setup, start-here]
---

# Welcome to Your AI Second Brain

This vault is your personal knowledge base — built so Claude Code can actually operate inside it.

Before you do anything else, read this file top to bottom. It takes 5 minutes and saves you hours.

---

## What This Is

Your vault is not just a folder of notes. It's a structured knowledge system that Claude Code can read, write, and reason across. Drop in raw content, run `/digest`, and Claude routes everything to the right place automatically.

---

## Step 1 — Fill In Your CLAUDE.md

Open `CLAUDE.md` in this folder. It's the file Claude reads first in every session.

Replace every `[PLACEHOLDER]` with your details:
- Your name
- What you help people do
- Who your audience is
- Your offer

This takes 10 minutes and makes every future Claude session 10x smarter.

---

## Step 2 — Install the Obsidian Skills

Open Claude Code in this vault folder and paste this:

> "Install the skills from this repo: https://github.com/kepano/obsidian-skills"

Claude will handle the rest. This teaches Claude how to write proper Obsidian markdown, use wikilinks, and interact with your vault correctly.

---

## Step 3 — Create Your 5 Core Files

These are the minimum files your brain needs to function. Templates are in each folder.

| File | Where |
|------|-------|
| `offer.md` | `01-Me/` |
| `brand-voice.md` | `01-Me/` |
| `icp-profile.md` | `02-Audience/` |
| `what-works.md` | `03-Content/` |
| `coaching-intelligence.md` | `04-Coaching/` |

Open each template, fill it in, save it. Don't overthink it — rough answers now, refine later.

---

## Step 4 — Drop Something Into raw/

Find a transcript, PDF, set of notes, or any raw content you want to process.

Drop it into the `raw/` folder.

Then open Claude Code and type: `/digest`

Watch Claude read it, extract what matters, and update the right files automatically.

---

## You're Set Up

From here, the system builds itself every time you use it. The more you put in, the smarter Claude gets about your brand, your audience, and your content.

**Next:** Open `CLAUDE.md` and fill in your details.
