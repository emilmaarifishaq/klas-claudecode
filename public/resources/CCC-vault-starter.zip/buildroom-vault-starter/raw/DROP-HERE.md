# raw/

This folder is for unprocessed inputs only.

**What to drop here:**
- Call transcripts (copy/paste or .txt)
- PDF exports
- Voice-to-text notes
- Interview notes
- Any raw content you want Claude to process

**Rules:**
- Never edit files in this folder
- Never delete files after processing — they stay here as the source of truth
- Claude will check `ingestion-log.md` before processing to avoid duplicates

**To process:** drop your file here, then open Claude Code and type `/digest`
