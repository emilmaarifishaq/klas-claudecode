---
tags: [audience, proof, testimonials, wins]
updated: 
---

# Proof Bank

Every member win, transformation, and testimonial lives here. Claude reads this before creating any content to find a real anchor — a story or result that makes the post credible.

**Rule:** Never publish content without an anchor from this file or a personal story from `01-Me/`.

---

## How to Add an Entry

Copy the template below and fill it in. Be specific — vague wins don't convert.

---

## Wins

### [Member Name or Alias] — [Short Result Title]

**Result:** [Specific, measurable outcome — e.g. "Grew from 200 to 4,100 followers in 6 weeks"]
**Timeframe:** 
**What they did:** [The action they took using your system]
**Their words:** "[Direct quote if you have one]"
**Used for:** [Content topics this supports — e.g. audience growth, consistency, AI tools]
**Last used:** 

---

### [Member Name or Alias] — [Short Result Title]

**Result:** 
**Timeframe:** 
**What they did:** 
**Their words:** ""
**Used for:** 
**Last used:** 

---

## AI Notes

[Claude adds context here — never above this line]
