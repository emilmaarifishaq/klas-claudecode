---
tags: [icp, audience]
updated: 
---

# ICP Profile — [Avatar Name]

Give your avatar a name and a situation. e.g. "Stuck Sarah — the coach with clients but no content system."

---

## Who They Are

**Job/role:** 
**Stage of business:** [e.g. 0-$5k/month, just starting, been at it 2 years]
**How they found you:** 

---

## Their Situation Right Now

[Describe a day in their life. What are they doing, struggling with, trying to figure out?]

---

## What They Want

**Surface want:** [What they say they want]
**Deep want:** [What they actually want underneath that]

---

## What's Stopping Them

[List 2-3 real blockers — not excuses, real obstacles]

1. 
2. 
3. 

---

## Their Biggest Fear

[The thing they're most afraid of — failure, embarrassment, wasting time, looking stupid, etc.]

---

## Real Language They Use

[Paste verbatim phrases your audience actually says — in DMs, comments, on calls. This is gold.]

- "..."
- "..."
- "..."
- "..."
- "..."

---

## What They've Already Tried

[What have they attempted before coming to you? Why didn't it work?]

---

## AI Notes

[Claude adds context here — never above this line]
