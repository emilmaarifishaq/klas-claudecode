# 02-Audience

Your ICP profiles, pain points, and real language your audience uses.

The most valuable thing in this folder is verbatim language — phrases your audience actually says, not your interpretation of what they mean. Claude uses this to write content that lands.

**Start with:**
- `icp-profile.md` — one avatar, their pain, their goal, their words

**Build over time:** every coaching call, DM, or comment that contains a phrase you haven't heard before → add it here.
