# 05-Content

All content intelligence, published work, and templates.

**Start with:**
- `what-works.md` — log every post or video that over-performs
- `hook-swipe-file.md` — hooks that landed, ranked by performance
- `post-log.md` — record of every published piece (so Claude doesn't repeat anchors)

**Build over time:**
- `video-archive/` — one file per published video
- Add a row to `post-log.md` every time you publish something

Claude reads `post-log.md` before suggesting content anchors to avoid repeating the same story or proof point.
