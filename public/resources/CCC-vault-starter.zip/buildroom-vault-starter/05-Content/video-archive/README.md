# Video Archive

One file per published video. Claude reads these to understand what you've already covered, find content gaps, and avoid repeating angles.

**Naming convention:** `YYYY-MM-DD-slug.md` — e.g. `2026-01-15-how-i-use-claude-code.md`

**Template:** Copy the block below into a new file for each video.

---

```markdown
---
tags: [video, published]
published: YYYY-MM-DD
platform: YouTube
status: published
---

# [Video Title]

## Hook / Thumbnail Angle

## Core Argument

## Key Points
1. 
2. 
3. 

## CTA

## Performance Notes

## AI Notes
```
