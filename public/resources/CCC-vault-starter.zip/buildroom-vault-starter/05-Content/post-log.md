---
tags: [content, log, published]
updated: 
---

# Post Log

Every published piece of content — one row per post. Claude checks this before picking a proof anchor so you never repeat the same story twice in a row.

---

## Log

| Date | Platform | Title / Hook | Anchor Used | Format | Notes |
|------|----------|--------------|-------------|--------|-------|
| | | | | | |
| | | | | | |

---

**Anchor** = the proof point or personal story you used (e.g. "Austin Lau case study", "my layoff story", "5 agents $5/day")

**Format** = e.g. list, story, hot take, how-to, before/after

---

## AI Notes

[Claude adds context here — never above this line]
