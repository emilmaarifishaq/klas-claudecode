---
tags: [content, hooks, swipe-file]
updated: 
---

# Hook Swipe File

Hooks that landed — your own and ones you've studied. Claude reads this when writing new content to match patterns that work for your audience.

**Performance key:** ⭐ good / ⭐⭐ great / ⭐⭐⭐ exceptional

---

## My Best Hooks

| Hook | Platform | Performance | Why It Worked | Last Used |
|------|----------|-------------|---------------|-----------|
| | | | | |
| | | | | |

---

## Hook Patterns That Work For My Audience

[After you collect 10+ hooks, look for patterns. Write them here.]

- 
- 

---

## Hooks I've Studied (from other creators)

| Hook | Creator | What I'd Steal |
|------|---------|---------------|
| | | |

---

## AI Notes

[Claude adds context here — never above this line]
