---
tags: [content, performance, what-works]
updated: 
---

# What Works

Every time a post, video, or hook over-performs — log it here. Claude uses this file to pattern-match your best content when generating new ideas.

**Over-perform = anything that beats your average by 2x or more in views, engagement, or replies.**

---

## Hooks That Landed

| Hook | Platform | Why It Worked | Date |
|------|----------|---------------|------|
| | | | |

---

## Formats That Over-Perform

| Format | Platform | Notes |
|--------|----------|-------|
| | | |

---

## Topics That Drive the Most Engagement

| Topic | Notes |
|-------|-------|
| | |

---

## Best-Performing Pieces (Links or Titles)

| Title / Description | Platform | Result | Date |
|--------------------|----------|--------|------|
| | | | |

---

## Patterns I've Noticed

[Write down observations over time — what's your audience responding to? What falls flat? What surprises you?]

---

## AI Notes

[Claude adds context here — never above this line]
