---
tags: [ingestion, log]
updated: 
---

# Ingestion Log

Track every raw file that's been processed here. Before running `/digest`, Claude checks this file to avoid processing the same content twice.

---

## Processed

| Date | File | Source Type | Routed To |
|------|------|-------------|-----------|
| — | — | — | — |

---

## Notes

Add any processing notes, edge cases, or decisions here.
