# [YOUR NAME]'s Brain — Vault CLAUDE.md

This is the persistent memory and operating context for all AI agents working in this vault.

---

## The Mission — Non-Negotiable Filter for All Content

**[YOUR ONE-LINE MISSION: e.g. "I help coaches build a profitable personal brand with AI."]**

Every YouTube video, LinkedIn post, newsletter, short-form clip, and content idea must connect to this. If it doesn't, it belongs somewhere else — not on the public channel.

The outcome ladder every piece of content should drive toward:
- Grow their audience
- Get more traffic to their offer
- Convert that traffic
- Make more money and more sales

**The channel authority is [YOUR TOPIC/NICHE].** Content that drifts from this loses the audience and the algorithm.

---

## Who I Am

- Name: [YOUR NAME]
- I run [YOUR COMMUNITY/PRODUCT NAME]: [PRICE/MODEL] — [ONE LINE DESCRIPTION]
- I create [CONTENT TYPES: e.g. YouTube content, LinkedIn posts, short-form]
- Primary goal: help [YOUR AUDIENCE] achieve [THEIR OUTCOME]

---

## My Audience

- **Who they are:** [DESCRIBE YOUR ICP IN 1-2 SENTENCES]
- **What they want:** [THEIR DESIRED OUTCOME]
- **What they're afraid of:** [THEIR BIGGEST FEAR OR FRUSTRATION]
- **Language they use:** [PHRASES THEY ACTUALLY SAY — fill this in over time]

---

## Vault Structure

- `raw/` — unprocessed inputs: transcripts, exports, PDFs. Never edit these.
- `01-Me/` — offer, brand voice, story, positioning
- `02-Audience/` — ICP profiles, proof bank, pain points, real client language
- `03-Product/` — course, community, coaching program, or service details
- `04-Coaching/` — call transcripts and distilled insight notes
- `05-Content/` — hooks, what-works data, post log, video archive
- `06-AI/` — templates, commands, skills

---

## Rules

- Human-written content in `01-Me` through `05-Content` is sacred. Never rewrite my voice. Add notes in a separate `## AI Notes` section at the bottom of any file.
- `raw/` files are read-only. Parse and distill them into the appropriate folder — never edit the source.
- When you create or update a note, add or update YAML frontmatter: `tags`, `source`, `updated`.
- Default to Markdown with wiki-links `[[note-name]]` for cross-referencing.
- When asked a question that requires searching the vault, search broadly before answering.
- Always check `ingestion-log.md` before processing raw files to avoid duplicates.

---

## Intelligence Flow

```
raw/ content → /digest
                    ↓
     04-Coaching/coaching-intelligence.md
     05-Content/what-works.md
     05-Content/hook-swipe-file.md (if hooks found)
     02-Audience/icp-profile.md (if new audience language found)
     02-Audience/proof-bank.md (if wins or results found)
                    ↓
     01-Me/offer.md (review manually after each digest)
```

## Content Rules

### Every Piece Needs an Anchor

Every content output must include either:
- A **proof point** — a member result, testimonial, or documented outcome from `[[proof-bank]]`
- A **personal story** — your own build, experiment, or result from `01-Me/`

Pure educational content without one of these is not complete.

### Before Writing Content

1. Read `[[proof-bank]]` — pick an anchor first
2. Check `[[post-log]]` — make sure this anchor hasn't been used recently
3. Check `[[hook-swipe-file]]` — match a hook pattern that works for your audience

---

## My Offer

[PASTE YOUR OFFER DETAILS HERE — or leave blank and fill in after completing offer.md]
