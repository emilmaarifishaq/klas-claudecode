---
tags: [brand-voice, writing]
updated: 
---

# Brand Voice

## How I Sound

[Describe your voice in 3-5 adjectives. e.g. "Direct, conversational, no fluff, slightly irreverent, practitioner not professor."]

---

## Sentence Patterns I Use

[List 3-5 sentence patterns or structures that feel like you. Examples:
- Short declarative sentences. Then a longer one that explains why.
- Questions that call out a belief. Then I flip it.
- "Here's what nobody tells you about X."]

---

## What to Avoid

- [e.g. Never use "leverage" or "synergy"]
- [e.g. Don't open with "In today's..."]
- [e.g. No bullet-point lists for social posts — I write in paragraphs]
- [e.g. Don't hedge — I make direct claims]

---

## My Opening Pattern

[Describe how you typically open content. e.g. "I usually lead with a counterintuitive claim or a specific situation my audience is stuck in — not a question, not a statistic."]

---

## Topics I Own

[List 5-10 topics you have a strong, specific POV on. These are the ideas you come back to over and over.]

1. 
2. 
3. 
4. 
5. 

---

## Sample Lines (Write These Yourself)

[Paste 3-5 lines you've written that feel exactly like you. Claude uses these as calibration.]

---

## AI Notes

[Claude adds context here — never above this line]
