---
tags: [offer, positioning]
updated: 
---

# My Offer

## The One-Line Version

[Write a single sentence: I help [WHO] achieve [OUTCOME] with [METHOD].]

---

## The Full Promise

**Who it's for:**
[Describe your ideal buyer in 2-3 sentences. Be specific — name the situation they're in right now.]

**What they get:**
[List the tangible deliverables or access they receive.]

**What changes for them:**
[Describe the transformation — what does their life/business look like after?]

---

## The Offer

**Name:** [Product/community name]

**Price:** [Price point]

**Format:** [e.g. monthly community, 1:1 coaching, course, etc.]

**What's included:**
- 
- 
- 

---

## What It's Not

[Clarify who this is NOT for — this makes the positioning sharper and pre-qualifies buyers.]

---

## The Guarantee / Commitment

[What do you promise if they show up and do the work?]

---

## AI Notes

[Claude adds context here — never above this line]
