# 01-Me

Everything about you — your offer, your voice, your story, your positioning.

Claude reads these files to understand who you are before writing anything on your behalf.

**Start with:**
- `offer.md` — what you sell, who it's for, what they get
- `brand-voice.md` — how you sound, what to avoid, sentence patterns

**Rule:** This is your voice. Claude never rewrites it — only adds notes below the line.
