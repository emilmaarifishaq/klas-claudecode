---
tags: [content, idea]
platform: 
status: idea
updated: 
---

# [CONTENT TITLE OR WORKING TITLE]

## The Angle

[One sentence: what's the specific take or claim this piece makes?]

## Hook

[Write the opening line or hook]

## Why This Will Work

[Connect it to your what-works.md — what pattern does this follow?]

## Outline

1. 
2. 
3. 

## CTA

[What do you want the viewer/reader to do after consuming this?]

## Notes

