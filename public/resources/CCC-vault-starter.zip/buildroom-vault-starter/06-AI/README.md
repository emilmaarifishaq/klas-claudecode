# 06-AI

Templates and skills that power the vault's AI workflows.

- `templates/` — note templates for creating new entries consistently
- `../.claude/skills/digest/` — the `/digest` skill Claude runs to process raw content

You don't need to edit anything in here to get started. It just works.
