# 03-Product

Everything about what you sell — your course, community, coaching program, or service.

This folder helps Claude understand your offer deeply so it can write content that converts, suggest curriculum improvements, and prep you for sales conversations.

**Start with:**
- `product.md` — your offer details, pricing, promise, and delivery model

**Build over time:** add modules, member results, FAQs, and objection-handling as you learn what your audience asks most.
