---
tags: [product, offer, curriculum]
updated: 
---

# My Product — [Product Name]

---

## The One-Line Promise

[What do you help people achieve, and how fast? e.g. "I help coaches get their first 5 clients in 90 days using a simple content system."]

---

## What It Is

**Type:** [Community / Course / Coaching / Service / Digital Product]
**Price:** 
**Model:** [One-time / Monthly / Annual / Done-for-you]
**Who it's for:** [One sentence — your ICP]

---

## What's Inside

[List the main modules, phases, or deliverables. Don't overthink it — bullet points are fine.]

- 
- 
- 
- 

---

## The Transformation

**Before:** [Where is the customer when they buy?]
**After:** [Where are they 30/60/90 days later?]

---

## Why It Works

[What makes your approach different from everything else out there? This is your mechanism.]

---

## Common Objections

| Objection | Response |
|-----------|----------|
| "I don't have time" | |
| "I've tried this before" | |
| "Is this for me?" | |

---

## Member Wins

[Paste results, testimonials, or outcomes here as you collect them. Claude will pull from these for content.]

---

## AI Notes

[Claude adds context here — never above this line]
