# /digest

Process all unprocessed files in `raw/` and route insights to the correct vault folders.

## Steps

1. Read `ingestion-log.md` to identify what's already been processed
2. List all files in `raw/` — skip anything already in the log
3. For each unprocessed file:
   - Read the full content
   - Identify the source type: coaching call, interview, notes, transcript, PDF, etc.
   - Extract insights based on type:
     - **Coaching/call content** → extract recurring questions, client language, warning patterns, teaching moments → append to `04-Coaching/coaching-intelligence.md`
     - **Content performance data** → extract hooks, formats, topics that worked → append to `03-Content/what-works.md`
     - **Audience language** → extract verbatim phrases, pain points, desires → append to `02-Audience/icp-profile.md` under Real Language
     - **Offer/positioning feedback** → flag for manual review → add to `01-Me/offer.md` under AI Notes
   - Add a row to `ingestion-log.md` with: date, filename, source type, where it was routed
4. Report back a summary: X files processed, what was extracted, what was added where

## Rules

- Never edit files in `raw/` — read only
- Never delete files from `raw/` after processing
- Append to existing files — never overwrite
- Add new entries under the correct section headers
- If a file is ambiguous, ask before routing
- Keep extracted insights concise — distill, don't paste raw content
