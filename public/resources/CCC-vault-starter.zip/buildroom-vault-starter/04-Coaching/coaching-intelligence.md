---
tags: [coaching, intelligence, patterns]
updated: 
---

# Coaching Intelligence

Distilled from calls, DMs, and client conversations. Raw transcripts live in `raw/` — this file contains only what's worth keeping.

---

## Recurring Questions

Questions that come up on multiple calls — these are content goldmines.

| Question | How Often | Notes |
|----------|-----------|-------|
| | | |

---

## Real Client Language

Exact phrases clients use. Verbatim. Don't paraphrase.

- "..."
- "..."
- "..."

---

## Warning Patterns

Signs a client is about to struggle, quit, or go off track.

| Pattern | What It Usually Means | What Helps |
|---------|----------------------|------------|
| | | |

---

## Teaching Moments

Moments where a reframe or explanation visibly clicked for someone. Document the insight, not the story.

| The Insight | Context |
|-------------|---------|
| | |

---

## Offers / Upsells That Came Up Naturally

Moments where clients asked for something you don't currently offer — signals for future products.

| Request | How Often |
|---------|-----------|
| | |

---

## AI Notes

[Claude adds context here — never above this line]
