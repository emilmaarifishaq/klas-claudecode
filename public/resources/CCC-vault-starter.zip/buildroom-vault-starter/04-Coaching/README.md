# 04-Coaching

Distilled insights from coaching calls, DMs, and client conversations.

Raw transcripts go in `raw/` — not here. This folder contains only the distilled intelligence extracted from those transcripts.

**Start with:**
- `coaching-intelligence.md` — patterns, recurring questions, warning signs, teaching moments

**How it works:** drop a transcript in `raw/`, run `/digest`, and Claude extracts the relevant insights into this folder automatically.
