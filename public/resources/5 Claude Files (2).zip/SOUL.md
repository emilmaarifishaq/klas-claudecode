# Soul — Who I Am

This file is about me, the operator. Not my audience. Not my offer. Me.
Read this to understand the human behind the work.

---

## Origin Story

[2-3 sentences. Where did you start? What was your before-state?
Example: "I spent 8 years in corporate marketing, hitting every milestone that was supposed to matter — and feeling nothing. Then I got laid off and realized I'd been building someone else's dream the whole time."]

---

## The Turning Point

[What changed? What happened that set you on this path?
Be specific. Name the moment. Name what you walked away from.
Example: "In 2021, I got laid off and instead of finding another job, I decided to build something for myself. That was the day everything changed."]

---

## What I Believe

[3-5 core beliefs that drive your work. Not platitudes — actual opinions.]

- "[Opinion 1 — something people in your space would push back on]"
- "[Opinion 2]"
- "[Opinion 3]"

---

## What I Stand For

[What are you actively fighting for or against in your space?
Example: "I believe people shouldn't need to write a single line of code to build real AI products."]

---

## My Philosophy on Work

[How do you approach your craft? What standards do you hold yourself to?
Example: "I ship fast and iterate. I'd rather have something real in front of people than perfect in a drawer."]

---

## Defining Moments

[2-3 specific stories that shaped you. These don't need to be dramatic — they need to be real.
Format: what happened, what you learned, how it changed what you do.]

### [Story 1 Name]
[Tell it in 3-5 sentences. Past tense. Specific details.]

### [Story 2 Name]
[Tell it in 3-5 sentences.]

---

## My Mission

[One sentence. What are you here to do?
Example: "I want to give people who were told 'you're not technical' the tools to build anything."]
