# Duncan Rogoff — Audience

## Who They Are

Creators, coaches, and freelancers who have real skills and some track record — but are stuck doing everything manually. They're not beginners. They've tried things. They've bought courses. They're frustrated because the information is everywhere and none of it adds up to a system that actually runs without them.

They're building on LinkedIn, YouTube, or Instagram. They have clients or a small following. They're making some money. But they feel like a one-person circus: creating content, chasing leads, running operations, and still trading every hour for every dollar.

They don't want to hire. They want to build something that scales without them — a one-person business with the leverage of a team.

---

## Their Core Problem

They know AI is the answer. They feel the urgency. But the landscape is noise — too many tools, too many gurus, nothing that shows them how to actually wire it into their business.

> "The most common mistake is buying too many tools simultaneously without mastering any single platform. This creates confusion rather than productivity." — Entrepreneurloop.com

> "I cancelled about 6 things in one go and literally nothing changed about my workflow. That's when you know you've been paying for peace of mind, not productivity." — r/Entrepreneur

They're not looking for more information. They're looking for the system.

---

## Pain Points (What They Complain About Daily)

> "I swear freelancing sometimes feels like I'm stuck in Groundhog Day. Every morning it's the same thing: open X, log into Y, check Z, send..." — r/Solopreneur

> "The problem with being a solopreneur is that you have to do everything yourself... The mental toll it takes is overwhelming." — r/smallbusiness

> "Solopreneurs are stuck doing cold outreach, chasing clients, and running on the content treadmill." — LinkedIn

> "Growing on social media takes too much time, too many tools." — solopreneur tool marketing (verbatim ICP language)

> "Switching between people and responsibilities nonstop. It's sneaky burnout because it doesn't feel dramatic, it just slowly fills up your..." — r/Solopreneur

**The phrases that repeat:**
- "content treadmill"
- "wearing all the hats"
- "doing everything myself"
- "spinning too many plates"
- "shiny object syndrome"
- "too many tools, no clear system"

---

## Fears (What Holds Them Back)

> "Scared to spend money on myself. Scared to get my hopes up. So I kept waiting until I felt 'ready.'" — Facebook community post

> "The risk is the course doesn't deliver... or it's just another waste of money and it set me back." — r/alexhormozi

> "Especially with the AI rush and information overload coming in, it feels like every second someone is hitting bigger milestones meanwhile I am..." — r/SaaS

> "Course creators and coaches make it look easy." — r/Entrepreneur

> "I've been burned before." / "Sounds too good to be true." / "I don't want to get my hopes up." — recurring across platforms

**The skepticism is real.** They've paid for communities that were ghost towns. Courses with promised content that never came. They won't buy on hype — they buy on proof and specificity.

---

## Dreams and Goals (What Success Looks Like)

> "Unlike coaching or consulting where you're trading time for money, courses give you the freedom to scale without being physically present." — r/systeme_io

> "No matter how much I earned, I was still trading time for money. So I quit freelancing. Now I'm focused on building a business that gives me..." — Instagram creator

> "I just want to work on my business, not in it." — recurring phrase across sources

> "Build a scalable one-person business in 2026. AI tools, automation platforms, and no-code builders replacing entire teams." — PrometAI blog (reflects their aspiration verbatim)

> "I want to make money while I sleep." / "I want my time back." / "I want to build something that doesn't require me to show up every day." — recurring across platforms

**The emotional core:** They don't want passive income for its own sake. They want to stop feeling like a hamster on a wheel. The transformation is time freedom, not income alone.

---

## Exact Language to Use (Repeat This Back to Them)

**Time-money trap:**
- "trading time for money"
- "I hit a ceiling"
- "the more I work, the more I make — but I can't work more"
- "feast or famine"

**AI overwhelm:**
- "I don't know where to start"
- "I've tried ChatGPT but the results are generic"
- "too many tools"
- "there's no clear way to use them"

**Scale aspiration:**
- "one-person business"
- "scale without hiring"
- "work from anywhere"
- "make money while I sleep"
- "replace my income"

**System desire:**
- "I want to stop doing everything manually"
- "I need a system, not more content"
- "I want it to run without me"

---

## Language to Avoid

- "passive income" (overused, triggers skepticism)
- "6 figures" without specifics (sounds like a guru claim)
- "just follow these 5 steps" (too formulaic — they've seen this before)
- "AI will do it for you" (too vague — they want to see the actual system)

---

## What They Need to See Before They Buy

1. **Proof with numbers** — not "I grew a following," but "200K+ following and $250K+ in revenue at $5/day in AI costs"
2. **The system shown, not just described** — a dashboard, a workflow, a screenshot of the thing running
3. **A real person building in public** — they want to trust that you're doing what you're teaching
4. **Community that's alive** — not a ghost town; proof that other people are building and winning inside

---

## Where They Hang Out

- LinkedIn (primary — this is where they're building)
- YouTube (where they research tools and workflows)
- Reddit: r/Solopreneur, r/Entrepreneur, r/ChatGPT, r/freelance, r/DigitalMarketing
- Instagram (especially for creator-adjacent audiences)
