# NOVA STUDIO_ Design System

**Version:** 1.0  
**Last Updated:** 2026  
**Category:** Editorial / Brutalist / High-Impact Social

---

## 01. Brand Philosophy

This system is built around three principles:

- **Compression over decoration.** Every element earns its place.
- **Contrast as communication.** Black/white photography + neon accent = immediate hierarchy.
- **System thinking.** Components that scale across formats without losing identity.

The visual language is editorial brutalism — high contrast, monospaced notation, condensed display typography, and controlled use of neon acid yellow and hot pink as signal colors.

---

## 02. Color Palette

| Token             | Hex       | RGB                | Usage                                       |
|-------------------|-----------|--------------------|---------------------------------------------|
| `--ink`           | `#0D0D0D` | rgb(13, 13, 13)    | Primary background, body text on light      |
| `--paper`         | `#FFFFFF` | rgb(255, 255, 255) | Secondary background, body text on dark     |
| `--acid`          | `#CCFF00` | rgb(204, 255, 0)   | Primary accent — headlines, highlight blocks, CTAs |
| `--hot`           | `#FF1F6E` | rgb(255, 31, 110)  | Secondary accent — inline emphasis, live indicators |
| `--smoke`         | `#F2F2F2` | rgb(242, 242, 242) | Card backgrounds, secondary surface         |
| `--ash`           | `#999999` | rgb(153, 153, 153) | Muted labels, metadata, secondary text      |

### Color Rules

- `--ink` background is the default. Assume black unless there's a reason not to.
- `--acid` is a signal color. Use it for the single most important element per composition.
- `--hot` is reserved for live states, key emphasis words inline, and active indicators.
- Never use `--acid` and `--hot` together at equal weight. One leads, one supports.
- White backgrounds are for service/content cards only — never hero or statement pieces.

---

## 03. Typography

### Typefaces

| Role          | Family              | Weight       | Style    |
|---------------|---------------------|--------------|----------|
| Display       | Barlow Condensed    | 800–900      | Uppercase |
| Label / Tag   | Space Mono          | 400–700      | Lowercase `//prefix` |
| Body          | DM Sans             | 400–500      | Sentence case |

### Type Scale

| Token         | Size       | Line Height | Usage                           |
|---------------|------------|-------------|---------------------------------|
| `--t-hero`    | 88–120px   | 0.9         | Card-filling statements         |
| `--t-xl`      | 56–72px    | 0.95        | Section headlines               |
| `--t-lg`      | 36–48px    | 1.0         | Card titles, sub-headlines      |
| `--t-md`      | 20–24px    | 1.1         | Callouts, emphasized labels     |
| `--t-sm`      | 13–16px    | 1.4         | Body copy, descriptions         |
| `--t-xs`      | 10–12px    | 1.5         | Metadata, footer labels         |

### Typography Rules

- **All display text is uppercase.** No exceptions.
- **Display font uses tracking of -0.02em or tighter.** Condensed width + tight tracking.
- **Labels use the `//` prefix convention.** e.g. `//creative agency`, `//meet the founder`
- **Bracket notation for metadata.** e.g. `[OUR SERVICES]`, `[CLIENT LOVE 001]`, `[LIVE]`
- **Brand name always ends in underscore.** `NOVA STUDIO_`
- **Body copy is never bold.** Use size and color contrast to create hierarchy instead.

---

## 04. Iconography & Notation

### System Symbols

| Symbol | Usage                                      |
|--------|--------------------------------------------|
| `//`   | Category/section label prefix              |
| `[ ]`  | Metadata bracket — type, number, state     |
| `_`    | Brand name suffix                          |
| `→`    | Internal navigation / CTA                  |
| `↗`    | External link / URL                        |
| `✦`    | Decorative sparkle — hero cards            |
| `+`    | Bullet list marker — features/services     |
| `●`    | Live indicator (typically in `--hot`)      |
| `"`    | Quote marks — oversized, accent colored    |

### Notation Patterns

```
//section-label          [METADATA TAG]
HEADLINE TEXT
CONTINUES HERE_

//strategy //design //development    BRAND NAME_
```

---

## 05. Spacing & Layout

### Base Grid

- **Card format:** 1080×1080px (1:1 for social)
- **Base unit:** 8px
- **Card padding:** 40–48px on all sides
- **Grid gap:** 4–8px between cards in feeds

### Spacing Scale

| Token      | Value  |
|------------|--------|
| `--s-1`    | 4px    |
| `--s-2`    | 8px    |
| `--s-3`    | 16px   |
| `--s-4`    | 24px   |
| `--s-5`    | 40px   |
| `--s-6`    | 64px   |
| `--s-7`    | 96px   |

### Layout Patterns

1. **Split card** — photo left/right, text opposite
2. **Full-bleed text** — headline fills entire card, no image
3. **Photo under text** — label + headline stacked above photo
4. **Highlight block** — word or phrase wrapped in `--acid` background
5. **Ticker strip** — horizontal scrolling tag across card diagonal

---

## 06. Components

### 06.1 Hero Card

Used for brand identity and opening statements.

**Structure:**
```
//CATEGORY LABEL         [top-left]
LARGE DISPLAY
HEADLINE TEXT_           [center-dominant]

+ feature one
+ feature two
+ feature three          [bottom-left bullets]

TAGLINE IN SMALL CAPS    [bottom]
```

**Rules:**
- Background: `--ink`
- Headline: `--paper`, Barlow Condensed 900
- Category label: `--paper`, Space Mono, small
- Photo: Black and white, positioned right or full-bleed with overlay

---

### 06.2 Statement Card

Single powerful sentence. No photos.

**Variants:**
- Black bg + white text + `--acid` highlight block on key word
- `--acid` bg + `--ink` text (maximum contrast)
- White bg + `--ink` text + `--acid` highlight

**Rules:**
- Headline fills 80%+ of card
- One word or phrase per card gets the highlight treatment
- Optional: `//REMINDER` or category tag top-left

---

### 06.3 Founder / About Card

Personal narrative card.

**Structure:**
```
//MEET THE FOUNDER      [top-left]
MY
[WORD]                  [large, with --acid highlight on key word]

[portrait photo, full height right side]

Body copy paragraph     [bottom-left]
CTA BUTTON →           [bottom]
```

---

### 06.4 Countdown / Teaser Card

Pre-launch announcement.

**Structure:**
```
NEW
WEBSITE.               [large, --acid on "WEBSITE"]

COMING SOON + COMING SOON + [ticker strip, diagonal or horizontal]

[laptop/device mockup]

D  |  HH  |  MM       [countdown blocks]
```

**Rules:**
- Background: `--paper` or `--ink`
- Numbers in large monospaced type
- Ticker uses `--acid` background strip

---

### 06.5 Live Announcement Card

**Structure:**
```
BRAND NAME_    (LIVE) ●    [top bar]
WE'RE [LIVE.]              [headline, LIVE in --hot block]
WWW.DOMAIN.ORG ↗          [URL, monospaced]

CHECK OUR NEW WEBSITE →    [bottom ticker]
```

**Rules:**
- `●` indicator always in `--hot`
- `LIVE` word wrapped in `--hot` background block
- Domain in Space Mono

---

### 06.6 Service Card

Light background variant.

**Structure:**
```
BRAND_          [OUR SERVICES]    [top bar]
//SERV.02

SERVICE
NAME            [large, dark on white]

Body description text, 2–3 sentences.

[supporting image grid, 2–4 images]
```

**Rules:**
- Background: `--smoke` or `--paper`
- Numbered service slug: `//SERV.01`, `//SERV.02`
- Images are lifestyle/fashion, full color here (exception to B&W rule)

---

### 06.7 Testimonial Card

Social proof component.

**Structure:**
```
// REVIEW        [CLIENT LOVE 001]

[circular avatar, small]

"THE QUOTE IN ALL CAPS,
WITH A KEY PHRASE IN
--acid HIGHLIGHT"

★★★★★
NAME, TITLE.
COMPANY
```

**Rules:**
- Background: `--ink`
- Oversized opening quote mark in `--acid`
- Star rating always 5-star, displayed as unicode ★★★★★
- Client name in Space Mono small caps

---

### 06.8 Case Study Card

Transformation narrative.

**Structure:**
```
// CASE STUDY    [BRAND NAME]     [top bar]

[B&W portrait photo]

THE INSANE                        [small label]
TRANSFORMATION OF
BRAND
NAME                              [large, acid highlight on name]

//strategy //design //development →  [bottom]
```

---

### 06.9 Podcast / Episode Card

Content promotion.

**Structure:**
```
NEW EPISODE
NEW EPISODE                       [repeating headline, fills card]
NEW EPISODE

[photo]

[audio player bar]
HOW WE [DID X] IN [TIME]

NEW EPISODE [continues repeating]
```

**Rules:**
- Background: `--ink`
- Repeating text creates texture — not a glitch, a pattern
- Audio bar mimics native player: time stamps, play button

---

### 06.10 CTA Card

Closing card / contact prompt.

**Structure:**
```
//LET'S BUILD    HELLO@DOMAIN.ORG   [top bar]

GOT A PROJECT ON THE DESK?         [small, --paper]

START A
BRIEF.                             [massive, --acid]

[supporting image]

LET'S WORK TOGETHER →             [bottom CTA]
```

---

## 07. Photography & Imagery

### Style
- **Default:** Black and white, high contrast
- **Exceptions:** Color used sparingly in service cards and lifestyle grid imagery
- **Subject:** Founder, clients, lifestyle — always human-centered
- **Device mockups:** Laptops, phones used in new website / service context

### Framing Rules
- Portraits: Medium-tight, subject confident, direct or off-camera gaze
- Full-bleed photos always have text overlay — never decorative-only
- Photos never compete with type. If the photo is strong, the type steps back (and vice versa).

---

## 08. Motion & Animation

### Principles
- Animations should feel like a **print piece coming to life**, not a web app.
- Entrances are fast (200–400ms). Exits are instant.
- Use **stagger** on list items and card sequences.

### Patterns

| Animation      | Duration | Easing          | Usage                     |
|----------------|----------|-----------------|---------------------------|
| Slide up fade  | 300ms    | ease-out        | Card entrance             |
| Ticker scroll  | 12–20s   | linear, loop    | Coming soon / live strips |
| Counter tick   | 1000ms   | steps(1)        | Countdown numbers         |
| Highlight pulse| 600ms    | ease-in-out     | `--hot` live indicator    |
| Scale in       | 250ms    | cubic-bezier    | CTA hover state           |

---

## 09. Voice & Copy

### Headline Rules
- **Compression first.** Never say in four words what you can say in two.
- **All uppercase.** No exceptions in display context.
- **End with a period.** Statement cards always end with a full stop — it adds weight.
- **No filler adjectives.** "POWERFUL DIGITAL SYSTEM" only if the quote says it. Otherwise cut.

### Label / Tag Rules
- `//` labels are always lowercase
- `[BRACKET METADATA]` is always uppercase
- URLs in body text: lowercase, Space Mono, no `https://`

### Sample Copy Patterns
```
SYSTEM BUILT. BRAND ELEVATED.
YOUR WEBSITE IS YOUR SYSTEM. MAKE IT WORK FOR YOU.
GOT A PROJECT ON THE DESK? START A BRIEF.
WE REBUILT A BRAND IN TWO WEEKS.
```

---

## 10. Don'ts

- Never use gradients (except as photo overlay scrims)
- Never use rounded corners on text highlight blocks — all edges are sharp
- Never use more than two accent colors per card
- Never center-align body copy
- Never use more than three typeface weights per card
- Never use `--acid` as a text color on `--paper` backgrounds (low contrast)
- Never use decorative illustration — this system is type-first, photo-second
- Never use the brand name without the underscore: ~~NOVA STUDIO~~ → `NOVA STUDIO_`
