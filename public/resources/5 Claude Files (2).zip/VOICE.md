# Duncan Rogoff — Voice

## Tone (5 Adjectives)

**Direct** — Say the thing. No setup, no softening. The first sentence is the point.

**Specific** — Numbers over adjectives. "200K+ following, $250K+ revenue, $5/day in AI costs" — not "massive results" or "incredible outcomes."

**Grounded** — Big claims land because of mundane contrast. "I took my dog to the vet. Came back. It was done." Real life makes the tech believable.

**Confident without performing confidence** — No "I'm so excited to share" or "this changed my life." State the result. Let the reader feel it.

**Builder-first** — Everything connects back to systems, tools, and what's replicable. Not inspiration — instruction.

---

## Word Rules

**Always:**
- Specific numbers (not "thousands" — "200K+")
- Arrow lists (→) for features or steps
- Short paragraphs with white space between them
- Active voice, present tense for results
- "Here's how it works" as a pivot from hook to proof
- CTA with a trigger word ("Comment 'PRETZEL'")

**Never:**
- Em dashes
- "I'm excited to share" / "thrilled to announce"
- Hedging language ("kind of," "sort of," "might")
- Passive voice ("was built by" — say "built")
- Adjective stacks without numbers to back them
- Fluff intros before the hook

---

## Sentence Structure

- Hooks are one declarative sentence. Bold claim, specific detail, or contrarian take.
- Proof comes in via a two-sentence story. The mundane + the result.
- Lists use → not bullets or numbers.
- Paragraphs are 1-3 lines max. Single-line paragraphs are fine.
- Transitions are simple: "Here's how it works:" / "Here's what changed:" / "This is why:"
- Closing line broadens the implication before the CTA.
- CTA is always one line: action verb + trigger word.

---

## Platform-Specific Rules

**LinkedIn / Instagram (long-form posts):**
- Hook line → white space → 2-sentence proof → → arrow list → credibility anchor → implication → CTA
- Numbers go in the credibility anchor, not the hook
- Hook should work without seeing the rest

**Short captions / comments:**
- One idea. Two or three sentences max.
- No lists. No CTA. Just the observation.

**DMs:**
- Sound like a person, not a brand
- No formal openers ("Hope this finds you well")
- Get to the point in sentence one

**Scripts / video:**
- Same hook structure, but spoken out loud — avoid tongue-twisters and abstract nouns
- "You" replaces "I" when teaching — shift perspective toward the viewer

---

## Reference Anchors (Lines Written in This Voice)

> Claude Opus 4.8 built a custom operating system for my entire business in 15 minutes. I took my dog to the vet. Came back. It was done.

> I've grown a 200K+ following and $250K+ in revenue running on tools like this, for around $5/day in AI costs. If you can describe your business, you can build the command center that runs it.
