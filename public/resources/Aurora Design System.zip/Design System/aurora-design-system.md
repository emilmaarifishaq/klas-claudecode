# Aurora — Design System

> A design language for the luminous web. Dark, atmospheric, editorial. Built around volumetric color and the soft physics of light.

**Version:** 1.0 · 2026
**Aesthetic:** Dark-mode, gradient-rich, editorial-tech
**Influence:** Print editorial, ambient cinematography, gradient mesh design

---

## 1. Design Principles

Aurora is defined by what it refuses to do. No flat backgrounds. No corporate gradients on white. No timid spacing. Every surface should feel like it's holding light.

### i. Light is the subject
Color exists as luminous, blurred volumes — never as flat fills. Every page has at least one source of soft, atmospheric glow that gives the composition depth.

### ii. The void carries weight
Dark is not absence — it's a material with grain, texture, and presence. Backgrounds should feel deep, almost dimensional, never simply "black."

### iii. Type is restrained, then released
Wide-tracked uppercase sans for structure. A characterful serif for moments of voice. The contrast between the two carries the editorial tension of the system.

### iv. Motion is atmospheric, not decorative
Things drift, breathe, and settle. Animation reinforces the sense of light moving through space — never the sense of a UI demanding attention.

---

## 2. Color

### 2.1 Voids (base palette)

The base palette is a sequence of near-blacks. Use them as canvases for color, never as color themselves. Always pair lighter voids with brighter aurora moments.

| Token | Hex | Use |
|---|---|---|
| `--void-900` | `#04060D` | Page background, deepest surfaces |
| `--void-800` | `#070A14` | Primary card / panel background |
| `--void-700` | `#0B0F1C` | Elevated surface, inputs |
| `--void-600` | `#121728` | Hover, secondary surface |
| `--void-500` | `#1A2038` | Borders on darker surfaces, top layer |

### 2.2 Aurora families (chromatic light)

Aurora colors are **never used as solids**. They live as gradients, glows, and atmospheric washes. Each family sits in a different region of the spectrum. Use with restraint — usually one family per composition.

| Family | Start | End | Mood |
|---|---|---|---|
| **Magenta · Rose** | `#D3308A` | `#B8265F` | Heat, urgency, premium |
| **Violet · Indigo** | `#7A3FC4` | `#4A4ED6` | Depth, vision, the unknown |
| **Azure · Cyan** | `#2D7FFF` | `#38C7FF` | Trust, technology, clarity |
| **Teal · Emerald** | `#14B89A` | `#1FA974` | Growth, calm, the organic |

### 2.3 Text on dark

| Token | Value | Use |
|---|---|---|
| `--text-primary` | `#F4F5FA` | Headlines, important UI |
| `--text-secondary` | `rgba(244,245,250,0.72)` | Body copy |
| `--text-tertiary` | `rgba(244,245,250,0.48)` | Captions, meta |
| `--text-quaternary` | `rgba(244,245,250,0.28)` | Disabled, watermarks |
| `--hairline` | `rgba(244,245,250,0.08)` | Default dividers |
| `--hairline-strong` | `rgba(244,245,250,0.18)` | Emphasized borders |

### 2.4 Signature gradients

Four named compositions — radial gradients of overlapping blurred orbs. These are the system's hero surfaces.

```css
--grad-cosmos:  radial-gradient(ellipse at 20% 30%, #D3308A 0%, transparent 45%),
                radial-gradient(ellipse at 70% 60%, #4A4ED6 0%, transparent 50%),
                radial-gradient(ellipse at 40% 90%, #7A3FC4 0%, transparent 55%);

--grad-deepsea: radial-gradient(ellipse at 30% 40%, #2D7FFF 0%, transparent 50%),
                radial-gradient(ellipse at 75% 70%, #38C7FF 0%, transparent 40%),
                radial-gradient(ellipse at 50% 20%, #4A4ED6 0%, transparent 55%);

--grad-forest:  radial-gradient(ellipse at 60% 40%, #14B89A 0%, transparent 50%),
                radial-gradient(ellipse at 30% 70%, #1FA974 0%, transparent 45%),
                radial-gradient(ellipse at 80% 80%, #2D7FFF 0%, transparent 35%);

--grad-ember:   radial-gradient(ellipse at 25% 50%, #B8265F 0%, transparent 50%),
                radial-gradient(ellipse at 70% 30%, #D3308A 0%, transparent 45%),
                radial-gradient(ellipse at 60% 85%, #7A3FC4 0%, transparent 50%);
```

**Critical recipe:** always apply with `filter: blur(60–120px)` and `opacity: 0.3–0.6` over a dark void. The blur is what makes the gradient feel like light rather than design.

---

## 3. Typography

Two typefaces in dialogue. The contrast is the point.

### 3.1 Font stack

| Token | Family | Role |
|---|---|---|
| `--display` | **Fraunces** (variable, optical sizing) | Voice — display, italics, expressive moments |
| `--sans` | **Inter Tight** | Structure — UI, body, microcopy |
| `--mono` | **JetBrains Mono** | Meta — captions, version numbers, code |

### 3.2 Type scale

| Style | Family | Weight | Size | Tracking | Use |
|---|---|---|---|---|---|
| Display XL | Fraunces | 300 | clamp(56, 9vw, 140) | -3.5% | Hero only |
| Display LG | Fraunces | 300 | clamp(40, 5vw, 72) | -3% | Section headlines |
| Tracked Cap | Inter Tight | 300 | clamp(20, 3vw, 40) | +28% | Editorial titles (the "DIGITAL TECHNOLOGY" treatment) |
| Tracked Cap SM | Inter Tight | 400 | 11px | +32% | Labels, badges |
| Eyebrow | Inter Tight | 500 | 11px | +24% uppercase | Section numbers, meta |
| Body LG | Inter Tight | 300 | 18px / 1.55 | -0.5% | Lead paragraphs |
| Body | Inter Tight | 400 | 15px / 1.6 | normal | Default reading |
| Caption | Inter Tight | 400 | 12px / 1.5 | normal | Meta, fine print |
| Mono | JetBrains Mono | 400 | 12px | normal | Tokens, data |

### 3.3 Typography rules

- **Display copy gets italic moments** — slip a `<em>` of italic Fraunces into a hero headline. This is the system's signature.
- **Headlines may receive gradient text** via `background-clip: text` using a 120° gradient through 2–3 aurora colors. Use sparingly — once per page maximum.
- **Tracked uppercase is for editorial cadence**, not navigation. Use it the way print magazines use it — to slow a reader down, not to label a button.
- **Body weight is 300 on display, 400 on UI.** Aurora prefers a slightly lighter feel than typical web type.

---

## 4. Spacing

A 4-pixel base unit creates a steady spatial cadence. Use the larger steps generously — the system breathes when content has room to drift.

| Token | Value | Typical use |
|---|---|---|
| `--s-1` | 4px | Hairline gaps |
| `--s-2` | 8px | Inline gaps, tag padding |
| `--s-3` | 12px | Tight stacks |
| `--s-4` | 16px | Default gap |
| `--s-5` | 24px | Component internal padding |
| `--s-6` | 32px | Card padding, container gutters |
| `--s-7` | 48px | Section internal rhythm |
| `--s-8` | 64px | Major breaks |
| `--s-9` | 96px | Section-to-section |
| `--s-10` | 128px | Hero padding |

**Rule of thumb:** when in doubt, jump up a step. Aurora errs toward generosity.

---

## 5. Radii

| Token | Value | Use |
|---|---|---|
| `--r-sm` | 4px | Tight elements (rare) |
| `--r-md` | 10px | Inputs, small cards |
| `--r-lg` | 18px | Default card radius |
| `--r-xl` | 28px | Hero panels, large surfaces |
| `--r-full` | 999px | Buttons, tags, pills |

Aurora favors soft, generous radii on cards and full pills on interactive controls. Sharp corners are reserved for grid lines and dividers.

---

## 6. Components

### 6.1 Buttons

Three variants, in descending visual weight:

| Variant | Surface | When to use |
|---|---|---|
| **Primary** | Gradient (violet → azure) with chromatic shadow | One per view, the primary action |
| **Ghost** | Transparent, hairline border | Secondary actions |
| **Text** | No surface, arrow on hover | Tertiary, inline, "read more" |

All buttons use `--r-full`, 14px vertical padding, 28px horizontal, 13px medium-weight Inter Tight.

**Primary shadow recipe:**
```css
box-shadow: 0 0 0 1px rgba(255,255,255,0.1) inset,
            0 12px 40px -10px rgba(122, 63, 196, 0.6);
```
The shadow tint should match the gradient — chromatic shadows, never gray.

### 6.2 Inputs

- Background: `--void-700`
- Border: 1px `--hairline-strong`
- Focus: cyan border (`--aurora-cyan`) with a 4px outer glow at 12% opacity
- Padding: 12px / 16px
- Radius: `--r-md`

### 6.3 Tags

Pill-shaped, tinted by aurora family. Always use rgba — 10–12% background, 25% border, full-saturation text.

```css
.tag {
  background: rgba(56, 199, 255, 0.1);
  color: var(--aurora-cyan);
  border: 1px solid rgba(56, 199, 255, 0.2);
}
```

### 6.4 Cards

The card is Aurora's signature surface. Three required properties:

1. **Background:** `--void-700` or `--void-800`
2. **Border:** 1px `--hairline`
3. **Hidden glow:** a `::before` pseudo-element with a blurred radial gradient (40–80px blur), positioned in one corner, at 30–50% opacity. This is the move that makes a card feel like Aurora.

```css
.card::before {
  content: '';
  position: absolute;
  top: -50%; left: -20%;
  width: 80%; height: 80%;
  background: radial-gradient(circle, var(--aurora-violet) 0%, transparent 60%);
  filter: blur(40px);
  opacity: 0.4;
  pointer-events: none;
}
```

---

## 7. Motion

Motion in Aurora reinforces atmosphere. Never bounce, never spring aggressively. Everything drifts.

### 7.1 Easing

| Token | Value | Use |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` | Default — entrance, hover |
| `--ease-in-out` | `cubic-bezier(0.65, 0, 0.35, 1)` | Loops, drift, ambient motion |

### 7.2 Durations

- Micro (hover, focus): **300ms**
- Reveal (page load, section entry): **1100ms** with staggered `animation-delay`
- Ambient (gradient drift, background motion): **30–45s** alternate

### 7.3 Signature animations

**Drift** — apply to background gradient orbs. The hero gradient should never sit still.
```css
@keyframes drift {
  0%   { transform: translate(0, 0) scale(1); }
  50%  { transform: translate(-3%, 2%) scale(1.08); }
  100% { transform: translate(2%, -2%) scale(1.04); }
}
```

**Rise** — page entrance. Children stagger at 150ms intervals.
```css
@keyframes rise {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

---

## 8. Texture

Aurora requires a film-grain overlay on every page. This is not decoration — it's what makes the dark surfaces feel like a material rather than a void of pixels.

```css
body::after {
  content: '';
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 100;
  opacity: 0.08;
  mix-blend-mode: overlay;
  background-image: url("data:image/svg+xml,...fractalNoise...");
}
```

Use a fractal noise SVG (baseFrequency around 0.9, 3 octaves). 8% opacity, `mix-blend-mode: overlay`. The grain should be felt, not seen.

---

## 9. Composition rules

Lessons learned from the reference Instagram tiles. These are the recipes that make a layout read as Aurora.

### 9.1 One light source per surface
A composition with two competing gradient hotspots reads as chaos. Pick one focal glow, let the other colors fade to support it.

### 9.2 Type sits in the dark, not the light
Place text in the darker quadrant of the composition. The aurora glow is the atmosphere; the type is the subject. Never set body copy directly on the brightest part of a gradient.

### 9.3 Generous breathing room
Editorial layouts. Type aligned to corners (top-left, bottom-left, bottom-right). The center is usually left to the light.

### 9.4 Asymmetric weighting
Aurora compositions are rarely centered. The headline anchors to one corner, the meta to the diagonal corner, and the light pools somewhere between.

### 9.5 Restraint with the palette
**Use one aurora family per surface.** A "Magenta · Violet" composition. A "Teal · Azure" composition. Mixing all four reads as confused. Save the multi-family blends for the signature gradients only.

---

## 10. Don'ts

- ❌ **No flat color backgrounds.** Always a gradient, glow, or void with texture.
- ❌ **No solid aurora colors.** They live as gradients only.
- ❌ **No hard shadows.** Soft, large-radius, chromatic shadows only.
- ❌ **No light mode.** Aurora is a dark-mode-only system by design.
- ❌ **No generic system fonts.** Always load Fraunces + Inter Tight.
- ❌ **No tight tracking on uppercase.** Editorial caps are +24% to +32% — wider than feels natural.
- ❌ **No bouncing animation.** Drift and rise only. Springs break the atmosphere.
- ❌ **No bright white text.** Use `#F4F5FA` — slightly cool, never pure white.

---

## 11. CSS variable reference (paste-ready)

```css
:root {
  /* Voids */
  --void-900: #04060d;
  --void-800: #070a14;
  --void-700: #0b0f1c;
  --void-600: #121728;
  --void-500: #1a2038;

  /* Aurora */
  --aurora-magenta: #d3308a;
  --aurora-rose:    #b8265f;
  --aurora-violet:  #7a3fc4;
  --aurora-indigo:  #4a4ed6;
  --aurora-azure:   #2d7fff;
  --aurora-cyan:    #38c7ff;
  --aurora-teal:    #14b89a;
  --aurora-emerald: #1fa974;

  /* Text */
  --text-primary:    #f4f5fa;
  --text-secondary:  rgba(244, 245, 250, 0.72);
  --text-tertiary:   rgba(244, 245, 250, 0.48);
  --text-quaternary: rgba(244, 245, 250, 0.28);
  --hairline:        rgba(244, 245, 250, 0.08);
  --hairline-strong: rgba(244, 245, 250, 0.18);

  /* Type */
  --display: 'Fraunces', serif;
  --sans:    'Inter Tight', system-ui, sans-serif;
  --mono:    'JetBrains Mono', monospace;

  /* Spacing */
  --s-1: 4px;  --s-2: 8px;  --s-3: 12px; --s-4: 16px;
  --s-5: 24px; --s-6: 32px; --s-7: 48px; --s-8: 64px;
  --s-9: 96px; --s-10: 128px;

  /* Radii */
  --r-sm: 4px;  --r-md: 10px; --r-lg: 18px;
  --r-xl: 28px; --r-full: 999px;

  /* Motion */
  --ease-out:    cubic-bezier(0.16, 1, 0.3, 1);
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
}
```

---

*Aurora · v1.0 · 2026 · A design language for the luminous web*
