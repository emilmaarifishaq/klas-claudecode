---
name: shortify
version: "2.0"
description: "Turn ONE long-form video (timestamped transcript + screen recording) into 3 distinct short-form vertical cuts (proof / contrarian / transformation) — each with its own hook + b-roll — then write per-platform captions and schedule them across YouTube Shorts / Instagram / TikTok / Facebook (+ LinkedIn as a story lane) via Blotato. HeyGen avatar bottom, screencap top, karaoke captions, conceptual gen b-roll, Claude-brand cold open, wide-dashboard payoff."
argument-hint: 'shortify <long-form folder or transcript path>   (e.g. shortify the tutorial video)'
allowed-tools: Bash, Read, Write, Agent
user-invocable: true
---

# Shortify — long-form → short-form (produce → caption → schedule)

Wraps `~/shortform-pipeline`. ONE long-form → 3 angle cuts → per-platform captions → Blotato queue.

**Pipeline (`pipeline.py`):** scene-analyze (skip the intro, skip carousels/notes) → per angle: write script → match a b-roll cut-plan → generate riso b-roll (cached) → auto Claude cold-open → HeyGen avatar → trim pauses → composite. **Then (separate):** captions (`write_captions.txt`) → schedule (`schedule.py` → Blotato). Cut-plan format: `~/shortform-pipeline/README.md`.

## Inputs (from the argument / message, else ask)
- **transcript**: the long-form timestamped `.txt`
- **screencap**: the long-form screen recording `.mp4` (1080p)
- **angles** (default `proof,contrarian,transformation`)
- **slug** for `out/<slug>/`

## Steps

0. **Source keys:** `set -a && source ~/.claude/.env && set +a` (HeyGen + Higgsfield + Blotato).

1. **SCRIPTS FIRST — review gate.** Generate just the scripts (cheap, no render) and show the user to approve/edit BEFORE spending avatar renders:
   ```bash
   python3 ~/shortform-pipeline/pipeline.py --transcript "<t>" --screencap "<s>" \
     --out-dir ~/shortform-pipeline/out/<slug> --angles <angles> --no-compose
   ```
   Read `out/<slug>/script_<angle>.txt`. Check: the spoken hook matches a proven pattern from the hook vault (variables swapped only — if it's an invented shape, rewrite it from the vault), hook_title is 3-4 words (max 4 per line, `\n`-broken if longer), distinct angle-specific openings, concrete-number hook, NO "AI"/"AIs", result before mechanism, thought-line pauses. Fix wording before rendering.
   **Also check the cut-plans.** `--no-compose` writes `out/<slug>/cutplan_<angle>.json` per angle. Sanity-check each one before the full render: screencap-dominant, no sentence text-cards (word cards <=4 words), file-naming beats matched to the right moment. Fix before running the full pipeline.

2. **FULL RUN** — avatars + basic composite (uses HeyGen credits, ~3-5 min/angle):
   ```bash
   python3 ~/shortform-pipeline/pipeline.py --transcript "<t>" --screencap "<s>" \
     --out-dir ~/shortform-pipeline/out/<slug> --angles <angles>
   ```
   (Re-render only the composite: call `compose.py` with the avatar + cut-plan.)

3. **B-ROLL (the make-or-break step — build carefully and VERIFY).** Per angle write `out/<slug>/broll_<angle>.json`, aligning visuals beat-by-beat. The screencap of the real product (the dashboard) is the STAR — show it EARLY (right after the cold open) and cut through its panels as the script names them; reserve GEN art for the conceptual opener + the **SHARED CANONICAL SCENES verbatim** (e.g. a recurring character scene — generate ONCE, reuse across angles via the cache). A LIST line ("watch every line / approve every step / catch every mistake") gets one rapid-fire word card per item. Subagents CAN draft this but do NOT trust blindly — one once set every beat to a full-sentence word card; always sanity-check the JSON (screencap-dominant, no sentence text cards) and VERIFY the actual frames. Then apply: merge into the cut-plan, set the hook, gen with the shared cache, re-compose.

4. **CAPTIONS** — run `write_captions.py` per angle:
   ```bash
   python3 ~/shortform-pipeline/write_captions.py --out-dir ~/shortform-pipeline/out/<slug> \
     --angles <angles> --subject "<one-line description of what the long-form video is actually about>"
   ```
   The `--subject` comes from the scene analysis / transcript (NOT a generic "dashboard" assumption). This writes `captions_<angle>.json` consumed by `schedule.py`. Titles + first lines must be angle-distinct. Reads `out/<slug>/meta_<angle>.json` for `video_type` and `cta_noun` — the soft CTA adapts automatically (tutorial → "Learn to build like this..."; showcase → "Get [cta_noun] inside Claude Code Club...").

5. **SCHEDULE** — `python3 schedule.py --slug <slug> [--linkedin-angle contrarian] [--trial] [--dry-run]`. SELF-DRIVING: auto-uploads each cut (presigned PUT), reads the LIVE Blotato queue, and drops the 3 angles into the next OPEN days (>=8 days apart, rotating times 8am/1pm/5pm PT) so new videos stagger in around what's already scheduled. Per angle: 4 video channels (YouTube `<YOUR_BLOTATO_YOUTUBE_ID>`, Instagram `<YOUR_BLOTATO_INSTAGRAM_ID>` reel, TikTok `<YOUR_BLOTATO_TIKTOK_ID>` PUBLIC + isAiGenerated, Facebook page `<YOUR_BLOTATO_FACEBOOK_ID>` reel); the chosen LinkedIn angle also posts its STORY caption (`<YOUR_BLOTATO_LINKEDIN_ID>` personal, no CTA) at 11am PT. Future-dated. Run with `--dry-run` first to preview the slot plan. `--start-in-days` defaults to **1** (first short posts tomorrow). **`--trial`** posts the Instagram reel as a trial reel (shown only to non-followers; auto-graduates via SS_PERFORMANCE if it performs well). Useful for testing new angles without risking feed reach.

> **Setup:** replace the `<YOUR_BLOTATO_*_ID>` placeholders in `config.json` with your Blotato account IDs (found at blotato.com → Accounts).

6. **Verify + auto-repair.** Extract frames (hook ~2s, the conceptual opening, a mid beat, the wide ending) from each cut and review them. Then grep each compose log for `TRIGGERS_UNMATCHED`:
   - `compose.py` prints `TRIGGERS_UNMATCHED: a | b | c` (or `TRIGGERS_UNMATCHED: none`) per run.
   - For any unmatched trigger, transcribe that angle's avatar to find what Whisper actually said:
     ```bash
     ffmpeg -i out/<slug>/avatar_<angle>_trim.mp4 -vn -ar 16000 a.wav
     whisper a.wav --model base
     ```
   - Pick a plain word Whisper produced near that beat, edit the trigger in `cutplan_<angle>.json`, and re-compose that angle (see **Re-render without losing edits** below).
   - Common causes: numbers/`$10,000` → use an adjacent plain word, never a number; dotted filenames like `CLAUDE.md` → Whisper writes "claude .md"; homophones (e.g. soul→sole).

7. **Re-render without losing hand edits.** After editing a `cutplan_<angle>.json` (or `script_<angle>.txt`), re-render with:
   ```bash
   python3 ~/shortform-pipeline/pipeline.py --from-cutplan \
     --out-dir ~/shortform-pipeline/out/<slug> --angles <angle>
   ```
   `--from-cutplan` skips scene analysis, script writing, and match — it renders directly from the existing cut-plan + script. Use this instead of a full pipeline run (which would overwrite your edits via the match stage). This supersedes the older `drive_render.py` workaround.

## Rules baked into the prompts/code (do not override)
- **FORMATS (3 distinct shapes, never homogenized into one):** proof = RESULT-LED (result + number, then proof line, what, how, stakes); contrarian = BELIEF-FLIP (the wrong belief FIRST, then the result as the mic-drop PROOF *after* it — never before); transformation = BEFORE/AFTER (old-world cost, then new world + result).
- **HOOKS (the most important part):** ALWAYS instantiated from the proven hook vault (`~/your-hook-vault.md` — set the path in `config.json`) — `pipeline.py` injects it into the script prompt; keep the proven pattern's shape and swap ONLY the variables (tool, number, outcome), never invent a new hook shape; distinct per angle; an intrigue-building PAYOFF description; say "Claude Code" (or the named feature), NEVER "AI"; contrarian may be a pattern-interrupt ("STOP BUILDING WITH CLAUDE CODE"). **On-screen hook_title: 3-4 words ideal, HARD max 4 words per line — longer titles get an explicit `\n` break so the card never spans the full frame horizontally (`compose.py` enforces `max_words=4` on the hook card).**
- **OPENINGS:** angle-specific + distinct (proof = the result; contrarian = the belief it breaks; transformation = the shift); the FIRST SENTENCE carries the headline number; one PROOF stat line after the payoff (set your own social proof stats in `config.json`); conceptual gen-b-roll opens contrarian/transformation before the dashboard.
- **SCRIPTS:** never "AI"/"AIs" (Claude Code / Claude / agents); NAME the model + feature (Opus 4.8, Ultra Code) — never a generic "a new mode"; ANSWER WHY (the pain it removes, "now I don't have to..."), not just what; RESULT before mechanism (never bury the payoff); thought-line pauses; no spoken CTA.
- **B-ROLL:** per-beat source (screencap / riso infographic / riso illustration / character-you / library clip / word card); the REAL PRODUCT (dashboard) is the STAR — shown EARLY and carrying most beats, gen is a spice; a LIST line gets one rapid-fire word card per item (<=4 words; a sentence is NEVER a word card — the word_card renderer caps + wraps); BE PRESENT in illustrations (character:me; describe your pet/character accurately in gen prompts); absence two-shot with continuous push (zcont); SHARED canonical scenes generated once; end on a WIDE dashboard payoff; NEVER a carousel / notes / plain-editor frame when the line is not about code; cold-open = a relevance-matched Claude library clip; motion variety (no move >2x in a row; pan infographics, zoom illustrations).
- **CAPTIONS / TRANSCRIPTION:** Whisper mishears "Claude" as "cloud"/"quad" — `compose.py` auto-corrects them in the karaoke captions.
- **AVATAR:** HeyGen; `trim_pauses.py` single-pass (A/V-locked, leading fade removed → present on frame one).
- **CTA:** Set your community/offer name, price, and URL in `config.json` (`cta_community`, `cta_price`, `cta_url`). No comment-to-DM / ManyChat. **CTA adapts by video type:** tutorial → "Learn [topic]. Link in bio" end-card + "Learn to build like this inside [community]. [price], link in bio." caption; showcase → "Get [cta_noun]. Link in bio" end-card + "Get [cta_noun] inside [community]. [price], link in bio." caption. The script prompt determines `video_type` and `cta_noun` and saves them to `out/<slug>/meta_<angle>.json`. **End-card is now per-angle:** `compose.py` honors each cut-plan's own `endcard_text` field (precedence fixed) — per-angle CTAs render on-screen automatically; no config blank-and-restore hack needed.

## Key files
`pipeline.py` (orchestrator) · `prompts/` (scene_analyze, write_script, match, write_captions) · `compose.py` (compositor) · `trim_pauses.py` · `schedule.py` (Blotato) · `config.json` · `assets/broll/manifest.json` (15 Claude brand clips) · `assets/broll/clips/` · `out/<slug>/` (moments, scripts, cut-plans, broll plans, avatars, captions, schedule_result).
