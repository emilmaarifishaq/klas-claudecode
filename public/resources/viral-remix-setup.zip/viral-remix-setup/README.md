# Viral Remix — Setup Kit

Takes one viral video (URL or local file) and produces an AI-recreated version of it:
same beats, same camera moves, same pacing — rebuilt as Higgsfield Seedance 2.0 clips.

This folder has everything except the two paid CLIs (Claude Code + Higgsfield), which
you install with one command each below.

## What's in here

```
skills/viral-remix/SKILL.md     the skill itself — drop into your Claude Code skills folder
vendor/watch-plugin/            the /watch plugin this skill depends on (video download,
                                 frame extraction, transcription) — bundled so you don't
                                 need to hunt for it separately
```

## Setup (5 steps)

**1. Install Claude Code** (if you don't have it)
```bash
npm install -g @anthropic-ai/claude-code
```

**2. Install the system dependencies** — ffmpeg, yt-dlp, python3
```bash
brew install ffmpeg yt-dlp python3        # macOS
```

**3. Install the `/watch` plugin**

Copy the bundled plugin into your Claude Code plugin cache, or just point the skill at
this folder directly (see `skills/viral-remix/SKILL.md` — it looks for `watch.py`
under `~/.claude/plugins/cache/claude-video`). Easiest path: copy it there yourself:

```bash
mkdir -p ~/.claude/plugins/cache/claude-video/watch/0.1.3
cp -r vendor/watch-plugin/* ~/.claude/plugins/cache/claude-video/watch/0.1.3/
```

Then run its setup check:
```bash
python3 ~/.claude/plugins/cache/claude-video/watch/0.1.3/scripts/setup.py --check
```
Follow whatever it says is missing. Local Whisper transcription needs no API key; if you
want the faster cloud fallback instead, set `GROQ_API_KEY` (preferred, cheaper — get one
at console.groq.com/keys) or `OPENAI_API_KEY` in your shell environment. Transcription
quality doesn't gate rendering — it's a secondary cue, not required for this skill to work.

**4. Install and auth the Higgsfield CLI** (does the actual video rendering)
```bash
curl -fsSL https://raw.githubusercontent.com/higgsfield-ai/cli/main/install.sh | sh
higgsfield auth login
higgsfield account status     # confirms you're logged in and shows credit balance
```
Rendering costs Higgsfield credits per clip — check your plan's pricing before running
this on a long source video (it renders one clip per 15 seconds of source footage).

**5. Install the skill**
```bash
mkdir -p ~/.claude/skills/viral-remix
cp skills/viral-remix/SKILL.md ~/.claude/skills/viral-remix/SKILL.md
```

## Run it

In Claude Code:
```
/viral-remix <video URL or local path>
```

It runs fully autonomously — no check-ins — and writes everything to
`~/Desktop/viral-remix/<video-slug>/`, ending in a finished `remix-final.mp4`.

## Notes

- Fixed output spec: 9:16, 720p, regardless of the source's native aspect ratio.
- Long source videos render one Higgsfield clip per 15-second window — a 3-minute video
  is ~12 renders. Know your credit budget before pointing this at something long.
- No credentials are bundled in this kit. `GROQ_API_KEY`/`OPENAI_API_KEY` are optional
  environment variables you set yourself if you want cloud transcription instead of the
  local Whisper fallback.
