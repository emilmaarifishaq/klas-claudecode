# Claude Code – Video Editor

AI-powered video editing pipeline. Drop a raw recording into `Raw/`, run one command, get a clean edit in `Outputs/` — silence removed, hook added, captions burned in.

**What it does:**
1. Transcribes your video with Whisper (local, fast)
2. Sends the transcript to Claude, which decides exactly what to cut
3. Reassembles the video with FFmpeg — silence removed, filler cut, pacing tightened
4. Burns in animated captions and overlays a hook title at the start

---

## Requirements

- macOS (Apple Silicon recommended)
- Python 3.11+
- FFmpeg with full codecs
- An Anthropic API key

### Install FFmpeg

```bash
brew tap homebrew-ffmpeg/ffmpeg
brew install homebrew-ffmpeg/ffmpeg/ffmpeg --with-fdk-aac
```

> The pipeline expects FFmpeg at `/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg`. If yours is elsewhere, update the `FFMPEG` and `FFPROBE` paths at the top of `src/pipeline.py`.

### Install Python dependencies

```bash
pip install -r src/requirements.txt
```

---

## Setup

Copy `.env.example` to `.env` and add your key:

```bash
cp .env.example .env
```

Then edit `.env`:

```
ANTHROPIC_API_KEY=sk-ant-...
```

---

## Usage

### Single video

```bash
python src/pipeline.py Raw/your-video.mp4
```

### Batch (all videos in Raw/ at once)

```bash
python batch.py
```

The batch script processes all videos in `Raw/` in parallel, moves each finished file to `Processed/`, and writes per-video logs to `logs/`.

---

## Output

Finished videos land in `Outputs/` named `YYYY-MM-DD_your-video.mp4`.

---

## Configuration

Edit `src/config.json` to tune the pipeline without touching code:

| Key | Default | What it does |
|---|---|---|
| `whisper_model` | `medium` | Whisper model size (`tiny` → `large`) |
| `hook_mode` | `auto` | `auto` = Claude writes the hook, `manual` = set `hook_text` yourself |
| `hook_text` | `""` | Your hook text when `hook_mode` is `manual` |
| `silence_threshold_db` | `-35` | Louder = more aggressive silence removal |
| `silence_min_duration_sec` | `0.5` | Minimum silence length to cut |
| `export_crf` | `18` | Output quality (lower = better, 18 is near-lossless) |
| `caption_font` | `Inter` | Font used for captions (must be installed on your system) |
| `caption_words_per_chunk` | `4` | Words per caption chunk in the hook window |
| `caption_body_words_per_chunk` | `15` | Words per caption chunk in the body |

---

## Folder structure

```
.
├── Raw/          ← drop your source videos here
├── Processed/    ← originals move here after batch processing
├── Outputs/      ← finished edits land here
├── temp/         ← working files (auto-cleaned each run)
├── logs/         ← per-video batch logs
├── batch.py      ← batch processor
└── src/
    ├── pipeline.py     ← main pipeline
    ├── config.json     ← all tunable settings
    └── requirements.txt
```
