#!/usr/bin/env python3
"""
Batch video processor.
Scans Raw/ for unprocessed videos, runs the pipeline on each in parallel,
moves completed files to Processed/, and logs per-video output to logs/.
"""

import os
import subprocess
import sys
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path

from dotenv import load_dotenv

# Load .env files in the same order as pipeline.py
for _env in [
    Path(__file__).parent / ".env",
    Path.home() / ".claude" / ".env",
    Path.home() / "Documents" / "video-use" / ".env",
]:
    if _env.exists():
        load_dotenv(_env, override=True)

ROOT = Path(__file__).parent
RAW_DIR = ROOT / "Raw"
PROCESSED_DIR = ROOT / "Processed"
LOGS_DIR = ROOT / "logs"
PIPELINE = ROOT / "src" / "pipeline.py"
PYTHON = sys.executable

VIDEO_EXTENSIONS = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}


def find_raw_videos() -> list[Path]:
    return sorted(
        p for p in RAW_DIR.iterdir()
        if p.is_file() and p.suffix.lower() in VIDEO_EXTENSIONS
    )


def process_video(video: Path) -> tuple[Path, bool, str]:
    stem = video.stem.lower().replace(" ", "_")
    temp_dir = f"temp/{stem}"
    log_path = LOGS_DIR / f"{date.today()}_{stem}.log"

    cmd = [PYTHON, str(PIPELINE), str(video), "--temp-dir", temp_dir]

    with open(log_path, "w") as log_file:
        result = subprocess.run(
            cmd,
            cwd=ROOT,
            stdout=log_file,
            stderr=subprocess.STDOUT,
        )

    return video, result.returncode == 0, str(log_path)


def main() -> None:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        print("ERROR: ANTHROPIC_API_KEY not set.")
        print("Add it to the project .env file or ~/.claude/.env and retry.")
        sys.exit(1)

    PROCESSED_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)

    videos = find_raw_videos()
    if not videos:
        print("No videos found in Raw/. Nothing to do.")
        return

    print(f"Found {len(videos)} video(s) to process: {[v.name for v in videos]}")

    succeeded, failed = [], []

    with ThreadPoolExecutor(max_workers=len(videos)) as pool:
        futures = {pool.submit(process_video, v): v for v in videos}
        for future in as_completed(futures):
            video, ok, log_path = future.result()
            if ok:
                succeeded.append(video.name)
                if video.exists():
                    dest = PROCESSED_DIR / video.name
                    shutil.move(str(video), str(dest))
                    print(f"  ✓ {video.name}  →  Processed/  (log: {log_path})")
                else:
                    print(f"  ✓ {video.name}  →  Processed/ (pipeline auto-moved)  (log: {log_path})")
            else:
                failed.append(video.name)
                print(f"  ✗ {video.name}  FAILED — left in Raw/  (log: {log_path})")

    print(f"\nDone. {len(succeeded)} succeeded, {len(failed)} failed.")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
