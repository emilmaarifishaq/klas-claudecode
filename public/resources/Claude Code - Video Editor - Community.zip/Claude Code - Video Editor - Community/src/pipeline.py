#!/usr/bin/env python3
"""
Video Editing Pipeline
Drop a raw video into Raw/, run this script, get a clean edit in Outputs/.
"""

import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import date
from pathlib import Path

import anthropic
from dotenv import load_dotenv
from faster_whisper import WhisperModel

for _env_candidate in [
    Path(__file__).parent.parent / ".env",
    Path.home() / ".claude" / ".env",
    Path.home() / "Documents" / "video-use" / ".env",
]:
    if _env_candidate.exists():
        load_dotenv(_env_candidate, override=False)

# ── Constants ─────────────────────────────────────────────────────────────────

FFMPEG = "/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg"
FFPROBE = "/opt/homebrew/opt/ffmpeg-full/bin/ffprobe"
PROJECT_ROOT = Path(__file__).parent.parent
TEMP_DIR = PROJECT_ROOT / "temp"
SEGMENTS_DIR = TEMP_DIR / "segments"

DEFAULTS = {
    "whisper_model": "medium",
    "whisper_language": "en",

    "claude_model": "claude-sonnet-4-6",
    "claude_max_tokens": 8192,

    "hook_mode": "auto",
    "hook_text": "",
    "hook_duration_sec": 6.0,
    "hook_font_size": 72,
    "hook_font_color": "white",
    "hook_max_chars_per_line": 22,

    "silence_threshold_db": -35,
    "silence_min_duration_sec": 1.5,
    "silence_keep_padding_sec": 0.08,

    "export_crf": 18,
    "export_preset": "slow",
    "export_audio_bitrate": "192k",

    "audio_cleanup": True,
    "color_grade": "warm_cinematic",

    "caption_font": "Inter",
    "caption_font_size": 42,
    "caption_words_per_chunk": 4,
    "caption_hook_window_sec": 10.0,
    "caption_body_words_per_chunk": 15,
    "caption_shadow": 2,
    "caption_outline": 0,
    "caption_margin_bottom": 384,
}

SYSTEM_PROMPT = """You are a professional video editor. Your job is to construct the best possible edit of a raw recording — not just remove mistakes, but build the clearest, most confident, most narratively coherent version of what the speaker intended to say.

Return ONLY a valid JSON object. No prose, no analysis, no markdown, no commentary before or after.

TRANSCRIPT FORMAT
Each line is one sentence. The sentence start timestamp is in brackets. Every word has its exact timestamp in parentheses immediately after it:
  [6.8s] Here(6.8) are(7.0) four(7.1) things(7.3) you(7.5) can(7.7) upload(7.9)...
  [116.3s] If(116.3) you(116.7) want(116.9) to(117.1) get(117.3) access(117.5) to(117.8) this(118.1),(118.4) I(119.5) spent(119.8) the(120.1) last(120.3) 24(120.5) hours(120.7)...

You may use ANY word's timestamp as a cut boundary — not just sentence starts. This allows sub-sentence precision.
  start_sec = timestamp of the WORD where the cut begins (first word to remove)
  end_sec = timestamp of the WORD where content resumes (first word to keep after the cut)

Use ONLY timestamps that appear literally in the transcript. Never interpolate.

EDITING PHILOSOPHY
Read the ENTIRE transcript before identifying any cuts. Understand the full arc: what is the speaker trying to communicate, in what order, and how does each section serve that goal?

Then for each section, ask:
  - Is the speaker's intent clear and complete in this take?
  - Did they say the same thing (or near the same thing) somewhere else?
  - Which take is most complete, most confident, and clearest?
  - Does cutting this leave the edit coherent and unjarring?

Build the "best version" — not the original video with mistakes removed, but the video the speaker would have delivered if they'd nailed it in one take.

WHAT TO CUT
1. Repeated takes: when the same idea appears multiple times (even with different wording), keep only the best version. "Best" = most complete information + most confident delivery. Usually the final take, but not always.
   - If an idea appears 3 times, generate 2 cuts — one for each non-best take.
   - The takes don't have to be word-for-word identical. Match by meaning.
2. False starts: speaker begins a thought, stops (sometimes mid-sentence), then restarts with the same idea.
3. Filler openers at the very start: "hey", "okay so", "alright", "here really quick" — only if the next sentence is the real content and these add nothing.
4. Verbal bloopers: "um/uh" cluster, stumbled phrase, botched word.

WHAT TO NEVER CUT
- Any sentence or section that contains information, examples, or context not present anywhere else — even if the delivery isn't perfect.
- Audience connection lines: phrases like "if you're anything like me", "if your situation looks like this", "sound familiar?" — these are bridges to the viewer, not repetition. They always stay.
- Transitions between topics (cutting these creates jarring jumps).
- Any cut shorter than 1.5 seconds.

NARRATIVE CHECK
Before finalizing cuts, verify: does the edited video make sense end-to-end? Does each section flow into the next? Would a first-time viewer understand it without confusion? If a proposed cut creates a non-sequitur, remove it.

WHISPER TRANSCRIPTION ERRORS — Whisper consistently mishears proper nouns. Before writing the hook or slug, identify the actual topic by reading for meaning, not just the words. Common patterns in this speaker's content:
  - "Claude" is often transcribed as: "Cloud", "Clawed", "Quad", "Quod", "Claw"
  - "Claude Design" → "Cloud Design", "Quad Design", "Claw Design"
  - "Claude Code" → "Cloud Code", "Quad Code", "Clawed Code"
  - "Claude Projects" → "Cloud Projects", "Quad Projects"
Resolve the actual product name from context before writing the hook and slug.

HOOK — if hook_mode is "auto", write a SHORT text overlay for the first 6 seconds. Runs SIMULTANEOUSLY with what the speaker is saying — it is NOT a caption, it says something DIFFERENT. It should amplify and support what the speaker opens with — sharpen the tension they're setting up, don't contradict it.

Voice: Direct. Confident. No fluff. Name the specific pain or gap the viewer already feels but hasn't heard said out loud. Then flip it — show the possibility. Short sentences. Every word earns its place.

Pattern (the intimidation barrier):
  Name the pain → flip to possibility.
  Examples: "Everyone's AI output looks the same. Here's exactly why." / "You set up [X] wrong. Here's what's actually missing." / "Most [X] outputs look like slop. 4 uploads fix that."

Rules:
  - 8–18 words total
  - Must name the specific tool, concept, or technique — no vague abstractions
  - Must create urgency or a knowledge gap the viewer wants resolved
  - Must NOT be generic ("Here's what people get wrong...") — be specific to THIS video's content
  - Must NOT start with "Most people" — find a sharper opener
  - If hook_mode is not "auto", return "hook": null

SLUG — 2–4 words, lowercase, hyphenated, describes what the video is actually about (use the corrected product name, not the Whisper transcription). No dates.

CORRECTIONS — find-and-replace fixes for Whisper transcription errors. Each correction applies to caption text only.

If the video mentions any Claude product (Claude Code, Claude Design, Claude Projects, etc.), you MUST include ALL of the following corrections — even if you don't see every form in the transcript, the second Whisper pass on the edited video may produce different misreads:
  {"from": "Quad", "to": "Claude"}
  {"from": "Cloud", "to": "Claude"}
  {"from": "Clawed", "to": "Claude"}
  {"from": "Claw", "to": "Claude"}

Then add any additional compound-phrase corrections for the specific product mentioned (e.g. "Cloud Design" → "Claude Design", "Quad Code" → "Claude Code"). Preserve full names — never correct to just "Claude" when the full product name was spoken.

MOVES — use when a segment was recorded out of order and would be more impactful somewhere else in the narrative. Typical case: a pickup line recorded at the end of the session that proves, illustrates, or continues an earlier point.

Rules:
- Do NOT also list moved segments in "cuts" — the move implies removal from the original position.
- from_start / from_end: source timestamps bounding the pickup (snap to word boundaries).
- insert_after_sec: source timestamp of the word after which this pickup belongs narratively.
- Ask: would this segment land harder or serve the story better somewhere else? If yes, move it.
- If no moves are needed: "moves": []

RESPONSE FORMAT — valid JSON only:
{
  "cuts": [
    {"start_sec": 6.8, "end_sec": 22.5, "reason": "first two attempts at the intro; kept the final version at 22.5s which is most complete"},
    {"start_sec": 116.3, "end_sec": 119.5, "reason": "filler preamble 'if you want to get access to this' before the real sentence starting at 119.5s with 'I spent'"}
  ],
  "moves": [
    {"from_start": 183.4, "from_end": 191.7, "insert_after_sec": 47.2, "reason": "pickup correcting the setup step — belongs right after the setup explanation at 47.2s"}
  ],
  "hook": "Here's what people get wrong about Claude Design.",
  "slug": "claude-design-setup-tips",
  "corrections": [
    {"from": "Cloud Design", "to": "Claude Design"},
    {"from": "clawed code", "to": "Claude Code"}
  ]
}

If no cuts are needed: "cuts": []
If no moves are needed: "moves": []
If no corrections are needed: "corrections": []
If hook_mode is not auto: "hook": null"""

# ── Exceptions ────────────────────────────────────────────────────────────────

class PipelineError(Exception):
    pass

class FFmpegError(PipelineError):
    def __init__(self, step: str, returncode: int, stderr: str):
        snippet = stderr[-800:] if len(stderr) > 800 else stderr
        super().__init__(f"FFmpeg failed at '{step}' (exit {returncode}):\n{snippet}")

class ClaudeError(PipelineError):
    pass

class ConfigError(PipelineError):
    pass

# ── Logging ───────────────────────────────────────────────────────────────────

BOLD = "\033[1m"
YELLOW = "\033[33m"
RED = "\033[31m"
GREEN = "\033[32m"
RESET = "\033[0m"

def log(msg: str, level: str = "info") -> None:
    if level == "step":
        print(f"{BOLD}{GREEN}▶ {msg}{RESET}")
    elif level == "warn":
        print(f"{YELLOW}⚠ {msg}{RESET}")
    elif level == "error":
        print(f"{RED}✗ {msg}{RESET}", file=sys.stderr)
    else:
        print(f"  {msg}")

# ── Config ────────────────────────────────────────────────────────────────────

def load_config() -> dict:
    config_path = Path(__file__).parent / "config.json"
    if not config_path.exists():
        log("config.json not found — creating with defaults.", "warn")
        config_path.write_text(json.dumps(DEFAULTS, indent=2))
        return dict(DEFAULTS)
    with open(config_path) as f:
        user_config = json.load(f)
    return {**DEFAULTS, **user_config}

# ── Input resolution ──────────────────────────────────────────────────────────

VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}

def resolve_input(argv: list[str]) -> Path:
    if len(argv) > 1:
        p = Path(argv[1])
        if not p.exists():
            raise PipelineError(f"File not found: {p}")
        return p.resolve()

    raw_dir = PROJECT_ROOT / "Raw"
    candidates = sorted(
        [f for f in raw_dir.iterdir() if f.suffix.lower() in VIDEO_EXTS],
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise PipelineError(
            f"No video files found in {raw_dir}/\n"
            "Drop a video there or pass a path as an argument: python3 src/pipeline.py Raw/video.mp4"
        )
    if len(candidates) > 1:
        log(f"Multiple videos found — using newest: {candidates[0].name}", "warn")
    return candidates[0].resolve()

# ── Output naming ─────────────────────────────────────────────────────────────

def make_output_path(source: Path, slug: str | None = None) -> Path:
    if slug:
        stem = re.sub(r"[^a-z0-9\-]+", "-", slug.lower()).strip("-")
        stem = re.sub(r"-+", "-", stem)
    else:
        stem = source.stem.lower()
        stem = re.sub(r"[^a-z0-9]+", "-", stem).strip("-")
        stem = re.sub(r"-+", "-", stem)
    today = date.today().strftime("%Y-%m-%d")
    return PROJECT_ROOT / "Outputs" / f"{today}_{stem}.mp4"

# ── Video duration ────────────────────────────────────────────────────────────

def get_video_duration(path: Path) -> float:
    result = subprocess.run(
        [FFPROBE, "-v", "quiet", "-print_format", "json", "-show_format", str(path)],
        capture_output=True, text=True, timeout=30,
    )
    data = json.loads(result.stdout)
    return float(data["format"]["duration"])

# ── Transcription ─────────────────────────────────────────────────────────────

def transcribe(video_path: Path, config: dict) -> list[dict]:
    log(f"Loading Whisper model '{config['whisper_model']}'...")
    model = WhisperModel(config["whisper_model"], device="cpu", compute_type="int8")
    log("Transcribing audio...")
    segments, _ = model.transcribe(
        str(video_path),
        language=config["whisper_language"],
        word_timestamps=True,
    )
    words = []
    for seg in segments:
        if seg.words:
            for w in seg.words:
                words.append({"word": w.word, "start": w.start, "end": w.end})
    if not words:
        raise PipelineError("Transcription returned no words. Is the video silent?")
    log(f"Transcribed {len(words)} words.")
    return words

def build_transcript_text(words: list[dict]) -> str:
    """Sentence-level transcript with inline word timestamps.
    Format: [sentence_start] word(t) word(t) word(t)...
    Every word timestamp is available so Claude can make sub-sentence cuts."""
    if not words:
        return ""
    sentences = []
    current: list[dict] = []
    for w in words:
        current.append(w)
        txt = w["word"].strip()
        if txt.endswith((".", "?", "!")) and len(txt) > 1:
            start = current[0]["start"]
            parts = [f"{x['word'].strip()}({x['start']:.1f})" for x in current]
            sentences.append(f"[{start:.1f}s] {' '.join(parts)}")
            current = []
    if current:
        start = current[0]["start"]
        parts = [f"{x['word'].strip()}({x['start']:.1f})" for x in current]
        sentences.append(f"[{start:.1f}s] {' '.join(parts)}")
    return "\n".join(sentences)

# ── Programmatic repetition detection ────────────────────────────────────────

_STOP_WORDS = {
    "a", "an", "the", "and", "or", "but", "so", "if", "in", "on", "at", "to",
    "of", "for", "by", "with", "is", "are", "was", "be", "do", "did", "have",
    "has", "it", "its", "this", "that", "these", "those", "you", "your", "i",
    "we", "our", "my", "me", "he", "she", "they", "them", "their", "not", "no",
    "can", "will", "would", "could", "just", "all", "as", "up", "out", "here",
    "there", "then", "what", "how", "when", "from", "more", "also", "now",
}

def _content_words(text: str) -> set[str]:
    words = re.sub(r"[^a-z\s]", "", text.lower()).split()
    return {w for w in words if w not in _STOP_WORDS and len(w) > 2}

def build_sentence_tuples(words: list[dict]) -> list[tuple[float, str]]:
    """Same sentence splitting as build_transcript_text but returns (start_sec, text) tuples."""
    sentences: list[tuple[float, str]] = []
    current: list[dict] = []
    for w in words:
        current.append(w)
        txt = w["word"].strip()
        if txt.endswith((".", "?", "!")) and len(txt) > 1:
            start = current[0]["start"]
            text = " ".join(x["word"].strip() for x in current)
            sentences.append((start, text))
            current = []
    if current:
        sentences.append((current[0]["start"], " ".join(x["word"].strip() for x in current)))
    return sentences

def detect_repetitions(sentences: list[tuple[float, str]], window: int = 10, threshold: float = 0.55) -> list[dict]:
    """Compare every sentence against the next `window` sentences by content-word overlap.
    When similarity >= threshold, treat all but the last instance as a cut.
    Returns a list of cuts in the same format as Claude's cut list."""
    n = len(sentences)
    in_cluster: set[int] = set()
    cuts: list[dict] = []

    i = 0
    while i < n:
        if i in in_cluster:
            i += 1
            continue

        cw_i = _content_words(sentences[i][1])
        if not cw_i:
            i += 1
            continue

        cluster = [i]
        for j in range(i + 1, min(i + window + 1, n)):
            cw_j = _content_words(sentences[j][1])
            if not cw_j:
                continue
            overlap = len(cw_i & cw_j) / max(len(cw_i), len(cw_j))
            if overlap >= threshold:
                cluster.append(j)
                in_cluster.add(j)

        if len(cluster) > 1:
            # Cut from first duplicate's start to last (best) take's start
            cut_start = sentences[cluster[0]][0]
            cut_end = sentences[cluster[-1]][0]
            cuts.append({
                "start_sec": cut_start,
                "end_sec": cut_end,
                "reason": f"repeated take — kept final version at {cut_end:.1f}s",
            })
            in_cluster.add(i)

        i += 1

    return cuts

def merge_cuts(cuts_a: list[dict], cuts_b: list[dict]) -> list[dict]:
    """Merge two cut lists, collapsing overlapping or adjacent cuts into single intervals."""
    all_cuts = sorted(cuts_a + cuts_b, key=lambda c: c["start_sec"])
    if not all_cuts:
        return []
    merged: list[dict] = [dict(all_cuts[0])]
    for cut in all_cuts[1:]:
        prev = merged[-1]
        if cut["start_sec"] <= prev["end_sec"] + 0.1:
            # Overlapping or adjacent — extend the previous cut
            prev["end_sec"] = max(prev["end_sec"], cut["end_sec"])
            prev["reason"] = prev["reason"] + " + " + cut.get("reason", "")
        else:
            merged.append(dict(cut))
    return merged

# ── Claude analysis ───────────────────────────────────────────────────────────

def snap_cuts_to_words(cuts: list[dict], words: list[dict]) -> list[dict]:
    """Snap cut start/end times to actual word boundaries to prevent mid-sentence cuts."""
    starts = sorted(w["start"] for w in words)
    def nearest_at_or_after(t: float) -> float:
        for ws in starts:
            if ws >= t - 0.15:
                return ws
        return t
    return [
        {**c, "start_sec": nearest_at_or_after(c["start_sec"]),
              "end_sec":   nearest_at_or_after(c["end_sec"])}
        for c in cuts
    ]

def snap_moves_to_words(moves: list[dict], words: list[dict]) -> list[dict]:
    """Snap move from_start/from_end to word boundaries."""
    starts = sorted(w["start"] for w in words)
    def nearest_at_or_after(t: float) -> float:
        for ws in starts:
            if ws >= t - 0.15:
                return ws
        return t
    return [
        {**m, "from_start": nearest_at_or_after(m["from_start"]),
              "from_end":   nearest_at_or_after(m["from_end"])}
        for m in moves
    ]

def analyze_with_claude(transcript_text: str, duration: float, config: dict, words: list[dict] | None = None) -> dict:
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ConfigError("ANTHROPIC_API_KEY environment variable not set.")

    client = anthropic.Anthropic(api_key=api_key)

    user_message = (
        f"Video duration: {duration:.1f} seconds\n"
        f"Hook mode: {config['hook_mode']}\n\n"
        f"TRANSCRIPT:\n{transcript_text}"
    )

    log("Sending transcript to Claude for analysis...")
    try:
        response = client.messages.create(
            model=config["claude_model"],
            max_tokens=config["claude_max_tokens"],
            system=[
                {
                    "type": "text",
                    "text": SYSTEM_PROMPT,
                    "cache_control": {"type": "ephemeral"},
                }
            ],
            messages=[{"role": "user", "content": user_message}],
        )
    except anthropic.APIError as e:
        raise ClaudeError(f"Claude API error: {e}") from e

    raw = response.content[0].text.strip()
    # Strip markdown fences if present
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw).strip()
    # If Claude wrote prose before the JSON, extract the JSON object
    if not raw.startswith("{"):
        match = re.search(r"\{[\s\S]*\}", raw)
        if match:
            raw = match.group(0)

    try:
        result = json.loads(raw)
    except json.JSONDecodeError:
        raise ClaudeError(f"Claude returned non-JSON response:\n{raw[:500]}")

    cuts = result.get("cuts", [])
    min_cut = 1.5
    valid_cuts = []
    for c in cuts:
        if not (isinstance(c.get("start_sec"), (int, float)) and isinstance(c.get("end_sec"), (int, float))):
            continue
        if c["end_sec"] - c["start_sec"] < min_cut:
            continue
        if c["start_sec"] < 0 or c["end_sec"] > duration + 1:
            continue
        valid_cuts.append(c)

    if words:
        valid_cuts = snap_cuts_to_words(valid_cuts, words)
    result["cuts"] = valid_cuts

    raw_moves = result.get("moves", [])
    valid_moves = []
    for m in raw_moves:
        fs = m.get("from_start")
        fe = m.get("from_end")
        ia = m.get("insert_after_sec")
        if not all(isinstance(v, (int, float)) for v in [fs, fe, ia]):
            continue
        if fe - fs < 1.5:
            continue
        if fs < 0 or fe > duration + 1 or ia < 0 or ia > duration + 1:
            continue
        valid_moves.append(m)
    if words:
        valid_moves = snap_moves_to_words(valid_moves, words)
    result["moves"] = valid_moves

    return result

# ── Segment removal ───────────────────────────────────────────────────────────

def invert_intervals(cuts: list[dict], duration: float, start_key="start_sec", end_key="end_sec") -> list[tuple]:
    sorted_cuts = sorted(cuts, key=lambda c: c[start_key])
    merged = []
    for c in sorted_cuts:
        if merged and c[start_key] <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], c[end_key]))
        else:
            merged.append((c[start_key], c[end_key]))

    keep = []
    cursor = 0.0
    for start, end in merged:
        if cursor < start - 0.01:
            keep.append((cursor, start))
        cursor = end
    if cursor < duration - 0.01:
        keep.append((cursor, duration))
    return keep

def run_ffmpeg(args: list[str], step_name: str) -> subprocess.CompletedProcess:
    cmd = [FFMPEG, "-y"] + args
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if result.returncode != 0:
        raise FFmpegError(step_name, result.returncode, result.stderr)
    return result

MIN_SEGMENT_SEC = 1.0  # drop any segment shorter than this after splicing

def build_ordered_segments(cuts: list[dict], moves: list[dict], duration: float) -> list[tuple[float, float]]:
    """
    Produce the final ordered list of (start, end) source-time intervals.
    Cuts remove intervals; moves extract a segment and reinsert it at a new position.
    insert_after_sec splits the containing segment so the moved clip lands at exactly
    that source timestamp, not after the whole containing segment.
    """
    segments = invert_intervals(cuts, duration)

    for move in moves:
        fs = move["from_start"]
        fe = move["from_end"]
        ia = move["insert_after_sec"]

        # Remove [fs, fe] from current sequence (may split an interval)
        remaining: list[tuple[float, float]] = []
        for (s, e) in segments:
            if e <= fs or s >= fe:
                remaining.append((s, e))
            else:
                if s < fs:
                    remaining.append((s, fs))
                if e > fe:
                    remaining.append((fe, e))

        # Split the segment that contains insert_after_sec so the moved clip
        # lands at exactly that point rather than after the whole segment.
        split: list[tuple[float, float]] = []
        insert_idx = len(remaining)
        for i, (s, e) in enumerate(remaining):
            if s <= ia < e:
                # ia falls inside this segment — split it
                if ia - s >= MIN_SEGMENT_SEC:
                    split.append((s, ia))
                insert_idx = len(split)
                if e - ia >= MIN_SEGMENT_SEC:
                    split.append((ia, e))
            else:
                split.append((s, e))
                if e <= ia:
                    insert_idx = len(split)

        split.insert(insert_idx, (fs, fe))
        segments = split

    # Drop any sub-second fragments left by splicing (e.g. tail after a move)
    return [(s, e) for (s, e) in segments if e - s >= MIN_SEGMENT_SEC]

def extract_and_concat(input_path: Path, segments: list[tuple[float, float]], label: str = "seg") -> Path:
    """Extract ordered (start, end) intervals from input and concatenate them."""
    SEGMENTS_DIR.mkdir(parents=True, exist_ok=True)
    seg_files = []

    for i, (start, end) in enumerate(segments):
        seg_path = SEGMENTS_DIR / f"{label}_{i:04d}.ts"
        run_ffmpeg(
            ["-ss", str(start), "-i", str(input_path),
             "-t", str(end - start),
             "-c:v", "libx264", "-preset", "ultrafast", "-crf", "15",
             "-c:a", "aac", "-b:a", "192k",
             str(seg_path)],
            f"extract {label} {i}",
        )
        seg_files.append(seg_path)

    concat_list = TEMP_DIR / f"concat_{label}.txt"
    concat_list.write_text("\n".join(f"file '{p}'" for p in seg_files))

    output = TEMP_DIR / f"after_{label}.mp4"
    run_ffmpeg(
        ["-f", "concat", "-safe", "0", "-i", str(concat_list), "-c", "copy", str(output)],
        f"concat {label}",
    )
    return output

# ── Silence trimming ──────────────────────────────────────────────────────────

def detect_silences(input_path: Path, config: dict) -> list[dict]:
    threshold = config["silence_threshold_db"]
    min_dur = config["silence_min_duration_sec"]
    af = f"silencedetect=noise={threshold}dB:duration={min_dur}"
    result = subprocess.run(
        [FFMPEG, "-i", str(input_path), "-af", af, "-f", "null", "-"],
        capture_output=True, text=True, timeout=600,
    )
    stderr = result.stderr
    silences = []
    starts = re.findall(r"silence_start: ([\d.]+)", stderr)
    ends = re.findall(r"silence_end: ([\d.]+)", stderr)
    for s, e in zip(starts, ends):
        silences.append({"start_sec": float(s), "end_sec": float(e)})
    return silences

def trim_silences(input_path: Path, silences: list[dict], duration: float, config: dict) -> Path:
    pad = config["silence_keep_padding_sec"]
    padded = [
        {"start_sec": s["start_sec"] + pad, "end_sec": s["end_sec"] - pad}
        for s in silences
        if s["end_sec"] - s["start_sec"] > 2 * pad
    ]
    if not padded:
        return input_path
    keep = invert_intervals(padded, duration)
    return extract_and_concat(input_path, keep, label="sil")

# ── Hook overlay (returns filter strings — no render) ─────────────────────────

FONT_CANDIDATES = [
    "/System/Library/Fonts/HelveticaNeue.ttc",
    "/System/Library/Fonts/Helvetica.ttc",
    "/Library/Fonts/Arial Bold.ttf",
    "/Library/Fonts/Arial.ttf",
]

def _find_font() -> str | None:
    for path in FONT_CANDIDATES:
        if Path(path).exists():
            return path
    return None

def _wrap_text(text: str, max_chars: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current: list[str] = []
    for word in words:
        candidate = " ".join(current + [word])
        if current and len(candidate) > max_chars:
            lines.append(" ".join(current))
            current = [word]
        else:
            current.append(word)
    if current:
        lines.append(" ".join(current))
    return lines

def build_hook_ass(hook_text: str, config: dict) -> Path:
    """Write an ASS subtitle file for the hook overlay (top of frame, first N seconds)."""
    dur = config["hook_duration_sec"]
    size = config["hook_font_size"]
    max_chars = config["hook_max_chars_per_line"]
    font = config.get("caption_font", "Inter")

    sentences = re.split(r'(?<=[.?!])\s+', hook_text.strip())
    lines: list[str] = []
    for sentence in sentences:
        if sentence:
            lines.extend(_wrap_text(sentence, max_chars) if len(sentence) > max_chars else [sentence])

    # \N is ASS hard line break
    text_block = r"\N".join(lines)

    start = _secs_to_ass(0.0)
    end = _secs_to_ass(dur)

    # BorderStyle=3: opaque box drawn behind text using OutlineColour
    # Alignment=8: top-center; \pos(540,80) pins text 80px from top, centered
    content = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        "PlayResX: 1080\n"
        "PlayResY: 1920\n"
        "WrapStyle: 0\n"
        "\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, "
        "Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Hook,{font},{size},"
        "&H00FFFFFF,"   # white text
        "&H000000FF,"   # SecondaryColour (unused)
        "&H00000000,"   # OutlineColour = black outline
        "&H80000000,"   # BackColour = semi-transparent shadow
        "-1,0,0,0,100,100,0,0,1,3,2,8,20,20,80,1\n"
        # BorderStyle=1 (outline mode, no box), Outline=3, Shadow=2
        "\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
        f"Dialogue: 0,{start},{end},Hook,,0,0,0,,{{\\an8\\pos(540,150)}}{text_block}\n"
    )

    hook_ass_path = Path(tempfile.gettempdir()) / "pipeline_hook.ass"
    hook_ass_path.write_text(content, encoding="utf-8")
    return hook_ass_path

# ── Captions (returns ASS path — no render) ───────────────────────────────────

def _secs_to_ass(secs: float) -> str:
    h = int(secs // 3600)
    m = int((secs % 3600) // 60)
    s = int(secs % 60)
    cs = min(int(round((secs % 1) * 100)), 99)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

def _apply_corrections(text: str, corrections: list[dict]) -> str:
    for c in corrections:
        from_text = c.get("from", "")
        to_text = c.get("to", "")
        if from_text:
            text = re.sub(re.escape(from_text), to_text, text, flags=re.IGNORECASE)
    return text

def _add_line_breaks(text: str, words_per_line: int) -> str:
    words = text.split()
    lines = [" ".join(words[i:i + words_per_line]) for i in range(0, len(words), words_per_line)]
    return "\\N".join(lines)

def _trim_sentence_start(group: list[dict], max_trim: int = 3) -> list[dict]:
    """Remove trailing words that begin a new sentence (up to max_trim words)."""
    if len(group) <= 1:
        return group
    for n in range(1, min(max_trim + 1, len(group))):
        prev = group[-(n + 1)]["word"].strip()
        if prev and prev[-1] in ".?!":
            return group[:-n]
    return group

def _build_ass(words: list[dict], corrections: list[dict], config: dict) -> str:
    font = config["caption_font"]
    size = config["caption_font_size"]
    chunk = config["caption_words_per_chunk"]
    shadow = config["caption_shadow"]
    outline = config["caption_outline"]
    margin_v = config["caption_margin_bottom"]
    hook_window = config.get("caption_hook_window_sec", 10.0)
    chunk_body = config.get("caption_body_words_per_chunk", 15)

    play_res_x = 1080
    play_res_y = 1920
    pos_x = play_res_x // 2
    pos_y = play_res_y - margin_v

    header = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {play_res_x}\n"
        f"PlayResY: {play_res_y}\n"
        "WrapStyle: 0\n"
        "\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, "
        "Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Caption,{font},{size},"
        "&H00FFFFFF,"
        "&H000000FF,"
        "&H00000000,"
        "&H40000000,"
        f"0,0,0,0,100,100,0,0,1,{outline},{shadow},2,10,10,{margin_v},1\n"
        "\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )

    pos_tag = f"{{\\an2\\pos({pos_x},{pos_y})}}"

    # Build groups: sentence boundaries are always hard breaks; word-count is a secondary limit
    groups: list[list[dict]] = []
    i = 0
    while i < len(words):
        in_hook = words[i]["start"] < hook_window
        group_size = chunk if in_hook else chunk_body

        group: list[dict] = []
        for j in range(i, len(words)):
            w = words[j]
            if in_hook and w["start"] >= hook_window:
                break
            group.append(w)
            word_text = w["word"].strip()
            # Always end block at sentence boundary
            if word_text.endswith((".", "?", "!")) and len(word_text) > 1:
                break
            # Secondary: word-count limit (within a sentence)
            if len(group) >= group_size:
                break

        if not group:
            i += 1
            continue
        groups.append(group)
        i += len(group)

    dialogue_lines = []
    for idx, group in enumerate(groups):
        in_hook = group[0]["start"] < hook_window
        text = " ".join(w["word"].strip() for w in group).strip().lstrip("-").strip()
        text = _apply_corrections(text, corrections)
        if not text:
            continue

        if not in_hook and len(text.split()) > 5:
            text = _add_line_breaks(text, 5)

        start = _secs_to_ass(group[0]["start"])
        # End = start of next group for hard cut; last group gets natural end
        if idx + 1 < len(groups):
            end = _secs_to_ass(groups[idx + 1][0]["start"])
        else:
            end = _secs_to_ass(group[-1]["end"] + 0.05)
        dialogue_lines.append(f"Dialogue: 0,{start},{end},Caption,,0,0,0,,{pos_tag}{text}")

    return header + "\n".join(dialogue_lines) + "\n"

def prepare_captions(input_path: Path, corrections: list[dict], config: dict) -> Path:
    """Transcribes the edited video and writes an ASS file. Returns the ASS path."""
    log("Transcribing edited video for caption timing...", "step")
    words = transcribe(input_path, config)
    ass_content = _build_ass(words, corrections, config)
    ass_path = Path(tempfile.gettempdir()) / "pipeline_captions.ass"
    ass_path.write_text(ass_content, encoding="utf-8")
    return ass_path

# ── Color grade presets ───────────────────────────────────────────────────────

COLOR_GRADES = {
    "natural": (
        "eq=contrast=1.04:saturation=0.92,"
        "colorbalance=rs=-0.04:rm=-0.04:rh=-0.04:bs=0.03:bm=0.03:bh=0.03"
    ),
    "warm_cinematic": (
        "eq=contrast=1.05:brightness=0.02:saturation=1.1,"
        "colorbalance=rs=0.06:rm=0.04:rh=0.02:bs=-0.06:bm=-0.04:bh=-0.02"
    ),
    "neutral_punch": (
        "eq=contrast=1.08:brightness=0.01:saturation=1.05,"
        "unsharp=5:5:0.8:3:3:0.0"
    ),
    "none": None,
}

# highpass=100: cut low-end mud
# afftdn nf=-20: aggressive echo/room noise reduction
# equalizer f=280 g=-4: cut boxy/bloated 280Hz resonance
# equalizer f=3500 g=2: boost presence and clarity
# loudnorm: EBU R128 normalization
AUDIO_CLEANUP_CHAIN = (
    "highpass=f=100,"
    "afftdn=nf=-20,"
    "equalizer=f=280:width_type=o:width=2:g=-4,"
    "equalizer=f=3500:width_type=o:width=2:g=2,"
    "loudnorm=I=-16:LRA=11:TP=-1.5"
)

# ── Single-pass render + export ───────────────────────────────────────────────

def render_final(
    input_path: Path,
    output_path: Path,
    hook_ass_path: Path | None,
    caption_ass_path: Path | None,
    config: dict,
) -> None:
    """One FFmpeg pass: color grade + hook ASS + caption ASS + audio cleanup + final encode."""
    output_path.parent.mkdir(exist_ok=True)

    vf_parts = []

    grade_key = config.get("color_grade", "none")
    grade_filter = COLOR_GRADES.get(grade_key, None) if grade_key != "none" else None
    if grade_filter is None and grade_key not in ("none", None, ""):
        # Treat as raw ffmpeg filter string
        grade_filter = grade_key
    if grade_filter:
        vf_parts.append(grade_filter)

    if hook_ass_path:
        esc = str(hook_ass_path).replace("\\", "\\\\").replace(":", "\\:")
        vf_parts.append(f"ass={esc}")
    if caption_ass_path:
        esc = str(caption_ass_path).replace("\\", "\\\\").replace(":", "\\:")
        vf_parts.append(f"ass={esc}")

    args = ["-i", str(input_path)]
    if vf_parts:
        args += ["-vf", ",".join(vf_parts)]

    if config.get("audio_cleanup", True):
        args += ["-af", AUDIO_CLEANUP_CHAIN]

    args += [
        "-c:v", "libx264",
        "-preset", config["export_preset"],
        "-crf", str(config["export_crf"]),
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", config["export_audio_bitrate"],
        "-movflags", "+faststart",
        str(output_path),
    ]
    run_ffmpeg(args, "render and export")

# ── Cleanup ───────────────────────────────────────────────────────────────────

def cleanup_temp() -> None:
    shutil.rmtree(TEMP_DIR, ignore_errors=True)

# ── Main ──────────────────────────────────────────────────────────────────────

LAST_ANALYSIS_PATH = PROJECT_ROOT / "last_analysis.json"
LAST_TRANSCRIPT_PATH = PROJECT_ROOT / "last_transcript.json"

def _save_analysis(input_path: Path, analysis: dict) -> None:
    payload = {**analysis, "_input": str(input_path)}
    LAST_ANALYSIS_PATH.write_text(json.dumps(payload, indent=2))

def _save_transcript(input_path: Path, words: list[dict], transcript_text: str, duration: float) -> None:
    payload = {
        "_input": str(input_path),
        "words": words,
        "transcript_text": transcript_text,
        "duration": duration,
    }
    LAST_TRANSCRIPT_PATH.write_text(json.dumps(payload, indent=2))

def _load_analysis() -> tuple[Path, dict]:
    if not LAST_ANALYSIS_PATH.exists():
        raise PipelineError("No saved analysis found. Run without --render-only first.")
    data = json.loads(LAST_ANALYSIS_PATH.read_text())
    input_path = Path(data.pop("_input"))
    if not input_path.exists():
        raise PipelineError(f"Saved input file no longer exists: {input_path}")
    return input_path, data

def _load_transcript() -> tuple[Path, list[dict], str, float]:
    if not LAST_TRANSCRIPT_PATH.exists():
        raise PipelineError("No saved transcript. Run the full pipeline first.")
    data = json.loads(LAST_TRANSCRIPT_PATH.read_text())
    input_path = Path(data["_input"])
    if not input_path.exists():
        raise PipelineError(f"Saved input file no longer exists: {input_path}")
    return input_path, data["words"], data["transcript_text"], data["duration"]

def _run_pipeline(input_path: Path, analysis: dict, config: dict, words: list[dict] | None = None) -> None:
    cuts = analysis.get("cuts", [])
    moves = analysis.get("moves", [])
    hook = analysis.get("hook") or config.get("hook_text", "")
    slug = analysis.get("slug") or None
    corrections = analysis.get("corrections", [])

    output_path = make_output_path(input_path, slug)
    log(f"Output: {output_path.name}")

    if cuts:
        log(f"Found {len(cuts)} segment(s) to cut:")
        for c in cuts:
            log(f"  [{c['start_sec']:.1f}s → {c['end_sec']:.1f}s] {c.get('reason', '')}")
    else:
        log("No cuts needed.")

    if moves:
        log(f"Found {len(moves)} segment(s) to reorder:")
        for m in moves:
            log(f"  [{m['from_start']:.1f}s → {m['from_end']:.1f}s] → insert after {m['insert_after_sec']:.1f}s  {m.get('reason', '')}")

    if hook:
        log(f"Hook: \"{hook}\"")

    if corrections:
        log(f"Caption corrections: {corrections}")

    current = input_path
    duration = get_video_duration(input_path)

    if cuts or moves:
        log("Assembling segments (cuts + reorder)...", "step")
        segments = build_ordered_segments(cuts, moves, duration)
        current = extract_and_concat(current, segments, label="seg")

    log("Detecting silences...", "step")
    silences = detect_silences(current, config)
    if silences:
        log(f"Trimming {len(silences)} silence gap(s)...", "step")
        current = trim_silences(current, silences, get_video_duration(current), config)
    else:
        log("No significant silences found.")

    hook_ass_path = build_hook_ass(hook, config) if hook else None
    caption_ass_path = prepare_captions(current, corrections, config)

    log("Rendering final video (hook + captions + encode)...", "step")
    render_final(current, output_path, hook_ass_path, caption_ass_path, config)

    cleanup_temp()
    log(f"Done → {output_path}", "step")

def main() -> None:
    global TEMP_DIR, SEGMENTS_DIR
    config = load_config()

    render_only  = "--render-only"  in sys.argv
    reanalyze    = "--reanalyze"    in sys.argv
    argv_clean   = [a for a in sys.argv if a not in ("--render-only", "--reanalyze")]

    # Extract --temp-dir <path> or --temp-dir=<path>
    temp_dir_val = "temp"
    i, filtered = 0, []
    while i < len(argv_clean):
        if argv_clean[i] == "--temp-dir" and i + 1 < len(argv_clean):
            temp_dir_val = argv_clean[i + 1]; i += 2
        elif argv_clean[i].startswith("--temp-dir="):
            temp_dir_val = argv_clean[i].split("=", 1)[1]; i += 1
        else:
            filtered.append(argv_clean[i]); i += 1
    argv_clean = filtered
    TEMP_DIR = PROJECT_ROOT / temp_dir_val
    SEGMENTS_DIR = TEMP_DIR / "segments"

    if render_only:
        log("Re-render mode — loading saved analysis, skipping transcription + Claude.", "warn")
        TEMP_DIR.mkdir(parents=True, exist_ok=True)
        SEGMENTS_DIR.mkdir(parents=True, exist_ok=True)
        input_path, analysis = _load_analysis()
        _, words, _, _ = _load_transcript()
        log(f"Input:  {input_path.name}")
        _run_pipeline(input_path, analysis, config, words=words)
        return

    if reanalyze:
        log("Re-analyze mode — loading saved transcript, re-running Claude.", "warn")
        TEMP_DIR.mkdir(parents=True, exist_ok=True)
        SEGMENTS_DIR.mkdir(parents=True, exist_ok=True)
        input_path, words, _saved_text, duration = _load_transcript()
        # Rebuild transcript text with current format (word-level timestamps)
        # so Claude gets the new format even if the saved text is old format.
        transcript_text = build_transcript_text(words)
        log(f"Input:  {input_path.name}  ({duration:.1f}s, saved transcript)")
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise ConfigError("ANTHROPIC_API_KEY environment variable not set.")
        log("Analyzing with Claude...", "step")
        analysis = analyze_with_claude(transcript_text, duration, config, words=words)
        _save_analysis(input_path, analysis)
        _run_pipeline(input_path, analysis, config, words=words)
        return

    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise ConfigError("ANTHROPIC_API_KEY environment variable not set.")

    input_path = resolve_input(argv_clean)
    log(f"Input:  {input_path.name}")

    TEMP_DIR.mkdir(parents=True, exist_ok=True)
    SEGMENTS_DIR.mkdir(parents=True, exist_ok=True)

    log("Transcribing...", "step")
    words = transcribe(input_path, config)
    transcript_text = build_transcript_text(words)
    duration = get_video_duration(input_path)
    log(f"Duration: {duration:.1f}s")
    _save_transcript(input_path, words, transcript_text, duration)

    log("Analyzing with Claude...", "step")
    analysis = analyze_with_claude(transcript_text, duration, config, words=words)
    _save_analysis(input_path, analysis)

    _run_pipeline(input_path, analysis, config, words=words)

    processed_dir = PROJECT_ROOT / "Processed"
    processed_dir.mkdir(exist_ok=True)
    dest = processed_dir / input_path.name
    shutil.move(str(input_path), str(dest))
    log(f"Moved source → Processed/{input_path.name}")


if __name__ == "__main__":
    try:
        main()
    except PipelineError as e:
        log(str(e), "error")
        log(f"Intermediate files preserved at: {TEMP_DIR}", "warn")
        sys.exit(1)
    except KeyboardInterrupt:
        log("Interrupted. Temp files preserved.", "warn")
        sys.exit(130)
