# The Build Room — Offer Positioning

## The Offer
**The Build Room** — $97/month community
Positioning: The #1 community for building a highly-profitable personal brand with AI.

The exact system Duncan used to grow 150K+ followers, close multi-billion dollar clients from organic content, and build consistent inbound revenue — in under 12 months. No cold outreach. No manual content grind.

## What Members Get
- **TrendJacker** — proven hooks and content ideas in seconds
- **Brand Genius** — AI trained on your voice, works 24/7
- **Content Engine** — followers, leads, and conversions on autopilot
- **Lead Assets** — lead magnet, landing page, 30-day email sequence
- **Live Coaching** — weekly calls, daily Q&A, direct access

## The Outcomes (Value Props)
- Inbound leads that close themselves — they're sold before the first call
- Consistent monthly revenue from organic content
- A compounding pipeline built on content you create once
- An evergreen personal brand that keeps working after you stop posting

## Duncan's Credibility
- 150K+ followers across channels in under 12 months
- Closed multi-billion dollar clients from organic content alone
- Built brands @ Apple, PlayStation, Charles Schwab
- Runs a highly-profitable AI agency
- Scaled a Skool community to top 5% and $15K+ MRR in 90 days
- Multiple viral videos (5M TikTok, 188K YouTube)

## Target Avatar
**The Expertise-Rich, Audience-Poor Business Owner**

Who: Independent business owner doing $8K–20K/month from referrals and word of mouth. Great at what they do — clients love them. But growth is capped because nobody knows they exist outside their current network. Watches people with half their skill get twice the clients because they post content. Has tried posting a few times, felt cringe, gave up.

Why they need this now: Referrals are drying up or inconsistent. Knows the next level requires visibility. Ready to stop being the best-kept secret.

**Secondary Avatars:**

*The Burned-Out Outreach Grinder*
Independent consultant doing $5K–15K/month through cold outreach, DMs, or paid ads. Spends hours on outreach that converts at 1–2%. Wants to flip the dynamic so prospects come to them instead of chasing.

*The Stuck-at-a-Plateau Owner*
Business owner who hit $10K–25K/month and flatlined for 6+ months. Has the offer, has the delivery, but can't break through. Wants leverage, not another job.

## Positioning Rules for Content
- The Build Room is **$97/month** — never describe it as free
- Do NOT reference "14 days" or "49 days" timelines — these are retired
- Lead with outcomes: inbound leads, consistent revenue, compounding pipeline
- Duncan's proof points to reference: 150K+ followers, multi-billion dollar clients, top 5% Skool in 90 days, Apple/PlayStation/Charles Schwab brand work
- Pain language to use: "best-kept secret", "cold outreach exhausting", "referrals drying up", "posting feels cringe"
- CTA always uses "Comment [KEYWORD]" pattern — never link directly in the post
