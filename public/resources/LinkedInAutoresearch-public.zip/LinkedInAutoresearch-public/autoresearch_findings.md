# Autoresearch Findings

## Run: 2026-03-25 — Strategy v4
Posts Analyzed: 28

---

## Top Performers at a Glance
- **Hook type:** transformation
- **Topic:** ai_automation
- **Format:** list
- **Content type:** results_reveal
- **Angle:** social_proof

---

## Performance by Hook Type

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| transformation | 5 | 20650.4 | 0.0% |
| big_number | 10 | 12329.0 | 0.0% |
| i_statement | 12 | 2963.0 | 0.0% |


---

## Performance by Topic

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| ai_automation | 17 | 15122.3 | 0.0% |
| linkedin_growth | 1 | 1068.0 | 0.0% |
| AI workflow that replaces manual content grind | 1 | 1026.0 | 0.0% |
| 3 Claude instructions that dramatically reduce hallucination | 1 | 853.0 | 0.0% |
| personal_brand | 2 | 727.5 | 0.0% |
| 3 Claude instructions that reduce AI hallucination | 1 | 617.0 | 0.0% |
| AI workflow that replaces hours of manual work daily | 2 | 0.0 | 0.0% |
| AI system that replaces cold outreach with inbound leads | 1 | 0.0 | 0.0% |
| AI system that replaces hours of manual content research | 1 | 0.0 | 0.0% |


---

## Performance by Format

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| list | 16 | 14946.9 | 0.0% |
| step_by_step | 2 | 5221.0 | 0.0% |
| narrative | 8 | 1439.6 | 0.0% |
| before_after | 1 | 988.0 | 0.0% |


---

## Performance by Content Type

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| results_reveal | 13 | 16129.5 | 0.0% |
| announcement | 7 | 4980.4 | 0.0% |
| tutorial | 5 | 3134.6 | 0.0% |
| how_to | 2 | 939.5 | 0.0% |


---

## Performance by Angle

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| social_proof | 6 | 18068.0 | 0.0% |
| personal_experience | 16 | 8647.7 | 0.0% |
| aspiration | 2 | 5104.0 | 0.0% |
| contrarian | 1 | 3172.0 | 0.0% |
| industry_insight | 1 | 1246.0 | 0.0% |
| authority | 1 | 701.0 | 0.0% |


---

## Performance by Word Count Bucket

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| long (>150w) | 13 | 18090.6 | 0.0% |
| medium (80-150w) | 9 | 2631.4 | 0.0% |
| short (<80w) | 5 | 647.4 | 0.0% |


---

## Performance by Avg Line Length Bucket

| Category | Posts | Avg Impressions | Avg Engagement Rate |
|---|---|---|---|
| medium (40-70 chars) | 16 | 15297.4 | 0.0% |
| long (>70 chars) | 8 | 1925.4 | 0.0% |
| punchy (<40 chars) | 3 | 645.3 | 0.0% |

