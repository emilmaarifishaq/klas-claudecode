"""Metrics Agent — fetches LinkedIn engagement metrics via LeadShark post-stats API."""
import os
import csv
import re
import requests
from pathlib import Path
from datetime import datetime, timedelta
from urllib.parse import urlparse

RESULTS_TSV = Path("results.tsv")
LEADSHARK_BASE = "https://apex.leadshark.io"


class MetricsAgent:
    def __init__(self):
        self.api_key = os.environ["LEADSHARK_API_KEY"]
        self.headers = {"x-api-key": self.api_key}

    # ------------------------------------------------------------------ #
    # TSV helpers
    # ------------------------------------------------------------------ #

    def get_pending_posts(self) -> list:
        """Return post rows that need metric updates.

        Criteria:
        - impressions == 0 (never scraped), OR
        - post is less than 7 days old (keep refreshing recent posts)
        """
        if not RESULTS_TSV.exists():
            return []

        pending = []
        now = datetime.now()
        cutoff = now - timedelta(days=28)

        with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                post_url = row.get("post_url", "").strip()
                if not post_url or "pending" in post_url.lower():
                    continue

                impressions = int(row.get("impressions", 0) or 0)

                try:
                    post_date = datetime.strptime(row.get("date", ""), "%Y-%m-%d")
                except ValueError:
                    post_date = datetime.min

                if impressions == 0 or post_date >= cutoff:
                    pending.append({
                        "post_url": post_url,
                        "notion_tracking_id": row.get("notion_tracking_id", ""),
                        "notion_lead_magnet_url": row.get("notion_lead_magnet_url", ""),
                        "cta_keyword": row.get("cta_keyword", "GUIDE"),
                        "lm_title": row.get("lm_title", row.get("topic", "")),
                        "leadshark_automation_id": row.get("leadshark_automation_id", ""),
                        "hook_line": row.get("hook_line", ""),
                        "date": row.get("date", ""),
                    })

        return pending

    # ------------------------------------------------------------------ #
    # LeadShark stats API
    # ------------------------------------------------------------------ #

    def fetch_stats(self) -> list:
        """Fetch all recent posts from LeadShark post-stats API with pagination."""
        items = []
        cursor = None
        while True:
            url = f"{LEADSHARK_BASE}/api/post-stats"
            if cursor:
                url += f"?cursor={cursor}"
            resp = requests.get(url, headers=self.headers, timeout=30)
            resp.raise_for_status()
            data = resp.json()
            items.extend(data.get("items", []))
            cursor = data.get("paging", {}).get("cursor")
            if not cursor or not data.get("items"):
                break
        return items

    def parse_metrics(self, item: dict) -> dict:
        """Extract engagement metrics from a LeadShark stats item."""
        return {
            "impressions": int(item.get("impressions", 0) or 0),
            "likes": int(item.get("reactions", 0) or 0),
            "comments": int(item.get("comments", 0) or 0),
            "shares": int(item.get("reposts", 0) or 0),
        }

    def parse_media(self, item: dict) -> dict:
        """Extract first attachment as media dict."""
        attachments = item.get("attachments") or []
        if not attachments:
            return {"type": "", "url": "", "thumbnail": ""}
        att = attachments[0]
        return {
            "type": att.get("type", ""),
            "url": att.get("url", ""),
            "thumbnail": att.get("url", "") if att.get("type") == "img" else "",
        }

    def extract_ugcpost_urn(self, social_id: str) -> str:
        """Extract numeric ID from urn:li:ugcPost:ID or urn:li:activity:ID."""
        m = re.search(r":(\d+)$", social_id or "")
        return m.group(1) if m else ""

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #

    def run(self) -> list:
        """Full metrics flow. Returns list of update dicts."""
        pending = self.get_pending_posts()
        if not pending:
            print("  No posts need metric updates.")
            return []

        print(f"  Fetching LeadShark post stats ({len(pending)} posts pending)...")

        try:
            items = self.fetch_stats()
        except requests.exceptions.RequestException as exc:
            print(f"  LeadShark stats fetch failed: {exc}. Will retry next run.")
            return []

        if not items:
            print("  LeadShark returned no items.")
            return []

        # Index pending posts by URL path
        pending_by_path = {
            urlparse(p["post_url"]).path: p for p in pending
        }
        # Secondary index: hook_line → pending post (for unresolved URLs)
        pending_by_hook = {
            p["hook_line"].strip().lower(): p
            for p in pending
            if p.get("hook_line")
        }

        updates = []
        for item in items:
            share_url = item.get("share_url", "")
            if not share_url:
                continue

            # Match by URL path first, then by hook_line
            matching = pending_by_path.get(urlparse(share_url).path)
            if not matching and pending_by_hook:
                item_text = (item.get("text") or "").strip().lower()
                for hook, candidate in pending_by_hook.items():
                    if hook and item_text.startswith(hook):
                        matching = candidate
                        break

            if matching:
                updates.append({
                    "post_url": share_url,
                    "tsv_post_url": matching["post_url"],
                    "ugcpost_urn": self.extract_ugcpost_urn(item.get("social_id", "")),
                    "notion_tracking_id": matching.get("notion_tracking_id", ""),
                    "notion_lead_magnet_url": matching.get("notion_lead_magnet_url", ""),
                    "cta_keyword": matching.get("cta_keyword", "GUIDE"),
                    "lm_title": matching.get("lm_title", ""),
                    "leadshark_automation_id": matching.get("leadshark_automation_id", ""),
                    "metrics": self.parse_metrics(item),
                    "post_text": item.get("text", ""),
                    "media": self.parse_media(item),
                })

        print(f"  Matched metrics for {len(updates)} of {len(pending)} pending posts.")
        return updates
