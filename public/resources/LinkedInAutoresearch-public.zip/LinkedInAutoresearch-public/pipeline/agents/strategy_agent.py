"""Strategy Agent — analyzes results.tsv and rewrites strategy.md."""
import csv
import re
import json
from pathlib import Path
from datetime import datetime, timedelta
from collections import defaultdict

import anthropic

from pipeline.base_agent import BaseAgent

RESULTS_TSV = Path("results.tsv")
STRATEGY_MD = Path("strategy.md")
MIN_POSTS_FOR_ANALYSIS = 5
MIN_POST_AGE_HOURS = 48


class StrategyAgent(BaseAgent):
    system_prompt = """You are a content strategy analyst for Duncan Rogoff, a LinkedIn creator who teaches AI automation and personal branding.

Your job is to analyze post performance data and improve the content strategy.

Duncan's brand:
- Target audience: $8K-20K/mo business owners who are "expertise-rich, audience-poor"
- Voice: direct, proof-driven, operator energy, specific numbers
- Offer: The Authority System (TrendJacker + Brand Genius + LinkedIn System)
- CTA: always drives to skool.com/buildroom
- Starting hypothesis: "I" statements + specific numbers are the highest-performing hook type

When analyzing data, look for:
1. Which hook_types have the highest avg impressions_per_day and engagement rate
2. Which topics perform best (by impressions_per_day and comment rate)
3. Which post formats (list, narrative, before_after, step_by_step, q_and_a) drive highest engagement
4. Which content types (tutorial, results_reveal, case_study, how_to, story, opinion) perform best
5. Which angles (personal_experience, social_proof, contrarian, authority, curiosity_gap, aspiration, industry_insight) get most reach
6. Whether post length (word_count, line_count) correlates with impressions — shorter or longer?
7. Whether avg_line_length correlates with engagement (punchy short lines vs longer explanations)
8. What day-of-week patterns exist
9. How engagement rate differs by strategy_version (is the strategy improving?)

IMPORTANT: Use impressions_per_day as the primary performance metric, not raw impressions. A post that is 2 days old with 500 impressions (250/day) outperforms a 30-day-old post with 600 impressions (20/day). Only compare posts that are at least 2 days old for fair analysis.

Key insight to look for: the starting hypothesis is that i_statement hooks with specific numbers outperform. Confirm or disprove this with data. Be specific about which combinations work (e.g., "i_statement + results_reveal + personal_experience" vs "big_number + list + authority").

When rewriting strategy.md:
- Keep the exact same format (Strategy Version: N header, same sections)
- Increment the version number
- Update "Last Updated" date
- Update "Posts Analyzed" count
- Rewrite "What's Working" based on data
- Rewrite "What to Avoid" based on data
- Update hook type priority ranking based on actual performance
- Keep topic guidance aligned with what's working
- Be specific: cite the actual numbers from the data
- Output ONLY the full strategy.md content, no explanation"""

    # ------------------------------------------------------------------ #
    # Data sufficiency check
    # ------------------------------------------------------------------ #

    def has_sufficient_data(self, rows: list) -> tuple:
        """Check if we have enough mature data to run analysis.
        Returns (bool, reason_string).
        """
        now = datetime.now()
        threshold = now - timedelta(hours=MIN_POST_AGE_HOURS)
        mature_rows = [
            r for r in rows
            if int(r.get("impressions", 0) or 0) > 0
            and self._parse_date(r.get("date", "")) <= threshold
        ]
        if len(mature_rows) < MIN_POSTS_FOR_ANALYSIS:
            return False, (
                f"Only {len(mature_rows)} posts with 48h+ metrics "
                f"(need {MIN_POSTS_FOR_ANALYSIS})"
            )
        return True, ""

    def _parse_date(self, date_str: str) -> datetime:
        try:
            return datetime.strptime(date_str, "%Y-%m-%d")
        except (ValueError, TypeError):
            return datetime.min

    # ------------------------------------------------------------------ #
    # Data loading
    # ------------------------------------------------------------------ #

    def load_results(self, days_back: int = 30) -> list:
        """Load results.tsv rows from the last N days."""
        if not RESULTS_TSV.exists():
            return []

        cutoff = datetime.now() - timedelta(days=days_back)
        rows = []

        with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                post_date = self._parse_date(row.get("date", ""))
                if post_date >= cutoff:
                    # Coerce integer fields
                    for field in ("impressions", "likes", "comments", "shares", "strategy_version",
                                  "word_count", "line_count"):
                        try:
                            row[field] = int(row.get(field, 0) or 0)
                        except (ValueError, TypeError):
                            row[field] = 0
                    # Coerce float fields
                    try:
                        row["avg_line_length"] = float(row.get("avg_line_length", 0) or 0)
                    except (ValueError, TypeError):
                        row["avg_line_length"] = 0.0
                    # Add age-normalized metrics
                    post_date = self._parse_date(row.get("date", ""))
                    days_since = max((datetime.now() - post_date).days, 1) if post_date != datetime.min else 1
                    row["days_since_post"] = days_since
                    row["impressions_per_day"] = round(row["impressions"] / days_since, 1)
                    rows.append(row)

        return rows

    # ------------------------------------------------------------------ #
    # Pattern analysis
    # ------------------------------------------------------------------ #

    def analyze_patterns(self, rows: list) -> dict:
        """Group by hook_type and topic, compute avg impressions_per_day and engagement rate."""
        # Only use mature posts (≥2 days old) for fair comparisons
        mature_rows = [r for r in rows if r.get("days_since_post", 0) >= 2]

        def engagement_rate(r: dict) -> float:
            imps = r.get("impressions", 0)
            if not imps:
                return 0.0
            eng = r.get("likes", 0) + r.get("comments", 0) + r.get("shares", 0)
            return round(eng / imps * 100, 4)

        def _ipd(r: dict) -> float:
            return r.get("impressions_per_day", 0.0)

        # By hook type
        hook_groups: dict = defaultdict(list)
        for row in mature_rows:
            hook = row.get("hook_type", "unknown") or "unknown"
            hook_groups[hook].append(row)

        hook_stats = {}
        for hook, group in hook_groups.items():
            hook_stats[hook] = {
                "count": len(group),
                "avg_impressions_per_day": round(sum(_ipd(r) for r in group) / len(group), 1),
                "avg_impressions": round(sum(r.get("impressions", 0) for r in group) / len(group), 1),
                "avg_engagement_rate_pct": round(sum(engagement_rate(r) for r in group) / len(group), 4),
            }

        # By topic
        topic_groups: dict = defaultdict(list)
        for row in mature_rows:
            topic = row.get("topic", "unknown") or "unknown"
            topic_groups[topic].append(row)

        topic_stats = {}
        for topic, group in topic_groups.items():
            topic_stats[topic] = {
                "count": len(group),
                "avg_impressions_per_day": round(sum(_ipd(r) for r in group) / len(group), 1),
                "avg_impressions": round(sum(r.get("impressions", 0) for r in group) / len(group), 1),
                "avg_comments": round(sum(r.get("comments", 0) for r in group) / len(group), 2),
                "avg_engagement_rate_pct": round(sum(engagement_rate(r) for r in group) / len(group), 4),
            }

        # By day of week
        dow_groups: dict = defaultdict(list)
        for row in mature_rows:
            dt = self._parse_date(row.get("date", ""))
            if dt != datetime.min:
                dow = dt.strftime("%A")
                dow_groups[dow].append(row)

        dow_stats = {}
        for dow, group in dow_groups.items():
            dow_stats[dow] = {
                "count": len(group),
                "avg_impressions_per_day": round(sum(_ipd(r) for r in group) / len(group), 1),
                "avg_impressions": round(sum(r.get("impressions", 0) for r in group) / len(group), 1),
            }

        # By strategy version
        version_groups: dict = defaultdict(list)
        for row in mature_rows:
            ver = str(row.get("strategy_version", 1))
            version_groups[ver].append(row)

        version_stats = {}
        for ver, group in version_groups.items():
            version_stats[ver] = {
                "count": len(group),
                "avg_impressions_per_day": round(sum(_ipd(r) for r in group) / len(group), 1),
                "avg_impressions": round(sum(r.get("impressions", 0) for r in group) / len(group), 1),
                "avg_engagement_rate_pct": round(sum(engagement_rate(r) for r in group) / len(group), 4),
            }

        def _group_stats(rows_subset: list, label: str) -> dict:
            """Generic grouping helper: avg impressions_per_day + engagement rate."""
            groups: dict = defaultdict(list)
            for r in rows_subset:
                key = r.get(label, "unknown") or "unknown"
                groups[key].append(r)
            stats = {}
            for key, group in groups.items():
                stats[key] = {
                    "count": len(group),
                    "avg_impressions_per_day": round(sum(_ipd(r) for r in group) / len(group), 1),
                    "avg_impressions": round(sum(r.get("impressions", 0) for r in group) / len(group), 1),
                    "avg_engagement_rate_pct": round(sum(engagement_rate(r) for r in group) / len(group), 4),
                }
            return stats

        # Word count and line length correlations (buckets)
        def bucket_word_count(wc: int) -> str:
            if wc < 80: return "short (<80w)"
            if wc < 150: return "medium (80-150w)"
            return "long (>150w)"

        def bucket_line_length(al: float) -> str:
            if al < 40: return "punchy (<40 chars)"
            if al < 70: return "medium (40-70 chars)"
            return "long (>70 chars)"

        wc_groups: dict = defaultdict(list)
        ll_groups: dict = defaultdict(list)
        for row in mature_rows:
            wc_groups[bucket_word_count(row.get("word_count", 0))].append(row)
            ll_groups[bucket_line_length(row.get("avg_line_length", 0.0))].append(row)

        wc_stats = {k: {"count": len(g), "avg_impressions_per_day": round(sum(_ipd(r) for r in g)/len(g),1), "avg_impressions": round(sum(r.get("impressions",0) for r in g)/len(g),1), "avg_engagement_rate_pct": round(sum(engagement_rate(r) for r in g)/len(g),4)} for k,g in wc_groups.items()}
        ll_stats = {k: {"count": len(g), "avg_impressions_per_day": round(sum(_ipd(r) for r in g)/len(g),1), "avg_impressions": round(sum(r.get("impressions",0) for r in g)/len(g),1), "avg_engagement_rate_pct": round(sum(engagement_rate(r) for r in g)/len(g),4)} for k,g in ll_groups.items()}

        return {
            "by_hook_type": hook_stats,
            "by_topic": topic_stats,
            "by_format": _group_stats(mature_rows, "format"),
            "by_content_type": _group_stats(mature_rows, "content_type"),
            "by_angle": _group_stats(mature_rows, "angle"),
            "by_word_count_bucket": wc_stats,
            "by_avg_line_length_bucket": ll_stats,
            "by_day_of_week": dow_stats,
            "by_strategy_version": version_stats,
            "total_posts": len(rows),
            "mature_posts_analyzed": len(mature_rows),
            "date_range_days": 30,
        }

    # ------------------------------------------------------------------ #
    # Version bumping
    # ------------------------------------------------------------------ #

    def bump_version(self, content: str) -> str:
        """Increment Strategy Version: N by 1."""
        return re.sub(
            r"Strategy Version:\s*(\d+)",
            lambda m: f"Strategy Version: {int(m.group(1)) + 1}",
            content,
        )

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #

    def run(self, **kwargs) -> dict:
        rows = self.load_results(days_back=30)
        sufficient, reason = self.has_sufficient_data(rows)

        if not sufficient:
            print(f"  Strategy analysis skipped: {reason}")
            return {"skipped": True, "reason": reason}

        analysis = self.analyze_patterns(rows)
        current_strategy = STRATEGY_MD.read_text(encoding="utf-8")

        previous_findings = ""
        findings_path = Path("autoresearch_findings.md")
        if findings_path.exists():
            previous_findings = f"""Here are the findings from the previous autoresearch run:

{findings_path.read_text(encoding="utf-8")}

"""

        prompt = f"""Here is the performance data from the last 30 days:

{json.dumps(analysis, indent=2)}

Here is the current strategy.md:

{current_strategy}

{previous_findings}Today's date: {datetime.now().strftime('%Y-%m-%d')}
Total posts in window: {len(rows)} | Mature posts (≥2 days old) used for analysis: {analysis.get('mature_posts_analyzed', 0)}

Please rewrite strategy.md based on the performance data. Keep the same format but update all sections based on what the data shows. Where previous findings exist, note whether the new data confirms, contradicts, or extends those findings. Output ONLY the full strategy.md content."""

        new_strategy = self.call(prompt, max_tokens=2000)

        STRATEGY_MD.write_text(new_strategy, encoding="utf-8")

        match = re.search(r"Strategy Version:\s*(\d+)", new_strategy)
        new_version = int(match.group(1)) if match else 1

        print(
            f"  Strategy updated to v{new_version} "
            f"({len(rows)} posts analyzed)."
        )

        return {
            "skipped": False,
            "new_version": new_version,
            "posts_analyzed": len(rows),
            "analysis": analysis,
        }
