"""Post Writer Agent — generates a LinkedIn post to promote the lead magnet."""
import json
import re
from pathlib import Path

from pipeline.base_agent import BaseAgent

_REPO_ROOT = Path(__file__).resolve().parents[2]

# Valid classification labels
_HOOK_TYPES     = ["i_statement", "transformation", "big_number", "contrarian", "question", "list"]
_FORMAT_TYPES   = ["list", "narrative", "before_after", "step_by_step", "q_and_a"]
_CONTENT_TYPES  = ["tutorial", "results_reveal", "case_study", "how_to", "story", "opinion", "announcement"]
_ANGLE_TYPES    = ["personal_experience", "social_proof", "contrarian", "authority", "curiosity_gap", "aspiration", "industry_insight"]

_SYSTEM_PROMPT = """You are Duncan Rogoff's LinkedIn ghostwriter.

Duncan's voice:
- Direct, operator energy, no fluff
- Proof-driven: numbers dominate, adjectives are rare
- Short punchy sentences. One idea per line.
- White space between every sentence group — this is LinkedIn, not an essay.
- Never starts with a question.
- Uses "→" for bullet points, never "-" or "*"
- No markdown formatting (no bold, no italics, no headers)
- Reads at a 6th grade level

Duncan's proof points (use these verbatim — do not invent new numbers):
- 0 to 110K+ followers across channels in under 12 months
- $150K+ in revenue from content
- $5/day total AI tooling cost
- 80% reduction in research time
- 6 AI sub-agents running his full content pipeline

Target audience:
- Independent business owners doing $8K-20K/month from referrals
- Great at their craft. No audience. Feels like the best-kept secret.
- Referrals drying up. Ready to build visibility but has tried posting and felt cringe.
- Transformation they want: first leads in 14 days, 1500 real followers in 49 days

Post structure (follow exactly):
1. Hook line — I-statement + specific number (e.g. "I grew my LinkedIn to 10K followers. Claude Code automated 80% of it.")
2. Setup sentence — one line that earns the right to keep reading
3. 2-3 body sentences — proof, context, or a sharp insight. Numbers required.
4. Transition line — "Here's what's inside:" or "Here's what you get:"
5. 5-7 bullet points using → (each 8-15 words, concrete and specific)
6. Payoff sentence — one line that connects the content to their outcome
7. CTA line — exactly: Comment "[KEYWORD]" and I'll send it over.
8. Optional: Like or repost ask (one short line, not required every time)

Hook type priority (use this order unless the topic clearly suits another):
1. transformation — "I went from X to Y in N days." Numbers + result in the first line. This is the default.
2. big_number — Lead with a specific impressive metric. Make it impossible to scroll past.
3. i_statement — "I [result] in [timeframe]. [Tool/method] made it happen." Use when there's no clear before/after.
4. contrarian — Challenge common wisdom (only if the topic supports it)

Numbers rule: The first line must contain at least one specific number. Every hook needs a result or metric upfront — not buried in line 3.

Numbers rule: Specific numbers must appear in the hook AND at least 2 more times in the body.

Output format:
Return ONLY two sections separated by exactly this delimiter on its own line:
---METADATA---
First section: the post text (no labels, no quotes, plain text ready to paste into LinkedIn)
Second section: a JSON object with these keys:
  - hook_type: one of [i_statement, transformation, big_number, contrarian, question, list]
  - format: one of [list, narrative, before_after, step_by_step, q_and_a]
  - content_type: one of [tutorial, results_reveal, case_study, how_to, story, opinion, announcement]
  - angle: one of [personal_experience, social_proof, contrarian, authority, curiosity_gap, aspiration, industry_insight]
  - overlay_system: Short clickbait phrase for the video overlay top line (Gotham Medium). Max 28 characters — must fit on one line. Should be punchy and scroll-stopping — like a YouTube thumbnail or viral hook. Examples: "10 Claude skills that slap", "The AI cheat code nobody shares", "Stop wasting time on this", "This broke my content game"
  - overlay_result: Short punchy payoff for the video overlay bottom line (Gotham Ultra). Max 28 characters — one line only. The exclamation point, the outcome, the flex. Examples: "This sh*t works.", "Cheat code. Steal it.", "10x output. $5/day.", "I'm never going back."

Definitions:
- format/list: post uses → bullet points as its primary structure
- format/narrative: flows as prose paragraphs
- format/before_after: explicit contrast between old state and new state
- format/step_by_step: numbered or ordered sequence
- format/q_and_a: poses and answers a question
- content_type/tutorial: teaches how to do something
- content_type/results_reveal: shares a specific outcome/result
- content_type/case_study: tells the story of a transformation
- content_type/how_to: practical instructions (similar to tutorial but more prescriptive)
- content_type/story: narrative arc, personal journey
- content_type/opinion: takes a clear stance or position
- content_type/announcement: launches something new
- angle/personal_experience: "I did X and here's what happened"
- angle/social_proof: references others' results or social validation
- angle/contrarian: challenges common belief
- angle/authority: leads with credentials or track record
- angle/curiosity_gap: creates intrigue without revealing the answer upfront
- angle/aspiration: paints the desired future state
- angle/industry_insight: shares a market or trend observation

Example output format:
I built a 6-agent AI system that runs my entire content operation.

Total cost: $5/day.

[rest of post...]

Comment "KEYWORD" and I'll send it over.
---METADATA---
{"hook_type": "i_statement", "format": "list", "content_type": "results_reveal", "angle": "personal_experience", "overlay_system": "The AI cheat code nobody shares", "overlay_result": "This sh*t works."}"""


class PostWriterAgent(BaseAgent):
    system_prompt = _SYSTEM_PROMPT

    def run(self, topic: dict, lead_magnet: dict, **kwargs) -> dict:
        """Generate LinkedIn post, save it, return metadata dict."""
        audience = self.load_file(str(_REPO_ROOT / "AudienceInfo.md"))
        strategy = self.load_file(str(_REPO_ROOT / "strategy.md"))
        example2 = self.load_file(str(_REPO_ROOT / "examples" / "example2.md"))
        example3 = self.load_file(str(_REPO_ROOT / "examples" / "example3.md"))

        user_message = self._build_user_message(
            topic, lead_magnet, audience, strategy, example2, example3
        )

        raw = self.call(user_message, max_tokens=1024)
        post_text, meta = self._parse_response(raw)

        cta_keyword = lead_magnet.get("cta_keyword", topic.get("cta_keyword", "GUIDE"))
        today = self.today()
        self.save_output(f"{today}-post.txt", post_text)

        stats = self._compute_post_stats(post_text)

        return {
            "post_text": post_text,
            "hook_type": meta.get("hook_type", "i_statement"),
            "format": meta.get("format", "list"),
            "content_type": meta.get("content_type", "tutorial"),
            "angle": meta.get("angle", "personal_experience"),
            "hook_line": post_text.split("\n")[0].strip() if post_text else "",
            "word_count": stats["word_count"],
            "line_count": stats["line_count"],
            "avg_line_length": stats["avg_line_length"],
            "cta_keyword": cta_keyword,
            "overlay_system": meta.get("overlay_system", ""),
            "overlay_result": meta.get("overlay_result", ""),
        }

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def _build_user_message(
        self,
        topic: dict,
        lead_magnet: dict,
        audience: str,
        strategy: str,
        example2: str,
        example3: str,
    ) -> str:
        lm_title = lead_magnet.get("title", topic.get("topic", ""))
        lm_concept = topic.get("lead_magnet_concept", "")
        cta_keyword = lead_magnet.get("cta_keyword", topic.get("cta_keyword", "GUIDE"))
        framework = topic.get("storytelling_framework", "BAB")

        # Extract key bullet points from the lead magnet JSON if available
        sections_preview = ""
        full_json = lead_magnet.get("full_json", {})
        notion_doc = full_json.get("notion_document", {})
        sections = notion_doc.get("sections", [])
        section_labels = [s.get("label", "") for s in sections if s.get("label")]
        if section_labels:
            sections_preview = "Lead magnet sections: " + ", ".join(section_labels)

        return f"""Write a LinkedIn post promoting this lead magnet.

LEAD MAGNET DETAILS:
- Title: {lm_title}
- Topic: {topic.get("topic", "")}
- Concept: {lm_concept}
- CTA keyword: {cta_keyword}
- Storytelling framework used in the lead magnet: {framework}
{sections_preview}

CURRENT STRATEGY HOOK PRIORITY:
{self._extract_hook_priority(strategy)}

---
FEW-SHOT EXAMPLE 1 (study the voice and structure):
{example2}

---
FEW-SHOT EXAMPLE 2 (study the voice and structure):
{example3}

---
INSTRUCTIONS:
- Write in Duncan's voice: direct, proof-driven, operator energy
- Hook must be an I-statement with a specific number (follow hook priority from strategy)
- Include at least 2 more numbers in the body (use Duncan's proof points)
- Use → for bullets, no other bullet style
- No markdown formatting anywhere in the post
- White space between every sentence or group
- CTA must be exactly: Comment "{cta_keyword}" and I'll send it over.
- The post is for the target avatar: $8K-20K/mo business owner who feels like the best-kept secret
- Do not copy the example posts — use them only to calibrate voice and structure

Write the post now, then the delimiter, then the hook type label."""

    def _extract_hook_priority(self, strategy: str) -> str:
        """Pull the hook type priority lines from strategy.md."""
        lines = strategy.splitlines()
        in_section = False
        result = []
        for line in lines:
            if "Hook Type Priority" in line:
                in_section = True
                continue
            if in_section:
                if line.startswith("##") and "Hook Type Priority" not in line:
                    break
                if line.strip():
                    result.append(line.strip())
        return "\n".join(result) if result else "1. i_statement\n2. transformation\n3. big_number"

    def _parse_response(self, raw: str) -> tuple[str, dict]:
        """Split Claude's response on the delimiter, return (post_text, metadata_dict)."""
        delimiter = "---METADATA---"
        if delimiter in raw:
            parts = raw.split(delimiter)
            post_text = parts[0].strip()
            meta_raw = parts[1].strip() if len(parts) > 1 else "{}"
            try:
                meta = json.loads(meta_raw)
            except json.JSONDecodeError:
                meta = {}
        else:
            post_text = raw.strip()
            meta = {}

        # Validate / fallback each field
        meta["hook_type"] = self._validate(meta.get("hook_type", ""), _HOOK_TYPES, post_text, "hook_type")
        meta["format"] = self._validate(meta.get("format", ""), _FORMAT_TYPES, post_text, "format")
        meta["content_type"] = self._validate(meta.get("content_type", ""), _CONTENT_TYPES, post_text, "content_type")
        meta["angle"] = self._validate(meta.get("angle", ""), _ANGLE_TYPES, post_text, "angle")

        return post_text, meta

    def _validate(self, value: str, valid_set: list, post_text: str, field: str) -> str:
        """Return value if valid, else infer or return first option."""
        if value in valid_set:
            return value
        if field == "hook_type":
            return self._infer_hook_type(post_text)
        return valid_set[0]

    def _infer_hook_type(self, post_text: str) -> str:
        """Infer hook_type from the first line when Claude's label is missing/invalid."""
        first_line = post_text.split("\n")[0].lower() if post_text else ""
        if first_line.startswith("i "):
            if re.search(r"\bfrom\b.+\bto\b", first_line):
                return "transformation"
            return "i_statement"
        if re.search(r"\d[\d,]*[kK%]?\b", first_line):
            return "big_number"
        if first_line.endswith("?"):
            return "question"
        contrarian_words = ["wrong", "lie", "myth", "stop", "don't", "nobody", "most people"]
        if any(w in first_line for w in contrarian_words):
            return "contrarian"
        if ":" in first_line or first_line.startswith("here"):
            return "list"
        return "i_statement"

    def _compute_post_stats(self, post_text: str) -> dict:
        """Compute word count, line count, and avg line length from post text."""
        if not post_text:
            return {"word_count": 0, "line_count": 0, "avg_line_length": 0}
        lines = [l for l in post_text.splitlines() if l.strip()]
        word_count = len(post_text.split())
        line_count = len(lines)
        avg_line_length = round(sum(len(l) for l in lines) / line_count, 1) if lines else 0
        return {"word_count": word_count, "line_count": line_count, "avg_line_length": avg_line_length}
