"""Logger Agent — writes post data to results.tsv and creates/updates the Notion tracking row."""
import os
import csv
import re
from pathlib import Path
from datetime import datetime

from pipeline.agents.notion_agent import NotionAgent

RESULTS_TSV = Path("results.tsv")

TSV_COLUMNS = [
    "date",
    "post_url",
    "notion_lead_magnet_url",
    "topic",
    "lm_type",
    "lm_theme",
    "lm_title",
    "cta_keyword",
    "hook_type",
    "hook_line",
    "format",
    "content_type",
    "angle",
    "word_count",
    "line_count",
    "avg_line_length",
    "impressions",
    "likes",
    "comments",
    "shares",
    "overlay_system",
    "overlay_result",
    "strategy_version",
    "blotato_submission_id",
    "ugcpost_urn",
    "leadshark_automation_id",
    "notion_tracking_id",
]


class LoggerAgent:
    def __init__(self):
        self.notion = NotionAgent()

    # ------------------------------------------------------------------ #
    # TSV helpers
    # ------------------------------------------------------------------ #

    def append_to_tsv(self, row: dict):
        """Append a row to results.tsv. Creates header if file doesn't exist or is empty."""
        file_exists = RESULTS_TSV.exists() and RESULTS_TSV.stat().st_size > 0

        with RESULTS_TSV.open("a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=TSV_COLUMNS, delimiter="\t", extrasaction="ignore")
            if not file_exists:
                writer.writeheader()
            writer.writerow({col: row.get(col, "") for col in TSV_COLUMNS})

    def update_tsv_metrics(self, post_url: str, metrics: dict):
        """Find the row with matching post_url and update its metrics columns."""
        if not RESULTS_TSV.exists():
            return

        with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            rows = list(reader)
            fieldnames = reader.fieldnames or TSV_COLUMNS

        updated = False
        for row in rows:
            if row.get("post_url", "").strip() == post_url.strip():
                row["impressions"] = str(metrics.get("impressions", row.get("impressions", 0)))
                row["likes"] = str(metrics.get("likes", row.get("likes", 0)))
                row["comments"] = str(metrics.get("comments", row.get("comments", 0)))
                row["shares"] = str(metrics.get("shares", row.get("shares", 0)))
                updated = True

        if not updated:
            return  # URL not found — nothing to update

        with RESULTS_TSV.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)

    # ------------------------------------------------------------------ #
    # Strategy version
    # ------------------------------------------------------------------ #

    def _get_strategy_version(self) -> int:
        """Read Strategy Version number from strategy.md."""
        try:
            content = Path("strategy.md").read_text(encoding="utf-8")
            match = re.search(r"Strategy Version:\s*(\d+)", content)
            return int(match.group(1)) if match else 1
        except Exception:
            return 1

    # ------------------------------------------------------------------ #
    # Entry points
    # ------------------------------------------------------------------ #

    def run(self, topic: dict, post_data: dict, notion_data: dict, pub_data: dict, lm_data: dict = None):
        """Log a new post to results.tsv and create Notion tracking row."""
        lm_data = lm_data or {}
        strategy_version = self._get_strategy_version()

        row = {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "post_url": pub_data.get("post_url", ""),
            "notion_lead_magnet_url": notion_data.get("page_url", ""),
            "topic": topic.get("topic", ""),
            "lm_type": lm_data.get("lm_type", ""),
            "lm_theme": lm_data.get("lm_theme", ""),
            "lm_title": lm_data.get("title", ""),
            "cta_keyword": post_data.get("cta_keyword", ""),
            "hook_type": post_data.get("hook_type", ""),
            "hook_line": post_data.get("hook_line", ""),
            "format": post_data.get("format", ""),
            "content_type": post_data.get("content_type", ""),
            "angle": post_data.get("angle", ""),
            "word_count": post_data.get("word_count", 0),
            "line_count": post_data.get("line_count", 0),
            "avg_line_length": post_data.get("avg_line_length", 0),
            "overlay_system": post_data.get("overlay_system", ""),
            "overlay_result": post_data.get("overlay_result", ""),
            "blotato_submission_id": pub_data.get("submission_id", ""),
            "impressions": 0,
            "likes": 0,
            "comments": 0,
            "shares": 0,
            "strategy_version": strategy_version,
            "notion_tracking_id": "",
        }

        # Create Notion tracking row
        try:
            notion_row_id = self.notion.create_tracking_row({
                "title": topic.get("topic", ""),
                "post_url": pub_data.get("post_url", ""),
                "notion_lead_magnet_url": notion_data.get("page_url", ""),
                "published_date": row["date"],
                "topic": topic.get("topic", ""),
                "lm_type": lm_data.get("lm_type", ""),
                "lm_theme": lm_data.get("lm_theme", ""),
                "hook_type": post_data.get("hook_type", ""),
                "hook_line": post_data.get("hook_line", ""),
                "format": post_data.get("format", ""),
                "content_type": post_data.get("content_type", ""),
                "angle": post_data.get("angle", ""),
                "word_count": post_data.get("word_count", 0),
                "line_count": post_data.get("line_count", 0),
                "avg_line_length": post_data.get("avg_line_length", 0),
                "overlay_system": post_data.get("overlay_system", ""),
                "overlay_result": post_data.get("overlay_result", ""),
                "strategy_version": strategy_version,
                "post_text": post_data.get("post_text", ""),
            })
            row["notion_tracking_id"] = notion_row_id
        except Exception as exc:
            # Print response body if available (Notion API errors are often in resp.text)
            detail = ""
            if hasattr(exc, "response") and exc.response is not None:
                detail = f" — {exc.response.text[:300]}"
            print(f"  Warning: Notion tracking row creation failed: {exc}{detail}")

        self.append_to_tsv(row)
        print(f"  Logged to results.tsv (strategy_version={strategy_version})")

    def update_tsv_column(self, post_url: str, column: str, value: str):
        """Update a single column for the row matching post_url."""
        if not RESULTS_TSV.exists():
            return
        with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            rows = list(reader)
            fieldnames = reader.fieldnames or TSV_COLUMNS
        for row in rows:
            if row.get("post_url", "").strip() == post_url.strip():
                row[column] = str(value)
        with RESULTS_TSV.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)

    def update_metrics(self, updates: list):
        """Update metrics for multiple posts. Called by metrics_orchestrator."""
        for update in updates:
            post_url = update.get("post_url", "")
            metrics = update.get("metrics", {})

            tsv_url = update.get("tsv_post_url") or post_url
            if tsv_url:
                self.update_tsv_metrics(tsv_url, metrics)
                ugcpost_urn = update.get("ugcpost_urn", "")
                if ugcpost_urn:
                    self.update_tsv_column(tsv_url, "ugcpost_urn", ugcpost_urn)

            notion_tracking_id = update.get("notion_tracking_id", "")
            if notion_tracking_id:
                try:
                    self.notion.update_metrics_row(
                        notion_tracking_id, metrics,
                        post_text=update.get("post_text", ""),
                        media=update.get("media"),
                    )
                except Exception as exc:
                    print(f"  Warning: Notion metrics update failed for {notion_tracking_id}: {exc}")

        print(f"  Updated metrics for {len(updates)} posts.")
