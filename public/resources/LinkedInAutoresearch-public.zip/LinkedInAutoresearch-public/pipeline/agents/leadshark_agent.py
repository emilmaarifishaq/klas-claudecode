"""LeadShark Agent — creates a post automation that DMs commenters the lead magnet."""
import os
import re
import requests
from urllib.parse import urlparse, urlunparse

LEADSHARK_BASE = "https://apex.leadshark.io"


def _strip_utm(url: str) -> str:
    """Remove query string (UTM params etc.) from a URL."""
    p = urlparse(url)
    return urlunparse(p._replace(query="", fragment=""))


def _extract_post_id(post_url: str) -> str:
    """Extract the numeric LinkedIn post ID from a post URL.

    Handles formats like:
    - https://www.linkedin.com/posts/username_activity-7150123456789012345-xxxx
    - https://www.linkedin.com/feed/update/urn:li:activity:7150123456789012345
    """
    # activity-DIGITS or activity:DIGITS
    match = re.search(r"activity[:\-](\d+)", post_url)
    if match:
        return match.group(1)
    # Fallback: last long numeric sequence in the URL
    numbers = re.findall(r"\d{10,}", post_url)
    return numbers[-1] if numbers else ""


class LeadSharkAgent:
    def __init__(self):
        self.api_key = os.environ["LEADSHARK_API_KEY"]
        self.headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
        }

    def create_automation(
        self,
        name: str,
        post_id: str,
        post_url: str,
        keyword: str,
        dm_template: str,
    ) -> dict:
        """Create a LeadShark automation that fires when someone comments the keyword."""
        # LeadShark expects the full URN, not just the numeric ID
        if post_id and not post_id.startswith("urn:"):
            post_id = f"urn:li:ugcPost:{post_id}"

        payload = {
            "name": name,
            "post_id": post_id,
            "linkedin_post_url": post_url,
            "keywords": [keyword],
            "dm_template": dm_template,
            "comment_reply_template": [
                "{{fullNameMention}} just sent!",
                "{{fullNameMention}} DM'd you!",
                "{{fullNameMention}} check your inbox!",
                "{{fullNameMention}} check your DMs!",
                "{{fullNameMention}} sent!",
            ],
            "non_first_degree_reply_template": ["{{fullNameMention}} connect with me!"],
            "auto_connect": True,
            "auto_like": True,
        }
        resp = requests.post(
            f"{LEADSHARK_BASE}/api/automations",
            json=payload,
            headers=self.headers,
            timeout=30,
        )
        if resp.status_code == 409:
            # Automation already exists for this post — not an error
            print(f"  LeadShark: automation already exists for post_id {payload.get('post_id')}")
            return {"id": f"existing:{payload.get('post_id')}", "already_exists": True}
        if not resp.ok:
            print(f"  LeadShark API error {resp.status_code}: {resp.text[:500]}")
            resp.raise_for_status()
        return resp.json()

    def get_post_stats(self) -> list:
        """Fetch recent posts from LeadShark stats API. Returns list of post dicts."""
        resp = requests.get(
            f"{LEADSHARK_BASE}/api/post-stats",
            headers=self.headers,
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json().get("items", [])

    def find_post_by_hook(self, hook_line: str) -> dict | None:
        """Find a post in LeadShark stats whose text starts with the hook_line."""
        hook = hook_line.strip().lower()
        for item in self.get_post_stats():
            text = (item.get("text") or "").strip().lower()
            if text.startswith(hook):
                return item
        return None

    def run(self, post_data: dict, notion_data: dict, pub_data: dict, lm_title: str) -> dict:
        """
        Create a LeadShark automation for the published post.

        Returns the automation ID (or empty string if LEADSHARK_API_KEY not set).
        """
        if not os.environ.get("LEADSHARK_API_KEY"):
            print("  Warning: LEADSHARK_API_KEY not set — skipping LeadShark automation.")
            return {"automation_id": ""}

        post_url = _strip_utm(pub_data.get("post_url", ""))
        post_id = _extract_post_id(post_url)

        if not post_id:
            print(f"  Warning: could not extract post ID from URL '{post_url}' — skipping LeadShark.")
            return {"automation_id": ""}

        keyword = post_data.get("cta_keyword", "GUIDE").upper()
        explicit_post_id = post_data.get("post_id", "")
        notion_url = notion_data.get("page_url", "")

        dm_template = (
            f"Hey {{{{firstName}}}}!\n\n"
            f"Here is the full {lm_title}:\n"
            f"{notion_url}\n\n"
            f"Enjoy! Let me know if you have any questions."
        )

        automation_name = f"{lm_title} — {keyword}"
        final_post_id = explicit_post_id or post_id

        print(f"  Creating LeadShark automation: '{automation_name}' (keyword: {keyword}, post_id: {final_post_id})")
        result = self.create_automation(
            name=automation_name,
            post_id=final_post_id,
            post_url=post_url,
            keyword=keyword,
            dm_template=dm_template,
        )

        automation_id = result.get("id", result.get("automation_id", ""))
        print(f"  LeadShark automation created: {automation_id}")
        return {"automation_id": automation_id}
