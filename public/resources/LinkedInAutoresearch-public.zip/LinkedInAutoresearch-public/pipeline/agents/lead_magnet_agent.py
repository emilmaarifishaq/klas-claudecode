"""Lead Magnet Agent — generates a full lead magnet JSON document from the selected topic."""
import json
from pathlib import Path

from pipeline.base_agent import BaseAgent

_REPO_ROOT = Path(__file__).resolve().parents[2]

# ---------------------------------------------------------------------------
# JSON FORMAT SPEC (hardcoded — source of truth for Notion document schema)
# ---------------------------------------------------------------------------
_JSON_FORMAT_SPEC = """
## Lead Magnet JSON Format Specification

Top-level shape:
{
  "notion_document": { ... },
  "social_promo": { ... }
}

### notion_document

Fields:
- title: string — document title
- subtitle: string — one-line description
- metadata: object
    - created: string (ISO date)
    - version: string (e.g. "1.0")
    - target_audience: string
    - prose_word_count: integer (target 1000-1500)
    - cta_url: "skool.com/buildroom"
    - cta_label: string
- page_settings: object
    - cover: { "color": "#0F1117" }
    - icon: string (one emoji)
    - full_width: true
- sections: array of section objects

### Section object
{
  "id": "section-slug",
  "label": "Section Display Name",
  "blocks": [ ...block objects... ]
}

### Block types

heading_1:  { "type": "heading_1", "content": "string" }
heading_2:  { "type": "heading_2", "content": "string" }
heading_3:  { "type": "heading_3", "content": "string" }
paragraph:  { "type": "paragraph", "content": "string" }
divider:    { "type": "divider" }
bulleted_list_item: { "type": "bulleted_list_item", "content": "string" }
numbered_list_item: { "type": "numbered_list_item", "content": "string" }
code:       { "type": "code", "content": "string", "language": "string" }

table:
{
  "type": "table",
  "headers": ["Col A", "Col B"],
  "rows": [["cell", "cell"], ...]
}

callout (standard):
{
  "type": "callout",
  "icon": "emoji",
  "content": "string",
  "styling": { "background": "blue" | "gray" | "green" | "yellow" | "red" | "purple" | "pink" | "brown" }
}

CTA callout — ALWAYS use this exact shape for any call-to-action block:
{
  "type": "callout",
  "icon": "🚀",
  "content": "<compelling action sentence>\\n\\n👉 Join The Build Room ($97/month) at skool.com/buildroom",
  "styling": { "background": "purple" }
}

Copy-paste prompt callout — use for any prompt the reader should copy:
{
  "type": "callout",
  "icon": "📋",
  "content": "<label>\\n\\n<the full prompt text>",
  "styling": { "background": "gray" }
}

### social_promo
{
  "linkedin_hook": "string — first 1-2 lines of the LinkedIn post",
  "instagram_hook": "string — shorter hook variant",
  "cta_trigger": "string — ALL CAPS keyword (matches cta_keyword from research)"
}

### Top-level metadata (add these alongside notion_document and social_promo)
"lm_type": one of [guide, framework, prompt_pack, checklist, swipe_file, playbook, template]
"lm_theme": 5-10 words describing the core idea (e.g. "AI content system that replaces manual research")

### CRITICAL RULES
- NEVER use **bold** markdown in any content string. Use plain text only.
- NEVER use *italic* markdown in content strings. Use plain text only.
- All prose must be plain text. Styling is handled by block type and the styling object.
- prose_word_count must be between 1000 and 1500.
- There must be a purple 🚀 CTA callout BEFORE the first main content section.
- There must be a purple 🚀 CTA callout as the LAST block in the document.
- Include at least 3 copy-paste prompts in 📋 gray callout blocks within the content.
- Required section order: header → intro/how-to-use → [early CTA] → main content sections → final CTA
"""

# ---------------------------------------------------------------------------
# VOICE & RULES SPEC (hardcoded)
# ---------------------------------------------------------------------------
_VOICE_AND_RULES = """
## Duncan's Voice & Writing Rules

Reading level: 6th grade. Hormozi-simple. Every sentence earns its place.

Core principles:
- Concrete over abstract. No hedging. No filler.
- Proof over persuasion: numbers, not adjectives.
- If you can cut a word without losing meaning, cut it.
- Short sentences. White space. No wall-of-text paragraphs.

Section titles and headings must be plain and direct. No invented jargon. No "The X Trigger", no "The Y Framework", no named concepts. Just say what the section does. Bad: "The Epistemic Honesty Trigger". Good: "How to Write Hooks That Get Clicks".

Duncan's proof points (use these — don't invent others):
- 0 to 110K+ followers across channels in less than 12 months
- $150K+ in revenue directly from content
- $5/day total AI tooling cost
- 80% reduction in research time using AI
- 6 AI sub-agents running his full content pipeline

Lead magnet structure (follow this order exactly):
1. Header section (title + subtitle)
2. Intro / How-to-Use section
3. Early CTA (purple 🚀 callout) — MANDATORY before main content
4. Main content sections (3–6 sections with real substance)
5. Final CTA (purple 🚀 callout)

Storytelling frameworks — pick one and commit:
- BAB (Before/After/Bridge): Open with the painful before state, paint the after, then bridge with the system
- Origin: Duncan's personal story — zero audience, discovered the method, built it, results followed
- CaseStudy: Walk through a real or illustrative example step by step with numbers
- BehindCurtain: Show exactly how Duncan's system works, no gatekeeping, inside look

Content requirements:
- At least 3 copy-paste prompts in 📋 gray callout blocks
- Numbers must appear throughout: follower counts, revenue, time saved, days, percentages
- Every section should teach something the reader can act on today
- The offer (skool.com/buildroom) is The Authority System — frame it as the shortcut to the full system
"""


class LeadMagnetAgent(BaseAgent):
    system_prompt = (
        "You are an expert content creator and copywriter who builds high-converting lead magnets "
        "for LinkedIn. You write in Duncan Rogoff's voice: direct, proof-driven, operator energy, no fluff. "
        "You output ONLY valid JSON — no markdown code blocks, no explanation text, no preamble. "
        "Raw JSON object only. Your output must be parseable by json.loads() with zero modification.\n\n"
        + _JSON_FORMAT_SPEC
        + "\n\n"
        + _VOICE_AND_RULES
    )

    def run(self, topic: dict, **kwargs) -> dict:
        """Generate lead magnet JSON, save it, return metadata dict."""
        audience = self.load_file(str(_REPO_ROOT / "AudienceInfo.md"))
        strategy = self.load_file(str(_REPO_ROOT / "strategy.md"))
        today = self.today()

        user_message = self._build_user_message(topic, audience, strategy, today)

        # First attempt
        raw = self.call(user_message, max_tokens=8192)
        parsed, error = self._parse_json(raw)

        # One retry on parse failure
        if parsed is None:
            retry_message = (
                f"{user_message}\n\n"
                f"---\nYOUR PREVIOUS RESPONSE FAILED JSON PARSING WITH ERROR:\n{error}\n\n"
                "Fix the JSON and return ONLY the corrected raw JSON object. No markdown. No explanation."
            )
            raw = self.call(retry_message, max_tokens=8192)
            parsed, error = self._parse_json(raw)
            if parsed is None:
                raise ValueError(
                    f"LeadMagnetAgent: JSON parse failed after retry.\nError: {error}\nRaw:\n{raw[:500]}"
                )

        # Extract key fields
        notion_doc = parsed.get("notion_document", {})
        title = notion_doc.get("title", topic.get("topic", "Untitled"))
        cta_keyword = (
            parsed.get("social_promo", {}).get("cta_trigger")
            or topic.get("cta_keyword", "GUIDE")
        )
        lm_type = parsed.get("lm_type", topic.get("lm_type", "guide"))
        lm_theme = parsed.get("lm_theme", topic.get("lead_magnet_concept", ""))

        filename = f"{today}-lead-magnet.json"
        json_path = self.save_output(filename, parsed)

        return {
            "title": title,
            "cta_keyword": cta_keyword,
            "lm_type": lm_type,
            "lm_theme": lm_theme,
            "json_path": str(json_path),
            "full_json": parsed,
        }

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def _build_user_message(
        self, topic: dict, audience: str, strategy: str, today: str
    ) -> str:
        return f"""Build a complete lead magnet JSON document using the spec in your system prompt.

TODAY'S DATE: {today}

TOPIC SELECTED BY RESEARCH AGENT:
- Topic: {topic.get("topic", "")}
- Reddit source: {topic.get("reddit_title", "")} (r/{topic.get("subreddit", "")})
- Lead magnet concept: {topic.get("lead_magnet_concept", "")}
- Storytelling framework to use: {topic.get("storytelling_framework", "BAB")}
- CTA keyword: {topic.get("cta_keyword", "GUIDE")}

TARGET AUDIENCE:
{audience}

CURRENT STRATEGY CONTEXT:
{strategy}

REQUIREMENTS:
- Output ONLY valid JSON. No markdown. No code blocks. No explanation.
- NEVER use **bold** or *italic* markdown in any content string — plain text only.
- prose_word_count must be between 1000 and 1500.
- Use the storytelling framework: {topic.get("storytelling_framework", "BAB")}
- Include a purple 🚀 CTA callout BEFORE the first main content section.
- Include a purple 🚀 CTA callout as the LAST block.
- Include at least 3 copy-paste prompts in 📋 gray callouts.
- Reference Duncan's proof points: 110K+ followers, $150K+ content revenue, $5/day AI cost, 80% time saved.
- CTA always points to skool.com/buildroom.
- The social_promo.cta_trigger must be: {topic.get("cta_keyword", "GUIDE")}

Output the JSON now:"""

    def _parse_json(self, raw: str) -> tuple[dict | None, str | None]:
        """Try to parse raw Claude response as JSON. Returns (parsed, error)."""
        cleaned = raw.strip()

        # Strip markdown fences if present
        if cleaned.startswith("```"):
            parts = cleaned.split("```")
            # parts[1] is the content between first pair of fences
            if len(parts) >= 2:
                cleaned = parts[1]
                if cleaned.startswith("json"):
                    cleaned = cleaned[4:]
                cleaned = cleaned.strip()

        try:
            return json.loads(cleaned), None
        except json.JSONDecodeError as exc:
            return None, str(exc)
