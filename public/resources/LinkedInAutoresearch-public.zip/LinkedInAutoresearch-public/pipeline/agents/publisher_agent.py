"""Publisher Agent — publishes the LinkedIn post + video via BloTato v2 REST API."""
import os
import json
import time
import requests
from pathlib import Path

BLOTATO_BASE = "https://backend.blotato.com/v2"
LINKEDIN_ACCOUNT_ID = os.environ.get("BLOTATO_LINKEDIN_ACCOUNT_ID", "654")
# How long to poll for postSubmissionId → final post URL (seconds)
POLL_TIMEOUT = 300
POLL_INTERVAL = 10


class PublisherAgent:
    def __init__(self):
        self.api_key = os.environ["BLOTATO_API_KEY"]
        self.headers = {
            "blotato-api-key": self.api_key,
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------ #
    # Media hosting — upload video to Google Drive, return public URL
    # ------------------------------------------------------------------ #

    def upload_video_to_drive(self, video_path: str) -> str:
        """Upload video to Google Drive using service account. Returns public download URL.

        Reads service account JSON from GOOGLE_SERVICE_ACCOUNT_JSON env var (full JSON string)
        or GOOGLE_SERVICE_ACCOUNT_FILE env var (path to JSON file).
        """
        from googleapiclient.discovery import build
        from googleapiclient.http import MediaFileUpload
        from google.oauth2 import service_account

        # Load service account credentials
        sa_json = os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON", "")
        sa_file = os.environ.get("GOOGLE_SERVICE_ACCOUNT_FILE", "")
        if sa_json:
            sa_info = json.loads(sa_json)
            creds = service_account.Credentials.from_service_account_info(
                sa_info, scopes=["https://www.googleapis.com/auth/drive"]
            )
        elif sa_file:
            creds = service_account.Credentials.from_service_account_file(
                sa_file, scopes=["https://www.googleapis.com/auth/drive"]
            )
        else:
            raise EnvironmentError(
                "Set GOOGLE_SERVICE_ACCOUNT_JSON or GOOGLE_SERVICE_ACCOUNT_FILE"
            )

        drive = build("drive", "v3", credentials=creds, cache_discovery=False)
        filename = Path(video_path).name

        drive_id = os.environ.get("GOOGLE_SHARED_DRIVE_ID", "0ABeLw0N_x6XPUk9PVA")

        # Upload into the Shared Drive
        media = MediaFileUpload(video_path, mimetype="video/mp4", resumable=True)
        file_meta = {
            "name": filename,
            "parents": [drive_id],
        }
        uploaded = drive.files().create(
            body=file_meta,
            media_body=media,
            fields="id",
            supportsAllDrives=True,
        ).execute()
        file_id = uploaded["id"]

        # Make publicly readable (anyone with link)
        drive.permissions().create(
            fileId=file_id,
            body={"type": "anyone", "role": "reader"},
            supportsAllDrives=True,
        ).execute()

        # Direct download URL
        return f"https://drive.google.com/uc?export=download&id={file_id}"

    # ------------------------------------------------------------------ #
    # BloTato v2 API
    # ------------------------------------------------------------------ #

    def create_post(self, post_text: str, media_urls: list = None) -> str:
        """Submit a LinkedIn post. Returns postSubmissionId."""
        payload = {
            "post": {
                "accountId": LINKEDIN_ACCOUNT_ID,
                "content": {
                    "text": post_text,
                    "mediaUrls": media_urls or [],
                    "platform": "linkedin",
                },
                "target": {
                    "targetType": "linkedin",
                },
            }
        }
        resp = requests.post(
            f"{BLOTATO_BASE}/posts",
            json=payload,
            headers=self.headers,
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()["postSubmissionId"]

    def check_post_url(self, submission_id: str) -> str:
        """Single GET to Blotato — returns the real post URL if published, else empty string."""
        try:
            resp = requests.get(
                f"{BLOTATO_BASE}/posts/{submission_id}",
                headers=self.headers,
                timeout=15,
            )
            if not resp.ok:
                return ""
            data = resp.json()
            status = data.get("status", "")
            if status not in ("published", "succeeded", "completed"):
                return ""
            return (
                data.get("publicUrl")
                or data.get("postUrl")
                or data.get("url")
                or data.get("post_url")
                or (data.get("data") or {}).get("url")
                or ""
            )
        except Exception:
            return ""

    def poll_post_status(self, submission_id: str) -> dict:
        """Poll GET /posts/{postSubmissionId} until published or timeout."""
        deadline = time.time() + POLL_TIMEOUT
        while time.time() < deadline:
            resp = requests.get(
                f"{BLOTATO_BASE}/posts/{submission_id}",
                headers=self.headers,
                timeout=30,
            )
            if resp.status_code == 404:
                time.sleep(POLL_INTERVAL)
                continue
            resp.raise_for_status()
            data = resp.json()
            status = data.get("status", "")
            if status in ("published", "succeeded", "completed"):
                return data
            if status in ("failed", "error"):
                raise RuntimeError(
                    f"BloTato post failed. Check https://my.blotato.com/failed "
                    f"Response: {data}"
                )
            time.sleep(POLL_INTERVAL)

        # Timeout — return what we have (post may still succeed async)
        print(f"  Warning: post status poll timed out after {POLL_TIMEOUT}s. "
              f"Check https://my.blotato.com for status.")
        return {"postSubmissionId": submission_id}

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #

    def run(self, post_text: str, video_path: str, notion_url: str) -> dict:
        """Publish post to LinkedIn. Returns {post_url, account_id}."""
        media_urls = []

        # Upload video to GitHub Releases to get a public URL
        if video_path and Path(video_path).exists():
            try:
                print(f"  Uploading video to Google Drive...")
                public_url = self.upload_video_to_drive(video_path)
                media_urls = [public_url]
                print(f"  Video hosted at: {public_url}")
            except Exception as exc:
                print(f"  Warning: video upload failed ({exc}). Publishing text-only.")

        print(f"  Submitting post to BloTato (account {LINKEDIN_ACCOUNT_ID})...")
        submission_id = self.create_post(post_text, media_urls)
        print(f"  Submission ID: {submission_id}. Polling for status...")

        result = self.poll_post_status(submission_id)

        post_url = (
            result.get("publicUrl")
            or result.get("postUrl")
            or result.get("url")
            or result.get("post_url")
            or (result.get("data") or {}).get("url")
            or f"https://www.linkedin.com/feed/ (submission: {submission_id})"
        )

        return {"post_url": post_url, "account_id": LINKEDIN_ACCOUNT_ID, "submission_id": submission_id}
