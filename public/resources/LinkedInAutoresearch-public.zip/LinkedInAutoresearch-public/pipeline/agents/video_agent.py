"""Video Agent — generates styled HTML from lead magnet JSON, records a scroll video,
and burns a Gotham text overlay using FFmpeg."""
import os
import json
import subprocess
import time
import tempfile
from pathlib import Path
from datetime import datetime
import re


class VideoAgent:
    def __init__(self):
        self.output_dir = Path("data/output")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.overlay_config = self._load_overlay_config()

    def _load_overlay_config(self) -> dict:
        config_path = Path("assets/overlay_template.json")
        if config_path.exists():
            return json.loads(config_path.read_text())
        # Fallback defaults
        return {
            "box": {
                "margin_x": 30, "height": 160, "bottom_offset": 40,
                "color": "0x00FF00", "border_color": "black", "border_thickness": 4,
            },
            "title_text": {
                "font": "assets/fonts/Gotham-Ultra.ttf", "size": 52,
                "color": "black", "x_offset": 60, "y_from_box_top": 25,
            },
            "subtitle_text": {
                "font": "assets/fonts/Gotham-Medium.ttf", "size": 36,
                "color": "black", "x_offset": 60, "y_from_box_top": 90,
                "content": "FREE — Link in comments",
            },
            "video": {
                "width": 1080, "height": 1920, "scroll_duration_ms": 6500, "format": "mp4",
            },
        }

    # ------------------------------------------------------------------ #
    # HTML generation
    # ------------------------------------------------------------------ #

    def _render_block_html(self, block: dict) -> str:
        btype = block.get("type", "paragraph")
        text = block.get("content") or block.get("text", "")
        # Basic HTML escaping
        text_esc = (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                    .replace('"', "&quot;"))

        if btype == "heading_1":
            return f'<h1 class="h1">{text_esc}</h1>'
        if btype == "heading_2":
            return f'<h2 class="h2">{text_esc}</h2>'
        if btype == "heading_3":
            return f'<h3 class="h3">{text_esc}</h3>'
        if btype == "paragraph":
            if not text_esc.strip():
                return '<div style="height:16px;"></div>'
            return f'<p class="para">{text_esc}</p>'
        if btype == "bulleted_list_item":
            return f'<li class="blist">{text_esc}</li>'
        if btype == "numbered_list_item":
            return f'<li class="nlist">{text_esc}</li>'
        if btype == "divider":
            return '<hr class="divider">'
        if btype == "callout":
            icon = block.get("icon", "💡")
            color = block.get("color", "gray_background")
            bg_map = {
                "gray_background": "#2f3437",
                "blue_background": "#1a2c3d",
                "green_background": "#1c3829",
                "yellow_background": "#3d3117",
                "orange_background": "#3d2414",
                "red_background": "#3b1919",
                "purple_background": "#2e1f4a",
                "pink_background": "#3d1a2e",
                "brown_background": "#2e1f19",
                "default": "#2f3437",
            }
            bg = bg_map.get(color, bg_map["default"])
            return (
                f'<div class="callout" style="background:{bg};">'
                f'<span class="callout-icon">{icon}</span>'
                f'<span class="callout-text">{text_esc}</span>'
                f'</div>'
            )
        if btype == "code":
            return f'<pre class="code"><code>{text_esc}</code></pre>'
        if btype == "quote":
            return f'<blockquote class="quote">{text_esc}</blockquote>'
        if btype == "table":
            rows = block.get("rows", [])
            has_header = block.get("has_column_header", True)
            html = '<table class="table"><tbody>'
            for i, row in enumerate(rows):
                html += "<tr>"
                for cell in row:
                    cell_esc = str(cell).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                    tag = "th" if (i == 0 and has_header) else "td"
                    html += f"<{tag}>{cell_esc}</{tag}>"
                html += "</tr>"
            html += "</tbody></table>"
            return html
        # Fallback
        return f'<p class="para">{text_esc}</p>'

    def generate_html(self, lead_magnet_json: dict) -> Path:
        """Convert lead magnet JSON to a styled HTML page."""
        # Support nested notion_document structure (same as notion_agent.push_lead_magnet)
        doc = lead_magnet_json.get("notion_document", lead_magnet_json)
        title = doc.get("title", lead_magnet_json.get("title", "Lead Magnet"))
        icon = doc.get("page_settings", {}).get("icon", lead_magnet_json.get("icon", "📄"))

        # Flatten blocks from all sections
        blocks = []
        for section in doc.get("sections", []):
            for block in section.get("blocks", []):
                blocks.append(block)
        # Fallback: top-level blocks key (older format)
        if not blocks:
            blocks = lead_magnet_json.get("blocks", [])

        # Group consecutive list items so <ul>/<ol> wrap them correctly
        body_parts = []
        i = 0
        while i < len(blocks):
            b = blocks[i]
            btype = b.get("type", "")
            if btype == "bulleted_list_item":
                items = []
                while i < len(blocks) and blocks[i].get("type") == "bulleted_list_item":
                    items.append(self._render_block_html(blocks[i]))
                    i += 1
                body_parts.append("<ul>" + "".join(items) + "</ul>")
            elif btype == "numbered_list_item":
                items = []
                while i < len(blocks) and blocks[i].get("type") == "numbered_list_item":
                    items.append(self._render_block_html(blocks[i]))
                    i += 1
                body_parts.append("<ol>" + "".join(items) + "</ol>")
            else:
                body_parts.append(self._render_block_html(b))
                i += 1

        body_html = "\n".join(body_parts)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
    background: #191919;
    color: #e3e3e3;
    width: 100%;
    margin: 0;
  }}
  .cover {{
    background: #191919;
    width: 100%;
    padding: 80px 64px 60px 64px;
    display: flex;
    align-items: flex-end;
    min-height: 280px;
  }}
  .cover-inner {{ }}
  .cover-icon {{ font-size: 72px; line-height: 1; margin-bottom: 20px; display: block; }}
  .cover-title {{
    color: #ffffff;
    font-size: 48px;
    font-weight: 700;
    line-height: 1.2;
    letter-spacing: -0.5px;
  }}
  .content {{
    padding: 56px 96px 120px 96px;
    width: 100%;
  }}
  .h1 {{
    font-size: 40px; font-weight: 700; margin: 36px 0 16px 0;
    color: #ffffff; line-height: 1.2;
  }}
  .h2 {{
    font-size: 30px; font-weight: 600; margin: 32px 0 14px 0;
    color: #ffffff; line-height: 1.25;
  }}
  .h3 {{
    font-size: 24px; font-weight: 600; margin: 24px 0 10px 0;
    color: #ffffff;
  }}
  .para {{
    font-size: 18px; line-height: 1.7; color: #c7c7c7;
    margin: 12px 0;
  }}
  ul, ol {{
    margin: 10px 0 10px 28px;
  }}
  .blist, .nlist {{
    font-size: 18px; line-height: 1.7; color: #c7c7c7;
    margin: 6px 0;
    padding-left: 4px;
  }}
  .divider {{
    border: none; border-top: 1px solid rgba(255,255,255,0.13);
    margin: 28px 0;
  }}
  .callout {{
    display: flex; align-items: flex-start;
    padding: 16px 20px; border-radius: 6px;
    margin: 16px 0; gap: 14px;
  }}
  .callout-icon {{ font-size: 22px; line-height: 1.6; flex-shrink: 0; }}
  .callout-text {{ font-size: 17px; line-height: 1.65; color: #c7c7c7; white-space: pre-wrap; }}
  .code {{
    background: #2f3437; border-radius: 6px;
    padding: 18px 20px; font-size: 15px;
    font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace;
    overflow-x: auto; margin: 16px 0;
    white-space: pre-wrap; word-break: break-word;
    color: #e3e3e3;
  }}
  .quote {{
    border-left: 4px solid rgba(255,255,255,0.35);
    padding: 8px 20px; margin: 16px 0;
    color: #a3a3a3; font-size: 18px; font-style: italic;
  }}
  .table {{
    width: 100%; border-collapse: collapse;
    margin: 20px 0; font-size: 16px;
  }}
  .table th, .table td {{
    border: 1px solid rgba(255,255,255,0.13);
    padding: 10px 14px; text-align: left;
  }}
  .table th {{
    background: rgba(255,255,255,0.05); font-weight: 600; color: #ffffff;
  }}
</style>
</head>
<body>
  <div class="cover">
    <div class="cover-inner">
      <span class="cover-icon">{icon}</span>
      <div class="cover-title">{title}</div>
    </div>
  </div>
  <div class="content">
    {body_html}
  </div>
</body>
</html>"""

        today = datetime.now().strftime("%Y-%m-%d")
        html_path = self.output_dir / f"lead_magnet_{today}.html"
        html_path.write_text(html, encoding="utf-8")
        return html_path

    # ------------------------------------------------------------------ #
    # Playwright recording
    # ------------------------------------------------------------------ #

    def record_with_playwright(self, html_path: Path, duration_ms: int = 6500) -> Path:
        """Use Playwright to open the HTML and record a scroll video. Returns .webm path."""
        video_dir = str(self.output_dir.resolve())
        file_url = html_path.resolve().as_uri()

        vid_cfg = self.overlay_config.get("video", {})
        vid_width = vid_cfg.get("width", 1080)
        vid_height = vid_cfg.get("height", 1350)

        # Write a temporary playwright script
        playwright_script = f"""
import asyncio
from playwright.async_api import async_playwright

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            viewport={{"width": {vid_width}, "height": {vid_height}}},
            record_video_dir="{video_dir}",
            record_video_size={{"width": {vid_width}, "height": {vid_height}}},
        )
        page = await context.new_page()
        await page.goto("{file_url}")
        await page.wait_for_load_state("networkidle")

        # Smooth scroll to the bottom over duration_ms
        scroll_duration = {duration_ms}
        await page.evaluate(\"\"\"
            async () => {{
                const totalHeight = document.body.scrollHeight - window.innerHeight;
                const steps = 60;
                const delay = {duration_ms} / steps;
                for (let i = 0; i <= steps; i++) {{
                    window.scrollTo(0, Math.round(totalHeight * i / steps));
                    await new Promise(r => setTimeout(r, delay));
                }}
            }}
        \"\"\")
        await page.wait_for_timeout(500)
        await page.close()
        await context.close()
        await browser.close()

asyncio.run(main())
"""

        with tempfile.NamedTemporaryFile(
            mode="w", suffix="_pw_record.py", delete=False, encoding="utf-8"
        ) as f:
            f.write(playwright_script)
            script_path = f.name

        try:
            result = subprocess.run(
                ["python", script_path],
                capture_output=True, text=True, timeout=120
            )
            if result.returncode != 0:
                raise RuntimeError(
                    f"Playwright recording failed:\n{result.stderr}"
                )
        finally:
            Path(script_path).unlink(missing_ok=True)

        # Find the most recently created .webm in output_dir
        webm_files = sorted(
            self.output_dir.glob("*.webm"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if not webm_files:
            raise FileNotFoundError(
                f"No .webm file found in {self.output_dir} after Playwright recording."
            )
        return webm_files[0]

    # ------------------------------------------------------------------ #
    # FFmpeg overlay
    # ------------------------------------------------------------------ #

    def _escape_ffmpeg_text(self, text: str) -> str:
        """Escape characters that break FFmpeg drawtext."""
        text = text.replace("\\", "\\\\")
        text = text.replace("'", "\\'")
        text = text.replace(":", "\\:")
        text = re.sub(r"[^\x20-\x7E]", "", text)  # strip non-ASCII
        return text

    def burn_overlay(self, webm_path: Path, overlay_system: str, overlay_result: str) -> Path:
        """Convert webm to mp4 and burn two-line centered Gotham overlay. Returns mp4 path.

        Top line  — Gotham Medium: short system description (e.g. 'My exact AI content system')
        Bottom line — Gotham Ultra: specific result/number  (e.g. '150K followers in 12 months')
        Both lines are horizontally centered.
        """
        today = datetime.now().strftime("%Y-%m-%d")
        mp4_path = self.output_dir / f"post_{today}.mp4"

        cfg = self.overlay_config
        video_cfg = cfg.get("video", {})
        box_cfg = cfg.get("box", {})
        system_cfg = cfg.get("system_text", {})
        result_cfg = cfg.get("result_text", {})

        vid_height = video_cfg.get("height", 1920)

        margin_x = box_cfg.get("margin_x", 30)
        box_height = box_cfg.get("height", 180)
        position = box_cfg.get("position", "top")
        top_offset = box_cfg.get("top_offset", 80)
        bottom_offset = box_cfg.get("bottom_offset", 40)
        box_color = box_cfg.get("color", "0x00FF00").replace("0x", "#")
        border_color = box_cfg.get("border_color", "black")
        border_thickness = box_cfg.get("border_thickness", 4)

        box_x = margin_x
        box_w = "iw-" + str(margin_x * 2)  # FFmpeg expression: full width minus margins
        if position == "top":
            box_y = top_offset
        else:
            box_y = vid_height - box_height - bottom_offset

        system_font = system_cfg.get("font", "assets/fonts/Gotham-Medium.otf")
        system_size = system_cfg.get("size", 38)
        system_color = system_cfg.get("color", "black")
        system_y = box_y + system_cfg.get("y_from_box_top", 28)

        result_font = result_cfg.get("font", "assets/fonts/Gotham-Ultra.otf")
        result_size = result_cfg.get("size", 54)
        result_color = result_cfg.get("color", "black")
        result_y = box_y + result_cfg.get("y_from_box_top", 100)

        # Hard cap at 28 chars so neither line wraps inside the box
        system_esc = self._escape_ffmpeg_text(overlay_system[:28])
        result_esc = self._escape_ffmpeg_text(overlay_result[:28])

        # Check if font files exist
        fonts_available = Path(system_font).exists() and Path(result_font).exists()

        if fonts_available:
            # Both lines horizontally centered using FFmpeg text_w expression
            drawtext_system = (
                f"drawtext=fontfile='{system_font}':"
                f"text='{system_esc}':"
                f"fontsize={system_size}:fontcolor={system_color}:"
                f"x=(w-text_w)/2:y={system_y}"
            )
            drawtext_result = (
                f"drawtext=fontfile='{result_font}':"
                f"text='{result_esc}':"
                f"fontsize={result_size}:fontcolor={result_color}:"
                f"x=(w-text_w)/2:y={result_y}"
            )
            vf = (
                f"drawbox=x={box_x}:y={box_y}:w={box_w}:h={box_height}:"
                f"color={box_color}:t=fill,"
                f"drawbox=x={box_x}:y={box_y}:w={box_w}:h={box_height}:"
                f"color={border_color}:t={border_thickness},"
                f"{drawtext_system},"
                f"{drawtext_result}"
            )
        else:
            print(
                f"  Warning: font files not found at {system_font} / {result_font}. "
                "Skipping text overlay, rendering box only."
            )
            vf = (
                f"drawbox=x={box_x}:y={box_y}:w={box_w}:h={box_height}:"
                f"color={box_color}:t=fill,"
                f"drawbox=x={box_x}:y={box_y}:w={box_w}:h={box_height}:"
                f"color={border_color}:t={border_thickness}"
            )

        cmd = [
            "ffmpeg", "-y",
            "-i", str(webm_path),
            "-vf", vf,
            "-c:v", "libx264",
            "-preset", "fast",
            "-crf", "22",
            "-pix_fmt", "yuv420p",
            str(mp4_path),
        ]

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        if result.returncode != 0:
            # Last-resort fallback: just convert without overlay
            print(f"  Warning: FFmpeg overlay failed. Converting without overlay.\n{result.stderr[:500]}")
            fallback_cmd = [
                "ffmpeg", "-y",
                "-i", str(webm_path),
                "-c:v", "libx264",
                "-preset", "fast",
                "-crf", "22",
                "-pix_fmt", "yuv420p",
                str(mp4_path),
            ]
            fallback_result = subprocess.run(fallback_cmd, capture_output=True, text=True, timeout=300)
            if fallback_result.returncode != 0:
                raise RuntimeError(
                    f"FFmpeg conversion failed entirely:\n{fallback_result.stderr}"
                )

        return mp4_path

    # ------------------------------------------------------------------ #
    # Entry point
    # ------------------------------------------------------------------ #

    def run(self, lead_magnet: dict, post_data: dict = None, notion_page_id: str = None) -> dict:
        full_json = lead_magnet.get("full_json", lead_magnet)
        html_path = self.generate_html(full_json)

        scroll_duration = self.overlay_config.get("video", {}).get("scroll_duration_ms", 6500)
        webm_path = self.record_with_playwright(html_path, duration_ms=scroll_duration)

        post_data = post_data or {}
        overlay_system = post_data.get("overlay_system", lead_magnet.get("title", "Lead Magnet"))
        overlay_result = post_data.get("overlay_result", "")

        mp4_path = self.burn_overlay(webm_path, overlay_system, overlay_result)
        return {
            "video_path": str(mp4_path),
            "overlay_system": overlay_system,
            "overlay_result": overlay_result,
        }
