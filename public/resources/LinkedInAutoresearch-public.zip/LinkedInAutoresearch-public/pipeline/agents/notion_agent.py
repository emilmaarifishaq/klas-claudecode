"""Notion Agent — pushes lead magnet JSON to Notion and creates a tracking row."""
import os
import re
import time
import mimetypes
import requests

# Matches http(s):// URLs and bare URLs like skool.com/buildroom
_URL_RE = re.compile(
    r'(https?://[^\s]+|(?<!\w)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}/[^\s]*)'
)


NOTION_API_VERSION = "2022-06-28"
NOTION_BASE = "https://api.notion.com/v1"


class NotionAgent:
    def __init__(self):
        self.api_key = os.environ["NOTION_API_KEY"]
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Notion-Version": NOTION_API_VERSION,
        }

    # ------------------------------------------------------------------ #
    # Primitive block builders (ported verbatim from push_to_notion.py)
    # ------------------------------------------------------------------ #

    def rich_text(self, text: str, bold: bool = False, italic: bool = False, color: str = "default", link: str = None) -> dict:
        annotations = {
            "bold": bold,
            "italic": italic,
            "strikethrough": False,
            "underline": False,
            "code": False,
            "color": color,
        }
        text_obj = {"content": text}
        if link:
            text_obj["link"] = {"url": link}
        return {
            "type": "text",
            "text": text_obj,
            "annotations": annotations,
        }

    def rich_text_segments(self, text: str, bold: bool = False, color: str = "default") -> list:
        """Split text on URLs and return a list of rich_text objects with links embedded."""
        segments = []
        last = 0
        for m in _URL_RE.finditer(text):
            before = text[last:m.start()]
            if before:
                segments.append(self.rich_text(before, bold=bold, color=color))
            url_text = m.group(0)
            href = url_text if url_text.startswith("http") else f"https://{url_text}"
            segments.append(self.rich_text(url_text, bold=bold, color=color, link=href))
            last = m.end()
        tail = text[last:]
        if tail:
            segments.append(self.rich_text(tail, bold=bold, color=color))
        return segments or [self.rich_text(text, bold=bold, color=color)]

    def make_block(self, block: dict) -> dict:
        """Convert a JSON block spec to Notion API block format."""
        btype = block.get("type", "paragraph")
        # Lead magnet agent uses "content"; older format uses "text"
        block = {**block, "text": block.get("content") or block.get("text", "")}

        if btype == "heading_1":
            return {
                "object": "block",
                "type": "heading_1",
                "heading_1": {
                    "rich_text": [self.rich_text(block.get("text", ""), bold=True)]
                },
            }

        if btype == "heading_2":
            return {
                "object": "block",
                "type": "heading_2",
                "heading_2": {
                    "rich_text": [self.rich_text(block.get("text", ""), bold=True)]
                },
            }

        if btype == "heading_3":
            return {
                "object": "block",
                "type": "heading_3",
                "heading_3": {
                    "rich_text": [self.rich_text(block.get("text", ""))]
                },
            }

        if btype == "paragraph":
            return {
                "object": "block",
                "type": "paragraph",
                "paragraph": {
                    "rich_text": self.rich_text_segments(block.get("text", ""))
                },
            }

        if btype == "bulleted_list_item":
            return {
                "object": "block",
                "type": "bulleted_list_item",
                "bulleted_list_item": {
                    "rich_text": self.rich_text_segments(block.get("text", ""))
                },
            }

        if btype == "numbered_list_item":
            return {
                "object": "block",
                "type": "numbered_list_item",
                "numbered_list_item": {
                    "rich_text": self.rich_text_segments(block.get("text", ""))
                },
            }

        if btype == "divider":
            return {"object": "block", "type": "divider", "divider": {}}

        if btype == "callout":
            return {
                "object": "block",
                "type": "callout",
                "callout": {
                    "rich_text": self.rich_text_segments(block.get("text", "")),
                    "icon": {"type": "emoji", "emoji": block.get("icon", "💡")},
                    "color": block.get("color", "gray_background"),
                },
            }

        if btype == "code":
            return {
                "object": "block",
                "type": "code",
                "code": {
                    "rich_text": [self.rich_text(block.get("text", ""))],
                    "language": block.get("language", "plain text"),
                },
            }

        if btype == "quote":
            return {
                "object": "block",
                "type": "quote",
                "quote": {
                    "rich_text": self.rich_text_segments(block.get("text", ""))
                },
            }

        if btype == "table":
            rows = block.get("rows", [])
            has_header = block.get("has_column_header", True)
            table_width = max((len(r) for r in rows), default=1)
            table_rows = []
            for row in rows:
                cells = [[self.rich_text(str(cell))] for cell in row]
                table_rows.append({
                    "object": "block",
                    "type": "table_row",
                    "table_row": {"cells": cells},
                })
            return {
                "object": "block",
                "type": "table",
                "table": {
                    "table_width": table_width,
                    "has_column_header": has_header,
                    "has_row_header": False,
                    "children": table_rows,
                },
            }

        # Fallback: render as paragraph
        return {
            "object": "block",
            "type": "paragraph",
            "paragraph": {
                "rich_text": [self.rich_text(str(block.get("text", "")))]
            },
        }

    def create_page(
        self,
        title: str,
        icon: str,
        content_blocks: list,
        database_id: str,
        headers: dict,
    ) -> dict:
        """Create a Notion page then append blocks in chunks of 100."""
        payload = {
            "parent": {"database_id": database_id},
            "icon": {"type": "emoji", "emoji": icon},
            "properties": {
                "title": {
                    "title": [{"type": "text", "text": {"content": title}}]
                }
            },
        }
        resp = requests.post(f"{NOTION_BASE}/pages", json=payload, headers=headers)
        resp.raise_for_status()
        page = resp.json()
        page_id = page["id"]

        # Append blocks in chunks of 100
        notion_blocks = [self.make_block(b) for b in content_blocks]
        chunk_size = 100
        for i in range(0, len(notion_blocks), chunk_size):
            chunk = notion_blocks[i : i + chunk_size]
            append_resp = requests.patch(
                f"{NOTION_BASE}/blocks/{page_id}/children",
                json={"children": chunk},
                headers=headers,
            )
            append_resp.raise_for_status()
            if i + chunk_size < len(notion_blocks):
                time.sleep(0.35)

        return page

    # ------------------------------------------------------------------ #
    # Public methods
    # ------------------------------------------------------------------ #

    def push_lead_magnet(self, lead_magnet_json: dict) -> tuple[str, str]:
        """Create the lead magnet page in Notion. Returns (page_id, page_url)."""
        database_id = os.environ["NOTION_LEAD_MAGNET_DB_ID"]

        # Support nested notion_document structure from lead_magnet_agent
        doc = lead_magnet_json.get("notion_document", lead_magnet_json)
        title = doc.get("title", lead_magnet_json.get("title", "Untitled Lead Magnet"))
        icon = doc.get("page_settings", {}).get("icon", lead_magnet_json.get("icon", "📄"))

        # Flatten all blocks from all sections into a single list
        content_blocks = []
        for section in doc.get("sections", []):
            for block in section.get("blocks", []):
                content_blocks.append(block)
        # Fallback: top-level blocks key
        if not content_blocks:
            content_blocks = lead_magnet_json.get("blocks", [])

        page = self.create_page(title, icon, content_blocks, database_id, self.headers)
        page_id = page["id"]
        page_id_no_dashes = page_id.replace("-", "")
        page_url = f"https://www.notion.so/{page_id_no_dashes}"
        return page_id, page_url

    @staticmethod
    def _valid_url(url: str) -> str | None:
        """Return url only if it looks like a real URL (no spaces). Otherwise None."""
        if url and " " not in url and url.startswith("http"):
            return url
        return None

    def create_tracking_row(self, data: dict) -> str:
        """Create a row in the tracking database. Returns the Notion page ID."""
        database_id = os.environ["NOTION_TRACKING_DB_ID"]

        properties = {
            "Name": {
                "title": [{"type": "text", "text": {"content": data.get("title", "")}}]
            },
            "Post URL": {
                "url": self._valid_url(data.get("post_url", ""))
            },
            "Lead Magnet Page URL": {
                "url": data.get("notion_lead_magnet_url") or None
            },
            "Published Date": {
                "date": {"start": data.get("published_date", "")} if data.get("published_date") else None
            },
            "Topic": {
                "select": {"name": data.get("topic", "")} if data.get("topic") else None
            },
            "LM Type": {
                "select": {"name": data.get("lm_type", "")} if data.get("lm_type") else None
            },
            "LM Theme": {
                "rich_text": [self.rich_text(data.get("lm_theme", "")[:2000])]
            },
            "Hook Type": {
                "select": {"name": data.get("hook_type", "")} if data.get("hook_type") else None
            },
            "Hook Line": {
                "rich_text": [self.rich_text(str(data.get("hook_line", ""))[:2000])]
            },
            "Format": {
                "select": {"name": data.get("format", "")} if data.get("format") else None
            },
            "Content Type": {
                "select": {"name": data.get("content_type", "")} if data.get("content_type") else None
            },
            "Angle": {
                "select": {"name": data.get("angle", "")} if data.get("angle") else None
            },
            "Word Count": {
                "number": int(data.get("word_count", 0))
            },
            "Line Count": {
                "number": int(data.get("line_count", 0))
            },
            "Avg Line Length": {
                "number": float(data.get("avg_line_length", 0))
            },
            "Impressions": {
                "number": int(data.get("impressions", 0))
            },
            "Likes": {
                "number": int(data.get("likes", 0))
            },
            "Comments": {
                "number": int(data.get("comments", 0))
            },
            "Shares": {
                "number": int(data.get("shares", 0))
            },
            "Strategy Version": {
                "number": int(data.get("strategy_version", 1))
            },
            "Overlay System": {
                "rich_text": [self.rich_text(data.get("overlay_system", "")[:2000])]
            },
            "Overlay Result": {
                "rich_text": [self.rich_text(data.get("overlay_result", "")[:2000])]
            },
            "Post Text": {
                "rich_text": [self.rich_text(data.get("post_text", "")[:2000])]
            },
        }

        # Remove None-valued properties to avoid Notion API errors
        properties = {k: v for k, v in properties.items() if v is not None}

        payload = {
            "parent": {"database_id": database_id},
            "properties": properties,
        }
        resp = requests.post(f"{NOTION_BASE}/pages", json=payload, headers=self.headers)
        resp.raise_for_status()
        return resp.json()["id"]

    # ------------------------------------------------------------------ #
    # File upload (thumbnail → Notion-hosted, permanent)
    # ------------------------------------------------------------------ #

    def upload_file_to_notion(self, url: str, filename: str, mime_type: str) -> str:
        """Download a file from URL and upload it to Notion. Returns Notion file URL."""
        # Step 1: download the file bytes
        resp = requests.get(url, timeout=30)
        resp.raise_for_status()
        file_bytes = resp.content

        # Step 2: create an upload session
        headers_no_ct = {k: v for k, v in self.headers.items() if k != "Content-Type"}
        session_resp = requests.post(
            f"{NOTION_BASE}/file-uploads",
            json={"name": filename, "content_type": mime_type},
            headers=self.headers,
        )
        session_resp.raise_for_status()
        session = session_resp.json()
        upload_url = session["upload_url"]
        file_upload_id = session["id"]

        # Step 3: PUT bytes to the S3 upload URL
        put_resp = requests.put(
            upload_url,
            data=file_bytes,
            headers={"Content-Type": mime_type},
            timeout=60,
        )
        put_resp.raise_for_status()

        return file_upload_id

    def update_metrics_row(self, notion_page_id: str, metrics: dict, post_text: str = "",
                           media: dict = None):
        """PATCH the tracking row with updated engagement metrics, post text, and media."""
        properties = {
            "Impressions": {"number": int(metrics.get("impressions", 0))},
            "Likes": {"number": int(metrics.get("likes", 0))},
            "Comments": {"number": int(metrics.get("comments", 0))},
            "Shares": {"number": int(metrics.get("shares", 0))},
        }
        if post_text:
            rich_text = []
            for i in range(0, min(len(post_text), 6000), 2000):
                rich_text.append({"type": "text", "text": {"content": post_text[i:i+2000]}})
            properties["Post Text"] = {"rich_text": rich_text}

        patch_payload = {"properties": properties}

        # Set page cover from thumbnail
        thumbnail_url = (media or {}).get("thumbnail", "")
        if thumbnail_url:
            try:
                file_id = self.upload_file_to_notion(
                    thumbnail_url, "thumbnail.jpg", "image/jpeg"
                )
                patch_payload["cover"] = {
                    "type": "file",
                    "file": {"id": file_id},
                }
            except Exception as exc:
                print(f"  Warning: thumbnail upload failed: {exc}")

        resp = requests.patch(
            f"{NOTION_BASE}/pages/{notion_page_id}",
            json=patch_payload,
            headers=self.headers,
        )
        resp.raise_for_status()

        # Append video block if media is a video
        media_type = (media or {}).get("type", "")
        media_url = (media or {}).get("url", "")
        if media_type == "video" and media_url:
            try:
                file_id = self.upload_file_to_notion(
                    media_url, "post_video.mp4", "video/mp4"
                )
                requests.patch(
                    f"{NOTION_BASE}/blocks/{notion_page_id}/children",
                    json={"children": [{
                        "object": "block",
                        "type": "video",
                        "video": {"type": "file", "file": {"id": file_id}},
                    }]},
                    headers=self.headers,
                ).raise_for_status()
            except Exception as exc:
                print(f"  Warning: video upload failed: {exc}")

    def run(self, lead_magnet: dict) -> dict:
        """Push lead magnet JSON to Notion. Returns {page_id, page_url}."""
        full_json = lead_magnet.get("full_json", lead_magnet)
        page_id, page_url = self.push_lead_magnet(full_json)
        return {"page_id": page_id, "page_url": page_url}
