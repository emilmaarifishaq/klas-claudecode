"""Research Agent — scrapes Reddit for trending topics, selects the best one for today's lead magnet."""
import csv
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

from pipeline.base_agent import BaseAgent

# Weekly/pinned thread patterns to skip
_SKIP_PATTERNS = [
    "weekly thread",
    "weekly discussion",
    "weekly help",
    "weekly feedback",
    "weekly showcase",
    "weekly wins",
    "weekly q&a",
    "monthly thread",
    "monthly discussion",
    "pinned:",
    "[weekly]",
    "[monthly]",
    "megathread",
    "official thread",
]

_REPO_ROOT = Path(__file__).resolve().parents[2]


class ResearchAgent(BaseAgent):
    system_prompt = (
        "You are a content strategist specializing in AI, automation, and LinkedIn growth. "
        "Your job is to select the single best Reddit trend to build a lead magnet around for today's post. "
        "Always respond with raw JSON only — no markdown, no explanation, no code blocks."
    )

    # ------------------------------------------------------------------ #
    # Public entry point
    # ------------------------------------------------------------------ #

    def run(self, **kwargs) -> dict:
        """Scrape Reddit, pick a topic, save to data/output/today_topic.json."""
        subreddits = self._load_subreddits()
        raw_posts = self._scrape_all(subreddits)
        top_posts = self._rank_and_dedupe(raw_posts)
        strategy = self.load_file(str(_REPO_ROOT / "strategy.md"))
        audience = self.load_file(str(_REPO_ROOT / "AudienceInfo.md"))
        recent_topics = self._load_recent_topics(days=14)
        topic_data = self._select_topic(top_posts, strategy, audience, recent_topics)
        self.save_output("today_topic.json", topic_data)
        return topic_data

    def _load_recent_topics(self, days: int = 14) -> list[str]:
        """Return topic + lm_title strings from the last N days of results.tsv."""
        results_tsv = _REPO_ROOT / "results.tsv"
        if not results_tsv.exists():
            return []
        from datetime import timedelta
        cutoff = datetime.now() - timedelta(days=days)
        recent = []
        with results_tsv.open("r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f, delimiter="\t")
            for row in reader:
                try:
                    post_date = datetime.strptime(row.get("date", ""), "%Y-%m-%d")
                except ValueError:
                    continue
                if post_date >= cutoff:
                    topic = row.get("topic", "").strip()
                    lm_title = row.get("lm_title", "").strip()
                    hook_line = row.get("hook_line", "").strip()
                    if topic:
                        recent.append(f"- {topic}" + (f" | Lead magnet: {lm_title}" if lm_title else "") + (f" | Hook: {hook_line}" if hook_line else ""))
        return recent

    # ------------------------------------------------------------------ #
    # Subreddit loading
    # ------------------------------------------------------------------ #

    def _load_subreddits(self) -> list[str]:
        path = _REPO_ROOT / "data" / "subreddits.json"
        config = json.loads(path.read_text(encoding="utf-8"))
        return [entry["name"] for entry in config["subreddits"]]

    # ------------------------------------------------------------------ #
    # Reddit scraping (OAuth2 client_credentials)
    # ------------------------------------------------------------------ #

    _REDDIT_USER_AGENT = "LinkedInAutoresearch/1.0 (personal use script)"

    def _get_reddit_token(self) -> str:
        """Obtain a Reddit OAuth2 access token via client_credentials grant."""
        client_id = os.environ["REDDIT_CLIENT_ID"]
        client_secret = os.environ["REDDIT_CLIENT_SECRET"]
        resp = requests.post(
            "https://www.reddit.com/api/v1/access_token",
            auth=(client_id, client_secret),
            data={"grant_type": "client_credentials"},
            headers={"User-Agent": self._REDDIT_USER_AGENT},
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()["access_token"]

    def _fetch_subreddit(self, subreddit: str, token: str) -> list[dict]:
        """Fetch top-week posts from a subreddit via the Reddit OAuth API."""
        url = f"https://oauth.reddit.com/r/{subreddit}/top.json?limit=30&t=week"
        try:
            resp = requests.get(
                url,
                headers={
                    "Authorization": f"bearer {token}",
                    "User-Agent": self._REDDIT_USER_AGENT,
                },
                timeout=15,
            )
            resp.raise_for_status()
            children = resp.json().get("data", {}).get("children", [])
            return [child["data"] for child in children]
        except (requests.RequestException, json.JSONDecodeError, KeyError):
            return []

    def _scrape_all(self, subreddits: list[str]) -> list[dict]:
        """Scrape all subreddits with a short delay to avoid rate limiting."""
        token = self._get_reddit_token()
        all_posts = []
        for sub in subreddits:
            posts = self._fetch_subreddit(sub, token)
            for post in posts:
                post["_subreddit_override"] = sub  # normalise subreddit name
            all_posts.extend(posts)
            time.sleep(0.5)
        return all_posts

    # ------------------------------------------------------------------ #
    # Filtering, scoring, deduplication
    # ------------------------------------------------------------------ #

    def _is_skippable(self, post: dict) -> bool:
        if post.get("stickied") or post.get("pinned"):
            return True
        if post.get("score", 0) < 10:
            return True
        title_lower = post.get("title", "").lower()
        if any(pattern in title_lower for pattern in _SKIP_PATTERNS):
            return True
        return False

    def _recency_bonus(self, post: dict) -> float:
        """Up to 200 points for posts under 72 hours old."""
        created_utc = post.get("created_utc", 0)
        now = datetime.now(timezone.utc).timestamp()
        age_hours = (now - created_utc) / 3600
        if age_hours <= 72:
            return max(0.0, 200.0 * (1.0 - age_hours / 72.0))
        return 0.0

    def _virality_score(self, post: dict) -> float:
        score = post.get("score", 0)
        comments = post.get("num_comments", 0)
        return score + (comments * 3) + self._recency_bonus(post)

    def _rank_and_dedupe(self, posts: list[dict]) -> list[dict]:
        """Filter, score, deduplicate, and return top 15."""
        filtered = [p for p in posts if not self._is_skippable(p)]

        # Score each post
        for post in filtered:
            post["_virality_score"] = self._virality_score(post)

        # Sort descending
        filtered.sort(key=lambda p: p["_virality_score"], reverse=True)

        # Deduplicate by first 60 chars of title (case-insensitive)
        seen_prefixes: set[str] = set()
        deduped = []
        for post in filtered:
            prefix = post.get("title", "")[:60].lower()
            if prefix not in seen_prefixes:
                seen_prefixes.add(prefix)
                deduped.append(post)

        return deduped[:15]

    # ------------------------------------------------------------------ #
    # Claude topic selection
    # ------------------------------------------------------------------ #

    def _build_trends_summary(self, posts: list[dict]) -> str:
        lines = []
        for i, post in enumerate(posts, 1):
            sub = post.get("_subreddit_override") or post.get("subreddit", "unknown")
            title = post.get("title", "")
            score = post.get("score", 0)
            comments = post.get("num_comments", 0)
            virality = round(post.get("_virality_score", 0))
            lines.append(
                f"{i:>2}. [{sub}] {title}\n"
                f"     Score: {score} | Comments: {comments} | Virality: {virality}"
            )
        return "\n".join(lines)

    def _select_topic(self, posts: list[dict], strategy: str, audience: str, recent_topics: list[str] = None) -> dict:
        if not posts:
            raise ValueError(
                "ResearchAgent: No Reddit posts scraped — all subreddits returned empty results. "
                "Reddit may be rate-limiting or blocking requests from GitHub Actions."
            )
        trends_block = self._build_trends_summary(posts)

        recent_block = ""
        if recent_topics:
            recent_block = f"""---
TOPICS POSTED IN THE LAST 14 DAYS (DO NOT REPEAT THESE — pick something meaningfully different):
{chr(10).join(recent_topics)}

"""

        user_message = f"""Here are today's top 15 Reddit trends across AI, automation, and business subreddits:

{trends_block}

---
CURRENT CONTENT STRATEGY:
{strategy}

---
TARGET AUDIENCE:
{audience}

---
{recent_block}TASK:
Select the single best trend to build today's lead magnet around.

Choose the topic that:
1. Aligns most tightly with the current strategy focus (AI automation workflows, LinkedIn growth, Claude Code)
2. Would resonate most with the target avatar (expertise-rich, audience-poor $8K-20K/mo business owners)
3. Maps cleanly to a specific lead magnet idea (a guide, checklist, template, or system)
4. Has strong virality signal (high score + comments)
5. Is meaningfully different from anything posted in the last 14 days (different angle, different problem, different audience pain point)

Return ONLY a JSON object with exactly these keys:
{{
  "topic": "short topic label (5-10 words)",
  "reddit_title": "exact title of the Reddit post you selected",
  "subreddit": "subreddit name without r/",
  "lead_magnet_concept": "1-2 sentence description of the lead magnet to build (what it is, what it helps the reader do)",
  "storytelling_framework": "one of: BAB | Origin | CaseStudy | BehindCurtain",
  "cta_keyword": "ONE punchy ALL-CAPS word for the comment CTA (e.g. SYSTEM, GUIDE, AGENT, BLUEPRINT)"
}}

No markdown. No explanation. Raw JSON only."""

        raw = self.call(user_message, max_tokens=512)

        # Strip accidental markdown fences if Claude adds them
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```")[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
            cleaned = cleaned.strip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"ResearchAgent: Claude returned invalid JSON.\nRaw response:\n{raw}"
            ) from exc
