import os
import json
from datetime import datetime
from pathlib import Path
import anthropic

OUTPUT_DIR = Path("data/output")

class BaseAgent:
    model = "claude-sonnet-4-6"
    system_prompt = ""

    def __init__(self, client: anthropic.Anthropic):
        self.client = client
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    def call(self, user_message: str, max_tokens: int = 4096) -> str:
        """Make a single Claude API call and return the text response."""
        response = self.client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            system=self.system_prompt,
            messages=[{"role": "user", "content": user_message}]
        )
        return response.content[0].text

    def save_output(self, filename: str, data: dict | str):
        """Save agent output to data/output/ directory."""
        path = OUTPUT_DIR / filename
        if isinstance(data, str):
            path.write_text(data, encoding="utf-8")
        else:
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    def load_file(self, filepath: str) -> str:
        """Load a text file and return its contents."""
        return Path(filepath).read_text(encoding="utf-8")

    def today(self) -> str:
        return datetime.now().strftime("%Y-%m-%d")

    def run(self, **kwargs) -> dict:
        raise NotImplementedError
