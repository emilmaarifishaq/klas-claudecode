#!/usr/bin/env python3
"""Daily metrics scrape orchestrator."""
import csv
import os
import re
from pathlib import Path
from pipeline.agents.metrics_agent import MetricsAgent, RESULTS_TSV
from pipeline.agents.logger_agent import LoggerAgent, TSV_COLUMNS
from pipeline.agents.leadshark_agent import LeadSharkAgent, _extract_post_id


def _resolve_pending_submissions():
    """Check Blotato for any posts still stored as submission URLs and update TSV."""
    if not os.environ.get("BLOTATO_API_KEY") or not RESULTS_TSV.exists():
        return

    from pipeline.agents.publisher_agent import PublisherAgent
    publisher = PublisherAgent()

    with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        rows = list(reader)
        fieldnames = reader.fieldnames or TSV_COLUMNS

    updated = False
    for row in rows:
        post_url = row.get("post_url", "")
        match = re.search(r"submission: ([a-f0-9\-]+)", post_url)
        if not match:
            continue
        submission_id = match.group(1)
        real_url = publisher.check_post_url(submission_id)
        if real_url and ("linkedin.com" in real_url):
            print(f"  Resolved submission {submission_id} → {real_url}")
            row["post_url"] = real_url
            updated = True

    if updated:
        with RESULTS_TSV.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)


def run():
    print("=== Metrics Scrape Pipeline ===")

    print("\n[0/3] Resolving any pending Blotato submission URLs...")
    _resolve_pending_submissions()

    print("\n[1/3] Metrics Agent: Scraping LinkedIn metrics via Apify...")
    metrics = MetricsAgent()
    updates = metrics.run()
    print(f"  Matched {len(updates)} posts")

    print("\n[2/3] Logger Agent: Writing metrics to results.tsv + Notion...")
    logger = LoggerAgent()
    logger.update_metrics(updates)

    print("\n[3/3] LeadShark: Creating automations for newly resolved post URLs...")
    if os.environ.get("LEADSHARK_API_KEY"):
        # Read TSV directly — don't rely on Apify matching (URL formats differ)
        leadshark = LeadSharkAgent()
        with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
            tsv_rows = list(csv.DictReader(f, delimiter="\t"))
        for row in tsv_rows:
            post_url = row.get("post_url", "")
            if row.get("leadshark_automation_id"):
                continue
            if not row.get("notion_lead_magnet_url") or not row.get("cta_keyword"):
                continue
            # Resolve post_id and real URL from LeadShark stats API via hook_line match
            hook_line = row.get("hook_line", "")
            ugcpost_urn = row.get("ugcpost_urn", "")
            if hook_line:
                try:
                    stat = leadshark.find_post_by_hook(hook_line)
                    if stat:
                        social_id = stat.get("social_id", "")
                        share_url = stat.get("share_url", "") or post_url
                        # Extract numeric ID from social_id (urn:li:ugcPost:ID or urn:li:activity:ID)
                        m = re.search(r":(\d+)$", social_id)
                        if m:
                            ugcpost_urn = m.group(1)
                        post_url = share_url
                        logger.update_tsv_column(row["post_url"], "ugcpost_urn", ugcpost_urn)
                        logger.update_tsv_column(row["post_url"], "post_url", post_url)
                        row["post_url"] = post_url
                except Exception as exc:
                    print(f"  Warning: LeadShark stats lookup failed: {exc}")
            post_id = ugcpost_urn or _extract_post_id(post_url)
            if not post_url or not post_id:
                continue
            try:
                result = leadshark.run(
                    post_data={"cta_keyword": row.get("cta_keyword", "GUIDE"), "post_id": post_id},
                    notion_data={"page_url": row.get("notion_lead_magnet_url", "")},
                    pub_data={"post_url": post_url},
                    lm_title=row.get("lm_title", ""),
                )
                automation_id = result.get("automation_id", "")
                if automation_id:
                    logger.update_tsv_column(post_url, "leadshark_automation_id", automation_id)
            except Exception as exc:
                print(f"  Warning: LeadShark automation failed for {post_url}: {exc}")
    else:
        print("  LEADSHARK_API_KEY not set — skipping.")

    print("\n=== Metrics update complete ===")

if __name__ == "__main__":
    run()
