#!/usr/bin/env python3
"""Autoresearch strategy improvement orchestrator. Runs Mon/Wed/Fri."""
import json
import os
import requests
from datetime import datetime
from pathlib import Path

import anthropic
from pipeline.agents.strategy_agent import StrategyAgent

NOTION_BASE = "https://api.notion.com/v1"
NOTION_API_VERSION = "2022-06-28"
AUTORESEARCH_DB_ID = os.environ.get(
    "NOTION_AUTORESEARCH_DB_ID", "1bad273050f54749b13fa332cab53d8e"
)


def _top_key(stats: dict) -> str:
    """Return the key with the highest avg_impressions."""
    if not stats:
        return ""
    return max(stats, key=lambda k: stats[k].get("avg_impressions", 0))


def _hypothesis_confirmed(analysis: dict) -> str:
    """Check if i_statement beats other hook types by impressions."""
    hook_stats = analysis.get("by_hook_type", {})
    if len(hook_stats) < 2:
        return "inconclusive"
    top = _top_key(hook_stats)
    return "confirmed" if top == "i_statement" else "disproved"


def _make_rich_text(text: str) -> list:
    """Split long text into 2000-char Notion rich_text chunks."""
    chunks = []
    for i in range(0, min(len(text), 6000), 2000):
        chunks.append({"type": "text", "text": {"content": text[i:i+2000]}})
    return chunks


def log_to_notion(result: dict, new_strategy: str, old_strategy: str):
    """Write an autoresearch run record to the Notion Autoresearch Runs DB."""
    notion_key = os.environ.get("NOTION_API_KEY", "")
    if not notion_key:
        print("  Warning: NOTION_API_KEY not set — skipping Notion log.")
        return

    headers = {
        "Authorization": f"Bearer {notion_key}",
        "Content-Type": "application/json",
        "Notion-Version": NOTION_API_VERSION,
    }

    analysis = result.get("analysis", {})
    version = result.get("new_version", 1)
    today = datetime.now().strftime("%Y-%m-%d")

    # Build a human-readable strategy diff (what changed)
    old_lines = set(old_strategy.splitlines())
    new_lines = set(new_strategy.splitlines())
    added = [f"+ {l}" for l in new_lines - old_lines if l.strip()]
    removed = [f"- {l}" for l in old_lines - new_lines if l.strip()]
    diff_text = "\n".join(removed[:20] + added[:20]) or "No significant changes."

    # Summarise the analysis as compact JSON (top performers only)
    summary = {
        "top_hook": _top_key(analysis.get("by_hook_type", {})),
        "top_topic": _top_key(analysis.get("by_topic", {})),
        "top_format": _top_key(analysis.get("by_format", {})),
        "top_content_type": _top_key(analysis.get("by_content_type", {})),
        "top_angle": _top_key(analysis.get("by_angle", {})),
        "by_hook_type": analysis.get("by_hook_type", {}),
        "by_topic": analysis.get("by_topic", {}),
        "by_format": analysis.get("by_format", {}),
        "by_strategy_version": analysis.get("by_strategy_version", {}),
    }
    analysis_text = json.dumps(summary, indent=2)

    properties = {
        "Name": {
            "title": [{"type": "text", "text": {
                "content": f"Autoresearch v{version} — {today}"
            }}]
        },
        "Date": {"date": {"start": today}},
        "Strategy Version": {"number": version},
        "Posts Analyzed": {"number": result.get("posts_analyzed", 0)},
        "Top Hook Type": {
            "select": {"name": summary["top_hook"]} if summary["top_hook"] else None
        },
        "Top Topic": {
            "select": {"name": summary["top_topic"]} if summary["top_topic"] else None
        },
        "Top Format": {
            "select": {"name": summary["top_format"]} if summary["top_format"] else None
        },
        "Hypothesis Confirmed": {
            "select": {"name": _hypothesis_confirmed(analysis)}
        },
        "Analysis JSON": {"rich_text": _make_rich_text(analysis_text)},
        "Strategy Diff": {"rich_text": _make_rich_text(diff_text)},
        "Findings": {"rich_text": _make_rich_text(_load_findings())},
    }
    # Remove None selects
    properties = {
        k: v for k, v in properties.items()
        if not (isinstance(v, dict) and v.get("select") is None)
    }

    resp = requests.post(
        f"{NOTION_BASE}/pages",
        json={"parent": {"database_id": AUTORESEARCH_DB_ID}, "properties": properties},
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    print(f"  Autoresearch run logged to Notion.")


def _load_findings() -> str:
    """Load the current autoresearch_findings.md if it exists."""
    p = Path("autoresearch_findings.md")
    return p.read_text(encoding="utf-8") if p.exists() else ""


def _write_findings(result: dict):
    """Write a human-readable findings report to autoresearch_findings.md."""
    analysis = result.get("analysis", {})
    version = result.get("new_version", 1)
    posts = result.get("posts_analyzed", 0)
    today = datetime.now().strftime("%Y-%m-%d")

    def fmt_table(data: dict) -> str:
        if not data:
            return "_No data._\n"
        rows = sorted(data.items(), key=lambda x: x[1].get("avg_impressions", 0), reverse=True)
        lines = ["| Category | Posts | Avg Impressions | Avg Engagement Rate |",
                 "|---|---|---|---|"]
        for k, v in rows:
            lines.append(
                f"| {k} | {v.get('count', 0)} "
                f"| {v.get('avg_impressions', 0):.1f} "
                f"| {v.get('avg_engagement_rate', 0):.1f}% |"
            )
        return "\n".join(lines) + "\n"

    top_hook = _top_key(analysis.get("by_hook_type", {}))
    top_topic = _top_key(analysis.get("by_topic", {}))
    top_format = _top_key(analysis.get("by_format", {}))
    top_content = _top_key(analysis.get("by_content_type", {}))
    top_angle = _top_key(analysis.get("by_angle", {}))

    md = f"""# Autoresearch Findings

## Run: {today} — Strategy v{version}
Posts Analyzed: {posts}

---

## Top Performers at a Glance
- **Hook type:** {top_hook}
- **Topic:** {top_topic}
- **Format:** {top_format}
- **Content type:** {top_content}
- **Angle:** {top_angle}

---

## Performance by Hook Type

{fmt_table(analysis.get("by_hook_type", {}))}

---

## Performance by Topic

{fmt_table(analysis.get("by_topic", {}))}

---

## Performance by Format

{fmt_table(analysis.get("by_format", {}))}

---

## Performance by Content Type

{fmt_table(analysis.get("by_content_type", {}))}

---

## Performance by Angle

{fmt_table(analysis.get("by_angle", {}))}

---

## Performance by Word Count Bucket

{fmt_table(analysis.get("by_word_count_bucket", {}))}

---

## Performance by Avg Line Length Bucket

{fmt_table(analysis.get("by_avg_line_length_bucket", {}))}
"""
    Path("autoresearch_findings.md").write_text(md, encoding="utf-8")
    print("  Findings written to autoresearch_findings.md")


def run():
    print("=== Autoresearch Strategy Loop ===")

    # Capture old strategy before update
    old_strategy = ""
    strategy_path = Path("strategy.md")
    if strategy_path.exists():
        old_strategy = strategy_path.read_text(encoding="utf-8")

    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    agent = StrategyAgent(client)
    result = agent.run()

    if result.get("skipped"):
        print(f"  Skipped: {result['reason']}")
    else:
        new_strategy = strategy_path.read_text(encoding="utf-8") if strategy_path.exists() else ""
        print(f"  Strategy updated to version {result['new_version']}")
        print(f"  Posts analyzed: {result['posts_analyzed']}")
        print(f"  Top hook: {_top_key(result.get('analysis', {}).get('by_hook_type', {}))}")
        print(f"  Top topic: {_top_key(result.get('analysis', {}).get('by_topic', {}))}")
        _write_findings(result)
        log_to_notion(result, new_strategy, old_strategy)

    print("\n=== Autoresearch complete ===")


if __name__ == "__main__":
    run()
