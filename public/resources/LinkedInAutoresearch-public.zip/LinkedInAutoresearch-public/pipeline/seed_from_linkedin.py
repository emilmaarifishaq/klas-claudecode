"""One-time script: scrape last 20 LinkedIn posts, classify with Claude, seed results.tsv."""
import csv
import json
import os
import re
import requests
from datetime import datetime
from pathlib import Path

import anthropic
from pipeline.agents.notion_agent import NotionAgent

RESULTS_TSV = Path("results.tsv")
APIFY_BASE = "https://api.apify.com/v2"
ACTOR_ID = "apimaestro~linkedin-profile-posts"
LINKEDIN_USERNAME = "duncanrogoff"
SYNC_TIMEOUT = 300

TSV_COLUMNS = [
    "date", "post_url", "notion_lead_magnet_url", "topic", "hook_type",
    "hook_line", "format", "content_type", "angle", "word_count",
    "line_count", "avg_line_length", "impressions", "likes", "comments",
    "shares", "strategy_version", "notion_tracking_id",
]

_HOOK_TYPES    = ["i_statement", "transformation", "big_number", "contrarian", "question", "list"]
_FORMAT_TYPES  = ["list", "narrative", "before_after", "step_by_step", "q_and_a"]
_CONTENT_TYPES = ["tutorial", "results_reveal", "case_study", "how_to", "story", "opinion", "announcement"]
_ANGLE_TYPES   = ["personal_experience", "social_proof", "contrarian", "authority", "curiosity_gap", "aspiration", "industry_insight"]
_TOPIC_TYPES   = ["ai_automation", "linkedin_growth", "content_systems", "agency_ops", "personal_brand", "other"]


# ------------------------------------------------------------------ #
# Apify
# ------------------------------------------------------------------ #

def scrape_profile(api_token: str, max_posts: int = 20) -> list:
    url = (
        f"{APIFY_BASE}/acts/{ACTOR_ID}/run-sync-get-dataset-items"
        f"?token={api_token}&timeout={SYNC_TIMEOUT}"
    )
    payload = {"username": LINKEDIN_USERNAME, "limit": max_posts}
    print(f"  Calling Apify sync endpoint (timeout={SYNC_TIMEOUT}s)...")
    resp = requests.post(url, json=payload, timeout=SYNC_TIMEOUT + 30)
    resp.raise_for_status()
    return resp.json()


def parse_post(item: dict) -> dict:
    """Extract fields from a raw Apify item."""
    stats = item.get("stats") or {}
    text = (
        item.get("text")
        or item.get("content")
        or item.get("commentary")
        or item.get("postContent")
        or ""
    )
    raw_date = (
        item.get("date")
        or item.get("postedAt")
        or item.get("publishedAt")
        or item.get("createdAt")
        or ""
    )
    # Normalise to YYYY-MM-DD
    post_date = ""
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d"):
        try:
            post_date = datetime.strptime(raw_date[:len(fmt) + 5], fmt).strftime("%Y-%m-%d")
            break
        except (ValueError, TypeError):
            pass
    if not post_date:
        post_date = datetime.now().strftime("%Y-%m-%d")

    return {
        "post_url": item.get("url", ""),
        "post_text": text,
        "date": post_date,
        "impressions": int(stats.get("total_reactions", 0) or 0),
        "likes": int(stats.get("like", 0) or 0),
        "comments": int(stats.get("comments", 0) or 0),
        "shares": int(stats.get("reposts", 0) or 0),
    }


# ------------------------------------------------------------------ #
# Post stats
# ------------------------------------------------------------------ #

def compute_stats(text: str) -> dict:
    if not text:
        return {"word_count": 0, "line_count": 0, "avg_line_length": 0.0}
    lines = [l for l in text.splitlines() if l.strip()]
    word_count = len(text.split())
    line_count = len(lines)
    avg_line_length = round(sum(len(l) for l in lines) / line_count, 1) if lines else 0.0
    return {"word_count": word_count, "line_count": line_count, "avg_line_length": avg_line_length}


# ------------------------------------------------------------------ #
# Claude classification
# ------------------------------------------------------------------ #

CLASSIFY_SYSTEM = """You are a LinkedIn content analyst. Classify a LinkedIn post into structured metadata.

Return ONLY a JSON object with these keys:
- topic: one of [ai_automation, linkedin_growth, content_systems, agency_ops, personal_brand, other]
- hook_type: one of [i_statement, transformation, big_number, contrarian, question, list]
- format: one of [list, narrative, before_after, step_by_step, q_and_a]
- content_type: one of [tutorial, results_reveal, case_study, how_to, story, opinion, announcement]
- angle: one of [personal_experience, social_proof, contrarian, authority, curiosity_gap, aspiration, industry_insight]

Definitions:
- hook/i_statement: first line starts with "I" (personal result or action)
- hook/transformation: "I went from X to Y"
- hook/big_number: leads with a standalone impressive metric
- hook/contrarian: challenges common wisdom
- hook/question: first line is a question
- hook/list: first line introduces a numbered list
- format/list: primary structure uses bullet points or →
- format/narrative: flows as prose
- format/before_after: explicit contrast old vs new state
- format/step_by_step: ordered sequence
- format/q_and_a: poses and answers questions
- content_type/results_reveal: shares a specific outcome
- content_type/case_study: tells a transformation story
- content_type/announcement: launches something new"""


def classify_post(client: anthropic.Anthropic, post_text: str) -> dict:
    """Use Claude to classify a post. Returns metadata dict."""
    msg = client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=256,
        system=CLASSIFY_SYSTEM,
        messages=[{"role": "user", "content": f"Classify this post:\n\n{post_text[:3000]}"}],
    )
    raw = msg.content[0].text.strip()
    # Extract JSON — handle markdown code fences
    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if match:
        try:
            meta = json.loads(match.group())
        except json.JSONDecodeError:
            meta = {}
    else:
        meta = {}

    def validate(val, valid):
        return val if val in valid else valid[0]

    return {
        "topic": validate(meta.get("topic", ""), _TOPIC_TYPES),
        "hook_type": validate(meta.get("hook_type", ""), _HOOK_TYPES),
        "format": validate(meta.get("format", ""), _FORMAT_TYPES),
        "content_type": validate(meta.get("content_type", ""), _CONTENT_TYPES),
        "angle": validate(meta.get("angle", ""), _ANGLE_TYPES),
    }


# ------------------------------------------------------------------ #
# TSV writer
# ------------------------------------------------------------------ #

def write_tsv(rows: list):
    file_exists = RESULTS_TSV.exists() and RESULTS_TSV.stat().st_size > 0
    with RESULTS_TSV.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=TSV_COLUMNS, delimiter="\t", extrasaction="ignore")
        if not file_exists:
            writer.writeheader()
        writer.writerows(rows)


# ------------------------------------------------------------------ #
# Main
# ------------------------------------------------------------------ #

def main():
    apify_token = os.environ.get("APIFY_API_TOKEN", "")
    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")

    if not apify_token:
        raise SystemExit("APIFY_API_TOKEN not set")
    if not anthropic_key:
        raise SystemExit("ANTHROPIC_API_KEY not set")

    print("=== LinkedIn Post Seeder ===\n")

    # 1. Scrape
    print("[1/4] Scraping LinkedIn profile...")
    items = scrape_profile(apify_token, max_posts=20)
    print(f"  Got {len(items)} posts from Apify\n")

    if not items:
        raise SystemExit("Apify returned no items — check actor ID and token")

    # 2. Classify with Claude
    print("[2/4] Classifying posts with Claude...")
    client = anthropic.Anthropic(api_key=anthropic_key)
    notion = NotionAgent()
    rows = []
    post_texts = {}  # post_url -> full text, for Notion

    for i, item in enumerate(items, 1):
        post = parse_post(item)
        if not post["post_url"]:
            print(f"  [{i}/{len(items)}] Skipping — no URL")
            continue

        text = post["post_text"]
        hook_line = text.split("\n")[0].strip() if text else ""
        stats = compute_stats(text)

        if text:
            meta = classify_post(client, text)
        else:
            meta = {
                "topic": "other", "hook_type": "i_statement", "format": "list",
                "content_type": "results_reveal", "angle": "personal_experience",
            }

        post_texts[post["post_url"]] = text

        row = {
            "date": post["date"],
            "post_url": post["post_url"],
            "notion_lead_magnet_url": "",
            "topic": meta["topic"],
            "hook_type": meta["hook_type"],
            "hook_line": hook_line,
            "format": meta["format"],
            "content_type": meta["content_type"],
            "angle": meta["angle"],
            "word_count": stats["word_count"],
            "line_count": stats["line_count"],
            "avg_line_length": stats["avg_line_length"],
            "impressions": post["impressions"],
            "likes": post["likes"],
            "comments": post["comments"],
            "shares": post["shares"],
            "strategy_version": 0,  # pre-strategy baseline
            "notion_tracking_id": "",
        }
        rows.append(row)
        print(f"  [{i}/{len(items)}] {post['date']} | {meta['hook_type']} | {meta['topic']} | "
              f"impressions={post['impressions']} likes={post['likes']} → {hook_line[:60]}")

    # 3. Create Notion tracking rows (with full post text)
    print(f"\n[3/4] Creating {len(rows)} Notion tracking rows...")
    for row in rows:
        try:
            notion_id = notion.create_tracking_row({
                **row,
                "title": row["topic"],
                "published_date": row["date"],
                "post_text": post_texts.get(row["post_url"], ""),
            })
            row["notion_tracking_id"] = notion_id
        except Exception as exc:
            print(f"  Warning: Notion failed for {row['post_url'][:60]}: {exc}")

    # 4. Write TSV
    print(f"\n[4/4] Writing {len(rows)} rows to results.tsv...")
    write_tsv(rows)
    print(f"\n=== Done. {len(rows)} posts seeded into results.tsv + Notion ===")


if __name__ == "__main__":
    main()
