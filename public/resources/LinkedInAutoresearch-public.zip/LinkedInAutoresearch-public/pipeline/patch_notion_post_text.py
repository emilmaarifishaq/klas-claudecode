"""One-time script: re-scrape LinkedIn posts and patch Notion rows with full post text."""
import csv
import os
import requests
from pathlib import Path
from urllib.parse import urlparse

RESULTS_TSV = Path("results.tsv")
APIFY_BASE = "https://api.apify.com/v2"
ACTOR_ID = "apimaestro~linkedin-profile-posts"
LINKEDIN_USERNAME = "duncanrogoff"
SYNC_TIMEOUT = 300
NOTION_BASE = "https://api.notion.com/v1"
NOTION_API_VERSION = "2022-06-28"


def scrape_profile(api_token: str) -> list:
    url = (
        f"{APIFY_BASE}/acts/{ACTOR_ID}/run-sync-get-dataset-items"
        f"?token={api_token}&timeout={SYNC_TIMEOUT}"
    )
    print("  Calling Apify...")
    resp = requests.post(url, json={"username": LINKEDIN_USERNAME, "limit": 50},
                         timeout=SYNC_TIMEOUT + 30)
    resp.raise_for_status()
    return resp.json()


def patch_notion_page(page_id: str, post_text: str, headers: dict):
    rich_text = []
    # Notion rich_text blocks max 2000 chars each
    for i in range(0, min(len(post_text), 6000), 2000):
        rich_text.append({"type": "text", "text": {"content": post_text[i:i+2000]}})
    resp = requests.patch(
        f"{NOTION_BASE}/pages/{page_id}",
        json={"properties": {"Post Text": {"rich_text": rich_text}}},
        headers=headers,
    )
    resp.raise_for_status()


def main():
    api_token = os.environ["APIFY_API_TOKEN"]
    notion_key = os.environ["NOTION_API_KEY"]

    notion_headers = {
        "Authorization": f"Bearer {notion_key}",
        "Content-Type": "application/json",
        "Notion-Version": NOTION_API_VERSION,
    }

    # Load results.tsv to get notion_tracking_id by post_url
    with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))

    def url_path(u):
        return urlparse(u.strip()).path

    url_to_notion_id = {
        url_path(r["post_url"]): r["notion_tracking_id"].strip()
        for r in rows
        if r.get("notion_tracking_id", "").strip()
    }
    print(f"  Found {len(url_to_notion_id)} rows with Notion IDs\n")

    print("[1/2] Scraping LinkedIn for post text...")
    items = scrape_profile(api_token)
    print(f"  Got {len(items)} posts\n")

    print("[2/2] Patching Notion rows with post text...")
    patched = 0
    for item in items:
        item_url = item.get("url", "")
        post_text = (
            item.get("text") or item.get("content") or
            item.get("commentary") or item.get("postContent") or ""
        )
        if not item_url or not post_text:
            continue

        # Match by URL substring
        item_path = url_path(item_url)
        notion_id = url_to_notion_id.get(item_path)
        if not notion_id:
            continue

        try:
            patch_notion_page(notion_id, post_text, notion_headers)
            patched += 1
            print(f"  [{patched}] Patched: {item_url[:70]}")
        except Exception as exc:
            print(f"  Warning: failed for {item_url[:60]}: {exc}")

    print(f"\n=== Done. {patched} Notion rows updated with post text. ===")


if __name__ == "__main__":
    main()
