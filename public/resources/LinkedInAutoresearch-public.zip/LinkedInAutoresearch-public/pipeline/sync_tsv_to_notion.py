"""One-time script: create Notion tracking rows for any results.tsv rows missing notion_tracking_id."""
import csv
import os
from pathlib import Path

from pipeline.agents.notion_agent import NotionAgent

RESULTS_TSV = Path("results.tsv")


def main():
    if not RESULTS_TSV.exists():
        raise SystemExit("results.tsv not found")

    with RESULTS_TSV.open("r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        rows = list(reader)
        fieldnames = reader.fieldnames

    notion = NotionAgent()
    updated = 0

    for i, row in enumerate(rows):
        if row.get("notion_tracking_id", "").strip():
            continue  # already synced

        post_url = row.get("post_url", "").strip()
        if not post_url:
            continue

        try:
            notion_id = notion.create_tracking_row({
                "title": row.get("topic", ""),
                "post_url": post_url,
                "notion_lead_magnet_url": row.get("notion_lead_magnet_url", ""),
                "published_date": row.get("date", ""),
                "topic": row.get("topic", ""),
                "hook_type": row.get("hook_type", ""),
                "hook_line": row.get("hook_line", ""),
                "format": row.get("format", ""),
                "content_type": row.get("content_type", ""),
                "angle": row.get("angle", ""),
                "word_count": int(row.get("word_count", 0) or 0),
                "line_count": int(row.get("line_count", 0) or 0),
                "avg_line_length": float(row.get("avg_line_length", 0) or 0),
                "impressions": int(row.get("impressions", 0) or 0),
                "likes": int(row.get("likes", 0) or 0),
                "comments": int(row.get("comments", 0) or 0),
                "shares": int(row.get("shares", 0) or 0),
                "strategy_version": int(row.get("strategy_version", 0) or 0),
                "post_text": "",
            })
            rows[i]["notion_tracking_id"] = notion_id
            updated += 1
            print(f"  [{updated}] Created Notion row for: {post_url[:80]}")
        except Exception as exc:
            print(f"  Warning: failed for {post_url[:60]}: {exc}")

    # Write updated TSV back
    with RESULTS_TSV.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    print(f"\n=== Done. {updated} Notion rows created, results.tsv updated. ===")


if __name__ == "__main__":
    main()
