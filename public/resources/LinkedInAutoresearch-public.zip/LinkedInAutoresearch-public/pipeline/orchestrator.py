#!/usr/bin/env python3
"""Daily content pipeline orchestrator. Runs all agents in sequence."""
import os
import anthropic
from pipeline.agents.research_agent import ResearchAgent
from pipeline.agents.lead_magnet_agent import LeadMagnetAgent
from pipeline.agents.post_writer_agent import PostWriterAgent
from pipeline.agents.notion_agent import NotionAgent
from pipeline.agents.video_agent import VideoAgent
from pipeline.agents.publisher_agent import PublisherAgent
from pipeline.agents.logger_agent import LoggerAgent

def run():
    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    print("=== LinkedIn Autoresearch Daily Pipeline ===")

    # Step 1: Research - scrape Reddit, pick topic
    print("\n[1/7] Research Agent: Scraping Reddit trends...")
    research = ResearchAgent(client)
    topic_data = research.run()
    print(f"  Topic selected: {topic_data['topic']}")

    # Step 2: Lead Magnet - generate full JSON
    print("\n[2/7] Lead Magnet Agent: Generating lead magnet...")
    lm_agent = LeadMagnetAgent(client)
    lm_data = lm_agent.run(topic=topic_data)
    print(f"  Lead magnet: {lm_data['title']}")

    # Step 3: Post Writer - generate LinkedIn post
    print("\n[3/7] Post Writer Agent: Writing LinkedIn post...")
    post_agent = PostWriterAgent(client)
    post_data = post_agent.run(topic=topic_data, lead_magnet=lm_data)
    print(f"  Hook type: {post_data['hook_type']}")

    # Step 4: Notion - push lead magnet, get public URL
    print("\n[4/7] Notion Agent: Publishing lead magnet to Notion...")
    notion_agent = NotionAgent()
    notion_data = notion_agent.run(lead_magnet=lm_data)
    print(f"  Page ID: {notion_data['page_id']}")

    # Step 5: Video - record Notion page scroll + overlay
    print("\n[5/7] Video Agent: Recording scroll video...")
    video_agent = VideoAgent()
    video_data = video_agent.run(
        lead_magnet=lm_data,
        post_data=post_data,
        notion_page_id=notion_data['page_id']
    )
    print(f"  Video: {video_data['video_path']}")

    # Step 6: Publisher - BloTato publish to LinkedIn
    print("\n[6/7] Publisher Agent: Publishing to LinkedIn...")
    publisher = PublisherAgent()
    pub_data = publisher.run(
        post_text=post_data['post_text'],
        video_path=video_data['video_path'],
        notion_url=notion_data['page_url']
    )
    print(f"  Post URL: {pub_data['post_url']}")

    # Step 7: Logger - save to results.tsv + Notion tracking DB
    print("\n[7/7] Logger Agent: Saving to results.tsv + Notion...")
    logger = LoggerAgent()
    logger.run(
        topic=topic_data,
        post_data=post_data,
        notion_data=notion_data,
        pub_data=pub_data,
        lm_data=lm_data,
    )

    print("\n=== Pipeline complete ===")

if __name__ == "__main__":
    run()
