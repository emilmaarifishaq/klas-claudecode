# LinkedIn Post Examples

Each lead magnet gets 3 LinkedIn post variations. Each variation uses a different hook angle.

## Rules

- 150-200 words
- First 2 lines are everything — they must stop the scroll
- White space between sentences (mobile readability)
- End with comment-trigger CTA: "Comment KEYWORD and I'll send it"
- 3-5 hashtags at the end
- Tone: direct, proof-driven, operator energy
- No links in the body (LinkedIn throttles posts with links)

## 3 Hook Angles (ALWAYS produce all three)

### Variation A: Contrarian / Hot-Take
Lead with something unexpected or counter-intuitive. Challenge conventional wisdom.

Example hooks:
- "Most people are using Perplexity Computer like a $200/mo Google search."
- "Hot take: the AI agent wars are wasting your money."
- "Everyone's building AI agents. Almost nobody's using them right."

### Variation B: Pain-First / Problem-Aware
Start with the reader's frustration. Make them feel seen before offering the solution.

Example hooks:
- "Perplexity Computer costs $200/mo. Most people sign up, run 3 prompts, and cancel."
- "You signed up for 3 AI tools this month. You finished zero projects."
- "Every AI launch promises to 'do the work for you.' None of them explain how."

### Variation C: Results-Led / Proof
Lead with a specific, tangible result. Let the outcome sell the content.

Example hooks:
- "One prompt replaced 4 hours of competitor research."
- "I tested all 3 AI agents so you don't have to. Here's the honest breakdown."
- "15 prompts. 19 AI models. Zero wasted credits."

## Structure Template

```
[HOOK — 2 lines max, scroll-stopping]

[BLANK LINE]

[CONTEXT — 2-3 sentences explaining the problem or setup]

[BLANK LINE]

[VALUE — 3-5 bullet points or key insights from the lead magnet]

[BLANK LINE]

[CTA — Comment KEYWORD and I'll send it / Comment KEYWORD for the free guide]

[BLANK LINE]

#Hashtag1 #Hashtag2 #Hashtag3
```

## Anti-Patterns

- Don't start with "I just created..." — nobody cares about your process
- Don't list all 15 items — tease 3-4, let them want the rest
- Don't use corporate language — write like you talk
- Don't put the link in the post body — LinkedIn throttles it. Use comment CTA instead
- Don't make the CTA keyword generic — make it memorable and topic-specific (PERPLEXITY, AGENTS, PROMPTS, etc.)
