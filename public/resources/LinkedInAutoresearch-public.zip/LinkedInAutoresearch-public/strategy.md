# Content Strategy

Strategy Version: 4
Last Updated: 2026-03-25
Posts Analyzed: 27

## Starting Hypothesis
Personal "I" hooks with multiple specific numbers are the highest performers.
Example: "I grew my LinkedIn to 10,000 followers in 90 days. Claude Code did most of the work."
Pattern: "I [achieved result] in [timeframe]. [Specific tool/method] made it happen."
Include at least 2–3 numbers in every post (followers, days, percentage, dollars, hours saved).

## Topic Guidance
Focus: AI automation workflows above all else. 17 posts averaging 3,780.6 impressions/day and 404.59 avg comments at 3.71% engagement — this is the only topic with meaningful data volume and it dominates every metric by a wide margin.
LinkedIn growth (267.0 imp/day, 1 post) and personal brand (181.9 imp/day, 2 posts) are underrepresented and severely underperform. Do not deprioritize AI automation to diversify.
Avoid overly specific "AI workflow that replaces X" topic labels — posts with that framing averaged 0.0 impressions/day across 4 posts. These are likely tagging or publishing errors; audit and reclassify before adding more posts under those labels. This issue was flagged in v3 and remains unresolved.
Priority: Concrete copy-paste systems over theory. Show transformations with real numbers. Duncan's personal results and client wins should be the source material wherever possible.

## Hook Type Priority (updated with data)
1. **transformation — Dominant reach leader.** 5,207.7 avg impressions/day across 5 posts, 3.53% engagement. "I went from X to Y in N days." This is the clearest and most consistent reach signal in the dataset. Scale this immediately. Confirmed across v3 and v4 analysis runs.
2. **big_number — Reliable at volume.** 3,082.2 avg impressions/day across 10 posts, 3.07% engagement. The only hook type with double-digit post count and competitive reach. Consistent and scalable. Confirmed across v3 and v4 analysis runs.
3. **i_statement — Hypothesis disproved as a reach driver.** Only 740.8 avg impressions/day across 12 posts — the lowest reach of all three hook types by 4x vs big_number and 7x vs transformation. Engagement rate (2.98%) is comparable but reach is not. i_statement hooks sustain interaction from existing followers but do not drive new reach. This finding is now confirmed across three consecutive analysis runs (v2, v3, v4). Demoted from starting hypothesis. Do not use as default.

## Hook Guidance
Lead with a transformation or big number hook for maximum reach.
Transformation pattern: "I went from [before state] to [after state] in [timeframe]."
Big number pattern: Lead line is the metric. Make it impossible to scroll past.
i_statement hooks are acceptable for engagement plays targeting existing followers but must not be the default. The data is consistent across three analysis runs — they do not drive impressions.
Second line: "Here's X:" or "Here's how:"
Include 2–3 additional numbers in the body.
Never start with a question.

## Format Guidance
**List format is the reach engine.** 16 posts averaging 3,750.8 impressions/day and 3.21% engagement. Default to list structure for any post intended to drive reach. Confirmed across v3 and v4 analysis runs — this is the most volume-tested finding in the dataset.
Step-by-step has the highest engagement rate (3.82%) across 2 posts at 1,305.2 impressions/day. Low confidence due to sample size, but worth continued testing. Use for tutorial-style content.
Narrative underperforms severely on reach — 359.9 impressions/day across 8 posts, the lowest format in the set. This is consistent across v2, v3, and v4. Reserve narrative for high-stakes personal story moments only. Do not use as a default.
Before/after: 1 post at 247.0 impressions/day. Insufficient data. Do not rely on it.

## Content Type Guidance
**Results reveal drives reach.** 13 posts averaging 4,044.2 impressions/day. This is the workhorse content type. Confirmed from previous runs. Note: engagement rate (2.31%) is below dataset average — results reveal posts generate impressions but may not be converting to high interaction. Pair with a strong CTA and list format to compensate.
Announcement posts punch above their weight on engagement (3.81%) across 7 posts at 1,245.1 impressions/day. Use for product, offer, or milestone moments.
How_to: 2 posts at 270.4 impressions/day but the highest engagement rate in the dataset (4.83%). Sample is still too small to draw strong conclusions, but the engagement signal is noteworthy. Expanded testing warranted.
Tutorial has solid engagement rate (3.56%) but lower reach (783.6 impressions/day across 5 posts). Best for depth plays with existing audience, not new reach.

## Angle Guidance
**Social proof is the reach leader.** 6 posts averaging 4,517.0 impressions/day and 3.66% engagement. Lead with client wins, external validation, or third-party results wherever possible. Confirmed across v3 and v4 analysis runs — the most consistent high-reach signal by angle.
Personal experience is the most-used angle (16 posts) but generates less than half the reach of social proof (2,176.0 vs 4,517.0 impressions/day). Do not over-index on personal experience. Pair it with social proof framing when possible.
Aspiration has the highest engagement rate (4.25%) at moderate reach (1,276.0 impressions/day) across 2 posts. Good for CTA-heavy posts targeting existing audience.
Contrarian: 1 post at 793.0 impressions/day and 2.77% engagement. Previously flagged as a potential outlier — current data confirms it is mid-tier on both metrics. Lower confidence in the contrarian signal. Worth occasional testing but do not prioritize over social proof.
Authority (175.2 impressions/day) and industry insight (311.5 impressions/day) both severely underperform. Deprioritize.

## Post Length Guidance
**Long posts (>150 words) win on reach.** 13 posts averaging 4,540.0 impressions/day — the highest-reach bucket by a significant margin. This confirms the finding from v2, v3, and v4 across a growing sample. The signal is strong and consistent.
Medium posts (80–150 words) win on engagement rate (3.95%) but only 657.9 impressions/day across 9 posts. Use medium length for community engagement plays targeting existing followers, not new reach.
Short posts (<80 words) underperform on both reach (161.8 impressions/day) and engagement (2.07%) across 5 posts. Avoid entirely. Confirmed underperformers across all analysis runs.
Write long. Aim for 150+ words per post. This is the most consistent signal in the dataset.

## Line Length Guidance
Medium line length (40–70 chars) is the sweet spot — 3,824.4 impressions/day and 3.18% engagement across 16 posts. This is the confirmed default. Finding consistent across v3 and v4.
Long lines (>70 chars) hurt reach (509.5 impressions/day across 8 posts). Break up dense paragraphs into separate lines. Do not write walls of text.
Punchy short lines (<40 chars) also underperform on reach (161.3 impressions/day) and engagement (1.90%) across 3 posts — confirmed underperformers across all analysis runs. Despite common LinkedIn advice, do not write one-word lines or fragment sentences for effect.
Write complete, direct sentences in the 40–70 character range per line.

## Day-of-Week Guidance
25 of 27 mature posts were published on Saturday (avg 2,606.3 impressions/day). Sunday and Monday each have 1 post — insufficient for comparison. No day-of-week analysis is possible with this distribution. This data collection gap was flagged in v2 and v3 and remains unresolved.