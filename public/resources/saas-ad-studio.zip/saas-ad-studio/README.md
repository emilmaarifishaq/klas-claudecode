# SaaS Ad Studio

Turn a SaaS website, web app, or product URL into a short, premium **cinematic ad that features
the real product UI** — the pitch-black "Anthropic / Linear / Vercel" look: one accent color,
locked-frame scene-by-scene UI reveals built from real screenshots, scored with music and
on-screen text.

You give it a URL. It audits the live product, pulls the real brand colors, screenshots the hero
screens, builds cinematic hero frames, animates them, scores them, and assembles a finished MP4 —
with just **two check-ins** (concept, then storyboard). Everything else runs autonomously.

This is a Claude Code **skill**: a folder of instructions Claude reads and executes. There's no app
to install — Claude does the work, calling the tools listed below.

---

## What you need before running

| Requirement | Why | How to get it |
|---|---|---|
| **Higgsfield MCP** (connector or direct MCP) | Generates the hero frames (GPT Image 2) and animates them (Seedance 2.0) | Add Higgsfield as a connector in Claude, or install its MCP server. After connecting, run `/mcp` to see your exact tool prefix. |
| **Playwright MCP** | Screenshots the live product and reads its real CSS brand tokens | Add the Playwright MCP server (`mcp__playwright__browser_*`). |
| **Firecrawl MCP** *(optional)* | Fallback when a product is behind login or a heavy SPA Playwright can't reach | Add the Firecrawl MCP server, or skip — Playwright covers most cases. |
| **ffmpeg** | Stitches segments, burns on-screen text, muxes the music | `brew install ffmpeg` (macOS). |

> **Find your Higgsfield prefix first.** This skill calls tools like `generate_image` and
> `generate_video`. The full tool name is `<your-higgsfield-prefix>__generate_image`. The prefix
> depends on how Higgsfield is connected:
> - **claude.ai connector** → `mcp__claude_ai_Higgsfield__`
> - **Higgsfield's own MCP install** → `mcp__higgsfield__`
> - **a custom/direct MCP server** → a server-ID hash (e.g. `mcp__<hash>__`)
>
> Run `/mcp` to confirm yours, then use it throughout. The tool *names* after the prefix are the
> same in every case.

This skill spends **Higgsfield credits** every run (image + video generation). Use the `get_cost`
preflight (covered in `references/higgsfield-tools.md`) before a large batch if you're watching
spend.

---

## Install the skill

Drop this whole `saas-ad-studio/` folder into either:

- `~/.claude/skills/saas-ad-studio/` — available in every project, **or**
- `<your-project>/.claude/skills/saas-ad-studio/` — scoped to one project.

Restart Claude Code (or start a new session) so it picks up the skill.

## Run it

In Claude Code, type:

```
/saas-ad-studio https://yourproduct.com
```

…or just say *"make a cinematic ad for my SaaS — here's the URL."* You can pass options inline:
login creds (if the good screens are gated), aspect ratio (`16:9` default, `9:16`, `1:1`),
duration (`15` / `30` / `60`s), and brand colors if you already know them. If you don't, it reads
them off the live site.

Output lands in `./saas-ad-studio/<product-slug>/` — including a living `brief.html` you can open
in a browser to watch the whole build (research → concept → storyboard → final video).

---

## What's in this folder

| File | What it is |
|---|---|
| `SKILL.md` | The skill itself — the full pipeline Claude follows. |
| `references/cinematic-ui-doctrine.md` | The look: camera vocabulary, shot archetypes, copy-paste prompt templates, the no-morph rule. |
| `references/audit-playbook.md` | How to screenshot the live UI and extract the real brand palette. |
| `references/higgsfield-tools.md` | Tool + model contract: params, polling, downloading, cost preflight. |
| `references/assembly.md` | The ffmpeg recipes: text burn-in, concat, music mux, voiceover. |

---

## Companion: build a site to run the ad on

If you also want a **website** for the brand (not just the ad), grab the **CCC Site Kit** plugin —
it builds a $10k-class animated landing page from one config and ships it live. The two are a
natural pair: Site Kit makes the page, SaaS Ad Studio makes the cinematic spot that lives on it.
They're independent — neither needs the other to run.
