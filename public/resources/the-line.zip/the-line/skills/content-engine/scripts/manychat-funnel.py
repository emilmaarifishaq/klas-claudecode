#!/usr/bin/env python3
"""
One-shot ManyChat funnel creator (example/template).
Opens a visible browser — log in with Google SSO when prompted.
The automation continues once you're logged in.

Optional integration — bring your own ManyChat account. Fill in the CONFIG
block below with your own keyword, copy, links, and ManyChat page ID. The
flow URL contains your ManyChat page ID (the `fbNNNNNNN` segment) — set it via
the MANYCHAT_PAGE_ID env var or replace the placeholder below.
"""
from playwright.sync_api import sync_playwright
from pathlib import Path
import os
import time

PROFILE_DIR = Path.home() / ".claude/skills/manychat/.chrome-profile"

# ── CONFIG — fill in with your own values ───────────────────────────────────
KEYWORD = "EXAMPLE"
FLOW_NAME = f"EXAMPLE - Free Guide - MM/DD/YYYY"
OPENING_DM = "Want the free guide? Tap below 👇"
OPENING_BTN = "Send me the links"
LINK_DM = "Here you go 👇"
LINK1_LABEL = "Watch the Build"
LINK1_URL = "https://www.youtube.com/watch?v=VIDEO_ID"
LINK2_LABEL = "Free Guide"
LINK2_URL = "[YOUR_GUIDE_URL]"
FOLLOWUP_DM = "Did you grab it? Links are still above 👆"
# A second distinctive fragment from FLOW_NAME used to disambiguate the row
# in ManyChat's UI (e.g. a few words from your flow title).
FLOW_TAG = "Free Guide"

# Your ManyChat page ID — the `fbNNNNNNN` segment of your ManyChat URLs.
MANYCHAT_PAGE_ID = os.environ.get("MANYCHAT_PAGE_ID", "[YOUR_MANYCHAT_PAGE_ID]")
FLOWS_URL = f"https://app.manychat.com/{MANYCHAT_PAGE_ID}/cms?path=/&field=modified&order=desc"


def wait_for_captcha(page):
    """If a CAPTCHA appeared, wait for the user to solve it."""
    if "confirm you are human" in page.content().lower() or "captcha" in page.url.lower():
        print("\n⚠  CAPTCHA detected — please solve it in the browser window.")
        print("   Waiting up to 2 minutes...\n")
        try:
            page.wait_for_function(
                "() => !document.body.innerText.toLowerCase().includes('confirm you are human')",
                timeout=120000
            )
            time.sleep(2)
            print("✓ CAPTCHA solved.\n")
        except:
            print("⚠  CAPTCHA wait timed out — continuing anyway.")


def wait_for_login(page):
    """Watch the browser — user logs in visually, we detect when they're done."""
    if "/signin" in page.url or "/login" in page.url or "accounts.google" in page.url:
        print("\n⚠  Sign in with Google in the browser window. Waiting up to 5 minutes...")
        try:
            page.wait_for_function(
                "() => !window.location.href.includes('/signin') && "
                "!window.location.href.includes('/login') && "
                "!window.location.href.includes('accounts.google')",
                timeout=300000
            )
            time.sleep(2)
            print("✓ Logged in.\n")
        except:
            print("✗ Login timed out.")
            return False
    return True


def ensure_on_flows(page):
    """If ManyChat redirected to sign-in, watch the browser and wait for re-login."""
    if "/signin" in page.url or "/login" in page.url or "accounts.google" in page.url:
        print("\n⚠  ManyChat kicked you out — log back in via the browser window. Waiting...")
        try:
            page.wait_for_function(
                "() => !window.location.href.includes('/signin') && "
                "!window.location.href.includes('/login') && "
                "!window.location.href.includes('accounts.google')",
                timeout=300000
            )
            time.sleep(2)
            print("✓ Back in. Resuming...\n")
        except:
            print("✗ Re-auth timed out.")
            return False
    return True


def dismiss_overlays(page):
    """Remove Braze in-app message overlays and any ManyChat interstitial popups."""
    page.evaluate("""
        () => {
            // Remove Braze overlays (ab-iam-root)
            document.querySelectorAll('.ab-iam-root, .ab-in-app-message').forEach(el => el.remove());
            // Dismiss ManyChat interstitial buttons
            const btns = Array.from(document.querySelectorAll('button'));
            const dismiss = btns.find(b =>
                b.textContent.includes("Maybe Later") ||
                b.textContent.includes("Yes, That") ||
                b.textContent.includes("Dismiss") ||
                b.textContent.includes("Got it")
            );
            if (dismiss) dismiss.click();
        }
    """)
    time.sleep(0.5)


def set_react_value(page, selector_or_index, value, inputs_list=None):
    """Set value on a React-controlled input."""
    if inputs_list is not None:
        page.evaluate(f"""
            () => {{
                function setVal(el, value) {{
                    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
                    el.dispatchEvent(new Event('input', {{ bubbles: true }}));
                    el.dispatchEvent(new Event('change', {{ bubbles: true }}));
                }}
                const inputs = Array.from(document.querySelectorAll('input, textarea'));
                if (inputs[{selector_or_index}]) setVal(inputs[{selector_or_index}], {repr(value)});
            }}
        """)
    else:
        page.evaluate(f"""
            () => {{
                const el = document.querySelector({repr(selector_or_index)});
                if (el) {{
                    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
                    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, {repr(value)});
                    el.dispatchEvent(new Event('input', {{ bubbles: true }}));
                    el.dispatchEvent(new Event('change', {{ bubbles: true }}));
                }}
            }}
        """)


with sync_playwright() as p:
    # Persistent profile — login once, every future run is automatic
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    ctx = p.chromium.launch_persistent_context(
        user_data_dir=str(PROFILE_DIR),
        headless=False,
        slow_mo=200,
    )
    page = ctx.new_page()

    # ── Step 1: Login check ─────────────────────────────────────────────────
    print("Step 1: Checking login...")
    page.goto("https://app.manychat.com", wait_until="domcontentloaded", timeout=30000)
    time.sleep(2)

    if not wait_for_login(page):
        ctx.close()
        exit(1)

    print("✓ Using persistent profile — no session save needed.")

    # ── Step 2: Navigate to Flows ───────────────────────────────────────────
    print("Step 2: Navigating to Flows...")
    page.goto(FLOWS_URL, wait_until="domcontentloaded", timeout=30000)
    time.sleep(3)
    wait_for_captcha(page)

    # Dismiss interstitial popups and Braze overlays
    dismiss_overlays(page)

    page.screenshot(path="/tmp/mc_01_flows.png")
    print("  → Screenshot: /tmp/mc_01_flows.png")

    # ── Step 3: Duplicate LEADMAGNET TEMPLATE ──────────────────────────────
    print("Step 3: Duplicating LEADMAGNET TEMPLATE...")
    page.evaluate("""
        () => {
            // Works with both old (article/h1) and new (row/div) ManyChat UI
            function findRowByText(text) {
                // Try old CMS UI first
                for (const article of document.querySelectorAll('article')) {
                    const h = article.querySelector('h1');
                    if (h && h.textContent.includes(text)) return article;
                }
                // New automations UI: find the text node, walk up to the row with buttons
                for (const el of document.querySelectorAll('*')) {
                    if (el.children.length === 0 && el.textContent.trim() === text) {
                        let node = el.parentElement;
                        for (let i = 0; i < 8; i++) {
                            if (!node) break;
                            if (node.querySelectorAll('button').length > 0) return node;
                            node = node.parentElement;
                        }
                    }
                }
                return null;
            }
            const row = findRowByText('LEADMAGNET TEMPLATE');
            if (row) {
                row.scrollIntoView({ behavior: 'instant', block: 'center' });
                row.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                row.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
                const btns = row.querySelectorAll('button');
                if (btns.length) btns[btns.length - 1].click();
            }
        }
    """)
    time.sleep(1)
    page.evaluate("""
        () => {
            const dup = Array.from(document.querySelectorAll('button, li'))
                .find(el => el.textContent.trim() === 'Duplicate');
            if (dup) dup.click();
        }
    """)
    time.sleep(3)
    wait_for_captcha(page)

    # ManyChat sometimes forces re-auth after a write operation with a saved session
    if not ensure_on_flows(page):
        ctx.close()
        exit(1)

    page.screenshot(path="/tmp/mc_02_duplicated.png")
    print("  → Screenshot: /tmp/mc_02_duplicated.png")

    # ── Step 4: Rename flow ─────────────────────────────────────────────────
    print("Step 4: Renaming flow...")
    page.evaluate("""
        () => {
            function findRowByText(text) {
                for (const article of document.querySelectorAll('article')) {
                    const h = article.querySelector('h1');
                    if (h && h.textContent.includes(text)) return article;
                }
                for (const el of document.querySelectorAll('*')) {
                    if (el.children.length === 0 && el.textContent.trim().includes(text)) {
                        let node = el.parentElement;
                        for (let i = 0; i < 8; i++) {
                            if (!node) break;
                            if (node.querySelectorAll('button').length > 0) return node;
                            node = node.parentElement;
                        }
                    }
                }
                return null;
            }
            // Find the first row that contains "LEADMAGNET TEMP" (the new duplicate at top)
            const row = findRowByText('LEADMAGNET TEMP');
            if (row) {
                row.scrollIntoView({ behavior: 'instant', block: 'center' });
                row.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
                row.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
                const btns = row.querySelectorAll('button');
                if (btns.length) btns[btns.length - 1].click();
            }
        }
    """)
    time.sleep(1)
    page.evaluate("""
        () => {
            Array.from(document.querySelectorAll('button, li'))
                .find(el => el.textContent.trim() === 'Rename')?.click();
        }
    """)
    time.sleep(1)
    name_input = page.locator('[data-test-id="name-input"]')
    name_input.click(click_count=3)
    name_input.fill(FLOW_NAME)
    time.sleep(0.5)
    page.locator('button:has-text("Rename")').last.click()
    time.sleep(2)
    page.screenshot(path="/tmp/mc_03_renamed.png")
    print(f"  → Renamed to: {FLOW_NAME}")

    # ── Step 5: Open flow editor ────────────────────────────────────────────
    print("Step 5: Opening flow editor...")
    flow_url = page.evaluate(f"""
        () => {{
            // Try old CMS UI (article/a)
            for (const a of document.querySelectorAll('article')) {{
                const h = a.querySelector('h1');
                if (h && h.textContent.includes('{KEYWORD}')) {{
                    const link = a.querySelector('a');
                    if (link) return link.href;
                }}
            }}
            // New automations UI: find text node, walk up to find a link
            for (const el of document.querySelectorAll('*')) {{
                if (el.children.length === 0 && el.textContent.trim().includes('{KEYWORD}') && el.textContent.trim().includes('{FLOW_TAG}')) {{
                    let node = el;
                    for (let i = 0; i < 8; i++) {{
                        if (!node) break;
                        if (node.tagName === 'A' && node.href) return node.href;
                        // Also check children for links
                        const link = node.querySelector('a[href]');
                        if (link) return link.href;
                        node = node.parentElement;
                    }}
                }}
            }}
            return null;
        }}
    """)
    if flow_url:
        print(f"  → Navigating to: {flow_url}")
        page.goto(flow_url, wait_until="domcontentloaded", timeout=30000)
        time.sleep(3)
    else:
        # New UI: click the automation name directly to open the editor
        print(f"  → No link found — clicking automation name to open editor...")
        page.evaluate(f"""
            () => {{
                for (const el of document.querySelectorAll('*')) {{
                    if (el.children.length === 0 && el.textContent.trim().includes('{KEYWORD}') && el.textContent.trim().includes('{FLOW_TAG}')) {{
                        el.click();
                        return;
                    }}
                }}
            }}
        """)
        time.sleep(3)

    # ── Step 6: Click Edit ──────────────────────────────────────────────────
    print("Step 6: Entering edit mode...")
    edit_btn = page.locator('button:has-text("Edit")').first
    if edit_btn.is_visible():
        edit_btn.click()
        time.sleep(2)

    # Kill any Braze overlays that loaded in the editor
    dismiss_overlays(page)

    page.screenshot(path="/tmp/mc_04_editor.png")
    print("  → Screenshot: /tmp/mc_04_editor.png")

    # ── Step 7: Fill keyword, opening DM, link DM body, follow-up ──────────
    print("Step 7: Filling text fields...")
    set_react_value(page, 4, KEYWORD, inputs_list=True)
    time.sleep(0.3)
    set_react_value(page, 11, OPENING_DM, inputs_list=True)
    time.sleep(0.3)
    set_react_value(page, 16, LINK_DM, inputs_list=True)
    time.sleep(0.3)
    set_react_value(page, 18, FOLLOWUP_DM, inputs_list=True)
    time.sleep(0.5)
    page.screenshot(path="/tmp/mc_05_fields.png")
    print("  → Screenshot: /tmp/mc_05_fields.png")

    # ── Step 8: Scroll sidebar and fill link buttons ────────────────────────
    print("Step 8: Filling link buttons...")
    try:
        page.evaluate("() => { const s = document.querySelector('._sidebar_1vex7_19'); if (s) s.scrollTop = 2000; }")
        time.sleep(1)
    except:
        pass

    for label_text, new_label, new_url in [("link1", LINK1_LABEL, LINK1_URL), ("link2", LINK2_LABEL, LINK2_URL)]:
        try:
            page.evaluate(f"""
                () => {{
                    const spans = Array.from(document.querySelectorAll('span.text-ellipsis'));
                    const el = spans.find(s => s.textContent.trim() === '{label_text}');
                    if (el) el.closest('[class*="d-flex"]').click();
                }}
            """)
            time.sleep(1)
            modal = page.locator('[data-test-id="dm-link-modal"]')
            if modal.is_visible():
                label_field = modal.get_by_role('textbox', name='Button label')
                label_field.click(click_count=3)
                label_field.fill(new_label)
                url_field = modal.get_by_role('textbox', name='Link')
                url_field.click(click_count=3)
                url_field.fill(new_url)
                page.locator('button:has-text("Save")').click()
                time.sleep(1)
                print(f"  → {label_text}: '{new_label}' → {new_url}")
            else:
                print(f"  ⚠ Modal not visible for {label_text}")
        except Exception as e:
            print(f"  ⚠ Error on {label_text}: {e}")

    page.screenshot(path="/tmp/mc_06_buttons.png")

    # ── Step 9: Save and Go Live ────────────────────────────────────────────
    print("Step 9: Saving and activating...")
    dismiss_overlays(page)
    update_btn = page.locator('button:has-text("Update"), button:has-text("Save")').first
    if update_btn.is_visible():
        update_btn.click()
        time.sleep(2)

    golive_btn = page.locator('button:has-text("Go Live"), button:has-text("Activate")').first
    if golive_btn.is_visible():
        golive_btn.click()
        time.sleep(2)
        print("  ✓ Flow is LIVE")
    else:
        print("  ⚠ Go Live button not found — may already be live or check screenshot")

    page.screenshot(path="/tmp/mc_07_live.png")
    print("  → Screenshot: /tmp/mc_07_live.png")

    print(f"\n✓ Done! Flow: {FLOW_NAME}")
    print(f"  Keyword: {KEYWORD}")
    print(f"  Test: Comment '{KEYWORD}' from another account on your latest Instagram post.")

    ctx.close()
