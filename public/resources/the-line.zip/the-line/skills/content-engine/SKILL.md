---
name: content-engine
description: "Turn your YouTube video into a full content engine run with direct publishing via Blotato MCP. Fetches transcript automatically, generates all pieces in your voice, publishes immediately to LinkedIn (personal + your community page), Facebook, Instagram carousel, and TikTok. Saves short-form clip brief and a resource guide locally. Trigger on phrases like 'run the content engine', 'content engine for my video', 'generate content from my video', 'repurpose this video', 'turn this video into content', 'run on my latest video', or any request to turn a YouTube video into multi-platform content."
---

# Content Engine

Turn a YouTube video into a full content engine run published directly via Blotato MCP — no copy-paste required. Phase 1 (immediate): LinkedIn × 2, Facebook, Instagram carousel, TikTok carousel. Phase 2 (after editing): short-form clip brief ready for Blotato once clips are cut. Tutorial videos also get an optional resource guide.

## When This Skill Activates

- "Run the cascade on my latest video"
- "Content cascade for [URL]"
- "Repurpose this video for everything"
- `/content-engine`
- `/content-engine [URL]`

---

## Blotato Account IDs

All Blotato account IDs and page/board IDs are personal to your Blotato workspace. Set them in your config and reference them here. Pull the real values from Blotato (`blotato_list_accounts`) — never hardcode someone else's. Use the placeholder `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` everywhere an account ID, pageId, or boardId appears below.

| Platform | Account | ID |
|---|---|---|
| LinkedIn | Your personal profile | `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| LinkedIn | Your community/brand page | accountId `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` + pageId `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| Instagram | Your account | `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| TikTok | Your account | `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| Twitter/X | Your account | `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| YouTube | Your account | `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| Facebook | Your page | accountId `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` + pageId `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |
| Pinterest | Your account | accountId `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` + boardId `[YOUR_BLOTATO_ACCOUNT_IDS — from your config]` |

## API Keys

All API keys live in `~/.claude/.env`. Source it before any shell command that needs an API key:

```bash
set -a && source ~/.claude/.env && set +a
```

Never read keys from `~/.zshrc`, project `.env` files, or any other location. If a key is missing from `~/.claude/.env`, add it there — not anywhere else.

---

## Execution Model

This pipeline has hard dependencies at the start and end. Everything in the middle is independent and **must run in parallel**.

```
Phase 1 — Sequential (must complete in order):
  Step 1 → Step 2 → Step 3 → Step 4

Phase 2 — Parallel Launch (fire ALL as simultaneous tool calls after Step 4):
  ├── LinkedIn personal post
  ├── LinkedIn community/brand page post
  ├── Facebook post
  ├── X/Twitter thread
  ├── Pinterest pin
  ├── Reddit post
  ├── Short-form clip brief (writing only — no publish)
  ├── Resource guide HTML + description (tutorial only — optional integration)
  └── Carousel-creator ← invoke first, it's the slowest

Phase 3 — After carousel-creator returns image URLs:
  ├── TikTok carousel (reuses carousel URLs)
  └── LinkedIn carousel scheduled 48h out (reuses carousel URLs)

Phase 4 — Automation wiring:
  ├── ManyChat funnel (after Instagram publishes — always; optional: your own ManyChat integration)
  └── Comment-to-DM automation (BLOCKED until BOTH conditions met — tutorial only; optional: your own integration):
        1. LinkedIn personal post URL resolved (not https://www.linkedin.com/feed/)
        2. Guide URL confirmed (script returned real URL, not a placeholder)
      → Fire the guide publish early in Phase 2 alongside text posts so it has time to finish.
        Never substitute a placeholder URL. The comment-to-DM tool has no PATCH/PUT — only one shot.

Phase 5 — After all above complete:
  └── Summary report
```

**Critical execution rule:** In Phase 2, do NOT wait for one post to finish before starting the next. Fire ALL Phase 2 items as simultaneous tool calls in a single turn. Carousel-creator runs concurrently with all text posts — it renders while they publish. The comment-to-DM automation and TikTok are the only truly gated steps.

---

## Pipeline

### Phase 1 — Setup (Sequential)

### Step 1 — Get the Video

**If URL provided**, use it directly.

**If "latest video" or no URL**, auto-detect (replace `[YOUR_HANDLE]` with your YouTube handle, set in your config):
```bash
yt-dlp --flat-playlist --playlist-end 1 --print url --print title "https://www.youtube.com/@[YOUR_HANDLE]/videos"
```
First line = URL, second line = title. Confirm: "Found your latest video: [TITLE]. Running the cascade on this one."

Extract **Video ID** (11-character YouTube ID) from the URL.

**Thumbnail URL:** `https://i.ytimg.com/vi/VIDEO_ID/maxresdefault.jpg`

---

### Step 2 — Fetch Transcript via Blotato

Use `blotato_create_source` to extract the transcript directly:

```json
{
  "sourceType": "youtube",
  "url": "<youtube-url>"
}
```

If Blotato source fails, fall back to yt-dlp:

**Method A — original captions:**
```bash
yt-dlp --write-sub --sub-lang en-orig --skip-download --sub-format json3 -o "/tmp/yt-transcript" "<youtube-url>"
```

**Method B — auto-generated:**
```bash
yt-dlp --write-auto-sub --sub-lang en --skip-download --sub-format json3 -o "/tmp/yt-transcript" "<youtube-url>"
```

Parse json3:
```bash
node -e "
const fs = require('fs'), path = require('path'), dir = '/tmp';
const file = fs.readdirSync(dir).find(f => f.startsWith('yt-transcript') && f.endsWith('.json3'));
if (!file) { console.error('No subtitle file found'); process.exit(1); }
const data = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
const text = data.events.filter(e => e.segs).map(e => e.segs.map(s => s.utf8 || '').join('')).join(' ').replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
console.log(text);
"
```

**Validation:** Sanity-check first 2 sentences against video title. If transcript doesn't match → try next method.

If all methods fail:
> "Captions aren't available yet — YouTube takes 30-60 minutes after upload. Try again in a bit."

Do NOT proceed without a transcript.

---

### Step 3 — Metadata and Classification

Extract:
- **Video ID** — 11-character YouTube ID
- **Video title** — from Step 1 or `yt-dlp --get-title "<url>"`
- **Slug** — lowercase-hyphenated, max 50 chars
- **Date** — today's date YYYY-MM-DD
- **Video length** — approximate from transcript word count (150 wpm)
- **CTA Keyword** — a random, fun, non-offensive word. Think silly nouns: food items, animals, objects (e.g. `WAFFLE`, `GIRAFFE`, `PINEAPPLE`, `MANGO`, `PICKLE`, `FLAMINGO`, `NUGGET`, `ROCKET`). The word should be easy to type in a comment and make people smile. It does NOT need to relate to the video topic.

  **Before choosing:** read `~/.claude/skills/manychat/funnel-log.md` (if you use a ManyChat integration) and extract all keywords from the Keyword column. Your chosen keyword must not appear in that list. Pick a different fun word if your first pick is already used. Never reuse a keyword — each funnel must be unique so the comment-to-DM tool can route comments correctly.

**Classify as tutorial or discussion:**

**Tutorial** → generates everything including the resource guide:
- Step-by-step instructions, how-to framing, tool setup, walkthroughs, demos
- Viewer is expected to follow along or replicate something

**Discussion** → LinkedIn + Facebook only, no resource guide:
- Opinions, predictions, reactions, industry analysis, comparisons
- Viewer consumes perspective, not a process

Log the classification and CTA keyword — they'll appear in the Step 12 summary report. Do not pause here.

---

### Step 4 — Create Output Folder
```bash
mkdir -p ~/content/YYYY-MM-DD-SLUG
```

---

### Phase 2 — Parallel Launch (fire ALL simultaneously after Step 4)

**Start carousel-creator first** (it's the slowest), then fire all remaining Phase 2 items in the same turn. Do not wait for any one post to finish before firing the others.

### Step 5 — Generate and Publish LinkedIn Post (Personal + Community Page)

**Generate TWO separate posts** — personal and community/brand page have different formats and goals.

---

#### Personal LinkedIn — Lead Magnet Format

- **Hook** — transformation or big_number (never i_statement — it drives 5x less reach). Transformation pattern: "I went from [before] to [after] in [timeframe]." Big number: lead line is the metric, impossible to scroll past.
- **Second line** — "Here's X:" or "Here's how:"
- **Body** — 5-7 bullet points using `→` (never `-` or `*`). Each 8-15 words, concrete and specific. Include at least 2 numbers from your own proof points (e.g. follower count, revenue, daily AI cost, research time saved — pull these from your own notes file, bring your own).
- **Payoff line** — one line connecting content to the reader's outcome
- **CTA** — exactly: `Comment "[KEYWORD]" and I'll send it over.` (use the keyword from Step 3)
- **Length** — 150+ words (long posts drive 2,765 avg impressions/day vs 113 for short)
- **Formatting** — no markdown, no bold, no italics. White space between every sentence group. `→` bullets only.

For discussion videos: transformation hook with soft CTA pointing to the video instead of a keyword trigger. No lead magnet offer.

---

#### Community / Brand Page — Value-Driven Format

No lead magnet CTA. This audience is community members and brand followers — give them value and speak to their transformation.

- **Hook** — what this means for someone trying to grow their audience and make money with AI. Frame around the outcome, not the tool.
- **Body** — explain what the build does and why it matters for their business. Speak directly to your ICP (define your own audience). How does this specific thing help them get more followers, save time, or generate revenue?
- **Tone** — practitioner to practitioner. Not hype, not salesy. "Here's why this matters for you" energy.
- **Bullets** — `→` format, 5-6 points, focused on what the reader can apply or understand from this
- **Closing line** — one sentence connecting back to your community's mission
- **No keyword CTA.** End with a soft engagement prompt (a question or observation) or a pointer to the full video
- **Length** — 150+ words same as personal
- **Formatting** — same: no markdown, white space between groups, `→` only

---

**Publish via Blotato** (replace each account/page ID with your own from config):

```json
// Personal LinkedIn
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "text": "<personal post — lead magnet format>",
  "imageUrls": ["https://i.ytimg.com/vi/VIDEO_ID/maxresdefault.jpg"]
}

// Community / brand page — accountId + pageId
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "pageId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "text": "<community page post — value-driven format>",
  "imageUrls": ["https://i.ytimg.com/vi/VIDEO_ID/maxresdefault.jpg"]
}
```

Use `blotato_create_post` for each. **Store the full result** — you need the `postSubmissionId` (and post URL once published) for the comment-to-DM wiring in Step 11. If the result doesn't include a post URL immediately, note the `postSubmissionId` and poll via `blotato_get_post_status` before Step 11.

Save to `~/content/YYYY-MM-DD-SLUG/linkedin.md`.

---

### Step 6 — Generate and Publish Facebook Post

Facebook tone: casual, community-oriented, not professional network energy.

Write a post that:
- Leads with the most surprising or useful insight from the video
- Is conversational, not salesy
- Ends with a question to drive comments
- Final line: "**Comment [KEYWORD] below and I'll send you the full video link** 👇" (use the keyword from Step 3)

Keep under 300 words. No emojis unless content calls for it.

**Publish via Blotato** (replace IDs with your own from config):

```json
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "pageId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "text": "<post content>"
}
```

Save to `~/content/YYYY-MM-DD-SLUG/facebook.md`.

---

### Step 6b — Generate and Publish X (Twitter) Post

X rewards sharp opinions and building-in-public content. No lead magnet mechanic — just a punchy take that drives follows and engagement.

**Post format:**
- 1-3 lines max. Under 280 characters for the main post.
- Lead with the most counterintuitive or surprising thing about the build — what would make someone think "wait, that's possible?"
- No link in the main post (suppresses reach). End with "🔗 in replies" or "link in thread"
- Tone: builder to builder. Direct. No hype words.

**Self-reply (thread post):**
- YouTube URL on its own line
- One-line description of what they'll find in the video
- Keep it to 2 lines max

**Publish via Blotato as a thread using `additionalPosts`:**

```json
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "platform": "twitter",
  "text": "<punchy take — no link — ends with '🔗 in replies'>",
  "mediaUrls": [],
  "additionalPosts": [
    {
      "text": "https://www.youtube.com/watch?v=VIDEO_ID\n\n<one-line video description>"
    }
  ]
}
```

The `additionalPosts` array creates a thread — Blotato posts the main tweet first, then the reply automatically. No separate API call needed.

Save to `~/content/YYYY-MM-DD-SLUG/twitter.md`.

---

### Step 7 — Generate and Publish Instagram Carousel

**Always invoke the `/carousel-creator` skill to generate actual rendered slide images.** Do not write slide copy manually — the carousel-creator handles design, rendering, and Blotato upload.

Pass to carousel-creator:
- The full transcript (or key insights extracted in Step 3)
- Video title
- Instruction: "riso print style, step-by-step framework, 7 slides, cta_keyword: [KEYWORD from Step 3]"

The carousel-creator will:
1. Write per-slide copy and prompts using the riso print design system
2. Submit all slides to Higgsfield `nano_banana_2` in parallel (4:5 aspect ratio)
3. Download rendered slides and upload to Blotato, returning permanent image URLs

Once carousel-creator returns the hosted URLs, publish via Blotato (replace the account ID with your own from config):

```json
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "text": "<caption>",
  "imageUrls": ["<slide1-url>", "<slide2-url>", "..."]
}
```

**Caption format (Instagram):**
```
[Hook line from slide 1]

[2-3 line value tease]

Comment [KEYWORD] and I'll send you the full breakdown 👇

Full video → link in bio

#claudecode #ai #buildinpublic #aiautomation
```
(Swap in your own niche hashtags.)

Save to `~/content/YYYY-MM-DD-SLUG/instagram-carousel.md` (slide content + caption).

---

### Phase 3 — After Carousel-Creator Returns Image URLs

### Step 8 — Generate and Publish TikTok Carousel

TikTok gets the same carousel slides as Instagram — reuse the Blotato image URLs from Step 7. No need to re-render.

**Publish via Blotato** (replace the account ID with your own from config):
```json
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "text": "<caption>",
  "imageUrls": ["<slide1-url>", "<slide2-url>", "..."]
}
```

**Caption format (TikTok):**
```
[Hook line — slightly more casual than Instagram]

[2-3 lines value tease]

Comment [KEYWORD] and I'll send you the full breakdown 👇

#claudecode #ai #buildinpublic #aiautomation #vibecoding
```
(Swap in your own niche hashtags.)

> **Note:** Short-form VIDEO posts to TikTok are Phase 2 — only after you edit the clips. This step covers photo carousels only.

---

### Step 8d — Schedule LinkedIn Carousel (48 hours)

Reuse the same Blotato-hosted carousel image URLs from Step 7 (already uploaded for Instagram). Schedule them as a LinkedIn personal post 48 hours after the cascade runs.

**Calculate `scheduledTime`:**
```bash
python3 -c "
from datetime import datetime, timezone, timedelta
t = datetime.now(timezone.utc) + timedelta(hours=48)
print(t.strftime('%Y-%m-%dT%H:%M:%SZ'))
"
```

**Publish via Blotato with `scheduledTime`** (replace the account ID with your own from config):
```json
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "platform": "linkedin",
  "text": "<caption>",
  "imageUrls": ["<slide1-url>", "<slide2-url>", "..."],
  "scheduledTime": "<ISO-8601-48h-from-now>"
}
```

**Caption format (LinkedIn carousel — professional tone, same keyword CTA):**
```
[Hook line — transformation or big number, same style as Step 5 personal post but fresh angle]

[4-6 bullet points using → format — pull from a different angle than the original LinkedIn post]

Comment "[KEYWORD]" and I'll send it over.
```

Do NOT reuse the same hook or bullets from the initial LinkedIn personal post — this will appear 48 hours later to a partially overlapping audience. Pick a different angle on the same content.

**Comment-to-DM note:** The scheduled LinkedIn carousel will have its own post URL and its own commenters. It needs its own comment-to-DM automation wired to it — but the URL won't be known until it publishes. Add a reminder to `~/content/YYYY-MM-DD-SLUG/comment-to-dm.md`:

```
## LinkedIn Carousel (scheduled — 48h)
Status: PENDING — wire comment-to-DM automation after post publishes on [DATE+48H]
Keyword: [KEYWORD]
Action: Run Step 11 logic against the carousel post URL once live
```

Save the Blotato `postSubmissionId` for the scheduled post to `~/content/YYYY-MM-DD-SLUG/linkedin.md`.

---

### Step 8b — Publish Pinterest Pin

Pinterest gets the video thumbnail as a static pin linked back to the YouTube video.

**Pinterest requires a Blotato-hosted image — do NOT pass the YouTube CDN URL directly.** Passing `i.ytimg.com` URLs fails with "unsupported media source type: None". Upload first.

**Step 1 — Upload thumbnail to Blotato:**
```bash
# 1. Get presigned URL
curl -s -X POST "https://backend.blotato.com/v2/media/presigned-url" \
  -H "blotato-api-key: $BLOTATO_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"filename": "thumbnail.jpg"}'
# → save presignedUrl and publicUrl from response

# 2. Download thumbnail locally
curl -s -o /tmp/yt-thumbnail.jpg "https://i.ytimg.com/vi/VIDEO_ID/maxresdefault.jpg"

# 3. Upload to presigned URL (raw bytes, not multipart)
curl -s -X PUT "<presignedUrl>" \
  --data-binary "@/tmp/yt-thumbnail.jpg" \
  -H "Content-Type: image/jpeg"
```

Use `blotato_create_presigned_upload_url` (filename: `"thumbnail.jpg"`) + `curl --data-binary` PUT to the presignedUrl. The publicUrl is what goes into `mediaUrls`.

**Step 2 — Publish via Blotato** (replace account ID and board ID with your own from config):
```json
{
  "accountId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "boardId": "[YOUR_BLOTATO_ACCOUNT_IDS — from your config]",
  "title": "<pin title>",
  "text": "<pin description>",
  "mediaUrls": ["<blotato-hosted-publicUrl>"],
  "link": "https://www.youtube.com/watch?v=VIDEO_ID"
}
```

**Pin description format:**
```
[One-line hook from the video — what the viewer will learn or build]

[2-3 sentence value summary — specific and concrete, no fluff]

Full tutorial → link above

#claudecode #aitools #buildinpublic #aiautomation #personalbrand
```
(Swap in your own niche hashtags.)

Save to `~/content/YYYY-MM-DD-SLUG/pinterest.md`.

---

### Step 8c — Publish Reddit Post

Post to **one subreddit** picked by rotating through the list below. One post per cascade, never the same subreddit twice in a row (track last used in `~/content/.reddit-last-sub`).

**Subreddit rotation:**
```
r/ClaudeAI, r/SideProject, r/Entrepreneur, r/artificial, r/ChatGPT, r/automation, r/IMadeThis
```

Pick the subreddit that best matches the video content:
- Build / tool demo → r/SideProject or r/IMadeThis
- Claude Code specific → r/ClaudeAI
- Business / income angle → r/Entrepreneur
- General AI insight → r/artificial or r/ChatGPT
- Workflow / automation → r/automation

If no clear match, fall back to rotation order.

---

#### Reddit Tone Guidelines

Reddit requires a completely different register from LinkedIn. The same content written in LinkedIn voice will get downvoted or removed. Follow these rules exactly.

**Voice: raw, specific, builder-to-builder**
- Write like you're telling a friend what you built, not presenting to an audience
- Admit the messy reality — "zero users", "scrappy", "kinda dumb but it worked" — this is what earns trust
- Specific numbers always: time saved, money made/spent, lines of code, node count, client value
- Short sentences. Paragraph breaks every 2-3 lines max
- `→` for list items (reads well on Reddit too)

**What to never do:**
- No "game-changer", "revolutionary", "powerful", no hype words
- No CTA, no "join my community", no mention of your community in the post body
- No link to the YouTube video in the post body — it goes in the **first comment** only
- No em-dashes
- Don't start with "I built X and you should use it" — start with the situation or the question that sparked the build
- No namedropping unless it comes up completely naturally — never "as [Famous Person] says"
- Closing question must be casual and genuine: "Anyone else tried this?" or "curious if others have hit the same wall" — never "What's your biggest challenge with X?" (sounds like an AI wrote it)

**Two formats — pick based on content type:**

**Format A: Narrative story** (use when video is a build demo or launch)
```
[Situation that sparked the build — 1-2 sentences]

[The messy first version — what it was, why it was rough]

[What you layered on top → → →]

[The result — specific, honest. Include "zero users" / "zero dollars" type honesty if applicable]

[One genuine reflection on what surprised you]

[Closing question — what trips people up with this? what are you building?]
```

**Format B: Numbered insights list** (use when video is a learnings / principles video)
```
[Setup line — how long you've been doing this / how many you've built]

1. [Bold header]\n[2-3 sentence explanation with a specific anecdote or number]

2. ...

[Bonus insight if natural]

[Closing question — curious what their experience is]
```

**Title formats that work:**
- "I built [specific thing] in [timeframe] — here's how it works"
- "N things I learned after [specific milestone]"
- "[Counterintuitive claim] (here's why)"
- "I turned [basic thing] into [outcome]"
- Avoid: "How to...", "The Ultimate Guide to...", clickbait superlatives

**Flair:** Use "Discussion" for insights posts, no flair or "Project" for build posts (check what the subreddit offers).

**First comment (always post this):**
```
Made a full video on this if you want the step-by-step: [YOUTUBE_URL]
```

---

#### Generate and Publish

Write the post based on the transcript and video type. Choose Format A or B based on content. Generate a title that matches the patterns above.

Then run:

```bash
python3 ~/.claude/skills/content-engine/scripts/reddit-post.py \
  --title "TITLE" \
  --body "BODY" \
  --subreddit SUBREDDIT \
  --flair "Discussion" \
  --comment "Made a full video on this if you want the step-by-step: https://www.youtube.com/watch?v=VIDEO_ID"
```

Requires env vars: `REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET`, `REDDIT_USERNAME`, `REDDIT_PASSWORD`

If env vars are missing, save the post content and log a warning — don't block the cascade.

Update `~/content/.reddit-last-sub` with the subreddit used.

Save post content to `~/content/YYYY-MM-DD-SLUG/reddit.md`.

---

### Step 9 — Generate Short-Form Clip Brief (Phase 2 Setup)

Scan transcript for **3-5 best short-form moments** (30-90 seconds, ~75-225 words each).

**Clip-worthy signals:**
1. Self-contained insight — makes sense without full video context
2. High shock value — surprising stat, counterintuitive take (target 70+ shock score)
3. Emotional peak — passion, frustration, excitement in delivery
4. Quotable line — worth screenshotting
5. Demo reveal — works in vertical format

**NOT clip-worthy:** Setup without payoff, references to other video sections, wide-screen-only walkthroughs.

For each clip:

```
### Clip [N]: [Working Title]

**Timestamps:** [MM:SS → MM:SS] (~X seconds)
**Best for:** [reach / conversions / engagement]

**Hook:**
- Text overlay: "[2-5 words]"
- Spoken: "[First sentence]"
- Horseman: [Money / Time / Health / Status]

**Transcript excerpt:**
> [Exact words]

**Rewritten script:** [Tightened version / Use as-is]

**Caption (paste into Blotato):**
[One-line hook]
[1-2 lines value tease]
Follow for more → [YOUR_HANDLE]

**Hashtags:** #tag1 #tag2 #tag3 #tag4 #tag5

**Phase 2 accounts to post (use your own Blotato account IDs from config):**
- Instagram Reels → accountId: [YOUR_BLOTATO_ACCOUNT_IDS — from your config]
- TikTok video → accountId: [YOUR_BLOTATO_ACCOUNT_IDS — from your config]
- YouTube Shorts → accountId: [YOUR_BLOTATO_ACCOUNT_IDS — from your config]
```

**Rank:** 1 = best for reach, 2 = best for conversions, 3 = best for engagement.

> **This brief is Phase 2** — post video clips AFTER you edit them. Use Blotato `blotato_create_post` with video file upload at that time.

Save to `~/content/YYYY-MM-DD-SLUG/short-form.md`.

---

### Step 10 — Resource Guide (TUTORIAL ONLY — optional integration)

**Skip entirely if classified as discussion.** Publishing the guide requires an optional digital-product integration (e.g. your own Gumroad account). If you have no such integration, generate the HTML guide and save it locally, then skip the publish step.

Generate a standalone reference guide. Someone should be able to follow the steps without watching the video — but the guide should make them want to watch and join your community.

**Pricing:** Pay-what-you-want, minimum $0, suggested price $9.

**Embed the YouTube video** in the guide.

**Output as HTML:**

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>GUIDE_TITLE_HERE</title>
<style>
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 800px; margin: 0 auto; padding: 40px 20px; line-height: 1.7; color: #1a1a1a; }
  h1 { font-size: 28px; margin-top: 40px; }
  h2 { font-size: 22px; margin-top: 36px; border-top: 1px solid #e5e5e5; padding-top: 24px; }
  h3 { font-size: 18px; margin-top: 28px; }
  a { color: #0066cc; }
  ul, ol { padding-left: 24px; }
  li { margin-bottom: 6px; }
  code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 14px; font-family: 'SF Mono', Monaco, monospace; }
  pre { background: #f5f5f5; padding: 16px; border-radius: 6px; overflow-x: auto; }
  pre code { background: none; padding: 0; }
  .video-embed { display: block; position: relative; margin: 32px 0; border-radius: 8px; overflow: hidden; text-decoration: none; }
  .video-embed img { display: block; width: 100%; height: auto; }
  .video-embed .play-btn { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); width: 68px; height: 48px; background: #FF0000; border-radius: 10px; display: flex; align-items: center; justify-content: center; opacity: 0.92; transition: opacity 0.15s; }
  .video-embed:hover .play-btn { opacity: 1; }
  .video-embed .play-btn svg { fill: white; width: 24px; height: 24px; margin-left: 4px; }
  .cta { background: #f0f7ff; border-left: 4px solid #0066cc; padding: 16px 20px; margin: 32px 0; border-radius: 0 8px 8px 0; }
  .cta a { font-weight: 600; }
</style>
</head>
<body>

<h1>GUIDE_TITLE_HERE</h1>
<p><em>A companion guide to the YouTube video below.</em></p>

<a class="video-embed" href="https://www.youtube.com/watch?v=VIDEO_ID" target="_blank" rel="noopener">
  <img src="https://i.ytimg.com/vi/VIDEO_ID/maxresdefault.jpg" alt="Watch on YouTube" loading="lazy">
  <div class="play-btn"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div>
</a>

<!-- Guide content: h2 sections, step-by-step instructions, code blocks, etc. -->
<!-- Fill in gaps where video showed things visually — spell out commands, config details, setup steps -->

<div class="cta">
  <p><strong>Want to go deeper?</strong> Join <a href="[YOUR_COMMUNITY_URL]">your community</a> — for builders using AI to work faster and earn more.</p>
</div>

</body>
</html>
```

**Auto-publish to your digital-product platform (optional integration):**

Save guide to `~/content/YYYY-MM-DD-SLUG/SLUG-guide.html` (e.g. `5-levels-design-guide.html`).

**Generate a rich description** and save to `~/content/YYYY-MM-DD-SLUG/guide-description.txt`. Use this format (sections with emoji headers, bolded bullet points, `---` dividers):

```
**[emoji] [Section title based on main framework/skill]**

[1-2 sentence hook: what the reader will be able to do after using this guide]

- [first bullet item — text only, no bold markers]
[second bullet — NO leading "- ", the editor continues the list automatically]
[third bullet]
[fourth bullet]

---

**[emoji] [Section title — tools, prompts, or techniques covered]**

[Hook sentence]

- [first bullet]
[second bullet]
[third bullet]

---

**[emoji] What's Included**

- Full step-by-step guide (follow without watching the video)
All prompts used in the video, ready to copy-paste
The checklist to audit any Claude Code build

---

Join your community for building a highly-profitable personal brand with AI 👇
[YOUR_COMMUNITY_URL]
```

**Format rules (critical for the rich-text editor):**
- Section headers wrapped in `**...**` → rendered as bold
- Only the FIRST item in each bullet list starts with `- ` — subsequent items have no prefix (the editor continues the list automatically)
- `---` on its own line → horizontal rule divider
- No blank lines between bullet items — blank lines cause extra spacing
- Single blank line between a header and its content, and between list items and the next section header

Generate 2-3 sections based on the actual video content. Keep bullets tight — one line each.

Then run (optional Gumroad integration — bring your own account; the script reads its session from `~/.claude/skills/content-engine/.gumroad-session.json`, created by running `gumroad-save-session.py` once):

```bash
python3 ~/.claude/skills/content-engine/scripts/gumroad-publish.py \
  --file ~/content/YYYY-MM-DD-SLUG/SLUG-guide.html \
  --title "[VIDEO TITLE] — Free Resource Guide" \
  --description-file ~/content/YYYY-MM-DD-SLUG/guide-description.txt \
  --thumbnail "https://i.ytimg.com/vi/VIDEO_ID/maxresdefault.jpg"
```

Script runs headed (visible browser) by default. Session is already saved — no login needed.

If you have no such integration or the script fails, save the HTML and note "Upload manually to your digital-product platform".

---

### Phase 4 — After LinkedIn Personal Post URL AND Guide URL Both Confirmed

**HARD GATE — do not start Step 11 until BOTH are true:**
1. `blotato_get_post_status` for the LinkedIn personal post has returned a real post URL (not `https://www.linkedin.com/feed/`)
2. The guide publish script has returned a confirmed product URL (not a placeholder)

The guide publish should be kicked off early in Phase 2 so it has time to complete. But the comment-to-DM automation must never fire with a placeholder URL — it has no PATCH/PUT endpoint, so there is no way to update the DM template after creation without deleting and recreating the automation.

### Step 11 — Wire Comment-to-DM Automation (LinkedIn Personal) — optional integration

**Skip if this is a discussion video with no guide. Skip entirely if you don't use a comment-to-DM integration.**

This optional integration auto-DMs anyone who comments the keyword on the personal LinkedIn post (your personal profile only — not the community/brand page). The example below uses a generic comment-to-DM API; swap in your own provider's endpoint and key (stored in `~/.claude/.env`).

**1. Get the real post URL (two-step — Blotato returns a generic URL initially)**

Blotato initially returns `https://www.linkedin.com/feed/` — not the real post URL. Poll until `status` resolves, then fall back to your comment-to-DM provider's stats API if needed.

**Step A — Poll Blotato until published (up to 3 minutes):**
```bash
for i in {1..12}; do
  result=$(curl -s "https://backend.blotato.com/v2/posts/POST_SUBMISSION_ID" \
    -H "blotato-api-key: $BLOTATO_API_KEY")
  status=$(echo "$result" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status',''))")
  url=$(echo "$result" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('publicUrl') or d.get('postUrl') or d.get('url') or '')")
  if [[ "$status" == "published" || "$status" == "succeeded" || "$status" == "completed" ]]; then
    echo "URL: $url"
    break
  fi
  sleep 15
done
```

**Step B — If URL still lacks an activity ID, hit your comment-to-DM provider's stats API:**

Blotato sometimes resolves to `https://www.linkedin.com/feed/` even after status = published. In that case, your comment-to-DM provider has already indexed the post from your connected account — query it directly using the first line of your post as a matcher (replace the endpoint and `$COMMENT_TO_DM_API_KEY` env var with your own provider's):

```bash
curl -s "https://your-comment-to-dm-provider.example/api/post-stats" \
  -H "x-api-key: $COMMENT_TO_DM_API_KEY" | python3 -c "
import sys, json
hook = 'FIRST_LINE_OF_YOUR_POST'.strip().lower()
items = json.load(sys.stdin).get('items', [])
match = next((i for i in items if (i.get('text') or '').strip().lower().startswith(hook)), None)
if match:
    print('social_id:', match.get('social_id'))
    print('share_url:', match.get('share_url'))
else:
    print('not found')
"
```

The `social_id` will be `urn:li:ugcPost:7150123456789012345` — use this directly as `post_id`. The `share_url` is the real post URL.

**2. Extract the post ID**

Use whichever resolved first:
- `social_id` from the provider's stats (preferred — already a URN, no parsing needed)
- Numeric activity ID from the URL via `activity[:\-](\d+)` → format as `urn:li:ugcPost:NUMERIC_ID`

**3. Build the DM template**

For **tutorial videos**:
```
Hey {{firstName}}!

Here's the [VIDEO TITLE] guide + the full video walkthrough:

Guide (free): [GUIDE_URL]
Video: [YOUTUBE_URL]
Join your community: [YOUR_COMMUNITY_URL]

[One-line value statement summarizing what they'll get — e.g. "Everything you need to set up Claude Code computer use and control your desktop from your phone."]

Enjoy! Let me know if you have any questions.
```

For **discussion videos** (no guide): skip this step entirely.

**4. Create the automation** (replace the endpoint and `$COMMENT_TO_DM_API_KEY` with your own provider's):

```bash
curl -s -X POST "https://your-comment-to-dm-provider.example/api/automations" \
  -H "x-api-key: $COMMENT_TO_DM_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "[VIDEO TITLE] — [KEYWORD]",
    "post_id": "urn:li:ugcPost:NUMERIC_ID",
    "linkedin_post_url": "POST_URL",
    "keywords": ["KEYWORD"],
    "dm_template": "DM_TEMPLATE_HERE",
    "comment_reply_template": [
      "{{fullNameMention}} just sent!",
      "{{fullNameMention}} DM'"'"'d you!",
      "{{fullNameMention}} check your inbox!",
      "{{fullNameMention}} check your DMs!",
      "{{fullNameMention}} sent!"
    ],
    "non_first_degree_reply_template": ["{{fullNameMention}} connect with me!"],
    "auto_connect": true,
    "auto_like": true,
    "enable_follow_up": true,
    "follow_up_template": "Hey {{firstName}}!\n\nDid you have a chance to check out the community?",
    "follow_up_delay_minutes": 4320,
    "follow_up_only_if_no_response": false
  }'
```

`follow_up_delay_minutes: 4320` = 72 hours. `follow_up_only_if_no_response: false` — fires even if they replied with "thanks", since that's not real engagement.

A `409` response means the automation already exists for this post — not an error, treat as success.

If `COMMENT_TO_DM_API_KEY` is not set in the environment, log a warning and skip. Do not block the cascade.

Save automation ID to `~/content/YYYY-MM-DD-SLUG/comment-to-dm.md`.

---

### Step 11b — Wire ManyChat Funnel (Instagram) — optional integration

Run for both tutorial and discussion if you use a ManyChat integration — the Instagram carousel always uses a keyword CTA. Skip entirely if you don't.

**Context available at this point:**
- Keyword — from Step 3
- Video title — from Step 3
- YouTube URL — from Step 1
- Guide URL — from Step 10 (tutorial only; omit Link 2 for discussion)

**Generate copy (no approval pause — cascade is autonomous):**

**Opening DM:** One sentence, curiosity or direct value. One button, max 20 chars.
- Tutorial example: "Want the free [VIDEO TITLE] guide? Tap below 👇" → button "Send me the link"
- Discussion example: "Want the full breakdown? Tap below 👇" → button "I want it"

**Link DM:** Short delivery. No inline URLs — links go as buttons only.
- Button 1: YouTube URL → label "Watch the video" (or tighter if needed, max 20 chars)
- Button 2: Guide URL → label "Free guide" (tutorial only — omit for discussion)
- Body: "Here you go 👇"

**Follow-up DM:** One line, gentle. No URLs.
- Example: "Did you grab it? Link's still above 👆"

**Then invoke the `/manychat` skill** passing all generated copy and URLs directly — skip Step 1 (info gathering) and Step 2 (approval) since we already have everything. Jump straight to Step 3 (browser automation).

The `/manychat` skill will:
1. Log into ManyChat via Playwright (session should already be active)
2. Duplicate the "LEADMAGNET TEMPLATE" flow
3. Rename it: `[KEYWORD] - [Video Title short] - [MM/DD/YYYY]`
4. Fill in keyword, opening DM, link DM, follow-up DM, and button URLs
5. Save + Go Live
6. Append to your ManyChat funnel log (e.g. `~/.claude/skills/manychat/funnel-log.md`)

Save flow name + keyword to `~/content/YYYY-MM-DD-SLUG/manychat.md`.

---

### Phase 5 — After All Above Complete

### Step 12 — Summary Report

After all steps complete:

```
## Cascade Complete — [VIDEO TITLE]

**Video:** [URL]
**Type:** Tutorial / Discussion
**Saved to:** ~/content/YYYY-MM-DD-SLUG/

### Published ✓
- LinkedIn personal — post ID: [X]
- LinkedIn community/brand page — post ID: [X]
- Facebook page — post ID: [X] (or MANUAL if page not connected in Blotato)
- Instagram carousel — post ID: [X]
- TikTok carousel — post ID: [X]
- X/Twitter — post ID: [X] (thread: take + link reply)
- Pinterest — pin ID: [X]
- Reddit (r/[SUBREDDIT]) — post URL: [X] (YouTube link in first comment)

### Comment-to-DM ✓ (tutorial only — optional integration)
- Keyword: [KEYWORD]
- Automation ID: [X]
- DM sends: guide URL + YouTube URL
- Wired to: LinkedIn personal post

### LinkedIn Carousel (scheduled) ⏳
- Scheduled: 48h from now ([DATE+TIME])
- Blotato postSubmissionId: [X]
- Comment-to-DM: PENDING — wire after post publishes on [DATE+48H]

### ManyChat ✓ (optional integration)
- Keyword: [KEYWORD]
- Flow name: [X]
- DM sends: YouTube URL (+ guide URL if tutorial)
- Wired to: Instagram [YOUR_HANDLE]

### Phase 2 (after editing clips)
- short-form.md contains 3-5 clip briefs
- Post to Instagram Reels, TikTok video, YouTube Shorts via Blotato (your account IDs from config)

### Files
- linkedin.md
- facebook.md
- twitter.md
- instagram-carousel.md
- pinterest.md
- reddit.md
- short-form.md
- comment-to-dm.md (tutorial only)
- manychat.md
- guide.html (tutorial only)

### Pending
- Facebook (manual — only if page not connected in Blotato)
- Guide: [auto-published / upload manually]
```

---

### Step 13 — Log the Video to Your Knowledge Folder

**Local write only. This step publishes NOTHING and touches NO social accounts.** It writes one archive card so your other skills (`/angle-mine`, `/ideation`) can see this video as "already covered."

Write the entry to (the `[KNOWLEDGE_FOLDER]` base is set in the user's config):
```
[KNOWLEDGE_FOLDER]/video-archive/[PUBLISH_DATE]-[slug].md
```
- **PUBLISH_DATE** — the video's actual publish date (`YYYY-MM-DD`), NOT today. Get it from `yt-dlp --print upload_date "<url>"` (returns `YYYYMMDD` → reformat to `YYYY-MM-DD`). If unavailable, fall back to today's date.
- **slug** — kebab-case of the video title: lowercase, alphanumeric and hyphens only, all other characters dropped, collapsed/​trimmed hyphens.

**Idempotent — check before writing.** List `[KNOWLEDGE_FOLDER]/video-archive/`. If a file already exists with the same `[PUBLISH_DATE]-[slug].md` name, OR any file in that folder whose `# ` title heading matches this video's title case-insensitively, treat it as the existing entry and **UPDATE that file in place** rather than creating a duplicate. Preserve any human-added sections (especially `## Performance`, `## Related Notes`, and `source_transcript`) — only refresh the fields and sections this skill owns, and bump `updated`.

Fill the entry richly from the transcript already fetched in Step 2. Match the existing archive style:

```
---
source_transcript: ""
tags: [youtube, video-archive]
video_id: <11-char YouTube ID from Step 1>
views: <view count if available, else blank>
published: <PUBLISH_DATE — YYYY-MM-DD>
format: <long or short>
topic: <one-sentence topic>
icp: <one-sentence ICP / who it's for>
updated: <today's date YYYY-MM-DD>
source: content-engine
---

# <Video Title>

## Hook
**Format:** <hook format/type>
"<the opening line(s) verbatim from the transcript>"
<one line: the pain/gap + the promise>

## Structure
- <bullets describing the video's structure/segments>

## Frameworks Taught
<any frameworks/systems taught, distilled>

## ICP Language Captured
- <verbatim audience-language phrases from the transcript, if any>

## Performance
_(to be filled later by /yt-performance)_
```

Field notes:
- `format`: `short` if the video runs under ~3 min (from the Step 3 length estimate), else `long`.
- `topic` and `icp`: one tight sentence each, in your lane (define your own niche and audience).
- Pull the `## Hook` opening line verbatim from the first lines of the transcript.
- `## ICP Language Captured`: lift only real audience-language phrases that appear in the transcript. If none, write `- (none captured)`.

Write the file with the Write tool (or Edit if updating). Do not invoke Blotato, the comment-to-DM tool, ManyChat, or any publishing path here.

---

## Autonomy Rules

**If the user says "just do everything"** — skip approval pauses, publish directly, save all files.

**If only one piece is needed** — still fetch the transcript, only generate that piece.

**If a Blotato post fails** — log the error, save the content to file, flag it in the summary. Never silently skip.

---

## Voice Guidelines

- Direct, practitioner-to-practitioner. Not influencer energy.
- Avoid: "game-changer", "dive deep", "navigate", "it's worth noting", "let's explore", "revolutionize"
- No em-dashes in body copy
- LinkedIn: short paragraphs (1-3 lines max, lots of whitespace), hooks that create curiosity gaps
- Specific beats vague: "I built this in 2 hours with Claude Code" > "AI can save you time"
- Reference your own community naturally when relevant (set `[YOUR_COMMUNITY_URL]` in your config)
- All CTAs funnel back to the YouTube video first, your community second

---

## Channel Info

Set these in your config:
- Handle: `[YOUR_HANDLE]`
- Channel ID: `[YOUR_CHANNEL_ID]`
- Community: your community (`[YOUR_COMMUNITY_URL]`)
- Digital-product platform: optional integration (bring your own)
