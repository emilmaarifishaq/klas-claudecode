---
name: ideation
description: "Generate positioned YouTube video ideas with competitive gaps, desire mapping, and shock scores. Consumes research from yt-pipeline or firecrawl-search — does NOT redo deep research. Trigger on phrases like 'video ideas for', 'what should I make a video about', 'brainstorm video ideas', 'ideation for', 'content ideas about', 'what videos should I do about X', or any request for YouTube video concept generation."
---

# Video Ideation Engine

Generate positioned YouTube video ideas grounded in existing research and competitive analysis. Outputs structured idea briefs ready to feed into `/hooks` and `/outlines`.

**This skill is strategy, not research.** It consumes research outputs from `/yt-pipeline` or web searches. It does NOT replicate deep research — if no research exists yet, it runs a lightweight competitive scan only.

## When This Skill Activates

**Activate when the user wants to:**
- Brainstorm video ideas on a topic
- Figure out what video to make next
- Find angles on a trending topic
- Generate content ideas from research already done

**Example triggers:**
- "Give me video ideas about RAG"
- "What should I make a video about this week?"
- "Brainstorm some Claude Code video angles"
- `/ideation` or `/ideation <topic>`

## Workflow

---

### 🚨 Breaking News Mode

**Trigger:** Input contains phrases like "just dropped," "just launched," "just released," "new release," "came out," "just announced," or names a specific product/model launch.

When Breaking News Mode activates, **run Steps BN-1 through BN-3 before Step 0.** This replaces the standard Step 1/2 research flow for this session.

#### BN-1 — Check GitHub Trending Report First

Before searching, check if today's (or yesterday's) report already covers this release (optional — only if you maintain a GitHub trending report folder; path set in your config):

```bash
ls -t [KNOWLEDGE_FOLDER]/github-trending/*.md | head -2
```

Read the most recent file. If the repo appears in the Top 10 or Content Radar, use its stars, description, and topics directly — skip the GitHub search step. If it's not there, proceed with the web search below.

#### BN-1b — Web Search: What Actually Dropped

Search for the release and extract:
- What is it, what does it actually do
- Key claims and benchmark numbers from the announcement
- Market reaction (competitors affected, stock moves, industry response)
- Availability (who has access, what tier, timeline)

Goal: hard facts only. No speculation.

#### BN-2 — YouTube Competitive Scan: Performance Signals

```bash
python3 ~/.claude/skills/yt-search/scripts/search.py "<tool name>" --count 20 --months 1
```

Also run a second pass on your specific angle:
```bash
python3 ~/.claude/skills/yt-search/scripts/search.py "<tool name> <your niche angle>" --count 10 --months 1
```

Extract:
- **What's already saturated** — the obvious takes already covered (avoid)
- **Performance outliers** — high views relative to channel size = proven angle worth noting
- **Gaps** — angles nobody's taken yet, especially the implementation/build angle
- **Who's covering it** — are these big generalist channels or niche creators? Big channels = more search traffic but less differentiation opportunity

This tells you where the competition is weak so you can plant your flag in the open ground.

**For every performance outlier you identify, pull its hook:**

```bash
mkdir -p /tmp/yt-hooks
yt-dlp --write-auto-subs --sub-lang en --sub-format json3 --skip-download \
  -o "/tmp/yt-hooks/%(id)s" "VIDEO_URL" 2>/dev/null

python3 -c "
import json
with open('/tmp/yt-hooks/VIDEO_ID.en.json3') as f:
    data = json.load(f)
lines = []
for event in data.get('events', []):
    if event.get('tStartMs', 0) > 30000:
        break
    text = ''.join(s.get('utf8','') for s in event.get('segs',[])).strip()
    if text and text != '\n':
        lines.append(text)
print(' '.join(lines))
"
```

Present the extracted hook verbatim under the video entry so you can see exactly how competitors opened. Label it **Hook (first 30s):** in the output.

#### BN-3 — Reddit: Real Audience Language

Search the subreddits most relevant to the release topic. For AI tool drops, run:

```bash
python3 ~/.claude/skills/linkedin-post/scripts/scrape_reddit.py ClaudeAI --time week --sort top --show 15
python3 ~/.claude/skills/linkedin-post/scripts/scrape_reddit.py ChatGPT --time week --sort top --show 10
python3 ~/.claude/skills/linkedin-post/scripts/scrape_reddit.py entrepreneur --time week --sort top --show 10
```

Adjust subreddits to the topic (e.g., add `artificial`, `SideProject`, `freelance`, `personalbranding` as relevant).

Extract:
- **Exact questions people are asking** — "can it do X?", "how does it compare to Y?" → these are video titles
- **Real confusion** — where are people getting stuck or misunderstanding the tool? → these are the highest-value angles
- **Emotional reactions** — excitement, skepticism, overwhelm → this is hook language
- **Use cases being discussed** — what are people trying to do with it? Filter for ICP-relevant ones

**Use this language verbatim in hooks and angle descriptions.** The ICP's exact words, not paraphrases.

#### BN-4 — Synthesize Before Generating

Before moving to Step 0, write a 5-bullet synthesis:
1. What the tool actually does (one line)
2. The 2-3 angles already saturated on YouTube
3. The 1-2 open gaps (especially implementation/build angles)
4. The most emotionally loaded audience reactions from Reddit
5. Your unique edge on this topic (from positioning filter)

This synthesis drives every idea generated in Steps 3-4.

---

### Step 0 — Load Intelligence & Apply Positioning Filter

**Before anything else, read your positioning filter:**
`[KNOWLEDGE_FOLDER]/positioning-filter.md` — your own notes file (bring your own). The path is set in your config. This file should define the 3-question filter that every idea must pass.

This is a hard gate. Every idea generated must pass the 3-question filter in that file. Apply it silently — never ask the creator to explain their positioning or how something fits their brand. That's your job.

Then load your knowledge intelligence — these sharpen the ideas research finds. All paths below point into `[KNOWLEDGE_FOLDER]/`, the folder set in your config; each file is your own notes file (bring your own). If a file doesn't exist, skip it gracefully.

**A. Published video archive** — prevents re-pitching what's already been made:
```bash
ls [KNOWLEDGE_FOLDER]/video-archive/*.md 2>/dev/null | grep -v fetch-queue | grep -v DS_Store
```
Extract the slug/title from each filename. Any idea that closely overlaps a published video gets flagged or cut.

**B. What-works intelligence** — tells you which title patterns, formats, and hooks actually performed:
Read `[KNOWLEDGE_FOLDER]/what-works-youtube.md`
Extract: overcrowded patterns to avoid, winning title formulas (Stop/Don't, Distillation, Levels, Dollar Result, Problem+Fix, Contrarian Verdict), power words, character count rules (40-50 chars, 60 hard cap), hook patterns with view counts, structure/format that works, what flopped. Use what-works-youtube as the primary source for all title and hook decisions.

**C. ICP language** — sharpens desire mapping with real audience phrases:
Read the first 100 lines of `[KNOWLEDGE_FOLDER]/icp-language-library.md`
Pull 5-8 verbatim phrases relevant to the topic. Use these when writing proxy desires and angle descriptions — they should sound like the viewer's internal monologue, not marketing copy.

**D. Coaching intelligence** — surfaces live audience questions and blockers:
Read `[KNOWLEDGE_FOLDER]/coaching-intelligence.md` (first 80 lines)
Extract any recurring questions or resistance patterns relevant to the topic. If your audience is consistently stuck on something, a video that answers it will convert better than a theoretically interesting angle.

**E. Instagram competitor intelligence** — patterns proven across short-form videos from leading creators in your niche:
Read `[KNOWLEDGE_FOLDER]/instagram-intelligence/cross-creator-synthesis.md`
Extract: which content angles have multi-creator consensus (highest-confidence signals), and what these creators are NOT covering that you uniquely can.

**F. YouTube peer group intel** — your competitive landscape:
Read `[KNOWLEDGE_FOLDER]/creator-intel/youtube-peer-group.md` — your own notes file profiling [YOUR_COMPETITOR_CHANNELS — 8-12 top channels in your niche].

**G. Live competitor performance data** — outliers and recent uploads logged by your daily digest:
Read `[KNOWLEDGE_FOLDER]/competitor-intel.md`
Extract: which topics are getting outsized views right now (↑outlier entries), what angles competitors hit in the last 7-14 days, and — critically — what's NOT been covered yet. Any topic in the whitespace across F and G is a first-mover opportunity. Cross-reference with `~/.claude/latest-digest-signal.md` if it exists — this is the single highest-signal item from the most recent digest run.

**H. Thumbnail strategy** — two-template system, copy structures, competitor visual analysis:
Read `[KNOWLEDGE_FOLDER]/thumbnail-strategy.md` (skim — use when generating thumbnail concepts in Step 5)

Apply before generating any ideas:
- **White space check:** Does this idea live in your uncontested lane (your specific niche + unique angle)? Or is it competing on territory where larger, faster competitors dominate? Prefer ideas in the white space.
- **Overcrowded filter:** Is this one of the saturated formats in your niche (the generic tutorials and combo angles everyone is already making)? Flag it — these categories are saturated across the peer group. Only pitch them if there's a clear differentiation angle.
- **Title enforcement:** Each idea gets 3 title options in the brief. 40-60 chars, one tension per title. No "How to," no vague descriptive titles, no hedge language, no two claims stacked.

**How to use your knowledge data in the rest of the workflow:**
- Use published video list to filter ideas — don't re-pitch covered ground unless there's a clear new angle
- Use what-works title patterns to boost the shock score of ideas that match proven formats (+10 bonus)
- Use ICP phrases in desire mapping — the proxy desire should use their language, not yours
- Use competitor-intel.md outliers to identify topics with proven demand you haven't covered — if a competitor got 3x+ normal views on a topic, you have a window before saturation
- Don't let your knowledge data override strong research signal — if the competitive scan reveals a hot gap, pursue it even if it's adjacent to a published video

### Step 1 — Gather Existing Context

Check what research already exists before doing anything:

1. Check `[KNOWLEDGE_FOLDER]/content/` (set in your config) for recent research files on the topic
2. Check for recent yt-pipeline outputs
3. If the user references specific notes, read them

**If research exists:** Use it as the foundation. Do NOT re-research the topic.
**If no research exists:** Run a lightweight competitive scan (Step 2).

### Step 2 — Competitive Scan + Audience Signal

Run both in parallel:

**YouTube — what's performing:**
```bash
python3 ~/.claude/skills/yt-search/scripts/search.py "<topic keywords>" --count 15 --months 3
```

Extract:
- **Saturated angles** — covered to death, avoid
- **Open gaps** — no or weak coverage, pursue
- **Performance outliers** — high views-to-channel-size ratio = proven demand
- **Key creators** — size and positioning of who's already covering this

**For every performance outlier, pull its hook:**

```bash
mkdir -p /tmp/yt-hooks
yt-dlp --write-auto-subs --sub-lang en --sub-format json3 --skip-download \
  -o "/tmp/yt-hooks/%(id)s" "VIDEO_URL" 2>/dev/null

python3 -c "
import json
with open('/tmp/yt-hooks/VIDEO_ID.en.json3') as f:
    data = json.load(f)
lines = []
for event in data.get('events', []):
    if event.get('tStartMs', 0) > 30000:
        break
    text = ''.join(s.get('utf8','') for s in event.get('segs',[])).strip()
    if text and text != '\n':
        lines.append(text)
print(' '.join(lines))
"
```

Present extracted hooks verbatim under each outlier entry, labeled **Hook (first 30s):**

**Reddit — what the audience is actually saying:**
```bash
python3 ~/.claude/skills/linkedin-post/scripts/scrape_reddit.py entrepreneur --time month --sort top --show 10
python3 ~/.claude/skills/linkedin-post/scripts/scrape_reddit.py ChatGPT --time month --sort top --show 10
```

Add topic-specific subreddits as relevant (e.g., `ClaudeAI`, `SideProject`, `freelance`, `smallbusiness`).

Extract:
- Real questions people are asking that aren't answered by existing YouTube content → direct video titles
- Confusion or misconceptions → highest-value angles (correct the wrong belief)
- Emotional language around the topic → hook material

Present the combined landscape in 4-6 bullets. YouTube tells you what's working. Reddit tells you what the audience actually needs.

### Step 3 — Generate 10 Ideas

Output **10 numbered video ideas**. Each idea gets:

1. **Three title options** — target 40-55 chars, one tension per title, no "How to," no hedge language. Apply what-works-youtube title formulas (Stop/Don't, Accusation+Fix, I Replaced X, Distillation, Dollar Result, Levels, Problem+Fix, Contrarian Verdict).
2. **One-line angle** — what makes this different from what already exists.

No positioning maps, no shock scores, no thumbnail concepts, no hooks. That comes after the creator picks.

**Stop after listing all 10.** Ask the creator: *"Which of these do you want to go deep on?"*

---

### Step 4 — Full Brief (runs only after the creator picks)

Wait for the creator to select one or more ideas from Step 3. Then, for each selected idea:

```
## [Working Title]

- **Angle:** [One sentence positioning]
- **Core Desire:** [Money / Time / Health / Status]
- **Proxy Desire:** [One standard deviation away]
- **Shock Score:** [X/100]
- **Format:** [Video structure type]
- **Competitive Gap:** [What's missing from existing coverage]
- **Why Now:** [Timeliness signal — trending, just launched, community buzz]
- **Research Depth:** [Sufficient / Thin]

### Title Options

Three strongest titles for this angle. Target 40-50 characters. Only expand to 60 if the tension genuinely requires it — 60 is the hard cap, not the goal. One tension per title. No "How to," no hedge language, no vague descriptive titles.

- [Title 1]
- [Title 2]
- [Title 3]

### Thumbnail Concepts

Two concepts. Each must have a layout, a prop, copy, and expression — all four telling the same story.

**Layout options (pick one per concept):**
- Face left, text right (default workhorse)
- Face right, text left (more aggressive — face looks toward copy)
- Face center, copy wraps above/below (requires strong expression)
- Face + visual prop split (highest upside — prop creates a visual question)
- No face / pure visual (only if concept is stronger than any face shot)

**Prop options (use one — props are the scroll-stopper):**
- Screenshot — real Claude output, Stripe notification, analytics, workflow result
- Tool logos flanking the face — signals ecosystem/comparison without copy
- UI mockup — app icons, toggle, notification card, browser window
- Dollar amount as a graphic element — specific number ($83,333 not $80K), underlined in accent color
- Physical prop — glowing icon, small recognizable object held in hand
- Diagram/blueprint — signals "system" or "framework"

**Copy rules (max 5 words, non-negotiable):**
- Two weights: small/light for context, LARGE/HEAVY for the power word
- One accent color on the tension word only
- Frames that work: Instruction (STOP WASTING TIME), Declarative (THE 1 YEAR RULE), Contrast (Stop working → START BUILDING), Dollar/Number ($83,333/month), Incomplete tension (DON'T WASTE…)
- Never: How To, Tutorial, Tips, Guide, Introduction

**Expression must match the title's emotional register:**
- Accusation/Stop doing X → intense direct stare, slight challenge
- Results/Dollar amounts → confident smirk, knowing look
- Opinion/Exposé → raised eyebrow, skeptical
- Tutorial/Framework → pointing at prop, engaged and direct

**Concept A:**
- **Layout:** [Which of the 5 layouts]
- **Prop:** [What specific prop — screenshot of what, which logos, which graphic]
- **Background:** [Dark/dramatic | Light/editorial | Cinematic | Branded color]
- **Copy (max 5 words):** [All caps power word + weight contrast]
- **Expression:** [One word — intense / smirk / skeptical / pointing / concerned]
- **Visual question created:** [The one thing the viewer needs the video to answer]

**Concept B:**
- **Layout:** [Different layout from Concept A]
- **Prop:** [Different prop from Concept A]
- **Background:** [Dark/dramatic | Light/editorial | Cinematic | Branded color]
- **Copy (max 5 words):** [All caps power word + weight contrast]
- **Expression:** [One word — intense / smirk / skeptical / pointing / concerned]
- **Visual question created:** [The one thing the viewer needs the video to answer]

### Step 4b — Story Anchor

Every brief gets one story. Read your personal story files at `[KNOWLEDGE_FOLDER]/story/` and the consolidated briefing at `[KNOWLEDGE_FOLDER]/coach-briefing.md` (both set in your config — your own notes files, bring your own). Match the best story to this video's central angle.

**Matching logic:**
- Match by emotional resonance first, not just topical overlap. (Example: a "got laid off" story isn't just about a job loss — it's about proving yourself to yourself after being sidelined. Use the deeper layer.)
- Prefer stories with a clear before/after arc that mirrors the viewer's own journey.
- If two stories fit, pick the one with the sharper contrast.

**Output format:**

```
### Story Anchor

**Story:** [Title / story file]
**The true core:** [2 sentences — what actually happened, stripped bare]
**Creative nonfiction stretch:** [How to dramatize it — what emotional arc to foreground, what
  details to compress or amplify, what can be sharpened in service of the emotional truth.
  "Creative nonfiction" means: compress timelines, sharpen implied dialogue, heighten stakes.
  The facts anchor it. The narrative does the work.]
**Bridge to this video:** [1 sentence — how the story proves or sets up the video's central argument]
**Where it lands:** [Hook opener / Transition into main content / Payoff / Close] — and one sentence on why that placement works
```

One story per brief. This feeds directly into the hook script below — the intro should open with or reference this story where possible.

---

### Step 4c — Hook + Intro Script

Generate a **hook recommendation** and **full intro script** for the top idea. This runs automatically as part of the brief — no separate prompt needed. Use the Story Anchor from Step 4b to ground the hook — the best hooks open in the middle of a moment, not a statement.

---

#### Hook Type Library

**Quick triage — pick one of these three first, then go to the full library for the exact template:**

| Type | Use when | Signal |
|---|---|---|
| **A — The Result** | You have a specific output, demo, number, or before/after | Title has a concrete outcome or time claim |
| **B — The Enemy** | There's a popular thing people are doing wrong and you have the counter | Title has a contrarian or accusation frame |
| **C — The Empathy Reframe** | The audience is stuck, frustrated, or overwhelmed and you have the diagnosis | Video is a framework, system, or beginner guide |

Type A maps to **Type 3 (Distillation Promise)** or write it as: *"I [did specific thing] in [time/effort]. By the end of this video, you'll have the exact same setup."*
Type B maps to **Type 4 (Accusation)** or write it as: *"Everyone is doing [X]. Here's exactly why that's costing you [clients/time/money]."*
Type C maps to **Type 1 (Empathy Reframe)** below.

Pick the best-fit type for each idea. Never force a type — if two feel right, pick the one with the sharper opening line.

**Type 1 — Empathy Reframe**
Use when: the audience is stuck, frustrated, or blaming themselves. The video is a framework or diagnosis.
> "If you feel like [X] keeps [failing/going sideways], it's probably not because [obvious explanation]. It's because [structural root cause]. That's not a skill problem. That's a [missing piece] problem."

**Type 2 — Contrast Metaphor**
Use when: you have a crisp visual metaphor for the wrong way vs. the right way. Frameworks and system videos.
> "Most people use [tool] like [self-defeating metaphor — something they recognize]. You get [bad outcome]. But if we treat it like [better metaphor], suddenly [good outcome] becomes possible."

**Type 3 — Distillation Promise**
Use when: the value is synthesis and shortcuts. The video saves hours the viewer would spend researching.
> "I've spent [X hours / built X systems] figuring out [topic]. This video cuts that down to [what actually matters]. No fluff. Just what you can use today."

**Type 4 — Accusation / Exposé**
Use when: the title is contrarian or there's a clear villain (a tool, a trend, a category of creator).
> "You are being lied to about [X]. [Name the source]. In reality, [hard verdict]. [Overhyped] doesn't mean [useless] — but [the thing being sold] is not [what it claims to be]."

**Type 5 — The Correction**
Use when: a popular tool or approach has a specific, fixable flaw. You have a better version.
> "Everybody's [using / building with / talking about] [X]. But there's one problem nobody's addressing. [The thing] isn't actually [what they think]. And you don't just have to take my word for it — [external validator] is saying the same thing."

**Type 6 — Problem Diagnosis**
Use when: tutorial video where the audience has already tried the obvious fix and it still didn't work.
> "If you've been [trying X with AI] and it keeps coming out [wrong/breaking], and you've already tried [the obvious fix] — here's what's actually happening. [Root cause]. And once you understand that, everything changes."

**Type 7 — The Gap**
Use when: you're covering something everyone is talking about but nobody has done the specific implementation piece.
> "[Tool/topic] is all over [YouTube / the space]. But somehow, in all that coverage, nobody has shown you how to [specific critical step most people skip]. That's what this video is."

**Type 8 — Shared Skepticism**
Use when: a new tool or trend is blowing up and the audience is skeptical. You can position as fellow investigator.
> "[New thing] is all over the space. The pitch sounds incredible. And my question is probably the same as yours — does this actually do anything? Or is this just [productivity theater / setup porn / hype]? I went deep on it. Here's what I found."

---

#### The 5-Beat Intro Structure

Every long-form intro hits these five beats. Time budgets are hard limits — bloating one beat kills retention.

| Beat | Job | Time |
|---|---|---|
| 1. Tension Line | Open the hook — one of the 8 types above | 0–8s |
| 2. Stakes | What most people get wrong / what it costs them | 8–20s |
| 3. Promise | What they'll have by the end — concrete and specific | 20–35s |
| 4. Credibility Signal | ONE compressed line. No bio. One number or credential | 35–45s |
| 5. Retention Hook (optional) | "Best part is at X:XX — don't leave before that" | 45–50s |

**Credibility signal rule:** Never more than 15 words. Never a bio paragraph. Pick whichever number is biggest and most specific — "I've built this exact system for 40+ clients" or "I've used this across 200+ AI projects." The moment it becomes a paragraph, the viewer is gone.

**Common pattern to fix:** A multi-company resume bio paragraph (listing past employers/credentials) runs 30+ words before the viewer is bought in. That's the #1 retention killer in most creator intros. Replace it with one compressed line at Beat 4.

---

#### Intro Script Output Format

```
### Hook Type: [Type Name + one-sentence rationale for why this type fits]

**Script (read out loud):**
[Beat 1 — Tension Line]
[Beat 2 — Stakes]
[Beat 3 — Promise]
[Beat 4 — Credibility Signal (max 15 words)]
[Beat 5 — Retention Hook (optional)]

Word count: ~[X] words (~[Y] seconds at normal speaking pace)
```

Target: 80–120 words. 35–45 seconds. Conversational, not stiff. Write it so the creator can read it cold without it sounding scripted.

---

### Step 4d — Deepen Research (If Needed)

Check if existing research covers the top idea's angle well enough to build a video.

**Signs research is thin:**
- The angle is a subset or twist on the broader topic not yet explored in depth
- Key claims in the idea brief don't have supporting data yet
- You'd need to speculate in an outline

**If thin:** Suggest running `/yt-pipeline <topic>` first, or proceed with lighter research via web search.

**If sufficient:** Move straight to `/hooks` or `/outlines`.

### Hook Output Standard (applies to ALL hooks in this skill)

Every spoken hook must ship with a text overlay. No exceptions. The two are always written as a pair — the viewer hears the spoken hook while reading the overlay simultaneously.

**Rules for the text overlay:**
- 2-6 words
- Says something DIFFERENT from the spoken hook — never a caption, label, or summary
- Must work muted (viewer sees it with no audio)
- Must work standalone (makes sense with zero context)

**Three categories that work:**
- **Confession** — raw tension from the before-state: "3 months. $0." / "I almost quit." / "I kept building instead."
- **Paradox** — sounds wrong when heard alongside the hook: "The build was done." is NOT a paradox — it's a label. A real paradox contradicts expectation: "I fired the client." / "It made things worse."
- **Social proof gap** — implies others figured something out before you: "My first client never saw a demo." / "78K people knew this."

**Fail patterns — these are NOT valid overlays:**
- Descriptive labels: "The build was done." / "Not a design problem." — explains context, doesn't create tension
- Tool names: "Claude Code + LinkedIn"
- Preachy statements: "Zero excuses left."
- Anything that answers or sets up the spoken hook (sequential, not simultaneous)

**Self-check before finalizing:** Read the overlay alone. Does it make you ask a question? If it answers a question instead, rewrite it.

---

### Step 6 — Instagram Reel Ideas

Generate **3-5 Reel ideas** from the same research. Reels are a different format and a different algorithm — ideas that work on YouTube don't automatically translate.

**What works on Reels (from your what-works data):**
- Contrarian reframe of a named belief — #1 pattern by a massive margin (score 33,732)
- "Most beginners/people" contrast hook — #2 (score 8,178)
- Permission removal ("You don't need to...") — direct objection killer
- Everyone/Nobody social proof gap
- Short captions win — top posts avg 586 chars vs 651 for bottom posts
- Reels dramatically outperform carousels — video only

**What doesn't work:**
- Day X / journey series
- How-to instructional hooks (instruction as hook, not result)
- Opinion bait with no CTA or resource
- Negative/overrated framing without an immediate resolution

**How the two hooks work together:**

The spoken opener and text overlay are simultaneous — the viewer hears one and reads the other at the exact same moment. They must be written as a pair where each says something DIFFERENT, and each makes complete sense on its own.

**Write the spoken opener first.** It is a standalone hook built from the Kallaway framework (see `/hooks`) — one of the five desire variations (About Me, If I, To You, Can You, He/She Just Did), written at fifth-grade reading level, opening a curiosity loop. It must work with zero visual context. The viewer should be hooked by the words alone.

**Write the text overlay second.** It is a visual complement — never a setup for, follow-up to, or caption of what's being said. The goal is **intrigue, not description**. The best text overlays make the viewer ask a question — they don't answer one. Three categories that work:
- **Paradox** — something that sounds wrong or contradictory: "She was right." / "I fired all three." / "It cost me $20."
- **Social proof gap** — implies others knew something before you did: "78K people knew this before me."
- **Confession** — admits something that creates tension: "I almost didn't post this." / "Agency quote: $5,000."

Text overlays that don't work: descriptive labels ("Not a design problem."), tool names ("Claude Design + Claude Code"), preachy statements ("Zero excuses left."), anything that just summarizes the spoken hook.

**Bad example (reads as sequential):**
- Text: "Your designer charges $5,000 for this."
- Spoken: "I just built the same thing in 20 minutes." ← this is a *response* to the text, not simultaneous

**Good example (simultaneous, each stands alone):**
- Spoken: "I just built a landing page, a lead magnet, and a pitch deck. Traditional agency cost: $5,000 and three weeks. My cost: $20 and one afternoon." ← complete hook, works without visuals
- Text: "Agency quote: $5,000." ← paradox/confession anchor — you read the cost while hearing the story; together they create contrast without either explaining the other

**Format for each Reel idea:**

```
### Reel [N]: [Working concept]

- **Spoken opener:** [Standalone Kallaway hook — About Me / If I / To You / Can You / He-She Just Did. Works with no visual context. Fifth-grade reading level.]
- **Text overlay (on screen simultaneously):** [2-6 words — says something DIFFERENT from the spoken hook. Adds social proof, contrast, a paradox, or a question. Works muted.]
- **Core point:** [The one thing this clip delivers]
- **Pattern:** [Contrarian reframe / Most people contrast / Permission removal / etc.]
- **CTA:** [Comment [WORD] / Follow / Link in bio]
- **Repurposed from:** [YouTube idea #N, or standalone]
```

Reels can be cut from the YouTube video OR shot as standalone vertical content. Note which is which.

### Step 7 — Save (Optional)

Save to `[KNOWLEDGE_FOLDER]/content/YYYY-MM-DD-ideation-<topic>.md` (folder set in your config).

## Key Principles

- **This is strategy, not research.** Don't replicate what `/yt-pipeline` already does.
- **Differentiation is everything.** An idea without a competitive gap is a wasted video.
- **Desire mapping is not optional.** Every idea maps to a Horseman + proxy desire.
- **Don't pitch ideas the creator has already done.** Check `[KNOWLEDGE_FOLDER]/content/` and the video archive before suggesting.
- **Be opinionated.** "Film this one first because..." is more useful than a flat list.
- **Always include URLs.** Every referenced YouTube video must include its URL. Every referenced repo, article, or external tool must include a direct link. Never name something without linking it — the creator needs to be able to click straight to the source.
- **Pull hooks from outliers.** For any video called out as a performance outlier or reference, run the yt-dlp hook extraction and present the first 30 seconds verbatim. This is the most direct way to see what's actually working.
