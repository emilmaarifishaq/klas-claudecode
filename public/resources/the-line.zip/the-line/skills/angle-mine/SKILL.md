---
name: angle-mine
description: "Find YouTube video angles you haven't covered yet. Scans recent competitor content, compares against your own archive, and surfaces 5-8 unmade gaps ranked by opportunity. Output feeds into /ideation. Use when you say /angle-mine, 'what should I make next', 'what haven't I covered', 'find content gaps', 'what are competitors making that I haven't', or 'I need video ideas but don't have a topic'."
allowed-tools: Bash, WebSearch, Read, Write, mcp__claude_ai_vidIQ_for_Claude__vidiq_channel_videos
user-invocable: true
metadata:
  argument-hint: "/angle-mine [--days=N]"
---

# Angle Mine

Scan what competitors published recently, compare against your archive, find the gaps AND remix opportunities. Output: a ranked list of unmade or remixed angles ready to hand to /ideation.

**This skill is discovery only.** No hooks, no briefs, no thumbnails. Those belong to /ideation.

---

## Your Tool Stack (relevance filter)

Only surface angles for tools you actually use. Gaps on tools you don't use are irrelevant — your credibility comes from teaching what you do.

> **Bring your own:** Define your in-scope and out-of-scope tools below. List the tools your channel actually covers (so the skill only surfaces relevant gaps), and the adjacent tools you deliberately don't teach (so it filters them out). The lists below are EXAMPLES — replace them with your own niche.

**In scope (EXAMPLE — replace with your stack):** Claude Code, Claude Skills/plugins, CLAUDE.md, MCP servers, Higgsfield MCP, Firecrawl, memory systems, Remotion

**Out of scope (EXAMPLE — replace with tools you don't teach):** n8n, Make.com, Zapier, Replit, Lovable

**Your content formats (for remix step) — EXAMPLE templates, replace with your own:**
- "How I use X to do Y" — real use case, your actual workflow
- "X levels" framework — beginner to advanced progression  
- "Stop doing X, do Y instead" — contrarian correction
- "X changed everything about Y" — tool drop reaction with application
- "I replaced X with Y" — head-to-head
- "Copy my [system/stack/setup]" — reveal format, high trust
- "The X you can sell tomorrow" — monetization angle for your audience

---

## STEP 0 — Parse Input

- `--days=N` → scan last N days of competitor content
- No flag → default 30 days

---

## STEP 1 — Load in Parallel (fire all at once)

**A — Your published archive:**

```bash
ls [KNOWLEDGE_FOLDER]/video-archive/*.md 2>/dev/null \
  | grep -v DS_Store | grep -v fetch-queue \
  | xargs -I{} basename {} .md | sort
```

> `[KNOWLEDGE_FOLDER]` is the path to your own notes/archive folder (bring your own — set it in your config). Point it at wherever you keep a record of videos you've already published, one file per video. The relative structure (`[KNOWLEDGE_FOLDER]/video-archive`) is what matters.

Extract titles. This is the "already done" filter — any gap too close to a published video gets deprioritized.

**B — Competitor scans via vidIQ MCP (all in parallel):**

Call `mcp__claude_ai_vidIQ_for_Claude__vidiq_channel_videos` for each channel below with `videoFormat: "long"` and `popular: false` (recent uploads, not all-time popular). Fire all calls simultaneously.

> **Bring your own competitor list:** Replace the table below with the 8-12 top channels in your niche (channel name + YouTube channel ID). One real channel is left as an EXAMPLE so you can see the format — swap it and the placeholder row out for your own.

| Channel | ID |
|---|---|
| [YOUR_COMPETITOR_CHANNELS — 8-12 top channels in your niche, name + UC… id each] | [YOUR_CHANNEL_IDS] |
| Example Channel (replace) | UCoy6cTJ7Tg0dqS-DI-_REsA |

Filter results to the `--days=N` window (default 30 days) by publish date. From each result extract: **title, channel, view count, publish date.**

**C — Current tool landscape reference (built-in, no fetch needed):**

> **Bring your own tool map:** This is the active map of tools in your niche, used for gap detection (Type 3 tool-combination gaps especially). Replace the example groupings below with the tools and platforms relevant to your audience. Keep them grouped by category so combination gaps are easy to spot.

The active tool map for gap detection (EXAMPLE — replace with your niche):

*Agent/coding ecosystem:* Claude Code, Claude Skills/plugins, CLAUDE.md patterns, MCP servers, context window/context rot

*General AI stack:* Gemini, NotebookLM, and other models/platforms your audience uses

*Dev/memory tools:* note-taking + AI memory systems, LightRAG, Cursor, Playwright, Remotion

*Video/content AI:* the image/video/voice tools your audience cares about

---

## STEP 2 — Find Gaps AND Remixes

Four opportunity types to look for. Work through each systematically.

**Type 1 — Topic gaps**
A competitor has a high-performing video on a topic you haven't touched. Higher signal when 2+ competitors covered it.

**Type 2 — Angle gaps**
You or a competitor covered the *tool* but not with *this frame*. Examples:
- Tutorial exists → no "stop doing X" take
- Demo exists → no income/result angle
- Overview exists → no "levels" or "systems" framework
- Single tool covered → no combination angle

**Type 3 — Tool combination gaps**
Two tools exist in the ecosystem (see Step 1C) that no creator has combined into a video yet. These are highest-originality — nobody can copy it fast because they haven't thought of it.

**Type 4 — Remixes**
A competitor covered a topic you haven't, but in a format or for an audience that doesn't match your lane. Map their angle onto one of your content formats and your tool stack. A remix is valid when: (a) the underlying demand is proven by competitor views, AND (b) your version would be meaningfully different — different tool, different audience framing, or different format. Do NOT remix if you already covered the same angle.

**Score each gap or remix:**
- +1 if 2+ competitors covered the underlying topic (proven demand)
- +1 if it fits your white space: your core tool + your business/audience use case — AND uses a tool from your in-scope stack
- +1 if no video exists from any creator in the last 30 days on this specific angle (open ground)

**Recency filter (apply after scoring):**
The AI space moves fast. Content signal (views, multi-competitor coverage) is the primary rank signal. But among gaps with similar scores, prefer the one with the fresher competitor signal. A signal older than 3 weeks is a yellow flag — note it, but don't discard the gap if the demand is strong. A 1-week-old video with big views is still a live signal. Note the signal date next to each gap so the freshness is visible.

Max 3 points. Sort descending, with recency as a tiebreaker. Surface top 5–8 only.

---

## STEP 3 — Output

```
🎯 ANGLE MINE — {Date}
{N} competitor videos scanned · {N} of your videos in archive

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GAPS (topics competitors covered that you haven't touched)

1. [●●●] {Working title — written as if it's already a real video}
   Type: Topic gap / Angle gap / Tool combo
   Signal: {1 sentence — why this has proven demand or is wide open} · Signal date: {most recent competitor video date}
   Your edge: {1 sentence — what your POV adds that competitors can't match}

[3–5 gaps max]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

REMIXES (competitor angles reframed for your format + audience)

R1. [●●●] {Your version title}
    Source: {Competitor} did "{their title}" — their angle was {1-phrase summary}
    Your format: {which content format this maps to}
    What changes: {1 sentence — different tool / different audience / different frame}

[3–5 remixes max]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SKIP (out of scope or saturated):
→ {topic}: {reason — wrong tool, you already covered it, or too saturated}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

→ Pick any angle and run /ideation [angle] for the full brief.
```

---

## Principles

- **Output is a list, not a brief.** /ideation handles everything after this.
- **Signal first, recency second.** Strong content signal (views, multi-competitor) is the primary rank. Among close gaps, prefer the fresher one — the AI space moves in 2-week windows.
- **Gaps beat trends.** An open angle on an existing tool outranks chasing a new drop.
- **Multi-channel signal wins.** 3 competitors covered it and you haven't = top of the list. Heavy coverage means high demand — never skip a topic just because competitors are on it. Skip only when you have no differentiated angle. Saturated topic + your unique lane = gap. Saturated topic + no differentiation = skip.
- **Your white space first.** Prefer angles where your implementation/POV is the differentiator — not just "also a tutorial."
- **Title the gaps like real videos.** "Claude Code + a note system as a client memory system" is more useful than "note-system integration gap."
