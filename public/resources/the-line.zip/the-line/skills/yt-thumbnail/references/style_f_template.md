# Style F — Sleeping / Passive Income Notification

## Description
Person asleep face-down on a desk. A floating app notification popup appears above them showing a dollar figure or metric. Phone visible on the desk. The notification IS the proof — "AI is making money while you sleep." Claude branding front and center. No title text needed — the notification is the copy.

Martell reference: Claude +$2700/day with 587k views. Most powerful passive income format on YouTube.

## Full Prompt Template

```
A photorealistic, cinematic, high-resolution YouTube thumbnail. WIDE 16:9 — never portrait.

**Person:** Use Image 1 for exact likeness — wire-frame glasses, short brown beard, dark brown hair, orange hoodie. He is asleep or resting his head face-down on a desk or wooden table surface. Head tilted to one side, eyes closed, relaxed/exhausted expression. Left side of frame. Upper body visible.

**Desk surface:** Clean wooden desk or table. A smartphone lies face-up on the desk near his hand. Soft warm ambient lighting from below/side. A subtle coffee cup or notebook also on the desk — lived-in but clean.

**Notification popup — TOP-LEFT corner of the image (Martell reference placement):**
A floating smartphone notification card, rendered in crisp clean white with rounded corners and a subtle drop shadow. It looks exactly like an iOS notification banner — wide, horizontal pill shape. Contains:
- Left side: reproduce the logo from Image 2 exactly — the app icon
- App name: "[INSERT APP NAME]" in small dark grey text, with "Now" timestamp on the right
- Notification body: "[INSERT METRIC]" in large bold dark text — e.g. "+$2,700/day" or "14,000 followers"
The notification sits in the UPPER-LEFT area of the image, slightly overlapping the person. It is large and immediately readable.

**Person position:** Slightly right-of-center or centered. Face is VISIBLE and turned slightly toward camera — not fully face-down. Relaxed, exhausted, but face readable.

**Background:** Warm dark interior — blurred home office or living room. Warm ambient lighting. Bokeh. Dark and cozy.

**No title text overlay** — the notification number/metric IS the entire message.

**CRITICAL:** Wide 16:9. Notification in UPPER-LEFT. Person visible with face toward camera. Warm dark bokeh background. No extra text anywhere.
```

## Placeholder Guide

### [INSERT APP NAME]
The app that "did the work" — usually the hero tool or platform, e.g.: Claude, LinkedIn, Instagram, or your own community/brand name

### [INSERT METRIC]
Specific number — never round. Martell's rule: specificity = credibility.
- "+$2,700/day" not "+$3,000/day"
- "14,247 followers" not "14K followers"
- "+$847 this morning"
- "3 clients booked"

## When to Use
- Automation/passive income videos
- "Claude did this while I slept" angle
- Any video where the AI/system does the work
- Strong pairing with: The Confession, Kill the Subscription formats

## Logo Handling
Pass `--logos Claude` (or whatever app is in the notification). The notification icon must be pixel-accurate.
