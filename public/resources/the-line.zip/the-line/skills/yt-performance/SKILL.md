---
name: yt-performance
description: "Analyze your YouTube performance data to find what's working and surface double-down opportunities. Pulls real vidIQ analytics — outlier scores, velocity, comment signal — and returns a two-layer brief: 30-day action layer (what to make next week) + 90-day pattern layer (what formats/mechanisms consistently win). Also surfaces 'almost outliers' — videos with strong early velocity that dropped off, prime remix targets. Use when you say /yt-performance, 'what's working on my channel', 'analyze my performance', 'what should I double down on', 'find my best videos', or 'what content is resonating'."
allowed-tools: mcp__claude_ai_vidIQ_for_Claude__vidiq_user_channels, mcp__claude_ai_vidIQ_for_Claude__vidiq_outliers, mcp__claude_ai_vidIQ_for_Claude__vidiq_channel_videos, mcp__claude_ai_vidIQ_for_Claude__vidiq_channel_performance_trends, mcp__claude_ai_vidIQ_for_Claude__vidiq_channel_analytics, mcp__claude_ai_vidIQ_for_Claude__vidiq_video_stats, mcp__claude_ai_vidIQ_for_Claude__vidiq_video_comments, mcp__claude_ai_vidIQ_for_Claude__vidiq_channel_stats
user-invocable: true
metadata:
  argument-hint: "/yt-performance [--short] [--long]"
---

# YT Performance

Analyze your YouTube channel data to find what's working — then surface actionable double-down opportunities: remixes, angle variations, and format repeats.

**Output is a brief, not a report.** The goal is a clear list of what to make next, grounded in real performance data. No vanity metrics, no filler.

---

## What This Skill Answers

1. **What outlier content drove spikes in the last 30 days?** (Action layer)
2. **What videos had strong early velocity but died — and why are they prime remixes?** (Almost outlier layer)
3. **What formats and hook mechanisms won consistently over 90 days?** (Pattern layer)
4. **What did the audience say on your best videos?** (Comment signal)

---

## STEP 0 — Parse Input

- `--short` → Shorts only
- `--long` → Long-form only
- No flag → both (default)

---

## STEP 1 — Identify Channel

Call `vidiq_user_channels` to get your authorized channel ID. Store it — all subsequent calls use it.

---

## STEP 2 — Pull Data in Parallel

Fire all four calls simultaneously once channel ID is known.

**A — Your outliers (vidiq_outliers):**
Call with `channelIds: [channelId]`, `publishedWithin: "threeMonths"`, `limit: 30`, `sort: "breakoutScore"`.

Apply `--short`/`--long` via `contentType` if flag was passed.

Extract per video: `videoId`, `title`, `publishedAt`, `viewCount`, `vph`, `breakoutScore`.

**B — Recent uploads (vidiq_channel_videos):**
Call with `popular: false` to get chronological recent uploads. Pull both `"long"` and `"short"` (or just the flagged type).

Extract: `videoId`, `title`, `publishedAt`, `viewCount`. This is the full recent universe — needed to identify "almost outliers" that didn't make the outlier list.

**C — Channel performance trends (vidiq_channel_performance_trends):**
Call with your channelId. This returns the channel's typical view curve at days 1, 3, 7, 14, 30, etc. (median, average, percentiles).

Store the **median views at day 7** and **median views at day 14** — these are the "almost outlier" detection thresholds.

**D — Channel analytics — 30-day window (vidiq_channel_analytics):**
Call with:
- `startDate`: 30 days ago (YYYY-MM-DD)
- `endDate`: today
- `dimensions`: ["day", "video"]
- `metrics`: ["views", "estimatedMinutesWatched", "averageViewPercentage", "averageViewDuration", "subscribersGained", "likes", "comments"]
- `sort`: "-views"
- `maxResults`: 20

This gives per-video breakdown for the last 30 days — watch time %, avg view duration, subs driven.

**E — Channel analytics — 90-day window (vidiq_channel_analytics):**
Same call but `startDate` 90 days ago. Use `maxResults: 40`. This is the pattern layer data.

---

## STEP 3 — Velocity Deep Dive (Top 15 Recent Videos)

From Step 2B, take the 15 most recently published videos. For each, call `vidiq_video_stats` with:
- `granularity: "daily"`
- `from`: video publish date
- `to`: min(publish date + 14 days, today)
- `order: "asc"`

Extract from each:
- **Day 1 views** (first data point)
- **Day 3 views** (cumulative)
- **Day 7 views** (cumulative)
- **Day 14 views** (cumulative, or latest if < 14 days old)
- **Peak VPH** (highest views-per-hour in the first 72 hours)

Fire all 15 calls in parallel.

---

## STEP 4 — Comment Signal (Top 5 Outliers)

From Step 2A, take the top 5 videos by `breakoutScore`. For each, call `vidiq_video_comments` with:
- `videoId`: the video's ID
- `maxResult: 30`
- `order: "relevance"`

Extract: recurring questions, follow-up requests, exact phrases that signal emotional resonance or unmet need.

Fire all 5 calls in parallel.

---

## STEP 5 — Analysis

### 5A — Classify Outliers (from Step 2A + 2D)

For each outlier, determine its **hook mechanism** from the title:

| Mechanism | Signals |
|---|---|
| **Transformation demo** | "I built X", "I replaced X", "I went from X to Y" |
| **Tool reveal** | "This [tool] does X", "New X just dropped", "[Tool] changed everything" |
| **Contrarian** | "Stop doing X", "You don't need X", "X is killing your Y" |
| **Framework/system** | "The X system", "X levels", "Copy my X" |
| **Result proof** | Dollar amounts, follower counts, specific outcomes |
| **Curiosity gap** | "What happens when X", "I tried X for 30 days" |

Assign one mechanism per video. This is the pattern data.

### 5B — Identify "Almost Outliers"

From Step 3 velocity data, find videos that meet BOTH:
1. Day 3 views ≥ 1.5× channel median at day 3 (from Step 2C performance trends)
2. Day 14 views < 1.5× channel median at day 14

These are the "hook worked, content didn't deliver or algo dropped it" candidates.

These are prime remix targets: proven demand signal, execution gap.

### 5C — 30-Day Action Patterns

From Step 2D (30-day analytics by video), rank top 10 videos by views. Then cross-reference with:
- Average view percentage (higher = content matched the hook promise)
- Subscribers gained per video (higher = new audience capture, not just existing fans)
- Comments count (higher = emotional resonance)

Flag each video's primary signal type:
- **Hook worked + content delivered** → `averageViewPercentage > 45%` + high views
- **Hook worked, content underdelivered** → high views + `averageViewPercentage < 35%`
- **Content worked, hook weak** → lower views but high `averageViewPercentage`

### 5D — 90-Day Mechanism Map

Group all outlier videos (breakoutScore > 1.5×) from Steps 2A and 2E by hook mechanism (from 5A). Count wins per mechanism. Identify:
- **Dominant mechanism** — wins most consistently
- **Underused mechanism** — has won but hasn't been repeated recently (gap)
- **Dead mechanism** — tried multiple times, never outperformed

### 5E — Shorts-Long Bridge

Run this analysis in both directions.

**Direction 1 — Shorts → Long-form candidates:**

From Step 2D (30-day Shorts by views), compute the median Short view count. Flag any Short with 2×+ the median as a **long-form candidate** — this Short has validated demand at scale.

For each flagged Short, extract:
- The **exact title** — this becomes the long-form title or the basis for it. Don't reframe it; the algorithm already proved this language works.
- The **exact hook concept** — what the Short promised in the first 3 seconds. The long-form delivers that promise in full.
- The **implementation gap** — what the Short couldn't cover in 60 seconds that a long-form can (setup walkthrough, step-by-step build, deeper use cases, troubleshooting).

The long-form is not a "deep dive on the same topic." It is the **full delivery of what the Short teased.** Viewers who saw the Short already want this — the long-form is the answer they went looking for and couldn't find.

**Direction 2 — Long-form → Short candidates:**

From the almost-outlier list and any long-form with high velocity but low avg view % (<35%), flag for Short treatment. The hook concept clearly works — it just can't sustain a 10-minute video. Strip it to a 45-60 second Short that delivers the core claim without the supporting context. Test the hook at low commitment first.

### 5F — Comment Synthesis

From Step 4, extract per top video:
- **Follow-up questions** ("what about X?", "can you show Y?") → these are video titles
- **Emotional reactions** ("this changed everything", "I didn't know this") → hook language
- **Confusion points** ("wait, how does X work?") → angle gaps to fill

---

## STEP 6 — Output

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
YT PERFORMANCE BRIEF — {Date}
{N} videos analyzed · 30-day + 90-day windows
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

30-DAY ACTION LAYER
Top performers this month and what to do with them.

[For each top 3-5 outlier:]

▶ {Title}
   Published: {date} · Views: {N} · Breakout score: {N}×
   Avg view %: {N}% · Subs driven: {N} · Comments: {N}
   Velocity: Day 1 → {N} | Day 3 → {N} | Day 7 → {N}
   Hook mechanism: {mechanism}
   Signal type: Hook + content worked / Hook worked, content dropped / etc.

   DOUBLE DOWN:
   → Remix: {one specific remix angle — different framing, same demand}
   → Variation: {slightly new angle on the same topic}
   → Follow-up: {what the comments are asking for next}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ALMOST OUTLIERS — High Start, Dropped Off
Hook worked. Demand is real. These deserve a second shot.

[For each almost outlier:]

◈ {Title}
   Published: {date} · Day 3 velocity: {N}× channel median → then dropped
   What likely happened: {hook overdelivered / algo didn't push past initial burst / content dropped in retention}
   Remix this as: {specific angle tweak that aligns content to hook promise}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

90-DAY PATTERN LAYER
What's consistently winning across the last 3 months.

DOMINANT MECHANISM: {mechanism name}
{N} outliers used this → it's your highest-confidence bet

UNDERUSED (has won, hasn't been repeated):
→ {mechanism} — last used {date}, won {N}× channel avg — open for repeat

DEAD (tried it, never popped):
→ {mechanism} — skip until something changes

FORMAT NOTES:
→ Long-form avg view %: {N}% (channel benchmark: ~40% = hook delivering)
→ Shorts avg view %: {N}%
→ Best sub-driver format: {format/mechanism}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SHORTS → LONG-FORM BRIDGE
Shorts that proved demand. Long-form delivers what they promised.

[For each Short with 2×+ median Short views:]

▷ SHORT: "{Exact Short title}"
   Views: {N} · Completion: {N}% · Subs driven: {N}
   Why it worked: {hook mechanism — one line}

   LONG-FORM: "{Exact title or closest adaptation}"
   Use this title: keep the same words, numbers, and hook frame from the Short.
   The long-form delivers: {what the Short couldn't cover in 60s — the full
   setup, the step-by-step build, the use cases, the troubleshooting}
   First 60 seconds: show the end state first (the output the Short promised),
   then walk back through how to get there.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LONG-FORM → SHORT CANDIDATES
High-velocity long-forms with low retention. The hook works. The video doesn't.
Strip to a Short and test the premise without the commitment overhead.

[For each long-form with Day 3 velocity > 1.5× median AND avg view % < 35%:]

▷ "{Long-form title}"
   Velocity: {N}× median · Avg view %: {N}%
   Short concept: "{Short title — reuse exact hook language from the long-form title}"
   What the Short delivers: {the single claim from the title, proven in 45 seconds}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMMENT SIGNAL — What Your Audience Wants Next
Pulled from top 5 outliers.

{For each video:}
"{Title}"
→ Follow-up asks: {exact comment phrases}
→ Emotional language: {phrases that signal resonance — use in future hooks}
→ Confusion points: {what they didn't fully get — angle gap}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RECOMMENDED NEXT 3 VIDEOS

1. {Working title} — {why: mechanism + demand signal + what comment evidence supports it}
2. {Working title} — {why}
3. {Working title} — {why}

→ Run /ideation [title] for the full brief on any of these.
→ Run /angle-mine to cross-check against competitor gaps before filming.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## Principles

- **Velocity over total views.** A 3-week-old video with 50K views may have peaked at day 2 and gone cold. A 5-day-old video with 8K views and rising VPH is the live signal. Always present both.
- **Average view % is the truth test.** High views + low retention = the thumbnail/title lied. High retention + low views = the hook is weak. The intersection tells you where to fix vs. double down.
- **Comments mine the unmade videos.** Treat top-comment themes as a direct content brief from your audience. If 15 people asked the same follow-up, that's a video.
- **Almost outliers are the most underrated signal.** They have proven demand. They didn't win because of execution or algo timing, not because of topic failure. Remix them with tighter content-to-hook alignment.
- **Shorts are demand validators, not just distribution.** A Short that 2×+ outperforms your other Shorts is the algorithm telling you the topic has pull. The long-form is not a separate video — it's the delivery of what the Short already sold. Reuse the exact title language; it's already proven.
- **Direction matters on the bridge.** Shorts → Long-form: the Short teased it, the long-form delivers it. Long-form → Short: the hook concept works but can't hold an audience for 10 minutes. Strip it down, don't abandon it.
- **Mechanisms, not topics.** "[Tool A] + [Tool B]" is a topic. "Transformation demo + [Tool A]" is a mechanism. Mechanisms transfer to any topic. Report patterns at the mechanism level.
- **30 days is what to make. 90 days is how to make it.** Keep these two layers distinct in the output — they answer different questions.
