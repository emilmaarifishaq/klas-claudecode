# YouTube Clipping Agent — Handoff Doc
_Last updated: 2026-03-23_

---

## What This Does

Full automated pipeline: YouTube video → viral short-form clips (9:16) with captions + HeyGen avatar intro.

**Run command:**
```bash
npx tsx src/index.ts --input "Claude Code - Travel App"
# or auto-pick newest:
npx tsx src/index.ts --auto
```

**Output location:** `output/{video-folder-name}/clip-N-{title}.mp4`

---

## Pipeline Steps (in order)

1. **Discover** — matches partial folder name in `INPUT_BASE_PATH`, finds `.mp4` + `.txt` transcript pair
2. **Parse transcript** — `HH:MM:SS:FF` format, auto-detects FPS, distributes words per segment for word-level timing
3. **Claude analysis** — sends transcript + `viral_hooks (1).md` → gets 3-7 clip candidates with timestamps, hook script (one viral hook template WORD FOR WORD, placeholders filled, ends "Watch this."), visual hook text (ALL CAPS, 3-7 words)
4. **Submit HeyGen jobs** — fires all async, runs while local work proceeds (gracefully skipped if not configured)
5. **FFmpeg trim** — either standard crop OR split-screen PiP (see PiP Layout below)
6. **Remotion render (main clips)** — captions burned at 30fps, 1080×1920
7. **Claude proofread captions** — fixes "cloud code" → "Claude Code", etc. before Remotion render
8. **Wait for HeyGen** → Remotion render captioned intros at 30fps (bundle cache busted before this)
9. **FFmpeg concat** — captioned intro + captioned main clip → final file

---

## PiP Layout (Current Mode: ACTIVE)

`.env` has `PIP_LAYOUT=true`. This creates a split-screen 9:16:
- **Top half (1080×960):** Screen recording above face cam — zoomed/cropped to fill, embedded face cam excluded
- **Bottom half (1080×960):** Face cam — zoomed to fill (no letterbox)

**Current face cam coordinates (set in `.env`):**
```
PIP_X=0
PIP_Y=870     ← y-coordinate where face cam starts in the 1920×1080 16:9 source
PIP_W=380     ← face cam width in source
PIP_H=210     ← face cam height in source
```

**If these coordinates don't look right for a new video:** Open the source MP4, find the face cam bounding box, update these 4 values in `.env`.

**Captions in PiP mode:** Centered in the full 1920px frame height (not just top half). Yellow, uppercase, 88px, black outline.

---

## HeyGen Intro

- Renders at 30fps (HeyGen outputs at 25fps; Remotion ignores source fps, reads by timestamp — 30fps output matches main clip for clean concat)
- **1.5× base scale** applied in Remotion to fill the frame (HeyGen adds black padding by default)
- **Punch-in zoom:** Detects the word "watch" in the hook script → applies 30% additional zoom over 15 frames at that moment
- Visual hook text shown full duration on intro (white, 700 weight, 52px, uppercase, drop shadow)

---

## Key Files

| File | What It Does |
|------|-------------|
| `src/pipeline.ts` | Top-level orchestrator — step order and parallelism |
| `src/steps/3-analyze.ts` | Claude prompt for clip ID + hook generation |
| `src/steps/6-caption-render.ts` | Remotion bundle/render + Claude proofread |
| `src/remotion/CaptionedClip.tsx` | Caption + visual hook React component |
| `src/lib/ffmpeg.ts` | `trimClip`, `trimClipPiP`, `concatClips`, `getVideoInfo` |
| `src/lib/heygen.ts` | HeyGen submit/poll/download wrapper |
| `src/config.ts` | All env var reads |
| `.env` | API keys + all tuning params |

---

## .env Reference

```
ANTHROPIC_API_KEY=...
HEYGEN_API_KEY=...
HEYGEN_AVATAR_ID=...
HEYGEN_VOICE_ID=...

INPUT_BASE_PATH=/Users/duncanrogoff/Desktop/The Build Room/YouTube/Exports
OUTPUT_BASE_PATH=/Users/duncanrogoff/Desktop/YouTube Clipping Agent/output
TMP_PATH=/Users/duncanrogoff/Desktop/YouTube Clipping Agent/tmp

CLIP_MIN_SECONDS=30
CLIP_MAX_SECONDS=90
TARGET_CLIP_COUNT=1        ← bump to 5 for a full run

PIP_LAYOUT=true
PIP_X=0
PIP_Y=870
PIP_W=380
PIP_H=210
```

---

## Current Output State

All test runs used: `Claude Code - Travel App` video.

Latest output (all in `output/Claude Code - Travel App/`):
- `clip-1-ai-chat-bot-answers-trip-questions-instantly.mp4` ← **most recent** — this is the one to review

Previous runs (earlier iterations):
- `clip-1-ai-reads-your-gmail-and-builds-a-travel-app.mp4`
- `clip-1-ai-built-my-europe-trip-planner-in-minutes.mp4`
- etc.

---

## Known Issues / Still Needs Verification

### 1. Review latest output
`clip-1-ai-chat-bot-answers-trip-questions-instantly.mp4` — Duncan has NOT yet confirmed this visually. Need to check:
- [ ] HeyGen intro fills the frame (1.5× zoom, no black bars)
- [ ] Split-screen PiP is correct: screen recording top, face cam bottom, no letterbox on either
- [ ] Screen capture in top half has embedded face cam cropped out (zoomed enough)
- [ ] Captions centered in full 1920px height during PiP section
- [ ] Punch-in zoom fires at "watch this" in intro

### 2. Hook generation reliability
Claude fails Zod validation on first attempt ~50% of the time (hook too long, or multi-sentence). The code retries once and succeeds. Not blocking but could be improved by tightening the prompt or reducing `max` on the Zod schema.

### 3. PiP coordinates per video
`PIP_Y=870` was set for the "Claude Code - Travel App" video. Different videos with different layouts need these re-measured. If the face cam appears in the top half or the split looks wrong, measure the face cam bounding box in the new source video and update `.env`.

### 4. Intro base scale tuning
`baseScale = 1.5` in `CaptionedClip.tsx` (line 66) is tuned for HeyGen's current padding. If a future HeyGen render has more/less padding, adjust this value. No env var yet — edit the file directly.

---

## Things That Were Fixed (don't re-introduce)

- **ffprobe removed:** Was crashing with ENOENT. All video info now uses `ffmpeg -i` stderr parsing only (`getVideoInfo` in `ffmpeg.ts`).
- **Bundle cache bust before intro:** HeyGen intro downloaded AFTER the initial bundle is created. `bundleCache.delete(ctx.tmpDir)` is called in `renderCaptionedIntro` to force rebundle so the intro file is present.
- **Separate renders (not combined):** HeyGen is 25fps. Combining into one video before Remotion caused frozen frame artifacts at the transition. Each video (intro + main) is rendered separately at 30fps, then FFmpeg concat.
- **No objectFit cover on HeyGen intro:** HeyGen outputs same-size 1080×1920 — `objectFit: "cover"` does nothing. Scale transform (1.5×) is the actual fix.
- **PiP top half letterbox fix:** Old filter used `pad` with black bars. Current filter uses `scale=-1:960,crop=1080:960` to fill without padding.

---

## Resuming Work

1. Watch `clip-1-ai-chat-bot-answers-trip-questions-instantly.mp4`
2. Report what's still off (intro zoom, PiP split, caption position, etc.)
3. If PiP coordinates need fixing: measure face cam in source video, update `.env`
4. Once one video looks perfect, run with `TARGET_CLIP_COUNT=5` on a new video
