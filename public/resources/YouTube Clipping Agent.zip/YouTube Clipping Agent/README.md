# YouTube Clipping Agent

Automatically extracts the best clips from your YouTube videos, adds TikTok-style captions via Remotion, and prepends an AI avatar intro hook using HeyGen. Outputs vertical 9:16 MP4s ready for Shorts, Reels, and TikTok.

## How It Works

1. Reads your video transcript and finds the highest-tension moments using Claude AI
2. Trims clips with FFmpeg
3. Generates an avatar intro hook using HeyGen
4. Burns animated captions onto the clip using Remotion
5. Stitches intro + clip into a final vertical video

## Prerequisites

- [Node.js](https://nodejs.org) v18+
- [FFmpeg](https://ffmpeg.org/download.html) installed and available in your PATH
- An [Anthropic](https://console.anthropic.com) API key
- A [HeyGen](https://heygen.com) account with an avatar set up

## Setup

**1. Install dependencies**
```bash
npm install
```

**2. Configure your environment**

Copy `.env.example` to `.env` and fill in your values:
```bash
cp .env.example .env
```

| Variable | Where to find it |
|---|---|
| `ANTHROPIC_API_KEY` | console.anthropic.com → API Keys |
| `HEYGEN_API_KEY` | HeyGen → Settings → API |
| `HEYGEN_AVATAR_ID` | HeyGen → your avatar → Use in Video → copy Avatar ID |
| `HEYGEN_VOICE_ID` | HeyGen → your avatar → Use in Video → Voice → Switch → Get Voice ID |
| `INPUT_BASE_PATH` | Folder containing your video subfolders (each with an `.mp4` and `.txt` transcript) |
| `OUTPUT_BASE_PATH` | Where finished clips will be saved |
| `TMP_PATH` | Scratch space for intermediate files (safe to delete after each run) |

**3. Prepare your input folder**

Each video should be in its own subfolder with exactly two files:
```
Exports/
  My Video Name/
    My Video Name.mp4
    My Video Name.txt   ← SRT-format transcript
```

**4. Run**
```bash
npm start
```

## Configuration

| Variable | Default | Description |
|---|---|---|
| `CLIP_MIN_SECONDS` | 30 | Minimum clip length |
| `CLIP_MAX_SECONDS` | 90 | Maximum clip length |
| `TARGET_CLIP_COUNT` | 1 | How many clips to extract per video |
| `PIP_LAYOUT` | true | Set to `true` if your video is screen recording + face cam in corner |
| `PIP_X/Y/W/H` | — | Pixel coordinates of your face cam in the 1920×1080 source |
