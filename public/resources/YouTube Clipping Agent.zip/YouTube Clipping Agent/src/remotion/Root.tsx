import React from "react";
import { Composition } from "remotion";
import { CaptionedClip, type CaptionedClipProps } from "./CaptionedClip";

const defaultProps: CaptionedClipProps = {
  trimmedVideoPath: "",
  words: [],
  durationInFrames: 900,
  fps: 30,
  width: 1080,
  height: 1920,
  visualHook: "",
  isIntro: false,
  isPip: false,
  punchInMs: undefined,
};

export const Root: React.FC = () => {
  return (
    <Composition
      id="CaptionedClip"
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      component={CaptionedClip as any}
      durationInFrames={900}
      fps={30}
      width={1080}
      height={1920}
      defaultProps={defaultProps}
      calculateMetadata={async ({ props }) => {
        const p = props as unknown as CaptionedClipProps;
        return {
          durationInFrames: p.durationInFrames,
          fps: p.fps,
          width: p.width,
          height: p.height,
        };
      }}
    />
  );
};
