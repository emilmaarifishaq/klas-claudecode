import React from "react";
import {
  AbsoluteFill,
  OffthreadVideo,
  useCurrentFrame,
  useVideoConfig,
  interpolate,
  Easing,
  staticFile,
} from "remotion";
import type { Word } from "../types";

export interface CaptionedClipProps {
  trimmedVideoPath: string; // path relative to publicDir (served via staticFile())
  words: Word[]; // offset-adjusted (clip start = 0ms)
  durationInFrames: number;
  fps: number;
  width: number;
  height: number;
  visualHook?: string;  // text shown in top area
  isIntro?: boolean;    // if true, visualHook stays full duration; else fades at 3s
  isPip?: boolean;      // if true, captions centered in full frame
  punchInMs?: number;   // ms to start 30% zoom ("watch this" in HeyGen intro)
}

const PUNCH_IN_FRAMES = 15;

export const CaptionedClip: React.FC<CaptionedClipProps> = ({
  trimmedVideoPath,
  words,
  visualHook,
  isIntro = false,
  isPip = false,
  punchInMs,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const currentMs = (frame / fps) * 1000;

  // ── Active word (one-at-a-time) ──────────────────────────────────────────
  const activeWord = words.find(
    (w) => w.startMs <= currentMs && w.endMs > currentMs
  );

  // ── Visual hook opacity ──────────────────────────────────────────────────
  const hookFadeInEnd = 15;
  const hookHoldEnd = isIntro ? Infinity : Math.round(fps * 3);
  const hookFadeOutEnd = isIntro ? Infinity : hookHoldEnd + 15;

  let hookOpacity: number;
  if (frame <= hookFadeInEnd) {
    hookOpacity = interpolate(frame, [0, hookFadeInEnd], [0, 1], {
      easing: Easing.out(Easing.ease),
    });
  } else if (frame <= hookHoldEnd) {
    hookOpacity = 1;
  } else if (frame <= hookFadeOutEnd) {
    hookOpacity = interpolate(frame, [hookHoldEnd, hookFadeOutEnd], [1, 0]);
  } else {
    hookOpacity = 0;
  }

  // ── Scale: base zoom (fills HeyGen black padding) + punch-in ────────────
  // HeyGen renders the avatar centered with black padding. A 1.5x base scale fills the frame.
  // The punch-in adds another 30% on top at the "watch this" moment.
  const baseScale = isIntro ? 1.5 : 1.0;

  let zoomFactor = 1.0; // multiplies on top of baseScale
  if (punchInMs !== undefined) {
    const punchInFrame = Math.round((punchInMs / 1000) * fps);
    if (frame < punchInFrame) {
      zoomFactor = 1.0;
    } else if (frame < punchInFrame + PUNCH_IN_FRAMES) {
      zoomFactor = interpolate(
        frame,
        [punchInFrame, punchInFrame + PUNCH_IN_FRAMES],
        [1.0, 1.3],
        { easing: Easing.out(Easing.ease) }
      );
    } else {
      zoomFactor = 1.3;
    }
  }

  const scaleValue = baseScale * zoomFactor;

  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      {/* Source video */}
      <AbsoluteFill
        style={{
          transform: `scale(${scaleValue})`,
          transformOrigin: "center 30%",
        }}
      >
        <OffthreadVideo
          src={staticFile(trimmedVideoPath)}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
          }}
        />
      </AbsoluteFill>

      {/* Visual hook — positioned below top edge */}
      {visualHook && hookOpacity > 0 && (
        <AbsoluteFill
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "flex-start",
            alignItems: "center",
            paddingTop: 230,
            opacity: hookOpacity,
          }}
        >
          <div
            style={{
              background: "linear-gradient(180deg, rgba(0,0,0,0.75) 0%, rgba(0,0,0,0) 100%)",
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              height: 400,
            }}
          />
          <div
            style={{
              position: "relative",
              fontFamily: "'Arial', 'Helvetica Neue', sans-serif",
              fontSize: 52,
              fontWeight: 700,
              color: "#FFFFFF",
              textTransform: "uppercase",
              letterSpacing: 3,
              textAlign: "center",
              textShadow: "0px 2px 20px rgba(0,0,0,0.9), 0px 0px 40px rgba(0,0,0,0.7)",
              maxWidth: "85%",
              lineHeight: 1.25,
            }}
          >
            {visualHook}
          </div>
        </AbsoluteFill>
      )}

      {/* Caption — centered in full frame (isPip) or at bottom third */}
      {activeWord && (
        isPip ? (
          // Full-frame center: caption sits in the middle of the 1080x1920 canvas
          <AbsoluteFill
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <div
              style={{
                position: "absolute",
                inset: 0,
                background: "radial-gradient(ellipse at center, rgba(0,0,0,0.4) 0%, rgba(0,0,0,0) 65%)",
              }}
            />
            <div
              style={{
                position: "relative",
                fontFamily: "'Arial Black', 'Impact', sans-serif",
                fontSize: 88,
                fontWeight: 900,
                color: "#FFE600",
                textTransform: "uppercase",
                letterSpacing: 2,
                textShadow:
                  "3px 3px 0px rgba(0,0,0,1), -1px -1px 0px rgba(0,0,0,1), 2px 2px 12px rgba(0,0,0,0.9)",
                textAlign: "center",
                maxWidth: "88%",
                lineHeight: 1.1,
              }}
            >
              {activeWord.word}
            </div>
          </AbsoluteFill>
        ) : (
          // Standard: bottom third
          <AbsoluteFill
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-end",
              alignItems: "center",
              paddingBottom: 280,
            }}
          >
            <div
              style={{
                background: "linear-gradient(0deg, rgba(0,0,0,0.6) 0%, rgba(0,0,0,0) 100%)",
                position: "absolute",
                bottom: 0,
                left: 0,
                right: 0,
                height: 320,
              }}
            />
            <div
              style={{
                position: "relative",
                fontFamily: "'Arial Black', 'Impact', sans-serif",
                fontSize: 88,
                fontWeight: 900,
                color: "#FFE600",
                textTransform: "uppercase",
                letterSpacing: 2,
                textShadow:
                  "3px 3px 0px rgba(0,0,0,1), -1px -1px 0px rgba(0,0,0,1), 2px 2px 12px rgba(0,0,0,0.9)",
                textAlign: "center",
                maxWidth: "88%",
                lineHeight: 1.1,
              }}
            >
              {activeWord.word}
            </div>
          </AbsoluteFill>
        )
      )}
    </AbsoluteFill>
  );
};
