import path from "path";
import fs from "fs";
import { bundle } from "@remotion/bundler";
import { renderMedia, selectComposition } from "@remotion/renderer";
import { offsetWords, distributeWords } from "../lib/timestamps.js";
import { getVideoInfo } from "../lib/ffmpeg.js";
import { getClient } from "../lib/anthropic.js";
import { config } from "../config.js";
import type { ClipCandidate, RunContext, Word } from "../types.js";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REMOTION_ROOT = path.resolve(__dirname, "../remotion/index.ts");

// One bundle per run (keyed by tmpDir since publicDir changes per run)
const bundleCache = new Map<string, string>();

async function getBundleUrl(tmpDir: string): Promise<string> {
  const cached = bundleCache.get(tmpDir);
  if (cached) return cached;

  console.log("[remotion] Bundling compositions (one-time per run)...");
  const serveUrl = await bundle({
    entryPoint: REMOTION_ROOT,
    publicDir: tmpDir,
  });
  bundleCache.set(tmpDir, serveUrl);
  console.log("[remotion] Bundle ready");
  return serveUrl;
}

/**
 * Use Claude to proofread caption words — fixes transcription errors (e.g. "cloud code" → "Claude Code")
 * while preserving exact word count and timing.
 */
async function proofreadWords(words: Word[]): Promise<Word[]> {
  if (words.length === 0) return words;

  const client = getClient();
  const wordList = words.map((w) => w.word).join(" ");

  try {
    const msg = await client.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 600,
      messages: [
        {
          role: "user",
          content: `You are proofreading captions from a YouTube transcript for a creator named Duncan Rogoff who talks about AI tools, personal branding, and business.

Fix any transcription errors, misspellings, or misheard words. Common issues:
- "cloud code" or "cloud" alone → "Claude Code" or "Claude" (Anthropic's AI)
- "anthropic" should be "Anthropic"
- AI tool names should be properly capitalized (GPT, ChatGPT, Perplexity, etc.)
- Fix obvious word substitutions from speech-to-text errors

CRITICAL RULES:
- Return EXACTLY ${words.length} words, space-separated
- Do NOT add or remove words
- Do NOT add punctuation or change capitalization beyond fixing proper nouns
- Return ONLY the corrected words, nothing else

Words to proofread:
${wordList}`,
        },
      ],
    });

    const text = msg.content.find((b) => b.type === "text");
    if (!text || text.type !== "text") return words;

    const corrected = text.text.trim().split(/\s+/);
    if (corrected.length !== words.length) {
      console.warn(
        `[proofread] Word count mismatch (got ${corrected.length}, expected ${words.length}) — skipping`
      );
      return words;
    }

    const fixes = words
      .map((w, i) => (w.word !== corrected[i] ? `"${w.word}" → "${corrected[i]}"` : null))
      .filter(Boolean);
    if (fixes.length > 0) {
      console.log(`[proofread] Fixed ${fixes.length} word(s): ${fixes.join(", ")}`);
    }

    return words.map((w, i) => ({ ...w, word: corrected[i] }));
  } catch (err) {
    console.warn(`[proofread] Claude call failed, skipping: ${err}`);
    return words;
  }
}

async function renderWithCaptions(
  videoPath: string,
  outputPath: string,
  words: Word[],
  durationInFrames: number,
  fps: number,
  visualHook: string,
  isIntro: boolean,
  isPip: boolean,
  punchInMs: number | undefined,
  label: string,
  tmpDir: string
): Promise<void> {
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  const serveUrl = await getBundleUrl(tmpDir);
  const relativeVideoPath = path.relative(tmpDir, videoPath);

  const inputProps = {
    trimmedVideoPath: relativeVideoPath,
    words,
    durationInFrames,
    fps,
    width: 1080,
    height: 1920,
    visualHook,
    isIntro,
    isPip,
    punchInMs,
  };

  const composition = await selectComposition({
    serveUrl,
    id: "CaptionedClip",
    inputProps,
  });

  console.log(`[remotion] Rendering ${label} (${durationInFrames} frames @ ${fps}fps)...`);

  await renderMedia({
    composition,
    serveUrl,
    codec: "h264",
    outputLocation: outputPath,
    inputProps,
    concurrency: 1,
    imageFormat: "jpeg",
    jpegQuality: 80,
    chromiumOptions: { disableWebSecurity: true },
    onProgress: ({ progress }) => {
      process.stdout.write(`\r[remotion] ${label}: ${Math.round(progress * 100)}%`);
    },
  });

  process.stdout.write("\n");
}

/**
 * Render captions + visual hook on the main clip.
 */
export async function renderCaptionedClip(
  candidate: ClipCandidate,
  trimmedPath: string,
  allWords: Word[],
  index: number,
  ctx: RunContext
): Promise<string> {
  const outputPath = path.join(ctx.tmpDir, "captioned", `clip-${index}.mp4`);

  const durationSeconds = candidate.endSeconds - candidate.startSeconds;
  const fps = 30; // PiP clips are forced to 30fps in FFmpeg
  const durationInFrames = Math.ceil(durationSeconds * fps);

  const clipWords = allWords.filter(
    (w) =>
      w.startMs >= candidate.startSeconds * 1000 - 100 &&
      w.endMs <= candidate.endSeconds * 1000 + 500
  );
  const offsetted = offsetWords(clipWords, candidate.startSeconds);

  console.log(`[proofread] Proofreading clip ${index + 1} captions (${offsetted.length} words)...`);
  const proofed = await proofreadWords(offsetted);

  await renderWithCaptions(
    trimmedPath,
    outputPath,
    proofed,
    durationInFrames,
    fps,
    candidate.visualHook,
    false,
    config.pipLayout,
    undefined,
    `clip ${index + 1}`,
    ctx.tmpDir
  );

  return outputPath;
}

/**
 * Render captions + visual hook on the HeyGen intro video.
 * Uses the actual HeyGen fps (typically 25fps) to avoid frozen-frame artifacts.
 */
export async function renderCaptionedIntro(
  heygenVideoPath: string,
  hookScript: string,
  visualHook: string,
  index: number,
  ctx: RunContext
): Promise<string> {
  const outputPath = path.join(ctx.tmpDir, "captioned-intros", `intro-${index}.mp4`);

  // Bust the bundle cache: the intro video was downloaded AFTER the main clip bundle was created
  bundleCache.delete(ctx.tmpDir);

  const { duration: durationSeconds } = await getVideoInfo(heygenVideoPath);
  // Always render intro at 30fps so it matches the main clip for clean FFmpeg concat.
  // Remotion extracts video frames by timestamp (not frame number) so fps mismatch is fine.
  const fps = 30;
  const durationInFrames = Math.ceil(durationSeconds * fps);

  console.log(`[remotion] Intro ${index + 1}: ${durationSeconds.toFixed(2)}s @ ${fps}fps → ${durationInFrames} frames`);

  const words = distributeWords(hookScript, 0, durationSeconds);

  // Find punch-in at "watch" (second-to-last phrase)
  const watchWord = [...words].reverse().find((w) =>
    w.word.toLowerCase().replace(/[^a-z]/g, "") === "watch"
  );
  const punchInMs = watchWord?.startMs;
  if (punchInMs !== undefined) {
    console.log(`[remotion] Punch-in zoom at ${(punchInMs / 1000).toFixed(2)}s ("watch this")`);
  }

  await renderWithCaptions(
    heygenVideoPath,
    outputPath,
    words,
    durationInFrames,
    fps,
    visualHook,
    true,
    false, // intro is full-frame, no PiP
    punchInMs,
    `intro ${index + 1}`,
    ctx.tmpDir
  );

  return outputPath;
}
