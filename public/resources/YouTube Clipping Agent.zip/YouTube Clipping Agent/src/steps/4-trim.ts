import path from "path";
import { trimClip, trimClipPiP } from "../lib/ffmpeg.js";
import { config } from "../config.js";
import type { ClipCandidate, RunContext } from "../types.js";

export async function trimAllClips(
  candidates: ClipCandidate[],
  ctx: RunContext
): Promise<string[]> {
  const paths: string[] = [];
  const mode = config.pipLayout ? "PiP" : "crop";

  for (let i = 0; i < candidates.length; i++) {
    const c = candidates[i];
    const outPath = path.join(ctx.tmpDir, "trimmed", `clip-${i}.mp4`);
    console.log(
      `[trim] Clip ${i + 1}/${candidates.length} [${mode}]: ${c.startSeconds.toFixed(1)}s → ${c.endSeconds.toFixed(1)}s`
    );

    if (config.pipLayout) {
      await trimClipPiP(ctx.mp4Path, outPath, c.startSeconds, c.endSeconds,
        config.pipX, config.pipY, config.pipW, config.pipH);
    } else {
      await trimClip(ctx.mp4Path, outPath, c.startSeconds, c.endSeconds);
    }

    paths.push(outPath);
  }

  return paths;
}
