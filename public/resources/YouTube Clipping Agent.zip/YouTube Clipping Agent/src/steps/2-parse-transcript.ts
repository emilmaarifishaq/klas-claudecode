import fs from "fs";
import {
  detectFps,
  timecodeToSeconds,
  distributeWords,
} from "../lib/timestamps.js";
import type { TranscriptSegment } from "../types.js";

/**
 * Parse a transcript file into segments with word-level timing.
 * Format per segment:
 *   HH:MM:SS:FF - HH:MM:SS:FF
 *   Speaker
 *   Text content
 *   (blank line)
 */
export function parseTranscript(
  transcriptPath: string
): { segments: TranscriptSegment[]; fps: number; rawText: string } {
  const raw = fs.readFileSync(transcriptPath, "utf8");
  const fps = detectFps(raw);

  const segments: TranscriptSegment[] = [];

  // Split into blocks by blank lines
  const blocks = raw.split(/\n\s*\n/).map((b) => b.trim()).filter(Boolean);

  for (const block of blocks) {
    const lines = block.split("\n").map((l) => l.trim());

    // First line should be a timecode range
    const tcMatch = lines[0]?.match(
      /^(\d{2}:\d{2}:\d{2}:\d{2})\s*-\s*(\d{2}:\d{2}:\d{2}:\d{2})$/
    );
    if (!tcMatch) continue;

    const startSeconds = timecodeToSeconds(tcMatch[1], fps);
    const endSeconds = timecodeToSeconds(tcMatch[2], fps);

    // Remaining lines after speaker label are the text
    // Line index 1 is typically "Unknown" (speaker), line 2+ is content
    const textLines = lines.slice(2).filter(Boolean);
    if (textLines.length === 0) continue;

    const text = textLines.join(" ");
    const words = distributeWords(text, startSeconds, endSeconds);

    segments.push({ startSeconds, endSeconds, text, words });
  }

  return { segments, fps, rawText: raw };
}

/**
 * Get all words across all segments, flattened into a single array.
 */
export function getAllWords(segments: TranscriptSegment[]) {
  return segments.flatMap((s) => s.words);
}

/**
 * Get words that fall within a time range (inclusive).
 */
export function getWordsInRange(
  segments: TranscriptSegment[],
  startSeconds: number,
  endSeconds: number
) {
  return segments
    .filter(
      (s) => s.endSeconds > startSeconds && s.startSeconds < endSeconds
    )
    .flatMap((s) => s.words)
    .filter((w) => w.startMs >= startSeconds * 1000 && w.endMs <= endSeconds * 1000 + 500);
}
