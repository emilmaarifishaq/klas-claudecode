import fs from "fs";
import path from "path";
import { concatClips } from "../lib/ffmpeg.js";
import { sanitizeFilename } from "../lib/timestamps.js";
import type { ClipJob, RunContext } from "../types.js";

export async function finalizeClip(job: ClipJob, ctx: RunContext): Promise<string> {
  fs.mkdirSync(ctx.outputDir, { recursive: true });

  const safeName = sanitizeFilename(job.candidate.title);
  const outputPath = path.join(
    ctx.outputDir,
    `clip-${job.index + 1}-${safeName}.mp4`
  );

  if (job.heygenIntroPath && fs.existsSync(job.heygenIntroPath)) {
    console.log(`[concat] Clip ${job.index + 1}: intro + captioned → ${path.basename(outputPath)}`);
    await concatClips([job.heygenIntroPath, job.captionedPath], outputPath);
  } else {
    console.log(`[concat] Clip ${job.index + 1}: no intro — copying captioned clip`);
    fs.copyFileSync(job.captionedPath, outputPath);
  }

  return outputPath;
}
