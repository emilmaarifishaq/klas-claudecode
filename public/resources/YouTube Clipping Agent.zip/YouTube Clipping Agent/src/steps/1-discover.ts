import fs from "fs";
import path from "path";
import { config } from "../config.js";

export interface DiscoveredVideo {
  mp4Path: string;
  transcriptPath: string;
  videoName: string;
}

export function discover(inputArg: string): DiscoveredVideo {
  let folderPath: string;

  if (path.isAbsolute(inputArg) && fs.existsSync(inputArg)) {
    folderPath = inputArg;
  } else {
    // Search INPUT_BASE_PATH for a folder matching the arg (case-insensitive partial match)
    const entries = fs.readdirSync(config.inputBasePath, { withFileTypes: true });
    const match = entries.find(
      (e) =>
        e.isDirectory() &&
        e.name.toLowerCase().includes(inputArg.toLowerCase())
    );
    if (!match) {
      throw new Error(
        `No folder matching "${inputArg}" found in ${config.inputBasePath}`
      );
    }
    folderPath = path.join(config.inputBasePath, match.name);
  }

  const files = fs.readdirSync(folderPath);

  const mp4Files = files.filter((f) => f.toLowerCase().endsWith(".mp4"));
  if (mp4Files.length === 0) throw new Error(`No MP4 found in ${folderPath}`);

  // Pick the largest MP4 (most likely the main video, not a thumbnail export)
  const mp4File = mp4Files
    .map((f) => ({
      name: f,
      size: fs.statSync(path.join(folderPath, f)).size,
    }))
    .sort((a, b) => b.size - a.size)[0].name;

  const txtFiles = files.filter((f) => f.toLowerCase().endsWith(".txt"));
  if (txtFiles.length === 0)
    throw new Error(`No transcript .txt found in ${folderPath}`);

  // Pick the TXT that contains a timecode (looks like a transcript)
  const transcriptFile =
    txtFiles.find((f) => {
      const content = fs.readFileSync(path.join(folderPath, f), "utf8");
      return /\d{2}:\d{2}:\d{2}:\d{2}/.test(content);
    }) ?? txtFiles[0];

  return {
    mp4Path: path.join(folderPath, mp4File),
    transcriptPath: path.join(folderPath, transcriptFile),
    videoName: path.basename(folderPath),
  };
}

export function autoDiscover(): DiscoveredVideo {
  const entries = fs.readdirSync(config.inputBasePath, { withFileTypes: true });

  // Sort by the mtime of the largest MP4 file inside each folder (not folder mtime,
  // which can be bumped by directory reads)
  const folders = entries
    .filter((e) => e.isDirectory())
    .map((e) => {
      const folderPath = path.join(config.inputBasePath, e.name);
      try {
        const files = fs.readdirSync(folderPath);
        const mp4s = files.filter((f) => f.toLowerCase().endsWith(".mp4"));
        if (mp4s.length === 0) return null;
        const newest = mp4s
          .map((f) => fs.statSync(path.join(folderPath, f)))
          .sort((a, b) => b.mtimeMs - a.mtimeMs)[0];
        return { name: e.name, mtime: newest.mtime };
      } catch {
        return null;
      }
    })
    .filter((f): f is { name: string; mtime: Date } => f !== null)
    .sort((a, b) => b.mtime.getTime() - a.mtime.getTime());

  if (folders.length === 0)
    throw new Error(`No folders found in ${config.inputBasePath}`);

  console.log(`[auto-discover] Picking: ${folders[0].name} (MP4 added ${folders[0].mtime.toLocaleDateString()})`);
  return discover(path.join(config.inputBasePath, folders[0].name));
}
