import path from "path";
import { config } from "../config.js";
import {
  submitHeygenJob,
  pollHeygenJob,
  downloadVideo,
} from "../lib/heygen.js";
import type { ClipCandidate, RunContext } from "../types.js";

export interface HeygenJobHandle {
  index: number;
  promise: Promise<string | null>; // resolves to local file path or null on failure
}

/**
 * Submit all HeyGen intro jobs immediately (non-blocking).
 * Returns handles that resolve when videos are ready.
 * If HeyGen is not configured, all handles resolve to null.
 */
export function submitAllHeygenJobs(
  candidates: ClipCandidate[],
  ctx: RunContext
): HeygenJobHandle[] {
  const heygenConfigured =
    config.heygenApiKey && config.heygenAvatarId && config.heygenVoiceId;

  if (!heygenConfigured) {
    console.log("[heygen] Not configured — skipping intros");
    return candidates.map((_, i) => ({
      index: i,
      promise: Promise.resolve(null),
    }));
  }

  return candidates.map((candidate, i) => ({
    index: i,
    promise: submitAndDownload(candidate, i, ctx),
  }));
}

async function submitAndDownload(
  candidate: ClipCandidate,
  index: number,
  ctx: RunContext
): Promise<string | null> {
  const destPath = path.join(ctx.tmpDir, "intros", `clip-${index}-intro.mp4`);
  try {
    console.log(`[heygen] Submitting intro ${index + 1}: "${candidate.hookScript.slice(0, 60)}..."`);
    const videoId = await submitHeygenJob(candidate.hookScript);
    console.log(`[heygen] Polling intro ${index + 1} (id: ${videoId})`);
    const videoUrl = await pollHeygenJob(videoId);
    console.log(`[heygen] Downloading intro ${index + 1}`);
    await downloadVideo(videoUrl, destPath);
    console.log(`[heygen] Intro ${index + 1} ready: ${destPath}`);
    return destPath;
  } catch (err) {
    console.warn(`[heygen] Intro ${index + 1} failed — continuing without intro: ${err}`);
    return null;
  }
}
