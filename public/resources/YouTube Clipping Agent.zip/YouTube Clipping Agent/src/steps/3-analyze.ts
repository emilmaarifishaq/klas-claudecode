import fs from "fs";
import { z } from "zod";
import { getClient } from "../lib/anthropic.js";
import { timecodeToSeconds } from "../lib/timestamps.js";
import { config, PROJECT_ROOT } from "../config.js";
import type { ClipCandidate } from "../types.js";
import path from "path";

const ClipSchema = z.object({
  start_time: z.string().regex(/^\d{2}:\d{2}:\d{2}:\d{2}$/),
  end_time: z.string().regex(/^\d{2}:\d{2}:\d{2}:\d{2}$/),
  title: z.string().min(3).max(80),
  hook_script: z.string().min(5).max(120),
  visual_hook: z.string().min(3).max(60),
  tension_score: z.number().min(1).max(10),
  clip_type: z.string().transform((v) => {
    // Normalize verbose descriptions to the canonical enum values
    const lower = v.toLowerCase();
    if (lower.includes("opinion") || lower.includes("contrarian")) return "opinion";
    if (lower.includes("insight") || lower.includes("fact") || lower.includes("surprise")) return "insight";
    if (lower.includes("story") || lower.includes("narrative")) return "story";
    if (lower.includes("tip") || lower.includes("tutorial") || lower.includes("how")) return "tip";
    return "quote";
  }) as z.ZodEffects<z.ZodString, "opinion" | "insight" | "story" | "tip" | "quote">,
  reasoning: z.string(),
});

const ResponseSchema = z.object({
  clips: z.array(ClipSchema).min(1).max(10),
});

const SYSTEM_PROMPT = `You are a short-form video editor's assistant analyzing YouTube transcripts to find the best moments for clips (YouTube Shorts, TikTok, Reels). You produce precise JSON — nothing else.`;

function buildUserPrompt(
  transcriptText: string,
  hooksContent: string,
  fps: number,
  targetCount: number,
  minSeconds: number,
  maxSeconds: number
): string {
  return `## VIRAL HOOK TEMPLATES
${hooksContent}

---

## TRANSCRIPT (FPS: ${fps})
${transcriptText}

---

## YOUR TASK

Identify ${targetCount} clip candidates from the transcript above. Each clip should be ${minSeconds}–${maxSeconds} seconds long.

Choose moments that are one of:
- A strong opinion or contrarian take
- A surprising insight or fact drop
- A storytelling peak (conflict, tension, reveal)
- A concrete actionable tip with clear before/after
- A highly quotable one-liner with surrounding context

For each clip:
1. Pick the single most fitting viral hook template from the list above
2. Use that template WORD FOR WORD — do not paraphrase or restructure it
3. Replace every (insert X) placeholder with something specific and relevant from this clip
4. Append "Watch this." at the end if the template doesn't already end with it
5. Do NOT add extra sentences, context, or setup — one line, that's it

For visual_hook:
- 3-7 words, ALL CAPS, punchy
- This is TEXT overlaid on screen (not spoken) — it builds intrigue before the viewer sees the clip
- Should NOT duplicate the hook_script — it's a separate visual tease
- Examples: "THIS CHANGED MY BUSINESS", "NOBODY TALKS ABOUT THIS", "THE MISTAKE THAT COST ME CLIENTS", "WATCH WHAT HAPPENS NEXT"

Rules:
- Start clips 1–3 seconds BEFORE the key moment for context
- End clips at natural sentence completion after the peak
- Timestamps must exactly match the HH:MM:SS:FF format from the transcript
- Do NOT clip intro/outro sections
- hook_script MUST be a single sentence, under 20 words, ending with "watch this." — one punchy line, that's it

Return ONLY valid JSON. No markdown, no explanation.

{
  "clips": [
    {
      "start_time": "HH:MM:SS:FF",
      "end_time": "HH:MM:SS:FF",
      "title": "punchy 6-10 word title",
      "hook_script": "fully resolved hook ending with watch this.",
      "visual_hook": "ALL CAPS 3-7 WORD TEXT TEASE",
      "tension_score": 8,
      "clip_type": "opinion",
      "reasoning": "one sentence why this works"
    }
  ]
}`;
}

async function callClaude(prompt: string): Promise<string> {
  const client = getClient();
  const msg = await client.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 2000,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content: prompt }],
  });

  const text = msg.content.find((b) => b.type === "text");
  if (!text || text.type !== "text") throw new Error("No text content in Claude response");
  return text.text;
}

function parseAndValidate(raw: string): z.infer<typeof ResponseSchema> {
  // Strip any accidental markdown code fences
  const cleaned = raw.replace(/^```(?:json)?\s*/m, "").replace(/\s*```\s*$/m, "").trim();
  const parsed = JSON.parse(cleaned);
  return ResponseSchema.parse(parsed);
}

export async function analyzeTranscript(
  rawTranscript: string,
  fps: number
): Promise<ClipCandidate[]> {
  const hooksContent = fs.readFileSync(config.hooksFilePath, "utf8");

  // If transcript is very long (>50K chars), chunk it
  const MAX_CHARS = 50000;
  let allRawClips: z.infer<typeof ClipSchema>[] = [];

  if (rawTranscript.length > MAX_CHARS) {
    // Split into thirds, analyze each
    const third = Math.floor(rawTranscript.length / 3);
    const chunks = [
      rawTranscript.slice(0, third),
      rawTranscript.slice(third, third * 2),
      rawTranscript.slice(third * 2),
    ];

    console.log(`[analyze] Long transcript — analyzing in 3 chunks...`);
    for (const chunk of chunks) {
      const prompt = buildUserPrompt(chunk, hooksContent, fps, 3, config.clipMinSeconds, config.clipMaxSeconds);
      let raw: string;
      try {
        raw = await callClaude(prompt);
        const result = parseAndValidate(raw);
        allRawClips.push(...result.clips);
      } catch (err) {
        console.warn(`[analyze] Chunk failed: ${err}`);
      }
    }

    // Tournament: pick best N by tension_score
    allRawClips.sort((a, b) => b.tension_score - a.tension_score);
    allRawClips = allRawClips.slice(0, config.targetClipCount);
  } else {
    const prompt = buildUserPrompt(rawTranscript, hooksContent, fps, config.targetClipCount, config.clipMinSeconds, config.clipMaxSeconds);
    let raw = await callClaude(prompt);

    try {
      const result = parseAndValidate(raw);
      allRawClips = result.clips;
    } catch (err) {
      console.warn(`[analyze] Parse failed, retrying: ${err}`);
      // Retry with explicit error context
      const retryPrompt = `${prompt}\n\nPrevious response failed validation: ${err}\nReturn ONLY valid JSON matching the schema exactly.`;
      raw = await callClaude(retryPrompt);
      const result = parseAndValidate(raw);
      allRawClips = result.clips;
    }
  }

  return allRawClips.map((c) => ({
    startTime: c.start_time,
    endTime: c.end_time,
    startSeconds: timecodeToSeconds(c.start_time, fps),
    endSeconds: timecodeToSeconds(c.end_time, fps),
    title: c.title,
    hookScript: c.hook_script,
    visualHook: c.visual_hook,
    tensionScore: c.tension_score,
    clipType: c.clip_type,
    reasoning: c.reasoning,
  }));
}
