import "dotenv/config";
import { runPipeline } from "./pipeline.js";

const args = process.argv.slice(2);

function getArg(flag: string): string | null {
  const idx = args.indexOf(flag);
  if (idx !== -1 && args[idx + 1]) return args[idx + 1];
  return null;
}

const inputArg = getArg("--input");
const isAuto = args.includes("--auto");

if (!inputArg && !isAuto) {
  console.error(
    "Usage:\n" +
    '  npx tsx src/index.ts --input "Claude Code - Travel App"\n' +
    "  npx tsx src/index.ts --auto"
  );
  process.exit(1);
}

runPipeline(inputArg).catch((err) => {
  console.error("[fatal]", err);
  process.exit(1);
});
