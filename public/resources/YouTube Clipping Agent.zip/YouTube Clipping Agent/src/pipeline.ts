import fs from "fs";
import path from "path";
import crypto from "crypto";
import { discover, autoDiscover } from "./steps/1-discover.js";
import { parseTranscript, getWordsInRange } from "./steps/2-parse-transcript.js";
import { analyzeTranscript } from "./steps/3-analyze.js";
import { trimAllClips } from "./steps/4-trim.js";
import { submitAllHeygenJobs } from "./steps/5-heygen.js";
import { renderCaptionedClip, renderCaptionedIntro } from "./steps/6-caption-render.js";
import { finalizeClip } from "./steps/7-concat.js";
import { config } from "./config.js";
import type { ClipJob, RunContext } from "./types.js";

function log(step: string, msg: string) {
  const now = new Date().toTimeString().slice(0, 8);
  console.log(`[${now}][${step}] ${msg}`);
}

export async function runPipeline(inputArg: string | null): Promise<void> {
  const runId = crypto.randomBytes(4).toString("hex");

  // Step 1: Discover
  log("discover", inputArg ? `Searching for: ${inputArg}` : "Auto-discovering newest video");
  const discovered = inputArg ? discover(inputArg) : autoDiscover();
  log("discover", `Found: ${discovered.videoName}`);
  log("discover", `  MP4: ${discovered.mp4Path}`);
  log("discover", `  TXT: ${discovered.transcriptPath}`);

  const ctx: RunContext = {
    runId,
    videoName: discovered.videoName,
    mp4Path: discovered.mp4Path,
    transcriptPath: discovered.transcriptPath,
    outputDir: path.join(config.outputBasePath, discovered.videoName),
    tmpDir: path.join(config.tmpPath, runId),
    fps: 29.97,
  };

  fs.mkdirSync(ctx.tmpDir, { recursive: true });
  fs.mkdirSync(ctx.outputDir, { recursive: true });

  // Step 2: Parse transcript
  log("parse", "Parsing transcript...");
  const { segments, fps, rawText } = parseTranscript(discovered.transcriptPath);
  ctx.fps = fps;
  log("parse", `${segments.length} segments parsed at ${fps}fps`);

  // Step 3: Claude analysis
  log("analyze", "Sending transcript to Claude for clip identification...");
  const candidates = await analyzeTranscript(rawText, fps);
  log("analyze", `${candidates.length} clips identified:`);
  candidates.forEach((c, i) => {
    log("analyze", `  ${i + 1}. [${c.tensionScore}/10] "${c.title}" (${c.startTime} → ${c.endTime})`);
  });

  // Step 4 (early): Submit HeyGen jobs immediately (async, runs while we trim + render)
  log("heygen", "Submitting HeyGen intro jobs (running in background)...");
  const heygenHandles = submitAllHeygenJobs(candidates, ctx);

  // Step 5: FFmpeg trim
  log("trim", "Trimming clips with FFmpeg...");
  const trimmedPaths = await trimAllClips(candidates, ctx);

  // Step 6: Remotion render captions on main clips (parallel with HeyGen download)
  log("remotion", "Rendering captions on main clips...");
  const captionedPaths: string[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const words = getWordsInRange(segments, candidates[i].startSeconds, candidates[i].endSeconds);
    const captionedPath = await renderCaptionedClip(candidates[i], trimmedPaths[i], words, i, ctx);
    captionedPaths.push(captionedPath);
  }

  // Step 6b: Wait for HeyGen, then render captions on intros
  log("remotion", "Waiting for HeyGen intros, then rendering captions...");
  const captionedIntroPaths: (string | null)[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const rawIntroPath = await heygenHandles[i].promise;
    if (rawIntroPath) {
      try {
        const captionedIntro = await renderCaptionedIntro(
          rawIntroPath,
          candidates[i].hookScript,
          candidates[i].visualHook,
          i,
          ctx
        );
        captionedIntroPaths.push(captionedIntro);
      } catch (err) {
        log("remotion", `Intro ${i + 1} caption render failed — using raw: ${err}`);
        captionedIntroPaths.push(rawIntroPath);
      }
    } else {
      captionedIntroPaths.push(null);
    }
  }

  // Step 7: Concat captioned intro + captioned clip → final output
  log("finalize", "Finalizing clips...");
  const finalPaths: string[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const job: ClipJob = {
      index: i,
      candidate: candidates[i],
      words: [],
      trimmedPath: trimmedPaths[i],
      captionedPath: captionedPaths[i],
      heygenIntroPath: captionedIntroPaths[i],
      finalOutputPath: "",
    };
    const outputPath = await finalizeClip(job, ctx);
    job.finalOutputPath = outputPath;
    finalPaths.push(outputPath);
  }

  console.log("\n");
  log("done", `✓ ${finalPaths.length} clips ready in: ${ctx.outputDir}`);
  finalPaths.forEach((p, i) => {
    log("done", `  ${i + 1}. ${path.basename(p)}`);
  });
}
