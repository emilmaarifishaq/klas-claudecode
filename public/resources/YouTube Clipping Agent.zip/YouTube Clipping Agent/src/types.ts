export interface Word {
  word: string;
  startMs: number;
  endMs: number;
}

export interface TranscriptSegment {
  startSeconds: number;
  endSeconds: number;
  text: string;
  words: Word[];
}

export interface ClipCandidate {
  startTime: string; // raw HH:MM:SS:FF from Claude
  endTime: string;
  startSeconds: number;
  endSeconds: number;
  title: string;
  hookScript: string; // fully resolved, ends with "watch this."
  visualHook: string; // 3-7 word text overlay shown in top third
  tensionScore: number;
  clipType: "opinion" | "insight" | "story" | "tip" | "quote";
  reasoning: string;
}

export interface ClipJob {
  index: number;
  candidate: ClipCandidate;
  words: Word[]; // offset-adjusted to clip start = 0
  trimmedPath: string;
  captionedPath: string;
  heygenIntroPath: string | null;
  finalOutputPath: string;
}

export interface RunContext {
  runId: string;
  videoName: string;
  mp4Path: string;
  transcriptPath: string;
  outputDir: string;
  tmpDir: string;
  fps: number;
}
