import fs from "fs";
import path from "path";
import { config } from "../config.js";

const BASE_URL = "https://api.heygen.com";
const POLL_INTERVAL_MS = 5000;
const MAX_POLL_MS = 5 * 60 * 1000; // 5 minutes

interface GenerateResponse {
  data: { video_id: string };
  error: string | null;
}

interface StatusResponse {
  code: number;
  message: string;
  data: {
    id: string;
    status: "processing" | "completed" | "failed" | "pending";
    video_url?: string | null;
    error?: { code: string; message: string } | null;
  };
}

export async function submitHeygenJob(hookScript: string): Promise<string> {
  const body = {
    video_inputs: [
      {
        character: {
          type: "avatar",
          avatar_id: config.heygenAvatarId,
          avatar_style: "normal",
        },
        voice: {
          type: "text",
          input_text: hookScript,
          voice_id: config.heygenVoiceId,
        },
        background: {
          type: "color",
          value: "#000000",
        },
      },
    ],
    dimension: { width: 1080, height: 1920 },
    aspect_ratio: "9:16",
  };

  const res = await fetch(`${BASE_URL}/v2/video/generate`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Api-Key": config.heygenApiKey,
    },
    body: JSON.stringify(body),
  });

  const json = (await res.json()) as GenerateResponse;
  if (json.error) throw new Error(`HeyGen generate error: ${json.error}`);
  return json.data.video_id;
}

export async function pollHeygenJob(videoId: string): Promise<string> {
  const deadline = Date.now() + MAX_POLL_MS;

  while (Date.now() < deadline) {
    await sleep(POLL_INTERVAL_MS);

    const res = await fetch(
      `${BASE_URL}/v1/video_status.get?video_id=${videoId}`,
      { headers: { "X-Api-Key": config.heygenApiKey } }
    );
    const json = (await res.json()) as StatusResponse;

    const { status, video_url, error } = json.data;
    if (status === "completed" && video_url) return video_url;
    if (status === "failed") {
      const reason = error?.message ?? "unknown reason";
      throw new Error(`HeyGen video failed: ${reason}`);
    }
  }

  throw new Error(`HeyGen video ${videoId} timed out after 5 minutes`);
}

export async function downloadVideo(url: string, destPath: string): Promise<void> {
  fs.mkdirSync(path.dirname(destPath), { recursive: true });
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${res.status}`);
  const buf = await res.arrayBuffer();
  fs.writeFileSync(destPath, Buffer.from(buf));
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
