import type { Word } from "../types.js";

/**
 * Detect FPS from transcript by scanning for the highest frame number seen.
 * FF values: max 23 → 24fps, max 24 → 25fps, max 29 → 29.97fps
 */
export function detectFps(rawTranscript: string): number {
  const frameNums: number[] = [];
  // Match HH:MM:SS:FF timestamps
  const re = /\d{2}:\d{2}:\d{2}:(\d{2})/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(rawTranscript)) !== null) {
    frameNums.push(parseInt(match[1], 10));
  }
  if (frameNums.length === 0) return 29.97;
  const maxFrame = Math.max(...frameNums);
  if (maxFrame <= 23) return 24;
  if (maxFrame <= 25) return 25;
  return 29.97;
}

/**
 * Convert HH:MM:SS:FF to seconds (float).
 */
export function timecodeToSeconds(tc: string, fps: number): number {
  const parts = tc.split(":");
  if (parts.length !== 4) throw new Error(`Invalid timecode: ${tc}`);
  const [hh, mm, ss, ff] = parts.map(Number);
  return hh * 3600 + mm * 60 + ss + ff / fps;
}

/**
 * Distribute words evenly across a time range, returning Word[] with startMs/endMs.
 */
export function distributeWords(
  text: string,
  startSeconds: number,
  endSeconds: number
): Word[] {
  const tokens = text.trim().split(/\s+/).filter(Boolean);
  if (tokens.length === 0) return [];

  const totalMs = (endSeconds - startSeconds) * 1000;
  const msPerWord = totalMs / tokens.length;

  return tokens.map((word, i) => ({
    word,
    startMs: Math.round(startSeconds * 1000 + i * msPerWord),
    endMs: Math.round(startSeconds * 1000 + (i + 1) * msPerWord),
  }));
}

/**
 * Offset word timestamps so that clip start = 0ms.
 */
export function offsetWords(words: Word[], clipStartSeconds: number): Word[] {
  const offsetMs = clipStartSeconds * 1000;
  return words.map((w) => ({
    ...w,
    startMs: w.startMs - offsetMs,
    endMs: w.endMs - offsetMs,
  }));
}

/**
 * Sanitize a string for use as a filename.
 */
export function sanitizeFilename(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}
