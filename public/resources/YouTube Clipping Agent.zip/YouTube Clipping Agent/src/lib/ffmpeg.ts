import { spawn } from "child_process";
import fs from "fs";
import path from "path";

const FFMPEG = "ffmpeg";
const FFPROBE = "ffprobe";

function run(args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const proc = spawn(FFMPEG, args, { stdio: ["ignore", "pipe", "pipe"] });
    let stderr = "";
    proc.stderr.on("data", (d: Buffer) => (stderr += d.toString()));
    proc.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`ffmpeg exited ${code}: ${stderr.slice(-500)}`));
    });
  });
}

/**
 * Trim a clip from source MP4 using fast keyframe seeking (stream copy, no re-encode).
 */
export async function trimClip(
  inputPath: string,
  outputPath: string,
  startSeconds: number,
  endSeconds: number
): Promise<void> {
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  await run([
    "-y",
    "-ss", String(startSeconds),
    "-to", String(endSeconds),
    "-i", inputPath,
    "-c", "copy",
    outputPath,
  ]);
}

/**
 * Get video duration in seconds. Tries ffprobe first, falls back to ffmpeg stderr.
 */
/**
 * Get video duration and fps using ffmpeg -i (stderr parsing).
 */
export async function getVideoInfo(videoPath: string): Promise<{ duration: number; fps: number }> {
  return new Promise((resolve) => {
    let stderr = "";
    const ff = spawn(FFMPEG, ["-i", videoPath], { stdio: ["ignore", "ignore", "pipe"] });
    ff.stderr.on("data", (d: Buffer) => (stderr += d.toString()));
    ff.on("close", () => {
      const durMatch = stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
      const duration = durMatch
        ? parseInt(durMatch[1]) * 3600 + parseInt(durMatch[2]) * 60 + parseFloat(durMatch[3])
        : 20;

      // Parse fps from e.g. "25 fps" or "29.97 fps" in the Video stream line
      const fpsMatch = stderr.match(/(\d+(?:\.\d+)?)\s*fps/);
      const fps = fpsMatch ? parseFloat(fpsMatch[1]) : 30;

      resolve({ duration, fps });
    });
    ff.on("error", () => resolve({ duration: 20, fps: 30 }));
  });
}

export async function getVideoDuration(videoPath: string): Promise<number> {
  return (await getVideoInfo(videoPath)).duration;
}

/**
 * Trim and convert to 9:16 using split PiP layout:
 *   Top half  (1080×960) — screen recording above the face cam, scaled to fill (crops embedded face cam PiP)
 *   Bottom half (1080×960) — face cam cropped and scaled to fill
 *
 * pipY is the y-coordinate where the face cam starts in the 16:9 source.
 * Everything above pipY is treated as clean screen content.
 */
export async function trimClipPiP(
  inputPath: string,
  outputPath: string,
  startSeconds: number,
  endSeconds: number,
  pipX: number,
  pipY: number,
  pipW: number,
  pipH: number
): Promise<void> {
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  // Top: crop from y=0 to y=pipY (screen content above face cam), scale to fill 1080x960
  // Bottom: crop the face cam area, scale to fill 1080x960 (zoomed in close-up)
  const filter = [
    `[0:v]crop=in_w:${pipY}:0:0,scale=-1:960,crop=1080:960[screen]`,
    `[0:v]crop=${pipW}:${pipH}:${pipX}:${pipY},scale=-1:960,crop=1080:960[face]`,
    `[screen][face]vstack=inputs=2[out]`,
  ].join(";");

  await run([
    "-y",
    "-ss", String(startSeconds),
    "-to", String(endSeconds),
    "-i", inputPath,
    "-filter_complex", filter,
    "-map", "[out]",
    "-map", "0:a?",
    "-c:v", "libx264",
    "-r", "30",
    "-crf", "18",
    "-preset", "fast",
    "-c:a", "aac",
    "-b:a", "128k",
    outputPath,
  ]);
}

/**
 * Concatenate two MP4 files (intro + main clip) using concat demuxer.
 * Both must be h264/aac with same dimensions.
 */
export async function concatClips(
  files: string[],
  outputPath: string
): Promise<void> {
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });

  // Write concat list to a temp file
  const listPath = outputPath + ".concat.txt";
  const listContent = files.map((f) => `file '${f}'`).join("\n");
  fs.writeFileSync(listPath, listContent);

  try {
    await run([
      "-y",
      "-f", "concat",
      "-safe", "0",
      "-i", listPath,
      "-c", "copy",
      outputPath,
    ]);
  } finally {
    fs.unlinkSync(listPath);
  }
}
