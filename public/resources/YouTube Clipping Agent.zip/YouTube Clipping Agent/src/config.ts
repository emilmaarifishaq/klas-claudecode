import "dotenv/config";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const PROJECT_ROOT = path.resolve(__dirname, "..");

function require_env(key: string): string {
  const val = process.env[key];
  if (!val) {
    throw new Error(
      `Missing required env var: ${key}\nFill in .env in the project root.`
    );
  }
  return val;
}

function optional_env(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

export const config = {
  anthropicApiKey: require_env("ANTHROPIC_API_KEY"),
  heygenApiKey: optional_env("HEYGEN_API_KEY", ""),
  heygenAvatarId: optional_env("HEYGEN_AVATAR_ID", ""),
  heygenVoiceId: optional_env("HEYGEN_VOICE_ID", ""),

  inputBasePath: require_env("INPUT_BASE_PATH"),
  outputBasePath: require_env("OUTPUT_BASE_PATH"),
  tmpPath: require_env("TMP_PATH"),

  clipMinSeconds: Number(optional_env("CLIP_MIN_SECONDS", "30")),
  clipMaxSeconds: Number(optional_env("CLIP_MAX_SECONDS", "90")),
  targetClipCount: Number(optional_env("TARGET_CLIP_COUNT", "5")),

  // PiP layout: when true, stacks screen (top) + face cam (bottom) into 9:16
  pipLayout: optional_env("PIP_LAYOUT", "false") === "true",
  // Face cam crop coordinates in the source 16:9 video (pixels)
  pipX: Number(optional_env("PIP_X", "24")),
  pipY: Number(optional_env("PIP_Y", "810")),
  pipW: Number(optional_env("PIP_W", "480")),
  pipH: Number(optional_env("PIP_H", "270")),

  hooksFilePath: path.join(PROJECT_ROOT, "viral_hooks (1).md"),
};
