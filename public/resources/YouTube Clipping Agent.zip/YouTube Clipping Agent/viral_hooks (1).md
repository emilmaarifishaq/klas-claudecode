
This represents your X before, during, and after X

Here’s exactly how much (insert action/item) you need to (insert result)

Can you tell us how to (insert result) in 60 seconds?

This is what (insert thing) looks like when you’re (insert action). And this is what they look like when you’re not (insert action).

I’m going to tell you how to get (Insert result), (insert mind blowing method).

It took me 10 years to learn this but I’ll teach it to you in less than 1 minute.

When you get (insert item/result) here are the things you got to do right away.

If you don’t have (insert item/action), do (insert item/action).

My money rules as a (insert description) working towards ﬁnancial independence.

Money can buy you (insert item) but it can not buy you (insert result).

Here's how to develop a (insert skill) so strong that you physically can't stop (doing skill).

This is what (insert ) of (insert item) looks like.

If I woke up (insert pain point) tomorrow, and wanted to (insert dream result) by (insert time) here’s exactly what I would do.

If you're a (insert target audience) and you want (insert dream result) by (insert avenue) then listen to this video.

If you are (insert age group or range) do not do (insert action).

As an (insert trait) responsible (insert age) year old with a goal to (insert goal) here are 3 things I will never regret doing.

Not to ﬂex, but I'm fretty f\*cking good at (insert skill/niche).

This is what (insert object/item) looks like when you are using/doing (insert product/service).

Are you still (insert action)? I’ve got (insert result) in (insert time frame) and I have never (insert action).

3 Youtube channels that will teach you more than any (insert industry/niche) degree.

I think I just found the biggest (insert niche/industry) cheat code.

Here are 3 people who will make you a better (insert title).

(insert trait) Guy vs (insert trait) Guy.

I see you doing nothing but (insert action) after (insert event) so follow this agenda to avoid that.

Want to be the ﬁrst (insert dream result) in your family?

This is how many (insert item) you need to (insert result).

Everyone tells you to (insert action) but nobody actually tells you how to do it. Here is a second step by step tutorial that you can save.

If you're (insert age range) these are the things you need to do so you don't end up (insert pain point) by (insert age).

If I were starting over in my (insert age range) with no (insert item) here are the top things I would do to (insert dream result).

Here are some slightly unethical (insert industry/niche) hacks that you should know if you're (insert target audience).

Here's exactly how you're gonna lock in if you want to (insert dream result).

This is the same exact (insert thing) but the ﬁrst is/got (insert result and the second is/got X

If you want to end up (insert pain point) then skip this video.

We have never used (insert noun) in our home because we have found it to be generally (insert trait/traits).

(insert action) for (insert period of time) and you will get (insert dream result).

If you’re between the ages of (insert age) to (insert age) and you feel like (insert pain point).

(insert before state) to (insert after state) in simple steps in under of seconds.

If you're trying to (insert dream results) then here is the one (insert thing) you should do.

How long do you think you have to (insert action) to (insert result).

If you want to do this, ﬁrst do this.

If you’re trying to (insert dream result) and you haven't got a clue what to (insert action) on a daily basis I am going to show you an example.

I’m gonna save you of minutes off your next workout with of simple tips.

If I only had (insert time frame) in the (insert location/place) this is exactly what I would do to get (insert dream result).

How long can you skip (insert action) before losing (insert result).

If you want to (insert dream result) a week for the next (insert weeks) without (insert pain point) then listen up.

If you just turned (insert age) and you don’t want to (insert pain point) then you should do the following things immediately.

You can have a perfect (insert dream result) by simply dumbing it down.

Did you know that this, this, this, and this get (insert dream result).

Don’t start doing (insert action) until you learn how to do this.

(insert industry) tier list for (insert year).

In 60 seconds i’m going to teach you more about (insert thing) than you have ever learned in your entire life.

Everyone tells you to (insert action) but no one actually shows you how to do it. Here is a second step by step tutorial that you can save for later.

If you’re in your (insert 20’s, 30’s, 40’s, 50’s, 60’, etc) then these are the of things you need to do to make sure you don;t end up (insert pain point) by (insert age).

(Insert noun) loses (Insert noun) on this, so they can make (insert noun) on this.

You have (insert noun) tomorrow but you have no time to (insert action). Here’s how you save your (insert noun).

(Insert scenario) and (Insert dream result), here are the of steps to get (insert dream result).

Everyone tells you to do (insert action) but you think it’s too late because you are (Insert age). I am a (insert occupation) and these are of things you need to know in your (Insert age).

(Insert target audience) if you're serious about playing at the next level.

You only have to be dialed in on of things to be an elite (insert title).

(Insert noun) for dummies.

Don’t hate me but I don’t really mind (insert noun).

Best ways to save money while (insert action).

This is every way to (insert action).

What if I told you this (insert item) could (insert result).

Did you know that if you (insert action, (Insert action), (insert action), etc.

The (insert thing) you have now in you (insert age group) is so (insert noun).

At age (insert age) the age that many (insert target audience) is when (insert pain point).

Listen if you’re not forcing your (insert person/persons) to (insert action) in their (insert current state) don’t expect them to be (insert trait) in their (insert after state).

Would you rather watch your (insert person/persons) (insert pain point) or join them in their (insert niche) journey to save their lives?

This is the amount of (insert noun) you would lose per day in a (insert state).

If your in a (insert dream result) journey, this is exactly what you need to do to (insert dream goal) in simple steps.

If you told me of years ago I’d be (insert dream result) I wouldn't have believed you.

If your getting (insert adjective) or know someone (insert adjective) there are of incredulity important things you need to make sure you can do physically in order to (dream result).

If you don’t want to fail (insert life event).

I crammed the hardest (insert noun) and (insert dream result).

If you’re cooked for your (insert life event) but still can’t ﬁnd the motivation to do (insert action) you’re gonna want to see this.

Here’s the difference between (insert title), (insert title) , and (insert title).

If I were in my (insert age range) here is exactly how I would avoid (insert bad result).

Here’s every (insert noun) that you actually need to know.

The most important things I will teach my kids as a (insert job title).

If you can’t solve this (insert problem) in under 5 seconds go back to (insert pre-qualifying stage).

30 seconds of (insert industry) advice I give my best friend if he/she were starting from scratch.

I would do this before quitting your job.

If you do this you’ll (insert result).

If your a (insert target audience) who (insert pain point) and you want to (insert dream result) let's go over a very simple step plan you can follow to quickly (insert dream result).

Here are 5 books to (insert dream result) better than 99% of other people.

If you're somebody who (insert action) and your goal is to (insert dream result) and (insert dream result) at the same time. Then here are my best tips.

If you can't do (insert action).

If you can do of (insert action), than you can do of (insert action).

If your mom didn’t teach you how to make (insert noun) growing up, don't worry i'm your mommy now.

Never lose a game of (insert game) for the rest of your life.

3 levels of (insert noun).

Did you know that if you… (Insert action), (insert action), (insert action), etc

I am a professional (insert industry) hacker, and here's every hack at (insert store/location/event/etc).

I have a very long list of (insert noun) that I (insert action) that I gate keep from other people. But today I feel like giving back so I am going to tell you.

I am going to teach you how to identify a good (insert noun) to a bad (insert noun).

I went to (insert school type) so you don't have to.

Ranking all the most popular (insert noun), so I can rank them from worst to best.

Here is how I (insert action) as a (insert label) (insert age).

You wouldn't get (insert bad result) when you (insert action) if you (insert action).

This is harder than getting into Harvard.

Now how much does it really cost to (insert action).

This is why no one remembers you.

I'm 20 which means my teenage years are ofﬁcially over, so here;s everything I learned from the 7 most weirdest years of my life.

If you're a (target audience) and you want to become (insert dream result) by (insert action) then listen to this video because you have such a big advantage and I will tell you how to conquer it.

If you take (insert noun) it will (insert result).

I just made a website called (insert the longest but most relatable website name).

How to turn just one (insert noun) into a lifetime of free (insert noun).

Things that are damaging your (insert noun) without you even realizing it.

If you have when you see a girl and she just has (insert dream result).

I've (insert dream result) despite having (insert pain point) and this is the routine that did it.

Swap these (insert noun) for better (insert result).

Did you know that this, this, and this target (insert dream result).

Your (insert noun) looks like this and you want them to look like this.

(Insert last year) (insert noun), (insert current year) (insert noun).

Okay (insert pain point), how about we don't f up (insert current year)

This is the program/steps I would follow if I was trying to (insert dream result).

If your (insert noun) looks anything like this, these are not (insert noun) these are (insert noun) and here is how you can get (insert dream result).

Here are some (insert action) you can do without (insert noun).

Let's ﬁnd out what (insert noun) you are in steps.

Most people can only do (insert action) when trying to (insert action) but as an (insert title) you should be able to (insert action).

As an (insert title) you should be able to do this, if you can't (insert diagnosis).

If you're an (insert title) you should be able to do this, this, and this. If you can't I got you, just do this step/routine/program to (insert dream result).

If you have (insert pain point), (insert pain point), and (insert pain point) you might be (insert action) wrong.

If you feel like your never (insert point) here is everything you need for a (insert dream result).

Do you have a (insert pain point) don’t waste your money trying to (insert solution) it's just going to come back.

If giving yourself (insert result) causes (insert pain point), (insert pain point), and (insert pain point) here is how I cheat it.

You don't have (insert pain point), your not (insert adjective), your not (insert adjective) you just need to (insert solution) and I am going to tell you how to do it.

Worst thing you can do for your (insert thing) is to ignore your (insert noun) when (insert scenario).

Ladies, you can do all the (insert action) but that's not going to do sh\*t for your (insert noun).

Never (insert action) ﬁrst and then (insert action).

What happens when you go X hours/days/weeks/years without (insert noun).

There is no doubt in my mind that (insert action) are the best (insert noun) for your (insert noun).

Don't touch this.

What I wish I knew at (insert age) instead of (insert age).

You're damaging your (insert noun) if you (insert noun) looks like this or like this.

My most complemented (insert noun) of (insert year).

I have been dating my girlfriend/boyfriend for years here are basics I learned that every guy/girl should do for a partner in (insert scenario).

When I say I (insert action) everyday and I don't (insert action) everyday people always ask me… of ways to raise (insert adjective) children.

It's okay f you mom didn't talk to you about

The reason you can't (insert dream result) to get that (insert dream result) you keep talking about is because…

This is your (insert noun) on a regular day, this is you (insert noun) on (insert scenario).

You guys know this look, when someone perfectly (insert action) and (insert action) I am obsessed with this (insert noun).

You crave (insert noun) on your (insert scenario) here's why.

This is you (insert noun) when you (insert action), and this is your (insert noun) when you (insert action).

I have (insert noun) commercial (insert noun).

Stop (insert action) if you actually want to (insert dream result).

This is how much (insert dream result) you achieve if you (insert action), and this is how much (insert dream result) if you (insert action) and these of hacks.

If you want to (insert of dream result) per week this is how you are going to do it.

This is for the homies who promised (insert person/persons) and nice and fancy (insert noun).

What if I told you, you could (insert action) for only (insert low cost).

Why did it take me over years to realize you can make (insert result) in minutes.

Don't hate me but I don’t really mind (insert basic niche thing) but don;t worry I am going to show you how to make it way better.

(insert dream result) and (insert dream result) with these of tips. For reference I have (insert personal result).

If you have a (insert dream result) keep scrolling. Today we are going to talk about a (insert routine, method strategy) to (insert dream result)

Did you know that if you (insert action), (insert action), (insert action), etc.

Here's exactly how much (insert noun) you can make with under (insert dollar amount).

The lack of clinical studies on (insert noun) isn't because it doesn't work, it's because…

You'll never get (insert dream result) in your (insert age range) if you don;t do these 3 things when you turn (insert age).

lessons, of (insert person/persons), in of days/weeks/months.

I make more money than doctors, engineers, and lawyers and no I didn't go to college for more than 6 years to get a degree.

I worked at (insert company) for X months/years and now I am exposing everything they keep from customers.

This is what (insert money amount) will get you in (insert location).

How much do I need to make or buy a (insert price) (insert noun).

I make (insert hourly rate) can I qualify/buy (insert loan/noun).

Let's see what your monthly payment would look like if you owned (insert noun).

Lets see what $1,800 a month gets you in (insert location).

If you are paying over (insert price amount) for a (insert noun), you might as well buy a (insert noun).

I have made a spreadsheet with over (insert large number) of (insert noun).

This is (insert large number) of (insert noun).

There is one thing above all that sets the top (insert title) apart from the rest.

This is how I would (insert action) if I were starting from scratch).

If you're spending a lot of money on (insert noun) then you need to try this (insert recipe/method/strategy) because it's super easy and (insert dream outcome).

If you have a (insert noun) you have probably experienced this.

(insert noun) (insert trait) (insert similar noun) (insert trait).

It looks like you haven't done (insert noun) since (insert time frame).

I don’t know who needs to see this but if you have a (insert symptom) this is how I literally (insert dream result) every single time.

Oh look I found (insert $), that means I am going to (insert verb) I only need this.

One (insert noun), one (insert noun), and you have (insert time frame).

The reason your (insert noun) sucks, is because you have no freaking (insert adjective).

You’ve heard of the viral (insert method/strategy/noun name) right? Well I invested that\!

(insert noun) I would make for you based on your favorite (insert noun).

Here are (insert ) of (insert noun) from (insert noun) that I am going to (insert verb) in (insert time frame).

How we saved (insert $) on our (insert noun), and one thing we wish we did differently.

This is everything I bought at (insert store) today to stay (insert adjective) at (insert age).

(insert verb) is expensive. Here is how to (insert noun) for (insert time frame) for only (insert $).

How to (insert verb) you (insert noun) from a (insert title).

How many (insert nouns) can you make with only (insert $).

I present a challenge (insert noun) (insert noun).

This is every way to make (insert noun).

If I have to learn (insert noun) again here’s 5 tips of everything I would do in seconds.

(insert company/individual) if I (insert verb) (insert noun) for you this is what I would do.

This is what it would (insert adjective) like if (insert number) of (insert noun) were in one (insert noun).

This (insert adjective) (insert noun) gets (insert verb) by this (insert adjective) (insert noun).

In this video see if you can tell what’s real and what’s (inset noun).

I have no idea why I have no (insert adjective/noun).

I avoid all toxic (insert noun), here is how to clean up your (insert noun).

Here are of questions I ask before (insert verb).

Since (insert noun) from (insert prace/location) are basically (insert fact), you might as well learn how to make them from home.

Every wonder how the same (insert noun) can result in drastically different (insert noun).

Here’s what to look for when buying (insert noun) in (insert location).

If your (insert noun) look like this, and this pay attention.

Today I am going to show you have to make the perfect (insert noun) because I went to (insert school) so you don’t have to.

It took me full hours to (insert verb) this (insert noun) and I originally allotted myself minutes.

(Insert noun) (insert noun) (insert noun) where the 3 themes for this (insert noun). And you guys I delivered.

Take your (insert noun) from this to this.

I have to ask, girl, how do you (insert adjective) so good?

I got to (insert verb) for (insert noun) (insert time), but let me just (insert verb) for a bit.

Give me 10 seconds and I will let you know what one suits you best.

Give me 10 seconds and I will let you know if you have a (insert noun) or a (insert noun).

Anyone even notice how some people look naturally (insert adjective) without doing anything crazy.

If you’ve ever secretly (insert action) and hope no one noticed this is for you.

Today we are going to play did you know (insert noun) edition.

If this is your ﬁrst time being (insert adjective) I am (insert name) and I am trying to make it (insert adjective) to (insert verb) by using (insert noun).

My (insert noun) never (insert pain point) no matter what I do.

(insert noun) level 1\.

Here are of ways to make (insert noun).

Those little (insert nouns) are called (insert name) I am a (insert title) and I am going to show you how (insert result).

You want to know why it takes (insert noun) to get (insert result) again.

If your (insert noun) goes (insert result) when you (insert verb) while (insert noun) and (insert adjective) really (insert result) by now you know you have (insert noun) so why aren't you doing a (insert noun) routine.

If your (insert noun) is (insert adjective) like this, you are likely (insert diagnosis).

Stop buying your (insert noun) like this, and start buying them like this.

Did you know this tip, it’s going to blow your mind.

If I (insert action) right now would you believe me if I told you (insert truth).

This is what (insert noun) looks like. I am a pro (insert title) and this is the proper way to (insert action).

Does it actually matter what type of (insert noun) you use.

You would need to (insert verb) (insert number) (insert noun) today to get the same (insert result) you grandparents obtained from just (insert verb) (insert number).

Let’s (insert verb) our (insert noun).

This is what you would (insert verb) for (insert person) if you weren't terriﬁed to talk to them.

When making (insert noun) the (insert noun) is just as important as the (insert noun).

Today I am going to show you the most common ways to order your (insert noun) at a (insert place/location).

Guys this is so nerdy but it’s the coolest thing I have ever done with my (insert noun).

(insert noun), (insert noun), (insert noun), makes a (insert noun).

Here are of (insert noun) from across the world, let’s break them down to their core components.

There are way too many (insert noun) in the world that sort of all look that same, but are they?

(insert noun), (insert noun), (insert noun), are the basic components of a (insert noun).

Here's a little (insert noun) 101 for you.

These are the 3 most common mistakes I see when people are making (insert noun).

A quick guide to (insert verb) (insert noun) some basic and some unusual.

I see so many people using their (insert noun) just like this or maybe like this even when you (insert action). So let me show you the trick to perfectly (insert action).

Here’s how the form of (insert noun) you add into (insert noun) affects them.

Why (insert action) like a normal person, when you can be a psycho instead.

This is everything I got for free on my (insert event).

(insert noun) is my second (insert noun) so here are of (insert noun) that I used to do a lot and I recommend my students as well.

If you gave me (insert time frame) to get a job as a (insert title) this is what I would do.

Did you know if you have a (insert noun), (insert noun), (insert noun), (insert noun), (insert noun) then you can (insert dream result).

If you're the person who told me this I could kiss you right now because it literally saved my life.

I bought all the (insert noun) so you could ﬁnd out which are the best in each category and which is not worth your money.

Here’s how I get people the best (insert noun) on (insert noun).

Did you know that there are types of (insert noun).

Here’s how you can guess an almost perfect number every single time.

Here is how I make (insert noun) that lasts up to (insert time frame) and only costs (insert $).

I teach (insert noun) to people like they are in kindergarten, and it's time for class.

(insert noun) can be reversed so let’s talk about things you can do to improve your (insert noun).

This is how much (insert noun) you would lose at the end of the day with a (insert metric) (insert noun).

Did you know your (insert noun) are programmed to make your (insert result).

This might be the ultimate (insert person) hack.

To (insert verb) the (insert metric) in this (insert noun) the average would have to (insert action) for (insert time frame).

If you (insert verb) this (insert noun) this is the amount of (insert noun) your body would (insert result).

The worst (insert noun) that you will regret buying for your (insert noun) is right here.

(insert noun) how to (insert action) and still (insert dream result).

Use this, to pay for this.

I paid (insert $) to build this (insert noun) from scratch).

If I told you, you would (insert result) form (insert action) you would probably believe me right? Well here’s the thing…

How to budget with a (insert $) salary using this special (insert name) technique.

I spent (insert $) on new (insert noun) for my (insert noun).

Here’s a quick what to (insert result) (insert metric) of you (insert noun) legally.

(insert adjective) won’t get this but hopefully you will.

This is the exact order in which you should be (insert verb) for all of your (insert noun).

Why is it we are all so stressed about (insert noun) but we also all have a (insert noun) in (insert location).

Today my kids (insert noun) is due. So let’s (insert action).

There are things I like to do when I buy a new (insert noun).

Here are of things you have been putting off around the house that you can get done in minutes.

Show me the method of the best way to (insert result).

things everyone needs to know how to ﬁx in an (insert location).

Why does nobody talk about the cost of (insert action).

Top ways not to (insert action) to the (insert person) you (insert noun).

Top deadliest (insert noun) that can kill (insert living thing) in one (insert verb).

So this is (insert weight) of (insert noun) if I (insert verb) that to a (insert noun) what is that equivalent to for humans.

What is this? This is your (insert description of visual) and this is this 1 reason that (insert noun) die.

The easiest way to keep you (insert noun) (insert adjective) is to pretend…

If you're wanting to transfer your (insert noun) from this into (insert noun).

Let’s see how many (insert noun) we can get out of this.

This was the most popular (insert noun) in all of (insert year).

Did you know that you could (insert verb) a year's worth of (insert noun) in (insert time frame).

That is crazy.

Give me 60 seconds to show you how to (insert action) for the ﬁrst time after (insert life event).

Want a (insert noun) that (insert dream result) even when you (insert action).

Mom/Dad of of kids, here is how I treat being a mom/dad as a job.

minutes ago (insert pain point) and had (insert pain point) if you want to (insert dream result), here is how you do it under minutes.

If you have a (insert noun) in your house and a (insert noun) I am going to show you guys the of the best things we did to (insert dream outcome).

If I could suggest any tip to any (insert person) out these it would be this.

If you want to do this in (insert year). If you want (insert dream result) you have 3 main options to make it happen. I am going to go over them right now.

Your (insert noun) is to (insert adjective) and (insert adjective). Here are of (insert noun) to (insert result).

If you (insert verb) and (insert action) and it doesn't (insert result) it’s time to (insert action).

I just made over of (insert noun) in under (insert time) and I will show you how I did it.

If you want to add (insert noun) to you (insert noun) in (insert year) and you don’t know what (insert noun) to get I got you.

If you storing your (insert noun) in (insert noun) stop what you're doing and watch this video.

We spent $ of (insert noun) for our family of , and this will last us (insert time frame).

People always ask me (insert name) (insert fact) (insert question) well, let’s ﬁnd out.

If you’re wondering why when you (insert action) and don’t (insert result). Then proceed to (insert action) and (insert result). It’s because you are not doing this.

Whatever you do, do not let you (insert person) (insert action).

I am sick of hearing this word (insert word).

It starts off like this…

After (insert time frame) of research here is why I choose (insert noun) and started (insert action).

Does your (insert person) (insert action) like this?

If you have a (insert person) at home, then (insert action) will dramatically change their (insert noun).

I built this (insert noun) for (insert $).

I bought this (insert noun) for (insert $) and let me show you what I did next.

In (insert year) the (insert company/person) introduced the (insert noun).

Here’s the only way I will ever (insert action).

So I spent (insert $) at (insert store) on my last trip.

I turned one (insert noun) into different (insert noun).

(insert company) did not sponsor me this year, so here is how to make their (insert noun) at home.

Want a (insert person) who (insert dream result) every time, even when you don’t (insert noun/action).

It’s (insert noun) season, so let’s make a (insert noun) for your (insert person).

Your favorite (insert noun) hacks from (insert year).

years as a (insert occupation) you guys still don’t believe me when I say these things.

It’s wild to think (insert type of stores) still sell (insert noun) for (insert result). But not everyone knows they actually (insert result).

I am not a DIY guy/girl but I am going to show you how I spent (insert $) to transform my (insert noun).

3 (insert noun) we do not recommend for the ﬁrst time (insert noun) owners/users.

How to stop (insert verb).

People keep asking me what to do with (insert noun).

Does (insert noun) really kill (insert live thing).

I am going to show you how to (insert verb) your (insert noun) so they don’t (insert pain point).

things you should never put in the (insert noun).

Almost everyone thinks they know how to (insert action).

Let’s start by mixing (insert noun) and (insert noun) and I am going to give it a good shake. What happens?

Apparently if you…

Let’s get this brand new (insert noun) (insert action) so we can put it to good use.

Throw out you (insert noun).

This one mistake can actually kill your (insert living thing).

This is kind of gross but I had to share.

(insert name), how do you (insert result)?

We are going to text (insert noun), today on how (insert adjective) is it.

All you need is a (insert amount) of (insert noun) and you can turn (insert amount) of (insert noun) into

(insert result).

Here are (insert noun) that you should never (insert action).

If I can’t do it in one step, I am not doing it. This is the 1 most efﬁcient way to (insert verb) (insert noun).

When (insert occurrence) you will probably need a better (insert noun) than this.

I found out why (insert noun) wasn’t (insert result). So I am going to tell you what you’re doing wrong.

This is the ultimate master trick to (insert result) in just minutes.

Did you know you only need of ingredients to make (insert noun).

I am willing to bet, this (insert noun) is older than you.

Did you know our chicken is dunked in chlorine?

The viral (insert noun) hack that landed me in (insert news/magazine outlet).

I am a generation (insert title) and I hope this shows you why you should (insert action) when (insert task).

Here are the (insert noun) items you need to throw in the garbage right now.

We’re going to see if it’s true, that (insert noun) are so ﬁlled with toxins that they don’t burn when you hit them with a blow torch.

Believe it or not, this simple device can prevent (insert pain point), (insert pain point), and (insert pain point).

Here’s why I never use a (insert noun).

Did you know you could take a (insert noun) like this, and quick (insert action).

Here are (insert noun) as a (insert title) I would never own.

Want to ﬁnd out what’s hiding inside one of these (insert noun) when they are not properly maintenanced?

What I eat in a day on the (insert noun) diet.

These are of (insert noun) I would not own as a (insert title).

You should be able to look at her/his (insert noun) and see if come up to her/his (insert noun) here.

If you see (insert symptom), (insert symptom) especially on a (insert type of noun) you better worry about what’s called (insert name).

If you have a (insert noun) and you see that the (insert noun) is (insert observation) that's a dead giveaway that they are (insert action).

(insert name), overused (insert noun)?

Here are human foods that can kill your (insert living thing).

Before you ever take you (insert living thing) on a (insert action) for the ﬁrst time you need to watch this.

Strange (insert noun) behaviors explained.

(insert name) what is your (insert title) trigger?

What’s the most overrated (insert noun)?

The top (insert noun) for (insert target audience).

Here are the (insert noun) that are the least likely to (insert result).

If you (insert action) for (insert timeframe) what would happen?

This (insert noun) has something in it called (insert name). (insert verb) enough of these and they will kill you.

Here are of things, every (insert person) should keep in their (insert noun).

Man this, (insert noun) in (insert location) is trash. Maybe I should just get this cheap (insert noun). Yeah I wouldn't do that if I were you.

This (insert noun) isn't bad for you. Yeah it has some (insert noun) but what does that even mean?

So most people don’t know that on a (insert noun) there is one (insert noun) every (insert noun) owner always (insert action).

0 calorie (insert noun) I am not joking these are literally 0 calories.

This guy bought a failing (insert type) company for (insert noun). Now it’s worth over (insert $).

Stop wearing (insert noun), it really is just like wearing (insert analogy to represent damage).

We all have that one (insert label) in our life.

But it’s just an (insert noun) and it’s (insert positive) how bad could it be? Well this (insert noun) has the same amount of (insert metric) as (insert noun).

What if I told you that you could eat this entire jar of (insert noun) for less calories than 2 servings of their (insert noun).

A calorie deﬁcit per day, for a month should be around (insert pounds/kilos) of weight loss.

Welcome back to “I can’t (insert dream result)” a series where I show you (insert routine/tutorial/steps to insert result) that take less than (insert time) to do/make.

What I am (insert verb) on my (insert goal) journey, (insert result) last month.

If your (insert current state) you can’t just (insert result) like everyone else.

After over a decade of (insert action) here is what I wish someone would have told me from the start.

To everyone just doing (insert ) (insert action). Stop that.

If you want to (insert dream result), (insert action) is the worst thing you can do.

This is (insert metric) the exact same amount of (insert noun) you build everyday. If you (insert action) hard (insert ) times per week.

You want you (insert noun) to look like these? So did this guy.

If I had 90 days to go from being (insert current state) to (insert dream result) here’s exactly how I would do it\!

You are (insert adjective) than you think.

You can put on/take off (insert metric) on your (insert mile/exercise/vertical/etc) in one workout with these simple tips.

If you have (insert symptom) you probably have (insert condition).

If you (insert action) but don't when to (insert action). You could be losing up to (insert metric) of you (insert dream result) without even realizing it.

If your (insert verb) (insert noun) and then (insert noun) and then (insert noun) that is literally the worst thing you could be doing.

The worst possible thing that can happen to a man/woman is developing (insert result).

I grew about (insert metric) in the past year at (insert age) by ﬁxing my (insert condition) and (insert condition).

Person 1: (insert large number) Person 2: What are you doing? Person 1: (insert action) I want to get a (insert dream result) before (insert time).

So you want to impress you (insert person) when you (insert action) this (insert upcoming time).

Person 1: What aren't my (insert noun) (insert adjective)? Person 2: It’s because your (insert common mistake)

If you want to be the (insert adjective) person in the room, it all starts when you (insert action).

If you have (insert pain point) but not much time to (insert action) and you want to (insert result) then save these (insert noun) and (insert noun) steps/routines/tips.

I’ve had a (insert drea result) since I was (insert age).

The reason I can (insert result) and be comfortable, not have any (insert pain point) is this right here.

I spent (insert ) whole years with (insert condition) so you don’t have too.

I have a (insert metric) (insert noun) because this is one of my workouts/routines/steps/tips/strategies/methods.

If you can’t (insert skill), then follow this one minute routine/progressional/tutorial and you will have (insert skill) by the end of this video.

If your (insert current state) then the easiest way to have (insert dream state) is to have (insert result).

What would happen to you (insert noun) if you only (insert action) for an entire week.

Taking a (insert noun) can increase your (insert result) but only with one strategy.

If you’re serious about getting (insert result) then this is the only video you will ever need so save it for later and watch till the end.

If I had to start over and (insert verb) my (insert noun) from scratch, these are the only (insert noun) I would do for someone that is new to (insert noun).

Let’s see what’s inside (insert noun).

This is the reason (insert noun) is the size they are.

Here is a tier list of the best (insert noun) sources based off of how good they are for you (insert noun).

I don’t really show the (insert noun) a lot of love because I don’t like (insert action) but today I am going to show you (insert action).

What if I told you to (insert verb) (insert noun) everyday?

What would happen if you (insert dangerous action).

F\*ck it, I am going to role of (insert noun) in 60 seconds.

This is what a full (insert time) (insert action) looks like at top (insert school) in (insert location).

What’s hommies, I am going to give you a cash course of what (insert noun) to ask for, based on what you want that (insert noun) to do for you.

If your between the heights (insert height) to (insert height).

This is a great trick.

(insert $) in (insert time) and people still think you need a 9-5.

They say you can’t (insert result) with (insert noun) but they're wrong.

Here are of pricing mistakes we made when starting our (insert business).

things I'd do if I were to re-start (insert industry/niche/occupation/hobby).

The (insert noun) of a (insert noun) will tell you a lot about the (insert noun).

Here are some space saving (insert noun) hacks that saved our small space.

Do you feel (insert pain point) by your (insert noun) consistent (insert pain point).

My friends and I turned this (insert adjective) (insert noun) into this (insert adjective) (insert noun) in just (insert time).

What happened to (insert adjective) (insert noun).

(insert noun) used to have (insert trait), now they don’t.

Here is a complete cost breakdown to build my (insert sqft) home.

It cost (insert $) to build my own (insert noun), acting as my own general contractor. Here is the complete coast breakdown.

I paid (insert $) to build my own dream home and pool as an (insert title). Here is the complete cost breakdown.

I’ve (insert verb) over (insert ) of (insert noun) here are things I would never do.

If you want to (insert verb) in an exceptional (insert noun) you have got to stop half-assing things.

It’s also super hard to get (insert result) especially with the (insert condition).

It has taken me years if (insert occupation/skill/hobby) to realize I have been (insert action) wrong this entire time.

Remember (insert method/strategy name) for you next (insert noun).

Remember (insert ) (insert noun) combo for you next (insert noun).

(insert industry/niche) tips for if you're broke.

What (insert noun) and (insert noun) do I really need?

Every time you (insert action) your passing you (insert adjective) (insert noun) just because you don’t know what they are.

Alright you little DIY freaks here's how to build the sauciest (insert noun) of all time.

Normally I would never say this but please stop (insert action) until you're ready to (insert action).

(insert noun) for all the (insert condition) guys/girls out there.

How to take better (insert noun).

This is every single (insert noun) in my collection.

Invest in (insert adjective) (insert noun).

For people who (insert action) and are also into (insert noun) what the hell are we doing.

Here's how to build a good (insert noun) rotation.

This guy has made (insert $) proﬁt in one day using the technique he is about to use.

This book will teach you more about the (insert niche/industry/topic) than all of these books here.

If you wear a (insert noun) or (insert noun) with (insert noun) and a different (insert trait) (insert noun) then you have (insert result).

Every (insert noun) explained in one sentence.

If you keep failing your (insert noun), just ﬁgure out where you're failing it.

How long does it take to complete the impossible mile.

(insert noun) is believed to be super bad for us. Causing (insert symptom), (insert symptom), (insert symptom), and even (insert symptom).

(insert noun) can make you go bald\!

I’ll tell you a story, We have (insert noun) that were invented to solve 3 different problems.

(insert industry) tier list for 2025\.

How to start your (insert noun) from scratch.

Exposing the only (insert noun) you will ever need.

How to dress like a (insert person).

Every (insert store type) has a million (insert noun) with different (insert noun). But some of them are more special than others.

This is exactly how you and your friends are going to get (insert result) before this (insert time).

If you’re afraid to (insert action), then (insert action).

If you want to start a (insert noun) in (insert year) here are some things you are going to need.

Putting you on brands you may have never heard of.

**COMPARISON**

This is an (insert noun), and this is an (insert noun).

This (insert noun) and this (insert noun) have the same amount of (insert noun).

A lot of people ask me what's better (insert option 1\) or (insert option 2\) for (insert dream result) I achieved (insert dream result) doing one of these and it's not even close.

For this (insert item) you could have all of these (insert item).

He/she always (insert action), and he/she does (insert action).

For this (insert noun), you could have all of (insert noun).

This (option 1\) has (insert noun) in it, and (option 2\) has (insert noun) in it.

This group didn't (insert action) and this group did.

For this (insert noun), you could have this whole (insert noun).

This is (insert metric) of (insert noun) for (insert price), and this is also (insert metric) of (insert noun) for (insert price).

How long would it take you to go from (insert before state) like this (with pain point) to (insert dream result) with (insert desire).

If you're between the ages \- and you want to become (insert dream result) and I mean really (insert dream result). Then you have to do these things.

This (insert noun) has (insert metric) and will get you (insert dream result), and this (insert noun) has (insert metric) and will get you (insert dream result).

One (insert noun), and of my (insert noun) have the same (insert metric).

This is a (insert noun) from (insert restaurant/store/place) for (insert metric), and this is the same (insert noun) from (insert restaurant/store/place) for (insert metric).

This is a (insert noun), this is also a (insert noun).

This is (insert noun) before you (insert action), this is (insert noun) after you (insert action).

These two groups (insert similar result) but this group (insert result).

The (insert noun) offers you a (option 1\) and a (option 2\) what do you choose?

(insert ) (insert noun) I would have this one if I was (insert verb), and I would have this one if I was (insert verb).

This is (insert noun) at (insert metric), and it's perfect for (insert verb). This is (insert noun) at (insert metric).

This is (insert metric) of (insert noun), this is also (insert metric).

(insert metric) and (insert metric) both sides are (insert adjective) and look the same. Let’s see why.

(insert result) (insert noun) vs. (insert result) (insert noun).

Both these (insert noun) are exactly the same. I have not changed a single (insert noun). But this one is (insert metic) and this one is (insert metric).

Would you feel more (insert trait) in this (insert noun) or this one?

Both groups gained the same amount of (insert noun). Expect this grouped (insert action) days a week, and this group (insert action) .

Cheap vs. Expensive (insert noun).

You will (insert result) a week if you (insert action) on a (insert journey). But you will only (insert result) this much a week if you (insert action) on a (insert journey).

This is what your (insert noun) looks like when you don’t take (insert noun). And this is what your (insert noun) looks like when you take (insert noun).

This is me after (insert action) in the (insert location) with (insert condition). And this is me just (insert action) in the middle of (insert location).

**MYTH BUSTING**

(insert item) (insert fact), (insert complete opposite item) (insert similar fact).

This is why doing (insert action) makes you (insert pain point).

This is how you (insert dream result) while (insert guilty pleasure).

(insert item) (insert fact), (insert item) (insert similar fact), (insert complete opposite item) (insert similar fact).

If you're really a (insert dream result), why aren’t you doing (insert common belief)?

Just because you do (insert action) doesn't make you a good (insert label).

This is what (insert number) of (insert item) looks like.

If you are (insert action) just once per (month/day/year) than you are f\*ucked.

This is me when I (insert action) (insert frequency), and this is me still (insert action) (insert frequency).

No your (insert noun) is not cause (insert result).

Let me de-inﬂuence you from (insert action).

More (insert target audience) need to hear this, (insert common belief) will not (insert result).

It's time to throw away your (insert item), you don’t need it anymore.

They said, “(insert famous cliché or quote)” That's a lie.

Don't (insert action) until you've done this one thing.

Stop using (insert item) for (insert result).

You cannot be (insert dream result) before you enter (insert age group).

I stopped acting like the (insert person/title) in my life and you shouldn't be the (insert person/title) either.

Your life is boring because you don’t (insert action).

This is (insert large number) worth of (insert noun).

Just because you have never (insert action) before, doesn't make you a (insert label) person.

This is how we think we (insert pain point), but you would have to (insert action) on top of (insert action) of times for that to happen.

(Insert noun) is actually a really good (Insert noun) for (insert result).

things I would never (insert action) in my (insert age range) if I wanted to (insert dream result) by (insert age range).

If you look in the mirror and notice (insert observation) here's what you do to (insert dream result).

I haven't done (insert common action) in over years, and it's healed (insert noun).

(insert dream outcome) that don't taste/look like pure bootyhole.

You are not (insert bad label), you are not (insert bad label), you just can't (insert adjective) .

My biggest regret in (insert life event) was (insert accomplishment).

(insert action) I have never (insert action) before, to prove (insert action) is easy.

For the price of this many (insert noun) at the (insert place/store/restaurant) you could make this many at home.

If you (insert action) this (insert noun) then yes i'm judging you.

You are (insert action) too many (insert noun) that you didn't know.

I have never met a single person that (insert action), (insert action), (insert action), (insert action), and still has time to (insert dream result).

(insert well known person or brand) is trying to get this video removed from the internet because he/she exposes their product for being (insert negative result). Watch this now before it's gone.

What if I told you making your own (insert noun) is actually super easy and only costs (insert price).

I said it before and I am going to say it again (insert mind blowing fact).

There is absolutely no reason for you to be (insert pain point) every single day just because you are trying to (insert dream result).

Don’t make the mistake of (insert action), (insert action), (insert action).

You are not bad at (insert action), you probably were just never taught how to (insert action).

If you’re a young (insert person) and you are a (insert result) (insert title), let me tell you something you got a bright future buddy.

I can’t (insert verb) (insert noun) anymore.

Believe it or not this (insert noun) was not (insert verb) with a (insert noun).

(insert noun) are not (insert adjective) and they are not a cop-out. I think they can actually be made into something really really (insert adjective).

If your (insert noun) are not lasting you at least (insert time frame) you are probably doing them wrong.

This is why you should always (insert verb) your (insert noun) before (insert verb).

You're using your (insert noun) wrong and I am going to show you how to use it the right way.

Everyone on the internet is going to tell you making (insert noun) is impossible. But I am going to show you how to make them from home.

I will let you in on a secret (insert verb) is the easiest thing in the world.

Are you still (insert verb) (insert noun) like this? While I worked at (insert noun) and let me show you how to do it like a pro.

Instead of (insert verb) (insert noun) like this, try this method instead.

(insert verb) does not mean your (insert adjective), it means your just (insert adjective).

If you (insert action) like this, then you're doing it wrong.

I am going to hold you hand while I tell you this. If you only have of (insert noun) you are not doing it the right way.

things you should never put in your (insert noun).

(insert noun) are not as disgusting as you think.

(insert noun) is better for (insert result) than (insert noun). And yes I am going to back up my claim with studies.

Being (insert result) is not just based on (insert noun). You may not believe this but I could have been (insert adjective) then this guy/girl if I had just changed a few things.

I started my (insert business) when I was (insert age) with (insert $).

X years ago my (insert person) told me (insert quote).

I have (insert time) to get my sh\*t together.

I don’t have a backup plan so this kind of needs to work.

This is how my (insert event/item/result) changed my life.

So about a month ago my (insert person) and I did (insert action).

I have (insert action) over (insert ) in my life.

This is a picture of my (insert what picture is).

X years ago I decided to (insert decision).

Yesterday I was at (insert location) when I noticed something (insert adjective).

X years ago I was (insert action) because I (insert pain point).

Is it possible to (insert action) while (insert action) in X days.

When is it time to do (insert action).

So I did (insert action) last week.

When I was (insert description) I was always (insert bad habit).

If you are anything like me, you take your (insert event/item) very seriously.

In (insert time), I went from (insert before state) to (insert after state).

X years ago we (insert action) to (insert result).

Hi I am (insert ﬁrst name) and I am starting (insert business) from scratch.

This is the story of how I managed to do (insert achievement).

I am (insert age) having an identity crisis.

( days/months/years) ago I quit (insert thing).

This is probably the scariest thing I have ever done.

This girl/boy was in her/his ﬂop era.

Is it possible for (insert description) to make (insert $) a month?

I did everything right.

So I recently started feeling "the pressure" everyone talks about.

Can you (insert dream result) after (insert shortcut).

After X years of I (insert action) because I realized one thing: (insert statement).

It all started when (insert person) (insert action).

X years ago (insert people) (insert action).

I'm (insert action) in (insert time) and I just (insert action).

1 Year Ago today, I .

I'm (insert age) and I'm not ashamed to admit that \>\>

When I (insert action), people said (insert feedback).

X days/weeks/months/years into my (insert action), my worst nightmare became my reality.

It all started when this boy/girl, (insert action).

X days/weeks/months ago my (insert person) and I (insert action), (insert action), and (insert action) this is how it's going.

I started my (insert business) when I was (insert age) with (insert $)

X days/months/years ago my (insert person) told me (insert statement)

When I (insert action), people said (insert feedback)

I woke up this morning thinking about (insert thought)

X days/months/years I (insert life event) and decided to quit (insert bad habit)

X days/months/years I started (insert action) again after being stuck at (insert pain point)

X days/months/years I started (insert action) thinking it would magically solve (insert pain point) but here is what ended up happening

I am an X year old (insert occupation) from (insert location) and I just (insert action)

I don’t have a backup plan so this kind of needs to work…

This is how my X changed my life

I have (insert action) over (insert ) in my life

This is a picture of my (insert what picture is of)

X days/months/years ago I decided to (insert decision)

Yesterday I was at (insert location) when I noticed something (insert adjective)

X days/months/years ago I was (insert action) because I (insert pain point)

Is it possible to (insert dream result) while (insert action) in X days

When is it time to do (insert action)

So I did (insert action) last week

When I was (insert description) I was always (insert bad habit)

If you are anything like me, you take your (insert action) very seriously

In (insert time frame), I went from (insert before) to (insert dream result)

X days/months/years I (insert big risk)

I am starting/started a (insert business) from scratch

This is the story of how I managed to do (insert achievement)

I am (insert age) having an identity crisis

X days/months/years ago I quit (insert habit)

X days/months/years ago I stopped (insert action/or habit) and started (insert action/or habit)

This is probably the scariest thing I have ever done

This girl/boy was in her/his ﬂop era

Is it possible for (insert avatar) to (insert dream result)?

I did everything right/wrong

So I recently started feeling (insert feeling) everyone talks about

Can you (insert dream result) after (insert shortcut)

After X years of (insert action/or habit) I stopped/started (insert action/or habit)

It all started when (insert person) (insert action)

X days/months/years ago (insert people) (insert action)

X days/months/years, I

I'm (insert age) and I'm not ashamed to admit that

The secret is out I am (insert action)

I got (insert dream result) without (pain point/points) here’s how

So I (insert shocking action) for over (insert time frame)

So I messed up

I developed an X addiction so strong I physically can not stop (insert action)

X years it took me from (insert bad situation/result) to (insert good situation/result)

X Months/Years ago I (insert action) to (insert action)

I (insert action)

There is nothing more embarrassing than X

I am a (insert title) by day and a (insert title) by night

Come with me to make (insert object)

Come with me to break up with (insert object/company/etc)

I started (insert business) at (age/life event) and I had no idea I would (insert result/outcome)

You know the feminine urge to open (insert business)

It’s been (insert time) since we (insert experience)

I think (insert belief/opinion) so I have been taking matters into my own hands

I was shocked when I found out (insert fact)

So I just turned (insert age)

This is how I got to (insert cool opportunity) in my X week/month/year of doing/starting (insert business or job)

What happens when you (insert action) then you end up (insert result) but you (insert challenge)

What if I told you that (insert dream result) without (insert pain point)

I went on of (insert noun) this year, and here is the one trait I learned that you need to have to (insert dream result).

X days/months/years ago I was (insert action), every waking hour because I was (insert trait) and I wanted (insert result).

X days/months/years ago I was (insert life event), because I was (insert action) instead of (insert action).

This is (insert person) we have known each other from X years, X days, X hours, X minutes.

Put a ﬁnger down if you told the entire internet you were going to create a (insert noun) without having any idea how to (insert action) or any idea how to start?

I think (insert noun) should be better than this, so i;ve been taking matters into my own hands.

This is me (insert life state), yes my (insert observation) all my (insert persons) were (insert action) but I couldn't because I had to (insert scenario)

I used to be in a super toxic relationship back in (insert time frame) so let me tell you about it.

How I married my middle school/highschool/college girlfriend/boyfriend.

(insert person) always expects you to have (insert result) but the problem is….

My (insert label) (insert name) and I, started (insert business) in (insert year).

X days/months/years ago my (insert label) (insert name) and I (insert action) to (insert result).

You are not (insert label) is something I wish I could have told my younger self.

Is it possible to get (insert dream result) with only (insert action) for only 1 day.

I have no idea what I am doing at (insert place).

I got (insert result) at (insert age) and (insert result) by (insert age) if you are scared about (insert result) this is for you.

Is it possible to (insert action) successful (insert noun) for (insert noun) in just 1 hour?

(insert year) \- I think I am going to (insert goal).

So I bought this (insert noun) last week and quickly realized I have no idea how to (insert action).

X days/months/years ago I bought a (insert noun) as a (insert age) with a full-time (insert job).

We (insert action) over of the most (insert adjective) (insert profession) and responded.

I hate to say this but my wake up call wasn't as (insert scenario) no my ﬁrst wake up call was (insert scenario).

Is it possible to get (insert dream result) without your daddy being the CEO of apple.

If you're new to this channel let me catch you up.

The worst part about being a (insert title) is I literally do not…

Living in a (insert adjective) household has led me to literally having (insert bad result).

Nothing could have prepared me for how it feels being in your (insert age group) and (insert situation).

So apparently your frontal lobe does not develop fully until your age 25, so here are some things I have realized since it came in.

I tried a hour (insert noun) routine, which is much harder than you think.

You think you're a (insert label)? Well let me introduce you to my life.

My (insert person) and I tried a whole (insert time frame) without (insert action).

(insert quote) the ﬁrst time I heard this I was (insert action), and my (insert person) just dropped that line out of nowhere.

Build a (insert noun) with me while I (insert action).

I have had 0 (insert noun) in (insert time frame).

It was until I build of (insert noun) and completed over of (insert noun) that I realized (insert action) is not really that complicated.

X days/months/years ago me and my (insert person) bought (insert noun) for (insert price).

I am (insert life event) in (insert time frame) and I just wrote a letter that I wish my (insert age) self would have read.

I am leaving my (insert salary) dream job at (insert company) to (insert action).

This is day of making fake (insert noun) for our dream clients until one of them starts working with us.

X days/months/years ago I went extremely viral for (insert action).

Have you ever wondered why (insert noun) (insert adjective) is much better than (insert noun).

For those of you who don't know I have been bootstrapping a (insert business type) to see how big I can scale it.

When I told my (insert person) I was going to start doing this he/she thought it was the worst idea ever.

These are dumb things I have done in (insert stage) of (insert action) for my (insert noun).

This (insert noun) single handedly changed my career.

Have you ever tried to (insert action) something that was supposed to look like this but ended up looking like this.

Hi my name is (insert name) and this was me (insert time frame) ago a (insert label) in (insert noun).

Day of (insert action) until I (insert dream result).

I just (insert action) to make (insert noun).

I (insert action) to every (insert person) in the world. Here is how many people responded.

What happens when you (insert action), (insert action), (insert action), etc.

Ever since I was (insert adjective) my (insert person) made it very clear to me that he/she was (insert adjective) about certain aspects of (insert noun).

One day you're gonna get dumped. Not by your girlfriend, not by your boyfriend, not by your ﬁance, not by your spouse. But by your (insert noun).

I am (insert name) (insert age) you might know me from my (insert accomplishment), (insert accomplishment), or (insert accomplishment).

I was today years old when I found out that if you have (insert trait), (insert noun) will look really (insert adjective) on you.

People are shocked to hear that these are my natural (insert noun).

Have you ever noticed that some (insert noun) feel (insert description) while others feel (insert description).

This video got of views, with a lot of (insert adjective) feedback. Let's try it out and see if it makes a difference to my (insert noun).

If you've ever come across one of my reels and thought (insert adjective) that woman/man has (insert adjective) (insert noun). But here's a little secret: my (insert noun) was not always like this.

Welcome back to my (insert noun) series where I will be teaching you everything I know, no gatekeeping here.

After (insert time period) of having (insert bad result) come get my (insert noun) done with me.

Hi I am (insert name) and I am a (insert negative label).

Here is how I lost a (insert time frame) of my life.

I feel really bad for saying this but sometimes you just need to (insert harsh truth).

As you may know I have been (insert action) to (insert dream result).

I (insert action) almost everyday for a week and here is what happened.

(insert action) everyday has literally changed my life. In particular helping me (insert dream result).

I had this weird idea that if I added some (insert action), (insert action), (insert action), etc…

Did you know that if you combined (insert noun), (insert noun), (insert noun), etc…

When you're sad but then you remember you have (insert noun).

I spent (insert price) on a (insert noun) here's all the (insert noun) I got.

You know those days where it feels like (insert scenario) well today was that day for me.

I have (inset amount of thing), (insert amount of time), and a pipe dream to get ready for (insert event).

So I was just (insert action) to do my (insert action) of the day when I saw that…

Welcome back to another episode of (insert series name) where I (insert action).

We are not even (insert time frame) into (insert year) and have gone from being a (insert before state) to (insert after state).

I (insert action) but I don't have (insert noun).

I worked (insert hours) in just (insert days) making all of this (insert noun) for my (insert noun).

If you told (insert age) me that I wouldn't be a (insert title) I would probably tell you to go screw yourself.

I (insert action) all of the (insert noun) you want with all the (insert adjective) that you need.

Someone just (insert negative result) my business.

Can you please pack my (insert price) (insert noun) with me? Of course\!

The ultimate assembly video of my (insert huge metric) (insert noun).

I am on a journey to ﬁnd the best (insert noun) for (insert target audience) and today we went to (insert location).

Here's how I made a wireless (insert noun) that is valued at (insert price).

We pretty much (insert action) our entire (insert noun) into (insert noun).

X days/weeks/months/years ago I purchased (insert price) (insert noun) as a (insert label) with only a (insert price) deposit.

For our entire year relationship my (insert person) has been hiding something pretty important from me.

I always had the biggest dream of (insert dream).

(Insert noun) is cringe right now but let me tell you what a game changer it was for me.

Hey everyone I am (insert name) I am (insert age) and I am starting a (insert business) from scratch.

I didn't realize how bad I lost myself.

I just left my (insert salary) a year new grad job, and now I am just a disappointment.

Me and my (insert person) are supposed to be (insert action), but instead we (insert action).

(insert year) (insert occurrence).

I think I got (insert verb).

My (insert person) wanted a (insert noun) for (insert event) so I said thanks for the suggestion but that’s not my vibe and made them (insert noun) instead.

I’ve (insert verb) this almost every single day of my entire life.

Buying things I don’t need because I have adult money.

A fun fact about my (insert person) (insert name) is.

My entire life I grew up (insert adjective) and (insert adjective) it was just my (insert person) raising the of

I spent an entire (insert time) (insert verb) but was it a waste of time?

I am about to go on the biggest bender of my entire life\!

I think I am getting (insert verb) today.

Welcome back to me (insert verb) my (insert person) (insert noun).

I always wondered what it was like to (insert action).

So (insert time frame) ago me and my (insert person) had a little too much fun.

Selling (insert noun) at (insert location) has made me more money than my (insert person/title) and today I am going to be investing that money into (insert noun).

Welcome back to day , where I (insert verb) a (insert noun) everyday until I am (insert adjective)

(Insert person), (Insert person), or that one (Insert person) we just don’t have (insert title) like we did back then.

Day of trying to (insert action) all year.

This was the (insert noun) that changed my life forever.

Over of you saw this video.

Today I woke up and realized (insert realization).

I am (insert verb) a (insert noun), on my (insert noun).

Remember that time you were (insert adjective) so you (insert action) but the moment (insert person) (insert verb) you (insert action).

Okay real talk, I wasn't always this (insert adjective).

Is it possible to stop (insert pain point) and (insert dream result) in (insert time frame) even if you’re in

(insert noun) and all of your (insert person) think getting (insert verb) is (insert trait).

(insert question) I hate this question.

Last year I (insert verb) (insert noun) for (insert $).

Let’s make (insert ) (insert noun).

I had just (insert time) to (insert verb) (insert ) of (insert noun) for a (insert person). And you have until the end of the video to guess who they are for.

I only have (insert time) to ﬁnish over (insert number) of (insert noun) orders, including (insert number) of (insert noun), (insert number) of (insert noun), (insert number) of (insert noun), and (insert noun).

I (insert verb) (insert number) (insert noun) and I had to throw (insert number) of them away.

Have you ever seen (insert ) (insert noun) in one place?

I have a confession. I have no problem (insert verb) for my (insert noun) but it’s the process of actually (insert noun) that feels so (insert adjective).

I am (insert age) and I have an identity crisis.

I have been a (insert title) for years of my life I started when I was years old working at (insert location/place) in (insert location).

When I was growing up one (insert noun) I always (insert verb) with my (insert person) was (insert noun).

Once upon a time we bought a (insert noun) on (insert noun)

If I want my (insert person) to be (insert dream result one day) that means I got to (insert action) now.

Hi I am (insert name) and I have been secretly (insert action) for years.

Can you name something more terrifying than a (insert person) with a (insert noun).

months/years ago my friends and I started a (insert business). And it turned out to be the biggest (insert result).

This is the ultimate assembly video of my (insert noun).

So (insert time) ago my (insert person) and I bought a (insert noun).

I am on a journey to ﬁnd the best (insert noun) for (insert person) and today we (insert action).

This week I tried to see if I could (insert result) for all of my (insert noun) just by (insert action) the night before.

In (insert year) I started (insert action) and I gave my life to (insert person).

I lied to the (insert person) who (insert action).

Something I never thought I would have on my bingo card as a (insert title) was…

I had to spend (insert &) on this free (insert noun) before it even started.

I just left my 9-5 corporate job to start my (insert business.

I feel like years ago I had my life together as a (insert title) but just slowly over time things have shifted.

(insert year) I met my (insert person) when working at (insert job).

My house has this weird (insert trait) and it’s haunted me ever since I ﬁrst toured.

My (insert person) and I moved in together and ended up losing (insert $).

X years ago we decided we wanted to know exactly where our (insert noun) was coming from.

I made (insert $) doing (insert side hustle) as a side hustle.

I have no intention of…

Growing up my parents used to get upset when I (insert action), (insert action), or (insert action) they would get frustrated.

Hi my name is (insert name) and this is my home.

This is how much (insert adjective) (insert noun) cost me in (insert location) and a (insert age) (insert occupation).

Nearly years/months ago today I packed my bags and left for (insert location), thinking I would only be gone for (insert time).

I am attempting to be the ﬁrst person to (insert goal), day .

When we ﬁrst moved to the (insert location), my (insert person) bought a (insert noun) in (insert location).

My (insert person) told me he/she wanted a (insert noun) and instead of waiting around I decided to build it right now.

My parents had sons/daughters/kids thiers me, my (insert person), and (insert person).

(insert time) I bought a (insert adjective) (insert noun) because it’s cheaper than a (insert adjective) (insert noun).

Did you know that if you wake up at (insert time), and (insert action)...

I already know I am going to get a bunch of hate for this but the (insert noun) is getting taken out today.

People know me for nearly losing (insert noun) and dying in (insert location).

I am going to do it, i’m going to ﬂip this… house.

Dude, it’s day . And I almost went (insert result).

My (insert person) lives (insert exact number of miles) away from my house.

Why am I (insert action) at months pregnant?

Last year for (insert holiday) we (insert action).

We spent all day (insert action), burning through (insert metric) of (insert noun), and now I am having a fully blown (insert noun) choice crisis.

Day of my (insert persons) room makeover. Which I kind of took to the extreme but let’s start from the beginning.

Every year we make the questionable decision of (insert decision).

This is what I (insert action) in a day as someone who is trying to (insert action) less and (insert action) more.

I have been (insert title) for (insert time) now, and I have gained (insert ) of followers just by sharing (insert content type).

My (insert person) hasn't (insert action) in over years.

years ago my (insert person) and I started (insert action).

I have a problem. Which is that my (insert noun) it (insert pain point) and (insert pain point). So i’m going to build my own (insert noun) that has (insert beneﬁt).

This week in fatherhood/motherhood I am please to report that I (insert result).

Some say the strongest bond is between (insert person) and his/her (insert person).

Hi i’m (insert name) and I am a (insert title), this is my (insert person) and he/she loves (insert noun).

What is this massive stack of (insert noun) that I am holding in my hand, well it is the (insert noun) for the (insert number) of (insert noun) I have done this year.

I (insert traumatic event) at (insert age) but it’s what happened after that, that actually changed my life.

I was walking past this (insert store) when I say they had (insert noun).

Fourtnely my (insert person) and I have a tendency to be a little bit impulsive.

Yesterday I (insert action) in (insert hours) and (insert minutes).

Would you buy a house with no (insert noun), well my (insert person) did\!

How long does it take to catch (insert high number) of (insert noun)?

We got an insane deal on our (insert noun) a year ago because it needed to be (insert action).

There is a man/woman that comments on every single video I upload.

Buying (insert noun) that need a lot of work, can work out in your favor.

In days I am selling my (insert noun) and moving out of the country.

I think of my (insert noun) as my own personal (insert noun).

It’s been (insert time) since I bought my dream (insert noun), and I want to take you through what the last (insert time) has been like.

(insert $) home (insert bad result) in just time/months.

Come with me to (insert action) the (insert title) didn't (insert action).

I am revmong all my (insert noun) friendly upgrades before we (insert action). Today we are removing (insert noun).

Let’s try to unclog a (insert noun).

This is what my morning looks like while (insert situation).

Last night at around (insert time) (insert person) began textbook stage one (insert scenario).

After many years of total neglect my basement is ﬁnally getting much needed TLC.

How (insert action) ended with a (insert person) at my house telling me how lucky we are that (insert accident) didn't happen.

Customer called me up because they had (insert situation) and wanted it (insert result) immediately.

While my kids were taking a nap I went to (insert action) when I realized (insert realization).

My one goal this year was to showcase just how interesting (insert noun) is.

I don’t usually cry, but yesterday I did. And it wasn’t because of (insert reason).

You know when I started making (insert noun) I should have known this day would come.

I got a (insert noun) and it did not turn out to be what I expected.

About a (insert time) ago I got in trouble for having too many (insert nouns).

I baited this (insert google rating) (insert title) with this (insert noun) in excellent condition to see if they would rip me off.

I took my (insert person) to (insert location) to try this (insert noun) and it actually caught something.

I opened up a (insert business/store) in the middle of (insert location) and I can’t believe how much money I made.

I took a (insert hour) and (insert minute) (insert noun) to (insert location) and here’s how it went.

(insert verb) (insert noun), (insert action), and don’t

(insert result). Welcome to (insert event).

This is life as a (insert noun) addict part (insert ).

Welcome back to the journey of how I got (insert result).

Come take a (insert noun) with me that I did not (insert action) for at all.

It’s been (insert time) since I have seen myself with (insert feature) and that’s all about to change.

This was me when I was (insert pain point), (insert pain point), and (insert pain point).

From being (insert state), to (insert state), back to (insert state), to (insert state), to now being (insert current state) in (insert time) I have built tons of knowledge when it comes to (insert result).

I have (insert event) in (insert time) and I have not started (insert action). And if I don’t do well I have to (insert consequence).

Today I am eating like (insert person) for the full day and I am going to see how much weight I gain by the end of the day.

(insert time ago) my (insert person) (insert action) when my (insert person) passed away.

(insert time) I started accepting the choice to (insert drastic change).

2 years, no (insert noun), and today’s the ﬁrst time I get to use (insert noun).

Does this stuff actually work?

I gained (insert pounds/kilos) during (insert life event).

I am letting (insert business type) companies, control my (insert noun).

So I am (insert age) and I work nights at (insert store) that’s the dream life right?

So it’s been a week and I am already on (insert number) of followers.

So when I was (insert age) I started taking (insert noun) and at (insert age) I had to (insert action).

I used to always be the guy that had a (insert condition), (insert condition), and always struggled with (insert condition).

My (insert person) takes me to the doctor, because I am (insert age) and already (insert action).

It has come to my attention that some of you guys think I am actually (insert result) when I do (insert content type).

A little over (insert time) ago I posted a video about the beneﬁts of (insert action).

I did (insert action) everyday for one year, and here’s what's different.

I can conﬁdently say the only reason I can (insert verb) (insert metric) is simply because of the way I choose to (insert verb).

days ago I quit (insert noun) as a (insert age) (insert title), and started (insert noun) for literally one reason.

A competitor showed up at my job trying to get me ﬁred.

I damaged a customer's property and here’s how I handled it.

A customer (insert result) and tried to avoid paying.

I was harassed by (insert noun) so I had to do this.

Alright this is ofﬁcially day 1, trying to make (insert $) a month with (insert business).

I am a retired (insert title) who now owns a (insert business). So come with me to collect the quarters.

Did you know you can start your own (insert business ) from home without (insert pain point), (insert pain point), and (insert pain point).

I would like to welcome you to my (insert location).

Let me show yall how to make (insert $) per day, but installing a simple (insert noun).

Have you ever thought about starting your own (insert business)?

Day of trying a new hobby to recover from burnout.

My (insert noun) made me (insert $) last month, and what's crazy about this is I used no money to start this business.

Make (insert noun) and (insert noun) with me from my online (insert business) and a (insert label).

Hi i'm (insert name) a (insert ) generation (insert title) who shares tips about (insert niche) and (insert result).

Starting a (insert business) at (insert age).

Welcome to day of starting my life over at (insert age).

I have something to address, over the last week I have gained (insert ) of followers.

This is how I ended up taking the biggest risk of my life.

In 1 year I (insert verb) over (insert pounds) of (insert noun) in my extremely small (insert location).

I f\*cked up. I bought literally a (insert metric) of (insert noun). And for the last (insert time) I have been turning them into (insert results).

I ﬁnally built it. For the last years I've been turning (insert noun) into (insert noun).

Is it possible to go from (insert before state) to (insert after state) just by (insert action).

We are now at day , since starting my (insert project).

Proof that a (insert noun) can totally transform a space.

Alright today we are building this (insert $) (insert adjective) (insert noun).

Here is how we transformed my (insert persons) (insert location) from this to this using (insert noun).

There;s probably a reason why most people don't (insert action).

I bought this (insert noun) for (insert $). And today my (insert person) and I will ﬁnd out if it (insert result).

I can't stand this (insert noun), let's transform it.

Over the past days I (insert action) on of (insert nouns). In doing that I have gained over (insert ) of followers. So here's the thing.

Over the last (insert time) I have been ﬁnding a lot of cool things over (insert location). And today I am ﬁnally ﬁnishing my (insert project).

Do you ever (insert situation), yeah well that's my job.

I bought this (insert noun) for (insert $), and I am going to make it worth over (insert $) without changing the product in any way.

This might be the coolest DIY I have ever made.

Some people call it a problem but I call it (insert noun) genius.

With the (insert life event) coming, it’s time to (insert action).

**RANDOM**

This is (insert large number) of (insert item).

This is my (insert item) and this is (insert random action) if I were (insert random action).

You're losing your boyfriend/girlfriend this week to (insert event/hobby).

What (insert title) says vs what they mean.

(insert trend) is the most disgusting trend on social media.

I do not believe in (insert common belief), I believe in (insert your belief).

If you like these (insert job title), you'll probably like my (insert work).

(insert big brand) didn't want to sponsor this video, let me show you what they're missing out on.

I am trying a different (insert noun) for each letter of the alphabet.

My (insert person) has never been in the (insert place) before let's see if she can tell who is (insert adjective) or not.

If I get this in, then I have to (insert verb).

**AUTHORITY**

My (insert before state) used to look like this and now they look like this.

10 YEARS it took me from (insert before state) to (insert after state).

How to turn this into this in X simple steps.

(insert big result) from (insert item/thing). Here's how you can do it in X steps.

Over the past (insert time) I've grown my (insert thing) from (insert before) to (insert after).

Just (insert item/action) took my client from (insert before) to (insert after).

My customer/client got (insert dream result) without (insert pain point).

If I were to create a collab campaign for (insert big brands) here's how I would do it.

How I got my (insert item/thing) from this to this.

I became a (insert achievement) at (insert age) and if I could give you X pieces of advice it would be…

Everyone is complimenting on my (insert noun) because of one (insert noun) routine that I do.

I lost over (insert metric) in (insert time frame) and here are the of things I would do if I was to start all over.

My customer/client got (insert dream result) with out (insert pain point) and here's how.

I am in a (insert noun) and these habits dramatically transformed my (insert noun).

I got (insert dream result) on all of my (insert noun) with minimal (insert action) and here's how.

If I were to create a (insert noun) today this is how I would do it.

If I ever made it to the news I thought it would at least be for something illegal, turns out it's for (insert dream result).

(insert well known brand) commented that I am their new favorite (insert title).

What I (insert action) in a day as someone who has achieved (insert dream result).

I literally used to have a (insert before state).

My (insert noun) went from this to this in the last (insert time frame) and this is what I done.

I have been pretty much doing the same (insert noun) for the past (insert time frame) and they have legit (insert dream result).

When I was (insert before state) I was constantly (insert pain point).

In (insert year) my business made (insert dollar amount).

As a (insert title) for several years whose (insert action) I often get asked (insert name) (insert question).

I have never ended (insert noun) with a (insert result) or below.

He/she (insert action) for one day and got (insert dream result).

I jumped my (insert noun) from (insert before state) to (insert dream result).

This used to be my (insert noun) this is my (insert noun) now.

I have been able to go from this, to this.

Things I wish I knew before my (insert noun) that took me from this to this.

The (insert noun) I (insert action) everyday that took me from this, to this.

I went from this to this.

No because my transformation from (insert age) to (insert age) ought to be studied.

After (insert dream result) here is one thing I learned the hard way so you don't have to.

Okay bish you don't need to (insert action) to (insert dream result) coming from someone who (insert dream result).

I (insert dream result) in the past (insert time frame), here's proof.

Here's how my student/client/customer went from (insert before result) to (insert after result) and (insert symptom due to result).

% of the time when I am in (insert situation) I get (insert result), and today I will be showing you my (insert noun) routine so I can help you achieve (insert dream result).

I (insert verb) for (insert time frame) and I got a (insert dream result).

This is how I got my (insert noun) from this to this completely natural.

Nobody believes me if I say I went from this to this.

These are the products I use to keep (insert noun) (insert noun) and (insert adjective) as a (insert title).

Same recipe but different (insert noun). For this (insert noun) I used my tips to make (insert dream result) at home and you can really tell it makes a big difference.

(insert noun) is my second (insert noun) and here are the (insert noun) I did over, and over, and over again to improve my (insert noun).

How I took this (insert title) from 0 to (insert ) of (insert noun) in 1 week.

I am only (insert metric) but I have became one of the best (insert title) in the world.

We all have the same 24 hours in a day so here I am putting my 24 hours to work.

Day 1 of starting over my whole entire life.

So okay being an (insert target audience), my days vary quite a lot from one another.

Day in the life of a (insert adjective) person.

Welcome back to the day in the life of two (insert label) trying to build the next (insert business).

(insert noun) day (insert event about that day).

I am a year old (insert title), and I am heading to (insert event/location).

This is a day in the life of a (insert title) (insert noun) edition.

Come to work with me as a (insert title).

(insert school) day , my last (insert noun).

Day of turning from (insert before state) to (insert after state) and suddenly I don't want to be (insert after state) anymore.

Come with me to earn $ per day, with (insert avenue).

Day trying to make (insert $) by the end of the year, by (insert method).

Day in the life of a future millionaire.

Day in the life as a (insert title) (insert noun) edition.

This is what an average day of a (insert title) looks like a week out from (insert event).