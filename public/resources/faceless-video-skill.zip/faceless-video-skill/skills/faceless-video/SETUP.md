# Setup — faceless-video skill

This skill is a four-stage pipeline for documentary-narrator "video essays" (the Zenn /
RealLifeLore / Johnny Harris style). It runs inside **Claude Code** as a user-invocable
skill, and leans on a few local tools and one image-generation backend. Here's everything
you need to run it on a fresh machine.

---

## 1. What each stage needs

| Stage | What it does | Hard requirements |
|---|---|---|
| **1 — Write the script** | Research real facts + write the voiceover script | Claude Code with web search (`WebSearch`/`WebFetch`, or a search MCP like Firecrawl). No local install. |
| **2 — Transcribe** | Local Whisper → timestamped transcript + SRT/VTT | Python 3.9+, `openai-whisper`, `ffmpeg` |
| **3 — Generate images** | One illustrative image per timestamp | An image-generation backend (default: Higgsfield MCP). See §4. |
| **4 — Stitch the video** | FFmpeg-assembles images + VO into an MP4 | `ffmpeg` + `ffprobe` |

You can run Stage 1 and 2 with zero paid services. Stage 3 is the only part that needs an
image model.

---

## 2. Install the skill into Claude Code

Skills live in a `skills/` folder Claude Code reads. Copy the `faceless-video` folder there:

```bash
# user-level (available in every project):
mkdir -p ~/.claude/skills
cp -R skills/faceless-video ~/.claude/skills/

# OR project-level (just this repo):
mkdir -p .claude/skills
cp -R skills/faceless-video .claude/skills/
```

Restart Claude Code (or start a new session). You should now be able to type
`/faceless-video` or just ask it to "write me a faceless video script about X".

> The `name:` in `SKILL.md` frontmatter (`faceless-video`) is what registers the command.

---

## 3. Install the local tools (Stages 2 & 4)

### ffmpeg + ffprobe (required for transcribe + stitch)
```bash
# macOS
brew install ffmpeg
# Debian/Ubuntu
sudo apt-get install -y ffmpeg
# Windows
winget install Gyan.FFmpeg
```
Verify: `ffmpeg -version` and `ffprobe -version`.

### Python + Whisper (required for Stage 2)
```bash
python3 -m pip install -r requirements.txt
```
`requirements.txt` pins `openai-whisper`. The first transcription downloads the model
(`turbo` ≈ 1.5 GB) from OpenAI and caches it under `~/.cache/whisper`. After that it's offline.

Faster but slightly less accurate models: pass `--model small` or `--model base`.

> Apple Silicon / no GPU is fine — the script runs Whisper on CPU (`fp16=False`). A long
> VO just takes a few minutes.

---

## 4. Image generation backend (Stage 3)

The skill is written for the **Higgsfield MCP server** connected to Claude Code, using
`generate_image` (model `gpt_image_2`, 16:9). If you have that connector, nothing else to do.

**No Higgsfield?** Stage 3 is model-agnostic. Any text-to-image tool works as long as you:
- keep the locked STYLE block + `Avoid:` clause from `references/images.md` on every prompt
  (so the whole set looks like one hand), and
- save outputs as `NN_MM-SS.png` (zero-padded sequence) in one folder.

Drop-in alternatives:
- **OpenAI Images API** (`gpt-image-1` / DALL·E 3) — set `OPENAI_API_KEY`, request 1792×1024.
- **Replicate / Fal / Stability** — any flat-illustration-capable model.
- **Manual** — generate the images yourself, name them `NN_MM-SS.png`, and skip to Stage 4.

Stage 4 (`build_video.py`) only cares that the images are named in script order and that a
phrase SRT exists — it doesn't care how the images were made.

---

## 5. Quick end-to-end test

```bash
# Stage 2: transcribe a recording (point at the file OR its folder), with phrase chunks
python3 scripts/transcribe.py "/path/to/voiceover.m4a" --phrase --max-words 6

# Stage 3: generate NN_MM-SS.png images into an images/ folder (your backend of choice)

# Stage 4: stitch
python3 scripts/build_video.py --images "/path/to/images" --audio "/path/to/voiceover.m4a"
```

Output defaults to `<images-folder>/<audio-stem>.mp4`, 1920×1080, H.264 + AAC.

---

## 6. Troubleshooting

- **`openai-whisper is not importable`** → `python3 -m pip install -r requirements.txt`, and
  make sure you're running it with the same `python3` you installed into.
- **`ffmpeg`/`ffprobe` not found** → install ffmpeg (§3) and confirm it's on your `PATH`.
- **`no phrases SRT found next to <audio>`** in Stage 4 → re-run Stage 2 with `--phrase`
  (video timing reads the millisecond-precise `<audio>.phrases.srt`).
- **N images vs M cues warning** → Stage 2 and Stage 3 drifted out of sync; regenerate the
  images from the current `.phrases.txt` so counts match.
- **Whisper model download is slow** → it's a one-time ~1.5 GB pull; use `--model small`
  to test the pipeline faster.
