# Faceless Video Essay — Claude Code Skill

A four-stage pipeline that turns any topic into a finished, faceless documentary-style
**video essay** — the narrator-over-B-roll format used by channels like Zenn, RealLifeLore,
Johnny Harris, and Primal Space. One everyday thing, slowly revealed to hide a profound story.

It runs as a [Claude Code](https://claude.com/claude-code) skill: you type `/faceless-video`
(or just ask), and Claude walks the pipeline with you.

## The pipeline

1. **Write the script** — Claude researches *real* named studies/dates/stats, then writes a
   second-person voiceover script (curiosity-gap hook → three evidence pillars → rhetorical
   re-hook → bookend ending). Hands you a clean, teleprompter-ready script and stops.
2. **You record the voiceover** and drop the audio file in the script's folder.
3. **Transcribe** — local Whisper produces a millisecond-accurate, per-phrase timestamped
   transcript plus SRT/VTT captions. No API key.
4. **Generate images** — one illustrative image per timestamp, in one consistent hand-drawn
   style, named in script order.
5. **Stitch** — FFmpeg assembles the images + voiceover into a finished MP4, each image held
   over its phrase's exact time range.

## What's in here

```
README.md                      ← you are here
skills/faceless-video/
├── SKILL.md                   ← the skill itself (the instructions Claude follows)
├── SETUP.md                   ← full install guide — read this to set it up
├── requirements.txt           ← Python deps for the transcribe step
├── references/
│   ├── anatomy.md             ← annotated teardown of the model video + style rules
│   └── images.md              ← the locked art style + per-image prompt recipe
└── scripts/
    ├── transcribe.py          ← Stage 2: local Whisper → timestamped transcript + SRT/VTT
    └── build_video.py         ← Stage 4: FFmpeg-stitch images + VO → MP4
```

## Setup (short version)

1. Copy `skills/faceless-video` into your Claude Code skills folder (`~/.claude/skills/`).
2. Install `ffmpeg` and `pip install -r skills/faceless-video/requirements.txt`.
3. (For image generation) connect the Higgsfield MCP, or use any text-to-image model.

Full instructions, alternatives, and troubleshooting are in
[`skills/faceless-video/SETUP.md`](skills/faceless-video/SETUP.md).

## Notes

- **No API keys are bundled.** Stages 1–3 run with web search + local Whisper only. Stage 4
  needs an image backend (you supply it).
- **The anti-fabrication rule is the heart of this format.** The skill only cites studies,
  dates, and stats it actually verified through research — never invents authority. That's
  what makes the output publishable.
- The scripts are plain Python 3 + FFmpeg — no framework, nothing to configure.
