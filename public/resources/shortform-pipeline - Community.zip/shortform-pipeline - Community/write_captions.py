#!/usr/bin/env python3
"""
write_captions.py — generate social captions for each angle of a short-form video.

For each angle, reads:
  out/<slug>/script_<angle>.txt       — the voiceover script
  out/<slug>/meta_<angle>.json        — video_type, cta_noun
  out/<slug>/cutplan_<angle>.json     — hook_title

Fills prompts/write_captions.txt and calls Claude to produce:
  out/<slug>/captions_<angle>.json    — youtube_title, youtube_description,
                                        video_caption, linkedin_caption

Usage:
  python3 write_captions.py \\
      --out-dir out/my-video \\
      --subject "How to set up five CLAUDE.md context files that make Claude sound like you" \\
      --angles proof,contrarian,transformation
"""
import argparse, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import pipeline  # reuse claude_json and fill

REQUIRED_KEYS = {"youtube_title", "youtube_description", "video_caption", "linkedin_caption"}
DEFAULT_ANGLES = "proof,contrarian,transformation"


def main():
    ap = argparse.ArgumentParser(description="Generate social captions for each short-form angle.")
    ap.add_argument("--out-dir", required=True,
                    help="Output directory containing script_*, meta_*, cutplan_* files (e.g. out/my-video)")
    ap.add_argument("--subject", required=True,
                    help="One-line description of what the long-form video is actually about")
    ap.add_argument("--angles", default=DEFAULT_ANGLES,
                    help="Comma-separated list of angles (default: proof,contrarian,transformation)")
    args = ap.parse_args()

    out_dir = args.out_dir
    angles = [a.strip() for a in args.angles.split(",") if a.strip()]

    _cfg = json.load(open(os.path.join(HERE, "config.json")))
    creator = _cfg.get("creator", {})
    community_name  = creator.get("community_name", "Your Community")
    community_url   = creator.get("community_url", "")
    community_price = creator.get("community_price", "$9/mo")
    community_tagline = creator.get("community_tagline", "the community for building with AI")
    community_offer = "%s - %s. %s, locks in for life. URL: %s" % (
        community_name, community_tagline, community_price, community_url
    )

    for angle in angles:
        script_path  = os.path.join(out_dir, "script_%s.txt"   % angle)
        meta_path    = os.path.join(out_dir, "meta_%s.json"     % angle)
        cutplan_path = os.path.join(out_dir, "cutplan_%s.json"  % angle)

        # Validate inputs
        missing = [p for p in (script_path, meta_path, cutplan_path) if not os.path.exists(p)]
        if missing:
            print("[%s] ERROR: missing file(s): %s — skipping" % (angle, missing), flush=True)
            continue

        script   = open(script_path).read()
        meta     = json.load(open(meta_path))
        cutplan  = json.load(open(cutplan_path))

        video_type = meta.get("video_type", "tutorial")
        cta_noun   = (meta.get("cta_noun") or "").strip()
        hook_title = cutplan.get("hook_title", "")

        # Build and send the prompt
        prompt = pipeline.fill(
            "write_captions.txt",
            angle=angle,
            video_type=video_type,
            cta_noun=cta_noun,
            hook_title=hook_title,
            script=script,
            video_subject=args.subject,
            community_offer=community_offer,
            community_name=community_name,
            community_url=community_url,
            community_price=community_price,
        )

        result = pipeline.claude_json(prompt)

        # Validate required keys
        missing_keys = REQUIRED_KEYS - set(result.keys())
        if missing_keys:
            print("[%s] WARNING: Claude response missing keys: %s" % (angle, missing_keys), flush=True)

        out_path = os.path.join(out_dir, "captions_%s.json" % angle)
        json.dump(result, open(out_path, "w"), indent=2, ensure_ascii=False)
        print("[%s] captions written -> %s" % (angle, out_path), flush=True)


if __name__ == "__main__":
    main()
