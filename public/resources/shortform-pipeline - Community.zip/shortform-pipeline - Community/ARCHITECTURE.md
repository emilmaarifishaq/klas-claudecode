# Short-Form Pipeline — Architecture & Handoff

**One long-form video → three angle-distinct ~40-50s vertical shorts (1080x1920) → auto-distributed across YouTube Shorts / Instagram / TikTok / Facebook (+ a LinkedIn story lane).** HeyGen avatar on the bottom band, the screen recording up top, karaoke captions on the seam, a blue hook banner for the first 3s, a configurable end-card. Audience: non-developers building with AI.

This doc is the deep reference. See `SETUP.md` for first-time configuration.

---

## Quick start

```bash
set -a && source .env && set +a          # HeyGen + Blotato keys

# 1) SCRIPTS ONLY (cheap, no render) — REVIEW GATE. Read out/<slug>/script_<angle>.txt, approve/edit.
python3 pipeline.py --transcript "<t.txt>" --screencap "<s.mp4>" --out-dir out/<slug> --angles proof,contrarian,transformation --no-compose

# 2) FULL RUN — gen art + HeyGen avatars + trim + composite -> out/<slug>/short_<angle>.mp4
python3 pipeline.py --transcript "<t.txt>" --screencap "<s.mp4>" --out-dir out/<slug>

# 3) B-ROLL is the make-or-break step — build out/<slug>/broll_<angle>.json BY HAND (see "B-roll rules"),
#    then merge into the cut-plan, gen the images (shared cache), and re-compose. (Subagents misfire — verify.)

# 4) CAPTIONS — write_captions.txt per angle -> out/<slug>/captions_<angle>.json

# 5) DISTRIBUTE (self-driving): auto-uploads + auto-finds open Blotato slots
python3 schedule.py --slug <slug> --linkedin-angle contrarian --dry-run   # preview the slot plan
python3 schedule.py --slug <slug> --linkedin-angle contrarian             # actually schedule
```

---

## Pipeline stages (what `pipeline.py` does, per angle)

```
long-form (screencap.mp4 + timestamped transcript.txt)
  1. scene-analyze (Claude, prompts/scene_analyze.txt)  -> out/<slug>/moments.json
       a visual-moments library: {sec, shows, kind, region L/C/R, impact, tool}. SKIPS the intro,
       carousels, notes screens.
  2. write script (Claude, prompts/write_script.txt)    -> out/<slug>/script_<angle>.txt   [REVIEW GATE]
  3. match a b-roll cut-plan (Claude, prompts/match.txt) -> out/<slug>/cutplan_<angle>.json
       (basic auto cut-plan; the HAND-BUILT broll_<angle>.json is what makes it great — replaces this)
  3b. generate riso b-roll for "gen" beats (Higgsfield nano_banana_2) — CACHED by concept (gen_cache/)
  3c. auto-prepend a relevance-matched Claude brand cold-open clip (add_cold_open)
  4. render avatar (render_avatar.py -> HeyGen v3)       -> out/<slug>/avatar_<angle>.mp4
  4b. trim pauses (trim_pauses.py, single-pass A/V-locked) -> avatar_<angle>_trim.mp4
  5. composite (compose.py)                              -> out/<slug>/short_<angle>.mp4
THEN (separate): captions (write_captions.txt) -> schedule.py -> Blotato queue
```

---

## Files

| File | Role |
|---|---|
| `pipeline.py` | Orchestrator. scene→script→match→gen(cache)→cold-open→avatar→trim→compose. Helpers: `load_library`, `resolve_clips` ({"clip":id}→file), `add_cold_open`, `gen_image`. Forces `cp["hook_title"]=sc["hook_title"]` (matcher must not reword the hook). |
| `compose.py` | THE compositor (ffmpeg). `build_shots` (resolves opening + trigger beats, caches trigger times, splits long shots, caps graphics, diversifies moves), `shot_vf` (per-shot motion; `zstart`/`end_zoom` = continuous push across cuts), `make_card` (hook/endcard, balanced 2-line wrap), `word_card` (riso word card, GUARDED + wrapped to fit the zoom crop), `make_captions` (karaoke .ass), `fix_transcription` (Whisper "cloud"/"quad"→"Claude"). |
| `trim_pauses.py` | Shortens HeyGen's ~2x-too-long SSML pauses in ONE ffmpeg pass (select/aselect on video+audio together → A/V stays locked). Removes the leading fade (avatar present on frame 1), resets PTS to 0. |
| `render_avatar.py` | HeyGen v3 render. `--text <script> --out <mp4>`. Inserts SSML `<break>` pauses between thought-lines. |
| `schedule.py` | Blotato distribution. Self-driving: `upload()` (presigned PUT), `occupied_video_days()` + `find_slots()` (auto-fill open days ≥8 apart), `schedule_angle()` (4 video channels + optional LinkedIn). Talks to Blotato via the MCP JSON-RPC endpoint (`_call`). |
| `prompts/scene_analyze.txt` | Catalog on-screen software moments; exclude intro/carousels/notes. |
| `prompts/write_script.txt` | The 3 distinct FORMATS + all script rules. |
| `prompts/match.txt` | B-roll source decisioning + all b-roll rules. |
| `prompts/write_captions.txt` | Per-platform captions (punchy video + YT title/desc + LinkedIn story). |
| `config.json` | HeyGen IDs, brand (font/caption/hook/endcard/card colors+sizes), layout, character_ref. |
| `assets/broll/manifest.json` | 15 curated Claude brand clips (intro/section) + `clips/` (24 files). |
| `assets/creator-ref.png` | Your reference photo for `character:"me"` gen images (add your own headshot here). |
| `out/<slug>/` | All intermediates: moments, scripts, cutplans, broll plans, avatars, gen_<angle>/, gen_cache/ (shared), captions, schedule_result. |

---

## The cut-plan / broll JSON format

```json
{
  "hook_title": "CLAUDE CODE BUILT MY ENTIRE AGENTIC OS",   // first-3s blue banner; <=8 words; from the script
  "endcard_text": "Learn Claude Code. Link in bio",          // (config also supplies this)
  "opening_shots": [ {"at": 0.0, "ss": 579, "move": "zoomin", "anchor": "c"} ],   // FIXED times (often empty; cold-open auto-added)
  "beat_shots": [ ... ],     // trigger-word timed
  "cards": []                // full-frame STEP cards (tutorials only)
}
```

Each shot is ONE source:
- **screencap**: `{"trigger":"center","ss":579,"move":"zoomin","anchor":"c"}` — `ss` = a second from the screen recording.
- **gen image**: `{"trigger":"vet","gen":"<literal concept>","style":"illustration|infographic","character":"me"(opt),"move":...,"anchor":"c"}` — riso editorial art via Higgsfield.
- **library clip**: `{"trigger":"x","clip":"<manifest id>","move":...}` — a Claude brand clip (cold-open is auto-added).
- **word card**: `{"trigger":"x","text":"WATCH EVERY LINE","move":"push","anchor":"c"}` — riso card, <=4 words (guarded).

Fields: `trigger` = a DISTINCTIVE word copied EXACTLY from the script (resolved in order, cached so repeats/`+offset` reuse the time). `move` ∈ {zoomin, zoomout, push, panLR, panRL}. `anchor` ∈ {l,c,r} (+ t/b vertical). `offset` = seconds into a beat for a sub-cut (same trigger). `zcont:true` = start this shot's zoom where the previous ended (continuous push, e.g. the me-sitting→empty-chair two-shot). `image` = a resolved file path (gen output or a clip/word-card; .mp4/.webm = a clip played cover-fit).

---

## RULES (hard-won — all baked into the prompts/code; do not regress)

**Script FORMATS — 3 distinct shapes, NEVER homogenized into one:**
- **proof = RESULT-LED:** hook = result + number → one proof/credibility line → WHAT it built → HOW (mechanism) → stakes.
- **contrarian = BELIEF-FLIP:** hook = counterintuitive claim → the WRONG belief everyone holds (the pain) → the FLIP shown by action + the RESULT as the mic-drop PROOF (lands AFTER the belief, never before) → why → stakes.
- **transformation = BEFORE/AFTER:** hook = the shift → the OLD world (cost) → the NEW world + result → how → what it means for the viewer.

**Scripts:** never say "AI"/"AIs" — say the specific tool / "agents" (avatar mispronounces + brand). NAME the model + feature: "Opus 4.8", "Ultra Code" (never a generic "a new mode"). ANSWER WHY (the pain removed, "now I don't have to…"), not just what. RESULT before mechanism (never bury the payoff). First sentence carries the headline number. One PROOF stat line after the payoff (configured in `creator.proof_stats`). Thought-line pauses (one complete thought per line). No spoken CTA.

**Hooks (the blue banner):** an intrigue-building PAYOFF description; distinct per angle; say "Claude Code" not "AI"; contrarian may be a pattern-interrupt ("STOP BUILDING WITH CLAUDE CODE"); balances onto 2 even lines (make_card auto-balances).

**B-roll:** the SCREENCAP of the real product (the dashboard) is the STAR — show it EARLY (right after the cold-open) and cut through its panels as the script names them. GEN art is a spice: the conceptual opener + the recurring SHARED CANONICAL SCENES. A LIST line ("watch every line / approve every step / catch every mistake") gets one rapid-fire word card per item. BE PRESENT in illustrations (`character:"me"`; the dog is a MINIATURE DACHSHUND). Absence two-shot = him in scene then same scene empty (2nd shot `zcont:true`). NEVER a carousel/notes/plain-editor frame when the line isn't about code. End on a WIDE dashboard payoff. Motion variety (no move >2x in a row; pan infographics, zoom illustrations). Gen art = editorial RISO (burnt orange #E96A3C + charcoal #1C1B17 on cream #E8DCC4, 2 inks, halftone — NOT the dark web brand).

**SHARED CANONICAL SCENES** (use these EXACT strings so the cache generates them ONCE and reuses across angles):
- dog-at-vet: `"a man sitting in a veterinary clinic waiting room with his small miniature dachshund dog on his lap, relaxed and calm, no phone or laptop in sight"` (illustration, character:me)
- walk-out: `"a man walking calmly out his front door into daylight, his desk and a glowing computer screen visible in the room behind him"` (illustration, character:me)
- agent-team: `"an org chart of AI worker robots, one lead manager robot at the top handing job tickets down to a row of builder robots, and a second row of reviewer robots holding green check marks, arrows flowing between the rows"` (infographic)

**Captions:** per-platform, angle-distinct titles/first-lines. Video channels (IG/TikTok/FB) get the punchy caption + your community CTA; YouTube gets a searchable title + description with the real link. LinkedIn gets a STORY caption (no CTA — the story carries it; the profile converts). Community offer is configured in `config.json creator.*`.

**Distribution:** 4 video channels per angle (auto-blast) + LinkedIn for the ONE best story angle (its own lane, no CTA). Angles 7-10 days apart, rotating PT times (8am/1pm/5pm; LinkedIn 11am). TikTok flagged `isAiGenerated`, YouTube `containsSyntheticMedia`. Future-date with a review buffer (`--start-in-days`).

---

## Accounts / IDs / keys

- **Keys** (in `.env`): `HEYGEN_API_KEY`, `BLOTATO_API_KEY`. Higgsfield via its CLI (path set in `config.json paths.higgsfield_cli`). Always `set -a && source .env && set +a` before a run.
- **HeyGen** (config.json heygen): set your own `avatar_id` and `voice_id` — find these in your HeyGen account. engine `avatar_iv`, 16:9; tune `speed`/`pitch` to taste.
- **Blotato accounts**: set your own IDs in `config.json blotato`. The 4 video accounts (YT/IG/TT/FB) hold ONLY short-form posts; LinkedIn is a separate story lane.
- **Higgsfield**: `generate create nano_banana_2 --prompt "<concept>. <RISO base>" --aspect_ratio 16:9 --resolution 1k --wait --json`; `--image <ref>` for character consistency.
- **Offer**: configured in `config.json creator` (community_name, community_url, community_price).

---

---

## Gotchas / lessons (read before debugging)

- **ffmpeg `-nostdin`** everywhere — ffmpeg eats stdin inside `while read` loops otherwise.
- **Blotato re-hosts media** under its own URL, so you CANNOT find scheduled posts by the URL you uploaded. Match by **account + scheduledAt** instead (the 4 video accounts = AIOS-only, so that's a clean key). Use `update_schedule` to change a time (keeps media); `delete_schedule` + re-create to swap content.
- **Whisper mishears "Claude"** as "cloud" / "quad" / "clawed" — `compose.fix_transcription` corrects the captions (extend the `TRANSCRIPT_FIX` dict for new mishears).
- **word_card must fit the zoom crop** (~center 1040px of the 1920-wide card, since the top-region zoom crops the sides) — `maxw = W16*0.52`. A multi-word card wraps; a sentence is capped to 4 words.
- **Subagents are UNRELIABLE for b-roll** — one once set every beat's `text` to a full SENTENCE (rendered as overflowing cards). Build broll_<angle>.json by hand or always sanity-check the JSON (screencap-dominant, no sentence cards).
- **gen cache** is keyed by the exact (concept+style+ref) string — use the SHARED CANONICAL wordings verbatim so recurring scenes reuse the cached image instead of regenerating.
- **HeyGen renders SSML pauses ~2x too long** → `trim_pauses.py`. A clip shorter than its shot duration freezes/desyncs — clips must span their beat.
- **The matcher reworded hooks** — `pipeline.py` now force-overwrites `cp["hook_title"]=sc["hook_title"]`.
- `datetime.date.today()` is fine in schedule.py (the no-Date restriction is only inside Workflow-tool JS scripts).

---

## Common changes — where to make them

- Different hook/caption voice → `prompts/write_script.txt` (hook_title rule) / `prompts/write_captions.txt`.
- A new recurring visual to share across angles → add its canonical wording here + use it verbatim in the broll plans.
- New screencap timecodes → re-run scene-analyze or hand-edit `out/<slug>/moments.json`; verify by extracting the frame.
- Post timing/cadence → `schedule.py` (`TIMES_PT`, `find_slots min_gap`, `--start-in-days`, `--linkedin-angle`).
- Caption mishears → `compose.TRANSCRIPT_FIX`.
- Brand colors/sizes (hook, caption, endcard, font) → `config.json`.
- NEXT BUILD ITEM: wire `schedule.py` as an auto final step of `pipeline.py` (and generalize the b-roll build) so a long-form fully self-produces + self-distributes.
