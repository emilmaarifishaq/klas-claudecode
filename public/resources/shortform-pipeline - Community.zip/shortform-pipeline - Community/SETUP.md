# Setup Guide

Turn one long-form video into 3 finished short-form cuts — scripted, avatared, captioned, and scheduled — end to end.

---

## Requirements

- Python 3.10+
- [Claude Code CLI](https://claude.ai/code) — installed and authenticated (`claude --version`)
- [Higgsfield CLI](https://higgsfield.ai) — installed and authenticated
- [ffmpeg](https://ffmpeg.org/) — installed (`brew install ffmpeg` on Mac)
- [Whisper](https://github.com/openai/whisper) — installed (`pip install openai-whisper`)
- [Pillow](https://pillow.readthedocs.io/) — installed (`pip install Pillow`)
- A HeyGen account with a photo-avatar and cloned voice
- A Blotato account with social platforms connected

---

## 1. API Keys

Copy `.env.example` to `.env` and fill in your keys:

```bash
cp .env.example .env
# then edit .env with your keys
```

Source it before running any script:

```bash
set -a && source .env && set +a
```

---

## 2. config.json

Open `config.json` and fill in your details:

### HeyGen avatar + voice IDs

Find these in your HeyGen account:
- `avatar_id` — your photo-avatar look ID (from app.heygen.com/avatars)
- `voice_id` — your cloned voice ID (from app.heygen.com/voice-cloning)

```json
"heygen": {
  "avatar_id": "your_avatar_look_id_here",
  "voice_id": "your_voice_id_here",
  ...
}
```

### Creator profile

```json
"creator": {
  "name": "Your Name",
  "community_name": "Your Community Name",
  "community_tagline": "the community for learning Claude Code",
  "community_url": "https://www.skool.com/your-community",
  "community_price": "$9/mo",
  "proof_stats": "10K+ followers, $50K+ from content"
}
```

`proof_stats` is injected into the script prompt as one credibility line — use your real numbers.

### Blotato account IDs

Run this to find your account IDs:

```bash
# With your Blotato API key exported:
python3 -c "
import urllib.request, json, os
key = os.environ['BLOTATO_API_KEY']
req = urllib.request.Request('https://mcp.blotato.com/mcp',
  data=json.dumps({'jsonrpc':'2.0','method':'tools/call','id':1,'params':{'name':'blotato_list_accounts','arguments':{}}}).encode(),
  headers={'blotato-api-key': key, 'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'})
print(urllib.request.urlopen(req).read().decode()[:3000])
"
```

Fill in the IDs in config.json:

```json
"blotato": {
  "youtube_account_id": "123",
  "instagram_account_id": "456",
  "tiktok_account_id": "789",
  "facebook_account_id": "321",
  "facebook_page_id": "your_fb_page_id",
  "linkedin_account_id": "654"
}
```

### Paths

```json
"paths": {
  "hook_vault": "~/path/to/your-hook-swipe-file.md",
  "higgsfield_cli": "higgsfield"
}
```

`hook_vault` is a markdown file of your proven hook patterns. Leave it empty (`""`) and the pipeline falls back to built-in patterns.

`higgsfield_cli` is the path to the Higgsfield CLI. If it's on your PATH, `"higgsfield"` works. Otherwise use the full path (e.g. `"~/.npm-global/bin/higgsfield"`).

### Brand colors + endcard

Edit `brand.endcard.text` for your CTA:

```json
"endcard": { ..., "text": "Learn more.\nLink in bio" }
```

Change the RGB values in `hook`, `endcard`, and `card` to match your brand colors.

---

## 3. Character reference photo

Add a headshot to `assets/creator-ref.png`. This is used to keep your likeness consistent in AI-generated illustration beats (the "walking out the door" moments).

If missing, the pipeline logs a warning and renders generic illustrations instead — fully functional, just not personalized.

---

## 4. Run the pipeline

### Prepare inputs

You need two files:
- `long-form-screencap.mp4` — the screen recording of your full video (1080p)
- `transcript.txt` — a timestamped transcript (HH:MM:SS:FF format, one line per caption)

### Run

```bash
set -a && source .env && set +a

python3 pipeline.py \
    --transcript "/path/to/transcript.txt" \
    --screencap  "/path/to/screencap.mp4" \
    --out-dir    ./out/my-video

# Options:
#   --angles proof,contrarian         (default: proof,contrarian,transformation)
#   --no-compose                       (stop after scripts + cut-plans; no render)
#   --from-cutplan                     (re-render from hand-edited cut-plans)
```

**Step 1 (review gate):** Run with `--no-compose` first. Review the scripts in `out/my-video/script_*.txt`. Edit them if needed. Then run without `--no-compose` to render.

### Generate captions

```bash
python3 write_captions.py \
    --out-dir out/my-video \
    --subject "One sentence describing what your long-form video is about" \
    --angles proof,contrarian,transformation
```

### Schedule

```bash
# Dry run first to see the slot plan:
python3 schedule.py --slug my-video --dry-run

# Then schedule for real:
python3 schedule.py --slug my-video
```

Options:
- `--linkedin-angle contrarian` — which angle posts to LinkedIn (default: contrarian)
- `--trial` — post Instagram as a trial reel (non-followers only, SS_PERFORMANCE graduation)
- `--spacing-days 8` — min days between angles (default: 8)

---

## 5. Re-render from hand-edited cut-plans

After reviewing, you can edit `out/my-video/cutplan_<angle>.json` directly, then re-render without re-running the expensive scene/script/match steps:

```bash
python3 pipeline.py \
    --from-cutplan \
    --screencap "/path/to/screencap.mp4" \
    --out-dir out/my-video \
    --angles proof
```

---

## Troubleshooting

**`TRIGGERS_UNMATCHED` in compose output:**
A trigger word wasn't found in the Whisper transcript. Transcribe the avatar:
```bash
ffmpeg -i out/my-video/avatar_proof_trim.mp4 -vn -ar 16000 a.wav
whisper a.wav --model base
```
Pick a plain word Whisper actually said near that beat and update the trigger in `cutplan_<angle>.json`. Then re-render with `--from-cutplan`.

**HeyGen render fails:**
Check your `HEYGEN_API_KEY` and that `avatar_id`/`voice_id` in config.json are valid.

**Higgsfield b-roll fails:**
Make sure Higgsfield CLI is installed and authenticated (`higgsfield whoami`). Update `paths.higgsfield_cli` in config.json if needed.

**Wrong Blotato accounts:**
Run the account listing command above to find the correct IDs.
