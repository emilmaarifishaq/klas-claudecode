#!/usr/bin/env python3
"""
compose.py - composite a finished short-form vertical cut.

Inputs:
  --avatar    : the rendered HeyGen avatar mp4 (talking head, its own background)
  --screencap : the long-form screen recording (1080p) that the b-roll is pulled from
  --cutplan   : JSON describing the b-roll plan (see example_cutplan.json)
  --out       : output mp4 (1080x1920)

Pipeline (all deterministic, no LLM):
  1. Whisper the avatar audio -> word-level timestamps.
  2. Build the shot list: opening fixed-time shots (payoff first) + beat-triggered
     shots (resolved against the transcript) + offsets for sub-cuts.
  3. Generate karaoke captions (.ass): 3-word chunks, current word yellow.
  4. Render every b-roll shot from the screencap. EVERY shot is in motion
     (zoom or pan) - there are no static holds.
  5. Concat -> top track. Composite: screencap top, avatar bottom, captions on the
     seam, blue hook card (first N s), end-card (last N s).

Key rules baked in (from the Build Room short-form spec):
  - Lead with the payoff, new action every 3-6s, nothing static.
  - Region anchors: punch left/center/right to the panel actually being named.
  - For show-off angles: minimize code, mix the hero (dashboard) with brief tool shots.
"""
import argparse, json, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
W, H = 1080, 1920


def run(cmd):
    subprocess.run(cmd, check=True, stdin=subprocess.DEVNULL,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def probe_dur(path):
    out = subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                   "-of", "csv=p=0", path]).decode().strip()
    return float(out)


def whisper_words(audio):
    """Run whisper, return [(word, start, end), ...]."""
    outdir = os.path.dirname(audio)
    run(["whisper", audio, "--model", "base", "--language", "en", "--word_timestamps", "True",
         "--output_format", "json", "--output_dir", outdir, "--fp16", "False", "--verbose", "False"])
    j = json.load(open(os.path.splitext(audio)[0] + ".json"))
    words = []
    for seg in j.get("segments", []):
        for w in seg.get("words", []):
            t = w.get("word", "").strip()
            if t:
                words.append([t, float(w["start"]), float(w["end"])])
    return words


def low(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def find_trigger(words, trig, start_idx):
    """trig may be 'a|b|c' alternatives (handles whisper variance, e.g. 'fifteen|15');
    return the time of the first word at/after start_idx that contains any alternative."""
    alts = [low(a) for a in trig.split("|") if a.strip()]
    for j in range(start_idx, len(words)):
        wl = low(words[j][0])
        if any(a and a in wl for a in alts):
            return words[j][1], j
    return None, start_idx


def diversify_moves(out):
    """No move - and no zoom-type move (zoomin/zoomout/push) - more than twice in a row. The 3rd in a
    run becomes a region-aware pan (starts on the anchored side), so motion stays varied instead of
    over-indexing on zooms."""
    ZOOM = {"zoomin", "zoomout", "push"}
    res = []
    for st, ss, dur, mv, an, img in out:
        if img is None and len(res) >= 2:             # only diversify SCREENCAP moves; keep a graphic's chosen motion
            m1, m2 = res[-1][3], res[-2][3]
            if (mv in ZOOM and m1 in ZOOM and m2 in ZOOM) or (mv == m1 == m2):
                mv = "panRL" if an == "r" else "panLR"
                if mv == m1:                      # don't immediately start a new pan run
                    mv = "panLR" if mv == "panRL" else "panRL"
        res.append((st, ss, dur, mv, an, img))
    return res


def diversify_ss(out, window=2, near=3, hop=6):
    """Avoid cutting to the same SCREENCAP moment (or one within `near` seconds) inside any
    `window`+1 run - nudge it forward so it shows a different part of that scene. Image / word-card
    shots (img set) are left untouched."""
    res = []
    for st, ss, dur, mv, an, img in out:
        if img is None:
            recent = [r[1] for r in res[-window:] if r[5] is None]
            while any(abs(ss - r) < near for r in recent):
                ss += hop
        res.append((st, ss, dur, mv, an, img))
    return res


def cap_graphics(out, max_gfx=1.6):
    """Generated images and word cards should FLASH (1-2s), not linger. Cap any image-sourced shot to
    max_gfx and hand the freed time to the NEXT shot (it absorbs it). The graphic still hits on its
    beat - it just pops and gets out of the way."""
    res = [list(s) for s in out]
    for i in range(len(res)):
        # cap a graphic ONLY when the next shot is a SCREENCAP that can absorb the freed time. Never
        # cascade between consecutive graphics - that shifts an explainer series ahead of the audio.
        if res[i][5] and res[i][2] > max_gfx and i + 1 < len(res) and res[i + 1][5] is None:
            extra = round(res[i][2] - max_gfx, 3)
            res[i][2] = max_gfx
            res[i + 1][2] = round(res[i + 1][2] + extra, 3)
    return [tuple(s) for s in res]


def split_long_shots(out, max_dur=3.5):
    """No single shot should overstay ('new action every 3-6s'). Split a long SCREENCAP shot into
    pieces - each a fresh cut (advanced timecode + alternated motion) - so nothing reads as a pause.
    Graphics are already capped, so they are never split."""
    alt = {"zoomin": "panLR", "push": "panRL", "panLR": "zoomin", "panRL": "push", "zoomout": "panLR"}
    res = []
    for st, ss, dur, mv, an, img in out:
        if img is None and dur > max_dur:
            n = int(dur // max_dur) + 1
            piece = round(dur / n, 3)
            for k in range(n):
                res.append((round(st + k * piece, 3), ss + 3 * k, piece,
                            mv if k == 0 else alt.get(mv, "panLR"), an, None))
        else:
            res.append((st, ss, dur, mv, an, img))
    return res


def build_shots(cutplan, words, total, min_dur=0.5):
    """Opening fixed shots (payoff-first) + beat-triggered shots -> [(start, ss, dur, move, anchor, img)].

    Each trigger is resolved ONCE and cached, so a repeat entry (same trigger + an 'offset') is a
    SUB-CUT that reuses the parent's anchor time. Shots closer than min_dur to the previous kept shot
    are merged into it (logged, never silently dropped). A shot is sourced from the screencap (ss) OR a
    16:9 image (img = a generated nano_banana image or a pre-rendered word card)."""
    opening = [(s["at"], s.get("ss", 0), s["move"] + ("~c" if s.get("zcont") else ""),
                s.get("anchor", "c"), s.get("image")) for s in cutplan.get("opening_shots", [])]
    cache, idx, resolved, unmatched = {}, 0, [], []
    for s in cutplan.get("beat_shots", []):
        trig = s["trigger"]
        if trig not in cache:
            t, j = find_trigger(words, trig, idx)
            if t is None:
                print("WARN: trigger not found, shot skipped:", trig)
                unmatched.append(trig)
                continue
            cache[trig] = t
            idx = j + 1
        resolved.append((cache[trig] + s.get("offset", 0.0), s.get("ss", 0),
                         s["move"] + ("~c" if s.get("zcont") else ""), s.get("anchor", "c"), s.get("image")))
    print("TRIGGERS_UNMATCHED:", " | ".join(unmatched) if unmatched else "none")
    first_beat = min((r[0] for r in resolved), default=total)
    shots = sorted([o for o in opening if o[0] < first_beat - 0.4] + resolved, key=lambda x: x[0])
    kept, last = [], -999.0
    for sh in shots:
        if not kept or sh[0] - last >= min_dur:
            kept.append(sh); last = sh[0]
    merged = len(shots) - len(kept)
    out = []
    for i, (st, ss, mv, an, img) in enumerate(kept):
        nxt = min(kept[i + 1][0], total) if i + 1 < len(kept) else total
        dur = round(nxt - st, 3)
        if st < total and dur >= 0.1:                 # guard: never a zero/negative-length shot
            out.append((round(st, 3), ss, dur, mv, an, img))
    if merged:
        print("merged %d short sub-cut(s) (< %.2fs apart)" % (merged, min_dur))
    out = split_long_shots(cap_graphics(diversify_ss(diversify_moves(out))))
    print("shots:", len(out))
    return out


def shot_vf(ss, dur, move, anchor, zstart=1.0):
    """Return an ffmpeg -vf for one b-roll shot. EVERY move is continuously in motion. `zstart` lets a
    shot BEGIN its zoom where the previous one ended - a continuous push across a hard cut (e.g. the
    'me sitting -> empty chair' two-shot) instead of the zoom snapping back to 1.0 on every cut."""
    if move in ("panLR", "panRL"):
        if move == "panLR":
            xexpr = "(in_w-1080)*min(t/%g\\,1)" % dur
        else:
            xexpr = "(in_w-1080)*(1-min(t/%g\\,1))" % dur
        return "scale=-2:1000,crop=1080:1000:x='%s':y=0,fps=30,setsar=1" % xexpr
    ah = "l" if "l" in anchor else ("r" if "r" in anchor else "c")
    cropx = {"l": "0", "r": "iw-2160", "c": "(iw-2160)/2"}[ah]
    yc = "(ih-ih/zoom)*0.8" if "b" in anchor else ("(ih-ih/zoom)*0.2" if "t" in anchor else "(ih-ih/zoom)*0.5")
    if move == "push":
        z = "min(%g+0.004*on\\,1.40)" % zstart         # faster continuous push into a panel
    elif move == "zoomout":
        z = "max(%g-0.0016*on\\,1.0)" % (zstart if zstart > 1.0 else 1.18)   # start tight, ease out
    else:
        z = "min(%g+0.0016*on\\,1.35)" % zstart         # zoomin (default), always drifting in
    return ("scale=-2:2000,crop=2160:2000:x='%s':y=0,"
            "zoompan=z='%s':x='iw/2-(iw/zoom/2)':y='%s':d=1:s=1080x1000:fps=30,setsar=1"
            % (cropx, z, yc))


def end_zoom(move, dur, zstart=1.0):
    """The zoom level a shot ENDS at - passed as the next shot's zstart when it continues the push."""
    fr = dur * 30.0
    if move == "push":
        return min(zstart + 0.004 * fr, 1.40)
    if move == "zoomin":
        return min(zstart + 0.0016 * fr, 1.35)
    return 1.0                                          # pans / zoomout do not carry a continuous push


def at(t):
    h = int(t // 3600); m = int((t % 3600) // 60); s = t % 60
    return "%d:%02d:%05.2f" % (h, m, s)


TRANSCRIPT_FIX = {"cloud": "Claude", "clawed": "Claude", "claud": "Claude", "clyde": "Claude",
                  "quad": "Claude", "claud's": "Claude's", "cloud's": "Claude's",
                  # homophones / base-model mishearings
                  "sole": "soul"}

def fix_transcription(words):
    """Whisper mishears 'Claude' as 'cloud' (etc). Correct known errors before captions + triggers,
    preserving trailing punctuation."""
    out = []
    for t, s, e in words:
        core = t.rstrip(".,!?;:")
        punct = t[len(core):]
        if core.lower() in TRANSCRIPT_FIX:
            t = TRANSCRIPT_FIX[core.lower()] + punct
        out.append((t, s, e))
    return out


def make_captions(words, brand, path):
    cap = brand["caption"]
    n = cap.get("words_per_chunk", 3)
    yellow = "{\\c&H%s%s%s&}" % (cap["highlight"][4:6], cap["highlight"][2:4], cap["highlight"][0:2])  # RGB->BGR
    white = "{\\c&H%s%s%s&}" % (cap["color"][4:6], cap["color"][2:4], cap["color"][0:2])
    # merge stray decimal/punct tokens
    merged = []
    for t, s, e in words:
        if merged and (re.fullmatch(r"\.\d+", t) or t in ".,!?;:"):
            merged[-1][0] += t; merged[-1][2] = e
        else:
            merged.append([t, s, e])
    groups, cur = [], []
    for w in merged:
        cur.append(w)
        if len(cur) >= n or w[0][-1:] in ".!?":
            groups.append(cur); cur = []
    if cur:
        groups.append(cur)
    flat = [(gi, wi, w) for gi, g in enumerate(groups) for wi, w in enumerate(g)]
    hdr = ("[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n"
           "ScaledBorderAndShadow: yes\nWrapStyle: 2\n\n[V4+ Styles]\n"
           "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, Bold, "
           "Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
           "Style: Cap,Anton,%d,&H00%s%s%s,&H00000000,&H00000000,0,%d,0,5,60,60,0,1\n\n"
           "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
           % (cap["size"], cap["color"][4:6], cap["color"][2:4], cap["color"][0:2], cap["outline"]))
    lines = [hdr]
    for j, (gi, wi, w) in enumerate(flat):
        st = w[1]
        nxt = flat[j + 1][2][1] if j + 1 < len(flat) else w[2]
        en = max(w[2], nxt)
        parts = []
        for q, ww in enumerate(groups[gi]):
            tok = ww[0].upper()
            parts.append(yellow + tok + white if q == wi else tok)
        lines.append("Dialogue: 0,%s,%s,Cap,,0,0,0,,{\\pos(540,%d)}%s"
                     % (at(st), at(en), cap["y"], " ".join(parts)))
    open(path, "w").write("\n".join(lines))


def make_card(text, spec, font, path, max_w=1010, max_words=None):
    """Render a rounded card (cream/blue box + hard offset shadow + centered text) via PIL.
    max_words: hard cap on words per LINE (hook card uses 4 so it never spans the full frame)."""
    from PIL import Image, ImageDraw, ImageFont
    fs = spec["size"]; off = max(8, int(fs * 0.2)); pad = 12; ls = int(fs * 1.05); rad = int(fs * 0.18)
    f = ImageFont.truetype(font, fs)
    d0 = ImageDraw.Draw(Image.new("RGBA", (4, 4)))
    cap = max_words or 10**9
    wrapped = []
    for ln in text.split("\n"):                       # respect explicit breaks, then BALANCE-wrap each line
        words = ln.split()
        if not words:
            wrapped.append(""); continue
        if len(words) <= cap and d0.textlength(" ".join(words), font=f) <= max_w:
            wrapped.append(" ".join(words)); continue
        best = None                                   # most balanced 2-line split where both lines fit (no orphan word)
        for i in range(1, len(words)):
            if i > cap or len(words) - i > cap:
                continue
            a = " ".join(words[:i]); b = " ".join(words[i:])
            wa = d0.textlength(a, font=f); wb = d0.textlength(b, font=f)
            if wa <= max_w and wb <= max_w and (best is None or max(wa, wb) < best[0]):
                best = (max(wa, wb), [a, b])
        if best:
            wrapped.extend(best[1])
        else:                                         # too long for 2 lines -> greedy fill
            cur = ""
            for wd in words:
                t = (cur + " " + wd).strip()
                if len(t.split()) <= cap and d0.textlength(t, font=f) <= max_w:
                    cur = t
                else:
                    wrapped.append(cur); cur = wd
            wrapped.append(cur)
    block = len(wrapped) * ls
    text_w = max((d0.textlength(ln, font=f) for ln in wrapped), default=0)
    bw, bh = int(text_w) + int(fs * 0.6), block + int(fs * 0.5)   # box HUGS the text (scales with size)
    cw, ch = bw + pad * 2 + off, bh + pad * 2 + off
    img = Image.new("RGBA", (cw, ch), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.rounded_rectangle([pad + off, pad + off, pad + off + bw, pad + off + bh], rad, fill=tuple(spec["shadow"]) + (255,))
    d.rounded_rectangle([pad, pad, pad + bw, pad + bh], rad, fill=tuple(spec["bg"]) + (255,))
    cx, cy = pad + bw / 2, pad + bh / 2
    y = cy - block / 2 + ls / 2
    for lncur in wrapped:
        d.text((cx, y), lncur, font=ImageFont.truetype(font, fs), fill=tuple(spec["fg"]) + (255,), anchor="mm")
        y += ls
    img.save(path)


def fullframe_card(content, spec, font, bg_hex, out_png, is_image=False):
    """Build a FULL-FRAME 1080x1920 card the video CUTS to (a clean break from the stacked boxes,
    like the reference). text card = dark canvas + the centered box; image (proof) card = the image
    contained on the canvas."""
    from PIL import Image
    bg = tuple(int(bg_hex[i:i + 2], 16) for i in (0, 2, 4))
    canvas = Image.new("RGB", (W, H), bg)
    if is_image:
        im = Image.open(content).convert("RGB")
        s = min(W / im.width, H / im.height)
        im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))))
        canvas.paste(im, ((W - im.width) // 2, (H - im.height) // 2))
    else:
        boxp = out_png + ".box.png"
        make_card(content, spec, font, boxp)
        b = Image.open(boxp).convert("RGBA")
        canvas.paste(b, ((W - b.width) // 2, (H - b.height) // 2), b)
    canvas.save(out_png)


def word_card(text, brand, font, lay, out_png):
    """A 16:9 editorial riso word card (cream paper, the word in Anton charcoal + an orange accent bar),
    centered so it survives the top-region crop. Used for punchy single words like 'NOTHING' - it flows
    through the same motion engine as the screencap."""
    from PIL import Image, ImageDraw, ImageFont
    paper, ink, orange = (232, 220, 196), (28, 27, 23), (233, 106, 60)   # #E8DCC4 / #1C1B17 / #E96A3C
    W16, H16 = 1920, 1080
    img = Image.new("RGB", (W16, H16), paper); d = ImageDraw.Draw(img)
    words = text.upper().split()
    if len(words) > 4:                                  # GUARD: a word card is 1-4 words, never a sentence
        words = words[:4]
    maxw = W16 * 0.52                                   # must fit the top-region ZOOM crop (~center 1040px), not the full frame
    fs = 300; f = ImageFont.truetype(font, fs)          # shrink so the longest word fits the visible crop
    while fs > 60 and max((d.textlength(w, font=f) for w in words), default=0) > maxw:
        fs -= 14; f = ImageFont.truetype(font, fs)
    lines, cur = [], ""                                 # wrap onto centered lines that fit (never off-frame)
    for w in words:
        cand = (cur + " " + w).strip()
        if d.textlength(cand, font=f) <= maxw:
            cur = cand
        else:
            lines.append(cur); cur = w
    if cur:
        lines.append(cur)
    ls = int(fs * 1.08); block = len(lines) * ls; wmax = 0
    y = H16 // 2 - block // 2 + ls // 2
    for ln in lines:
        d.text((W16 // 2, y), ln, font=f, fill=ink, anchor="mm"); wmax = max(wmax, d.textlength(ln, font=f)); y += ls
    by = H16 // 2 + block // 2 + int(fs * 0.10)
    d.rectangle([W16 // 2 - wmax / 2, by, W16 // 2 + wmax / 2, by + 24], fill=orange)
    img.save(out_png)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.json"))
    ap.add_argument("--avatar", required=True)
    ap.add_argument("--screencap", required=True)
    ap.add_argument("--cutplan", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    cfg = json.load(open(args.config))
    brand, lay = cfg["brand"], cfg["layout"]
    font = os.path.join(HERE, brand["font"])
    plan = json.load(open(args.cutplan))
    work = tempfile.mkdtemp(prefix="compose_")
    dur = probe_dur(args.avatar)

    # 1) captions
    wav = os.path.join(work, "av.wav")
    run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", args.avatar, "-ar", "16000", "-ac", "1", wav])
    words = fix_transcription(whisper_words(wav))
    ass = os.path.join(work, "cap.ass"); make_captions(words, brand, ass)

    # 2) shots. A shot is sourced from the screencap (ss) OR a 16:9 image (a generated nano_banana
    #    image already on disk, or a "text" word card we render here). Pre-render the word cards first.
    wc = 0
    for s in plan.get("opening_shots", []) + plan.get("beat_shots", []):
        if s.get("text") and not s.get("image"):
            wp = os.path.join(work, "word_%02d.png" % wc); wc += 1
            word_card(s["text"], brand, font, lay, wp); s["image"] = wp
    shots = build_shots(plan, words, dur)
    # 3) render each (always in motion; same engine for screencap and 16:9 images)
    concat = os.path.join(work, "concat.txt"); cf = open(concat, "w")
    cover = "scale=1080:1000:force_original_aspect_ratio=increase,crop=1080:1000,setsar=1,fps=30"
    cur_z = 1.0                                       # running zoom level so a "zcont" shot continues the push
    for i, (st, ss, sdur, mv, an, img) in enumerate(shots):
        cont = isinstance(mv, str) and mv.endswith("~c")
        bmv = mv[:-2] if cont else mv                 # strip the continuation marker
        zstart = cur_z if cont else 1.0
        seg = os.path.join(work, "s%02d.mp4" % i)
        if img and img.lower().endswith((".mp4", ".mov", ".webm", ".m4v")):   # a video CLIP (e.g. Claude brand intro) - play as-is, it has its own motion
            run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-ss", str(ss), "-t", str(sdur),
                 "-i", img, "-vf", cover, "-an", "-r", "30", "-c:v", "libx264", "-pix_fmt", "yuv420p", seg])
            cur_z = 1.0
        elif img:                                     # 16:9 generated image / word card -> loop + motion
            run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-loop", "1", "-t", str(sdur),
                 "-i", img, "-vf", shot_vf(ss, sdur, bmv, an, zstart), "-an", "-r", "30", "-c:v", "libx264", "-pix_fmt", "yuv420p", seg])
            cur_z = end_zoom(bmv, sdur, zstart)
        else:                                         # screencap moment
            run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-ss", str(ss), "-t", str(sdur),
                 "-i", args.screencap, "-vf", shot_vf(ss, sdur, bmv, an, zstart), "-an", "-r", "30", "-c:v", "libx264", "-pix_fmt", "yuv420p", seg])
            cur_z = end_zoom(bmv, sdur, zstart)
        cf.write("file '%s'\n" % seg)
    cf.close()
    top = os.path.join(work, "top.mp4")
    run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", concat,
         "-r", "30", "-c:v", "libx264", "-pix_fmt", "yuv420p", top])

    # 4) hook (first N s), end-card (last N s), + optional FULL-FRAME cards from the cut-plan.
    #    A "cards" entry = {"at": sec, "dur": sec(=1), "text": "STEP 1"} (or "image": path for a proof
    #    card). Each card CUTS IN full-frame - a clean break from the stacked layout. Great for
    #    step-by-step / tutorial scripts; omit entirely for show-off cuts.
    hook = os.path.join(work, "hook.png"); make_card(plan["hook_title"], brand["hook"], font, hook, max_words=4)
    etext = plan.get("endcard_text") or brand["endcard"].get("text") or "Learn Claude Code. Link in bio"
    ecard = os.path.join(work, "ec.png"); make_card(etext, brand["endcard"], font, ecard, max_w=760)
    ecs = round(dur - brand["endcard"]["seconds"], 2)
    hooks = brand["hook"]["show_seconds"]
    cstyle = brand.get("card", brand["hook"])
    cards = []  # (full_frame_png, at, end)
    for k, cd in enumerate(plan.get("cards", [])):
        p = os.path.join(work, "card%02d.png" % k)
        fullframe_card(cd.get("image") or cd["text"], cstyle, font, lay["bg_color"], p, is_image=bool(cd.get("image")))
        a0 = float(cd["at"]); cards.append((p, a0, round(a0 + cd.get("dur", 1.0), 2)))

    # 5) composite: stack -> hook -> end-card -> captions, THEN full-frame cards on top (they cut over
    #    everything during their window). inputs: 0=top, 1=avatar, 2=hook, 3=endcard, 4..=cards.
    crop_r = lay["avatar_crop_ratio"]; av_h = lay["avatar_h"]; seam = lay["seam_y"]
    chain = ("[1:v]crop=ih*%g:ih,scale=1080:%d,setsar=1[av];"
             "color=c=0x%s:s=1080x1920:r=30[bg];"
             "[bg][0:v]overlay=0:0[a];[a][av]overlay=0:%d[b];"
             "[b][2:v]overlay=(W-w)/2:%d:enable='between(t\\,0\\,%g)'[c];"
             "[c][3:v]overlay=(W-w)/2:%d:enable='between(t\\,%g\\,%g)'[e];"
             "[e]subtitles=%s:fontsdir=%s[s];"
             % (crop_r, av_h, lay["bg_color"], seam, brand["hook"]["y"], hooks,
                brand["endcard"]["y"], ecs, dur, ass, os.path.join(HERE, "assets")))
    inputs = ["-i", top, "-i", args.avatar, "-i", hook, "-i", ecard]
    cur, nxt_in = "s", 4
    for ci, (p, a0, a1) in enumerate(cards):
        inputs += ["-i", p]
        chain += "[%s][%d:v]overlay=0:0:enable='between(t\\,%g\\,%g)'[fc%d];" % (cur, nxt_in, a0, a1, ci)
        cur, nxt_in = "fc%d" % ci, nxt_in + 1
    chain = chain.rstrip(";")
    run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error"] + inputs +
        ["-filter_complex", chain, "-map", "[%s]" % cur, "-map", "1:a",
         "-t", str(dur), "-r", "30", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac",
         "-movflags", "+faststart", args.out])
    print("done ->", args.out, "(%.1fs, %d shots, %d cards)" % (dur, len(shots), len(cards)))


if __name__ == "__main__":
    main()
