# Short-form pipeline

> **Read [`ARCHITECTURE.md`](ARCHITECTURE.md) first** — the complete, current reference (every module, the cut-plan format, all the hard-won rules, IDs/accounts, gotchas, and the current scheduled state). The overview below is the original early version.

Turn one long-form video (screen recording + timestamped transcript) into captivating ~45-60s vertical shorts (1080x1920): HeyGen avatar at the bottom, your screen recording up top, karaoke captions on the seam, a blue hook for the first 3s, and one fixed "Learn Claude Code. Link in bio" end-card. Built for a non-developer audience.

One finished short = **a script + a cut-plan**. The hard parts (HeyGen render, Whisper captions, motion b-roll, hook/end-card, title cards) are reusable.

---

## The flow

```
long-form (screencap.mp4 + transcript)
   │
   1. SCENE ANALYSIS  (Claude/Opus, line-by-line, SKIP the intro)
   │     -> a visual-moments library: {timecode, what's on screen, region L/C/R, impact}
   │
   2. SCRIPTS         (Claude: Sonnet draft -> Opus verify), 3 angles: proof / contrarian / transformation
   │     -> 5th-grade, non-dev, keeps the keyword draws, narrative flow, leads with the result, ends on impact
   │
   3. MATCH           (Claude) each script beat -> the long-form moment that actually shows it + region + move
   │     -> a cut-plan JSON (see example_cutplan.json)
   │
   4. render_avatar.py   script -> HeyGen v3 avatar mp4 (+ SSML <break> pauses between thought-lines)
   │
   5. compose.py         avatar + screencap + cut-plan -> finished vertical cut
```

Steps 1-3 are LLM judgment (run via the workflows we proved, or by hand). Steps 4-5 are deterministic scripts.

---

## Run it

```bash
# one-time: source your API keys
set -a && source .env && set +a

# 4) render the avatar from a script (adds sentence pauses automatically)
python3 render_avatar.py --script my_script.txt --out work/avatar.mp4

# 5) composite to the finished cut
python3 compose.py \
  --avatar work/avatar.mp4 \
  --screencap "/path/to/long-form-screencap.mp4" \
  --cutplan my_cutplan.json \
  --out ~/Desktop/my-short.mp4
```

`compose.py` Whispers the avatar for caption timing, builds the shots, renders each b-roll cut, then composites. No API key needed for step 5.

---

## The cut-plan (`example_cutplan.json`)

```jsonc
{
  "hook_title": "OPUS 4.8 BUILT AN AGENTIC OS IN 15 MINUTES!",  // blue card, first 3s
  "endcard_text": "Learn Claude Code. Link in bio",             // FIXED on-screen CTA (default lives in config), same on every platform
  "opening_shots": [        // fire at FIXED times -> payoff-first, new action every 3-6s
    { "at": 0.0, "ss": 843, "move": "zoomin", "anchor": "c" }    // ss = second in the screencap
  ],
  "beat_shots": [           // resolve a TRIGGER word against the avatar transcript
    { "trigger": "followers", "ss": 849, "move": "push", "anchor": "r" },
    { "trigger": "people", "ss": 879, "move": "push", "anchor": "r", "offset": 4.0 }  // sub-cut: reuses the cached "people" time + 4s
  ],
  "cards": [                // OPTIONAL: 1s FULL-FRAME cut-in cards (a clean break from the stacked layout,
    { "at": 8.0, "dur": 1.4, "text": "STEP 1" },                      //   avatar + screencap hidden, then cut back)
    { "at": 30.0, "dur": 1.2, "image": "assets/proof-headshot.png" }  // text card OR a proof-card image
  ]
}
```

- **`trigger`** can be alternatives to survive Whisper variance: `"fifteen|15"`, `"ultra|ultracode"`.
- **`move`** (always in motion, never static): `zoomin` `zoomout` `push` (faster zoom into a panel) `panLR` `panRL` (sweep across, clamped so no edge shows).
- **`anchor`**: `l` / `c` / `r` -> which third of the screen to focus (drops left, content center, metrics right).

---

## Rules baked in (the spec, learned the hard way)

- **Lead with the payoff.** Hero shot (the result/dashboard) in the first 2-3s. Never make them wait.
- **New action every 3-6s. Nothing static** — every shot zooms or pans.
- **Motion + moment variety (enforced in `compose.py`).** No move, and no zoom-type move (zoomin/zoomout/push), more than twice in a row — the 3rd becomes a region-aware pan, so it never over-indexes on zooms. And no cutting to the same screencap moment within a few shots. The matcher is told the same; the compositor guarantees it.
- **Region-accurate framing.** Punch to the panel actually being named, not always center.
- **Mix sources.** Even when one thing is the subject, cut back and forth a few times.
- **Code-density matches the ANGLE.** Show-off / proof / contrarian = minimize code, lead with the result, keep tool shots to brief glimpses. TUTORIAL / how-to = show the steps and code, that IS the value (and use STEP cards).
- **Step format is optional and a TEASER.** The script only goes stepped when the topic is genuinely a sequence (a setup/workflow/"how I do X"). Even then, tease high-level steps to drive the comment - never give the full tutorial away (that lives in the long-form / community). Proof + contrarian have no steps. Most cuts (incl. AIOS) use none. The script-writer must detect "is this a sequence?" before reaching for STEP cards.
- **Pauses.** SSML `<break>` only between complete thoughts (the writer puts each thought on its own line), never after every sentence. Punchy continuations and transition sentences flow. Exclamation points welcome.
- **One CTA, every platform.** No per-video comment-to-DM / ManyChat. A single fixed on-screen end-card ("Learn Claude Code. Link in bio", set in `config.json`), never spoken, pops up at the end.
- **No lens flares / fancy wipes.** Clean hard cuts + the title cards are the transitions.

## Visual elements: when to use what

- **B-roll clips:** rarely necessary — the screencap is usually the interesting visual. Add only when a beat is visually dead.
- **Proof / section cards** (a headshot, a tweet, a stat): the most useful "b-roll", easy to make, always on-brand. Use the `cards` array with `image` or `text`.
- **Step / section title cards:** yes for tutorials; punctuate and orient. `cards` array with `text`. They **cut in full-frame** (a clean break from the stacked boxes), then cut back, like the reference.
- **Lens flares / swipe transitions:** skip.

---

## Files

| File | What |
|---|---|
| `config.json` | Your HeyGen IDs, creator profile, Blotato accounts, brand tokens, layout geometry |
| `render_avatar.py` | script -> HeyGen v3 avatar mp4, auto SSML pauses |
| `compose.py` | avatar + screencap + cut-plan -> finished cut (captions, motion b-roll, hook, cards, end-card) |
| `example_cutplan.json` | the AIOS proof cut, mixed sources |
| `assets/` | Anton font (caption/card typeface) |
| `broll/` | b-roll library + `manifest.json` (TABLED — see below) |

## B-roll library (tabled)

`broll/manifest.json` is the gated library: each clip is tagged by `tool`, and the matcher may only use a clip whose tool is null (agnostic) or appears in the current script — so a Graphify clip never enters an AIOS video. Currently holds sample brand clips, but clips with burned-in captions or green screen are NOT usable here. The infrastructure stays for caption-free clips later (raw recordings, dedicated b-roll, stock).

## Known gaps / next

- Wire steps 1-3 into a single runner (`pipeline.py`) so a new long-form goes end-to-end.
- Build the contrarian + transformation angle cuts (the A/B set).
- Trigger->time still depends on Whisper; the cache + `a|b` alternatives + min-duration merge handle most variance, but verify the cut on a new video.
