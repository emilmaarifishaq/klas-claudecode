#!/usr/bin/env python3
"""
pipeline.py - one long-form video -> N finished short-form cuts, end to end.

  scene-analyze (claude) -> moments library
    -> per angle: write script (claude) -> match to a cut-plan (claude)
       -> render_avatar.py (HeyGen) -> compose.py -> finished short

The three judgment steps run headless via `claude -p` using the prompts in prompts/.
The render + composite steps are the proven deterministic scripts.

Usage:
  set -a && source .env && set +a        # HeyGen key, for the avatar render
  python3 pipeline.py \
      --transcript "/path/to/long-form-transcript.txt" \
      --screencap  "/path/to/long-form-screencap.mp4" \
      --out-dir ./out/my-video
  # options:
  #   --angles proof,contrarian        (default: proof,contrarian,transformation)
  #   --avatar /tmp/existing.mp4        (reuse an avatar, skip HeyGen - only valid for 1 angle / testing)
  #   --no-compose                      (stop after the cut-plans; render nothing)
"""
import argparse, concurrent.futures, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ANGLES = ["proof", "contrarian", "transformation"]


def claude(prompt_text, timeout=900):
    """Run headless claude and return its stdout text."""
    r = subprocess.run(["claude", "-p", prompt_text], capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError("claude -p failed (%d): %s" % (r.returncode, r.stderr[:1500]))
    return r.stdout


def claude_json(prompt_text):
    """Run claude and parse a single JSON object out of the response (tolerates ``` fences / prose)."""
    txt = claude(prompt_text)
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", txt, re.S) or re.search(r"(\{.*\})", txt, re.S)
    if not m:
        raise RuntimeError("no JSON in claude output:\n" + txt[:1500])
    return json.loads(m.group(1))


def fill(template_name, **kw):
    t = open(os.path.join(HERE, "prompts", template_name)).read()
    for k, v in kw.items():
        t = t.replace("{%s}" % k, str(v))
    return t


_global_cfg = json.load(open(os.path.join(HERE, "config.json")))
_paths_cfg = _global_cfg.get("paths", {})
_hook_vault_raw = _paths_cfg.get("hook_vault", "")
HOOK_VAULT = os.path.expanduser(_hook_vault_raw) if _hook_vault_raw else ""
HF = os.path.expanduser(_paths_cfg.get("higgsfield_cli", "higgsfield"))


def hook_vault_text():
    """Proven hook patterns injected into write_script.txt - the script's hooks must come from here."""
    if not HOOK_VAULT:
        return "(hook vault path not configured in config.json paths.hook_vault - use the PROVEN OPENERS below as the pattern source)"
    try:
        return open(HOOK_VAULT).read()
    except OSError:
        print("[warn] hook vault not found at %s - falling back to PROVEN OPENERS only" % HOOK_VAULT,
              flush=True)
        return "(hook vault unavailable - use the PROVEN OPENERS below as the pattern source)"
RISO_BASE = ("drawn in a risograph print editorial style, TWO INKS ONLY burnt orange #E96A3C and charcoal "
             "#1C1B17 on cream paper #E8DCC4, halftone grain, offset-print texture, bold simple shapes, "
             "CONTENT CENTERED with generous cream margins, nothing critical near the edges, NO text, no "
             "words, no letters, no numbers.")
STYLE = {
    "infographic": ("A CLEAR FLAT INFOGRAPHIC that instantly conveys the idea with simple bold icons, "
                    "symbols and arrows, easy to read at a glance, literal not abstract. It shows: "),
    "illustration": ("A bold editorial ILLUSTRATION - one clear scene or figure that captures the moment "
                     "with clarity and a little feeling. It shows: "),
}


def gen_image(concept, out_path, style="infographic", ref=None, timeout=300):
    """Generate one on-brand 16:9 riso b-roll image via Higgsfield nano_banana_2 (same aspect as the
    screencap, so it flows through the same motion engine). `style` = 'infographic' or 'illustration'
    (chosen by the matcher); `ref` = a reference photo path for character consistency (Duncan's look
    when the illustration depicts him). Retries transient API errors."""
    import urllib.request, time
    prompt = STYLE.get(style, STYLE["infographic"]) + concept + ". " + RISO_BASE
    cmd = [HF, "generate", "create", "nano_banana_2", "--prompt", prompt,
           "--aspect_ratio", "16:9", "--resolution", "1k", "--wait", "--json"]
    if ref:
        cmd += ["--image", ref]
    last = ""
    for _ in range(3):
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if r.returncode == 0:
            try:
                urllib.request.urlretrieve(json.loads(r.stdout)[0]["result_url"], out_path)
                return
            except Exception as e:
                last = str(e)
        else:
            last = (r.stderr or "")[:200]
        time.sleep(4)
    raise RuntimeError("gen failed after retries: " + last)


def load_library():
    """Load the curated brand-clip library (assets/broll/manifest.json). Returns (clips, prompt_text)."""
    try:
        clips = json.load(open(os.path.join(HERE, "assets", "broll", "manifest.json")))["clips"]
    except Exception:
        return [], "(no clip library)"
    rows = ['- "%s" [%s, use:%s] %s' % (c["id"], c.get("relevance"), ",".join(c.get("use", [])),
                                         c.get("description", "")) for c in clips]
    return clips, "\n".join(rows)


def _clip_path(c):
    f = c["file"]
    return f if os.path.isabs(f) else os.path.join(HERE, f)


def resolve_clips(cp, clips_lib):
    """Turn a matcher's {"clip": "<id>"} into an image=<clip file> + ss=<best segment start> shot."""
    by_id = {c["id"]: c for c in clips_lib}
    for s in cp.get("opening_shots", []) + cp.get("beat_shots", []):
        cid = s.get("clip")
        if not cid:
            continue
        c = by_id.get(cid)
        if c:
            s["image"] = _clip_path(c)
            s["ss"] = (c.get("best_segments") or [{}])[0].get("start", 0)
        else:
            print("WARN: unknown clip id:", cid)
        s.pop("clip", None)


def add_cold_open(cp, clips_lib, prefer="claude-code", seconds=1.5):
    """Prepend a relevance-matched premium INTRO clip as a ~1.5s Claude cold open; shift the opening."""
    intros = [c for c in clips_lib if "intro" in c.get("use", [])]
    if not intros:
        return
    intros.sort(key=lambda c: (c.get("relevance") != prefer, not c.get("premium")))
    c = intros[0]
    for s in cp.get("opening_shots", []):
        s["at"] = round(s.get("at", 0) + seconds, 2)
    cp.setdefault("opening_shots", []).insert(0, {"at": 0.0, "image": _clip_path(c),
        "ss": (c.get("best_segments") or [{}])[0].get("start", 0), "move": "zoomin", "anchor": "c"})
    print("[cold-open]", c["id"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--transcript", required=True)
    ap.add_argument("--screencap", required=True)
    ap.add_argument("--out-dir", default=os.path.join(HERE, "out"))
    ap.add_argument("--angles", default=",".join(ANGLES))
    ap.add_argument("--avatar", help="reuse an existing avatar mp4 (skip HeyGen render)")
    ap.add_argument("--no-compose", action="store_true", help="stop after writing the cut-plans")
    ap.add_argument("--from-cutplan", action="store_true",
                    help="skip scene/script/match; load existing cutplan_<angle>.json + script_<angle>.txt and re-render from stage 3b onward")
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    transcript = open(args.transcript).read()
    angles = [a.strip() for a in args.angles.split(",") if a.strip()]
    _cfg = json.load(open(os.path.join(HERE, "config.json")))
    creator = _cfg.get("creator", {})
    char_ref = _cfg.get("character_ref")
    if char_ref and not os.path.isabs(char_ref):
        char_ref = os.path.join(HERE, char_ref)
    if char_ref and not os.path.exists(char_ref):
        print("note: character_ref not found (%s) - 'character: me' shots render generic" % char_ref, flush=True)
        char_ref = None
    clips_lib, lib_text = load_library()

    # Collect per-angle data: either from Claude (normal) or from disk (--from-cutplan)
    angle_data = {}  # angle -> {"script": str, "cp": dict, "cppath": str}

    if args.from_cutplan:
        # --from-cutplan: load existing files, skip all Claude calls
        print("[pipeline] --from-cutplan: loading existing cut-plans (no Claude calls)", flush=True)
        for angle in angles:
            cppath = os.path.join(args.out_dir, "cutplan_%s.json" % angle)
            scpath = os.path.join(args.out_dir, "script_%s.txt" % angle)
            missing = [p for p in (cppath, scpath) if not os.path.exists(p)]
            if missing:
                print("[%s] ERROR: required file(s) missing, skipping angle: %s" % (angle, missing), flush=True)
                continue
            cp = json.load(open(cppath))
            script = open(scpath).read()
            angle_data[angle] = {"script": script, "cp": cp, "cppath": cppath}
            print("[%s] loaded cut-plan (%d opening + %d beats + %d cards) and script"
                  % (angle, len(cp.get("opening_shots", [])), len(cp.get("beat_shots", [])),
                     len(cp.get("cards", []))), flush=True)
    else:
        # 1) scene analysis -> moments library
        print("[scene] analyzing long-form...", flush=True)
        moments = claude_json(fill("scene_analyze.txt", transcript=transcript))
        json.dump(moments, open(os.path.join(args.out_dir, "moments.json"), "w"), indent=2)
        print("[scene] %d moments, intro ends at %ss"
              % (len(moments.get("moments", [])), moments.get("intro_ends_sec")), flush=True)

        for angle in angles:
            print("\n=== angle: %s ===" % angle, flush=True)
            # 2) script
            print("[%s] writing script..." % angle, flush=True)
            sc = claude_json(fill("write_script.txt", angle=angle, transcript=transcript,
                                  hook_vault=hook_vault_text(),
                                  proof_stats=creator.get("proof_stats", ""),
                                  community_name=creator.get("community_name", "your community")))
            open(os.path.join(args.out_dir, "script_%s.txt" % angle), "w").write(sc["script"])
            video_type = sc.get("video_type", "tutorial")
            cta_noun = (sc.get("cta_noun") or "").strip()
            if video_type == "showcase" and cta_noun:
                endcard_text = "Get %s. Link in bio" % cta_noun
            else:
                _default_endcard = _cfg.get("brand", {}).get("endcard", {}).get("text", "Learn more.\nLink in bio").replace("\n", " ")
                endcard_text = _default_endcard
            json.dump({"video_type": video_type, "cta_noun": cta_noun, "endcard_text": endcard_text},
                      open(os.path.join(args.out_dir, "meta_%s.json" % angle), "w"), indent=2)
            print("[%s] hook: %s | stepped=%s | type=%s | endcard: %s"
                  % (angle, sc["hook_title"], sc.get("stepped"), video_type, endcard_text), flush=True)

            # 3) match -> cut-plan
            print("[%s] matching b-roll..." % angle, flush=True)
            stepped_note = (("This script IS stepped. Add a 'cards' entry per step: a full-frame STEP card "
                             "{\"at\": <sec the step starts in the audio - estimate>, \"dur\": 1.2, \"text\": \"%s\"}.")
                            % " / ".join(sc.get("steps", []))) if sc.get("stepped") else \
                "This script is NOT stepped - leave \"cards\" an empty array."
            cp = claude_json(fill("match.txt", angle=angle, script=sc["script"], moments=json.dumps(moments),
                                  hook_title=sc["hook_title"], endcard_text=endcard_text,
                                  stepped_note=stepped_note, library=lib_text))
            cp["hook_title"] = sc["hook_title"]                      # never let the matcher reword the script's hook
            resolve_clips(cp, clips_lib)                              # matcher-chosen library clips -> file paths
            if any(k in sc["script"].lower() for k in ("claude", "opus", "agentic", "ultra", "anthropic")):
                add_cold_open(cp, clips_lib)                          # premium Claude cold open (~1.5s)
            cppath = os.path.join(args.out_dir, "cutplan_%s.json" % angle)
            json.dump(cp, open(cppath, "w"), indent=2)
            print("[%s] cut-plan: %d opening + %d beats + %d cards"
                  % (angle, len(cp.get("opening_shots", [])), len(cp.get("beat_shots", [])),
                     len(cp.get("cards", []))), flush=True)
            angle_data[angle] = {"script": sc["script"], "cp": cp, "cppath": cppath}

    if args.no_compose:
        print("\ndone (--no-compose). outputs in", args.out_dir, flush=True)
        return

    # Determine which angles actually have data to render
    render_angles = [a for a in angles if a in angle_data]

    # 4) Avatar rendering — parallel when multiple angles, serial for --avatar reuse path
    import hashlib, shutil

    def _render_avatar(angle):
        """Render one angle's avatar via HeyGen. Returns avpath on success, raises on failure."""
        avpath = os.path.join(args.out_dir, "avatar_%s.mp4" % angle)
        script = angle_data[angle]["script"]
        print("[%s] avatar: starting HeyGen render..." % angle, flush=True)
        subprocess.run([sys.executable, os.path.join(HERE, "render_avatar.py"),
                        "--text", script, "--out", avpath], check=True)
        print("[%s] avatar: render complete -> %s" % (angle, avpath), flush=True)
        return avpath

    if args.avatar:
        # Single reuse path (testing / single-angle): no parallel needed
        avatar_paths = {angle: args.avatar for angle in render_angles}
    else:
        # Parallel avatar renders — all angles concurrently
        print("\n[pipeline] rendering %d avatar(s) in parallel..." % len(render_angles), flush=True)
        avatar_paths = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(render_angles)) as ex:
            fut_to_angle = {ex.submit(_render_avatar, a): a for a in render_angles}
            for fut in concurrent.futures.as_completed(fut_to_angle):
                angle = fut_to_angle[fut]
                try:
                    avatar_paths[angle] = fut.result()
                except Exception as e:
                    print("[%s] avatar render FAILED: %s — skipping angle" % (angle, e), flush=True)
        print("[pipeline] all avatar renders done.\n", flush=True)

    # Per-angle: 3b gen b-roll -> 4b trim -> 5 compose
    for angle in render_angles:
        if angle not in avatar_paths:
            continue  # avatar failed, already logged
        cp = angle_data[angle]["cp"]
        cppath = angle_data[angle]["cppath"]
        avpath = avatar_paths[angle]

        print("\n=== angle: %s ===" % angle, flush=True)

        # 3b) generate riso b-roll images for any "gen" beats. CACHED by (concept+style+ref) across angles
        #     AND re-runs, so an identical visual (e.g. "walking out the door") is generated once, not paid for again.
        gen_dir = os.path.join(args.out_dir, "gen_%s" % angle); os.makedirs(gen_dir, exist_ok=True)
        cache_dir = os.path.join(args.out_dir, "gen_cache"); os.makedirs(cache_dir, exist_ok=True)
        gi = 0
        for s in cp.get("opening_shots", []) + cp.get("beat_shots", []):
            if s.get("gen") and not s.get("image"):
                ref = char_ref if s.get("character") == "me" else None
                key = hashlib.md5(("%s|%s|%s" % (s["gen"].strip().lower(), s.get("style", "infographic"),
                                                 ref or "")).encode()).hexdigest()[:16]
                cached = os.path.join(cache_dir, key + ".png")
                if os.path.exists(cached):
                    s["image"] = cached
                    print("[%s] reused cached b-roll: %s" % (angle, s["gen"][:40]), flush=True)
                    continue
                p = os.path.join(gen_dir, "g%02d.png" % gi); gi += 1
                print("[%s] gen b-roll image: %s" % (angle, s["gen"][:48]), flush=True)
                try:
                    gen_image(s["gen"], p, s.get("style", "infographic"), ref)
                    shutil.copy(p, cached); s["image"] = cached
                except Exception as e:
                    print("  gen failed (%s) - beat falls back to its ss" % e, flush=True)
        if gi:
            json.dump(cp, open(cppath, "w"), indent=2)
            print("[%s] generated %d b-roll image(s)" % (angle, gi), flush=True)

        # 4b) tighten the over-long SSML pauses (slight jump cuts) before whisper + compose
        trimmed = os.path.join(args.out_dir, "avatar_%s_trim.mp4" % angle)
        subprocess.run([sys.executable, os.path.join(HERE, "trim_pauses.py"), "--in", avpath, "--out", trimmed], check=True)
        avpath = trimmed

        # 5) compose
        print("[%s] compositing..." % angle, flush=True)
        outp = os.path.join(args.out_dir, "short_%s.mp4" % angle)
        subprocess.run([sys.executable, os.path.join(HERE, "compose.py"),
                        "--avatar", avpath, "--screencap", args.screencap,
                        "--cutplan", cppath, "--out", outp], check=True)
        print("[%s] -> %s" % (angle, outp), flush=True)

    print("\ndone. outputs in", args.out_dir, flush=True)


if __name__ == "__main__":
    main()
