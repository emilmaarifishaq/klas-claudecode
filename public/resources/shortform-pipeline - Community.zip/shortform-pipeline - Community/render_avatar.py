#!/usr/bin/env python3
"""
render_avatar.py - render a short-form avatar clip via the HeyGen v3 API.

Adds SSML <break> pauses between sentences (for comprehension), keeps the
voice speed/pitch from config, polls until done, downloads the mp4.

Usage:
    python render_avatar.py --script script.txt --out work/avatar.mp4 [--config config.json]
    # or pass the script inline:
    python render_avatar.py --text "First sentence. Second sentence." --out work/avatar.mp4

Requires HEYGEN_API_KEY in the environment (set it in .env and run: set -a && source .env && set +a).
"""
import argparse, json, os, re, sys, time, urllib.request, urllib.error

API = "https://api.heygen.com/v3/videos"


def add_pauses(script, gap="0.4s"):
    """Insert an SSML <break> only BETWEEN thought-lines, NOT after every sentence. The writer puts each
    COMPLETE THOUGHT on its own line; punchy continuations ('...the door. No code. Nothing.') and
    transition/contrast sentences ('You stop watching. But Opus 4.8...') stay on the SAME line so they
    flow with no pause. HeyGen v3 honors <break time='Xs'/> and does not speak it (verified). If the
    script already contains <break ...> tags, it is passed through unchanged (writer placed them)."""
    if "<break" in script:
        return script.strip()
    lines = [l.strip() for l in script.splitlines() if l.strip()]
    return (" <break time='%s'/> " % gap).join(lines)


def post(url, payload, key):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"x-api-key": key, "Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)


def get(url, key):
    req = urllib.request.Request(url, headers={"x-api-key": key})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(os.path.dirname(__file__), "config.json"))
    ap.add_argument("--script"); ap.add_argument("--text")
    ap.add_argument("--out", required=True)
    ap.add_argument("--pause", default="0.4s")
    args = ap.parse_args()

    key = os.environ.get("HEYGEN_API_KEY")
    if not key:
        sys.exit("HEYGEN_API_KEY not set — run: set -a && source .env && set +a")
    cfg = json.load(open(args.config))["heygen"]

    script = args.text if args.text else open(args.script).read()
    body = {
        "type": "avatar", "avatar_id": cfg["avatar_id"], "voice_id": cfg["voice_id"],
        "script": add_pauses(script, args.pause),
        "title": "shortform avatar", "resolution": cfg["resolution"], "aspect_ratio": cfg["aspect_ratio"],
        "engine": {"type": cfg["engine"]},
        "expressiveness": cfg["expressiveness"],
        "motion_prompt": cfg["motion_prompt"],
        "voice_settings": {"speed": cfg["speed"], "pitch": cfg["pitch"]},
    }
    resp = post(API, body, key)
    vid = resp.get("data", {}).get("video_id")
    if not vid:
        sys.exit("no video_id: %s" % json.dumps(resp))
    print("video_id", vid, "- polling...")
    for i in range(60):
        d = get("%s/%s" % (API, vid), key).get("data", {})
        st = d.get("status")
        print("poll %d: %s" % (i + 1, st))
        if st == "completed":
            urllib.request.urlretrieve(d["video_url"], args.out)
            print("downloaded", args.out)
            return
        if st == "failed":
            sys.exit("FAILED: %s" % json.dumps(d))
        time.sleep(12)
    sys.exit("timed out")


if __name__ == "__main__":
    main()
