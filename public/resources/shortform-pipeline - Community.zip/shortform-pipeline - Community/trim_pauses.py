#!/usr/bin/env python3
"""
trim_pauses.py - shorten the silent gaps in a rendered avatar clip.

HeyGen renders the SSML <break> pauses ~2x longer than they should be. This detects the silent
gaps and keeps only a short target slice of each, removing the excess -> a tighter cut with slight
jump cuts in the talking head (which actually help retention). Run this on the avatar BEFORE
whispering / compositing, so captions + b-roll align to the trimmed timeline.

Usage:
    python3 trim_pauses.py --in work/avatar.mp4 --out work/avatar_trim.mp4 [--keep 0.32] [--min 0.45]
"""
import argparse, os, re, subprocess, tempfile


def detect_silences(path, noise, min_d):
    out = subprocess.run(["ffmpeg", "-i", path, "-af", "silencedetect=noise=%s:d=%s" % (noise, min_d),
                          "-f", "null", "-"], capture_output=True, text=True).stderr
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", out)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", out)]
    return list(zip(starts, ends[:len(starts)]))


def trim(inp, out, keep=0.32, noise="-34dB", min_d=0.45):
    dur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                         "-of", "csv=p=0", inp]).decode().strip())
    sil = detect_silences(inp, noise, 0.12)   # low min so the leading fade/silence is caught too
    cuts = []
    for s, e in sil:
        if s < 0.12:                          # LEADING silence/fade-in -> remove it ALL so the avatar is present at t=0
            cuts.append((0.0, e))
        elif (e - s) > keep + 0.06:           # mid / trailing pause -> keep `keep`s, drop the excess
            cuts.append((s + keep, e))
    if not cuts:
        subprocess.run(["cp", inp, out]); print("[trim] no excess silence found"); return dur, dur
    # SINGLE PASS: drop the cut ranges from VIDEO and AUDIO in ONE filtergraph so the two streams stay
    # frame-locked. (Cutting + re-encoding many separate segments drifts lip-sync - offsets accumulate.)
    expr = "+".join("between(t,%.3f,%.3f)" % (cs, ce) for cs, ce in cuts)
    vf = "select='not(%s)',setpts=N/FRAME_RATE/TB" % expr
    af = "aselect='not(%s)',asetpts=N/SR/TB" % expr
    subprocess.run(["ffmpeg", "-nostdin", "-y", "-loglevel", "error", "-i", inp,
                    "-vf", vf, "-af", af, "-r", "30", "-c:v", "libx264", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-ar", "44100", "-movflags", "+faststart",
                    "-video_track_timescale", "30000", out], check=True)
    ndur = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                                          "-of", "csv=p=0", out]).decode().strip())
    print("[trim] %d gaps removed single-pass (A/V locked) | %.1fs -> %.1fs (-%.1fs)"
          % (len(cuts), dur, ndur, dur - ndur))
    return dur, ndur


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--keep", type=float, default=0.32, help="seconds of pause to keep at each gap")
    ap.add_argument("--noise", default="-34dB")
    ap.add_argument("--min", type=float, default=0.45, help="only trim silences longer than this")
    a = ap.parse_args()
    trim(a.inp, a.out, a.keep, a.noise, a.min)


if __name__ == "__main__":
    main()
