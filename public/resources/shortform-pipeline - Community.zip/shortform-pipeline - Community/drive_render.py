#!/usr/bin/env python3
"""Render finished shorts from ALREADY-WRITTEN (hand-edited) cut-plans.
Replicates pipeline.py stages 3b->5 (gen b-roll cache, avatar, trim, compose)
WITHOUT re-running scene/script/match (which would overwrite manual cut-plan edits)."""
import os, sys, json, argparse, hashlib, shutil, subprocess
HERE = os.path.dirname(os.path.abspath(__file__))
import pipeline  # reuse gen_image

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--screencap", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--angles", required=True)
    args = ap.parse_args()

    cfg = json.load(open(os.path.join(HERE, "config.json")))
    char_ref = cfg.get("character_ref")
    if char_ref and not os.path.isabs(char_ref):
        char_ref = os.path.join(HERE, char_ref)
    if char_ref and not os.path.exists(char_ref):
        print("note: character_ref missing (%s)" % char_ref, flush=True); char_ref = None

    for angle in args.angles.split(","):
        angle = angle.strip()
        print("\n=== angle: %s ===" % angle, flush=True)
        cppath = os.path.join(args.out_dir, "cutplan_%s.json" % angle)
        scpath = os.path.join(args.out_dir, "script_%s.txt" % angle)
        cp = json.load(open(cppath))
        script = open(scpath).read()

        # 3b) gen b-roll (cached across angles + reruns)
        gen_dir = os.path.join(args.out_dir, "gen_%s" % angle); os.makedirs(gen_dir, exist_ok=True)
        cache_dir = os.path.join(args.out_dir, "gen_cache"); os.makedirs(cache_dir, exist_ok=True)
        gi = 0
        for s in cp.get("opening_shots", []) + cp.get("beat_shots", []):
            if s.get("gen") and not s.get("image"):
                ref = char_ref if s.get("character") == "me" else None
                key = hashlib.md5(("%s|%s|%s" % (s["gen"].strip().lower(), s.get("style", "infographic"),
                                                 ref or "")).encode()).hexdigest()[:16]
                cached = os.path.join(cache_dir, key + ".png")
                if os.path.exists(cached):
                    s["image"] = cached
                    print("[%s] reused cached b-roll: %s" % (angle, s["gen"][:40]), flush=True); continue
                p = os.path.join(gen_dir, "g%02d.png" % gi); gi += 1
                print("[%s] gen b-roll image: %s" % (angle, s["gen"][:48]), flush=True)
                try:
                    pipeline.gen_image(s["gen"], p, s.get("style", "infographic"), ref)
                    shutil.copy(p, cached); s["image"] = cached
                except Exception as e:
                    print("  gen failed (%s) - beat falls back to its ss" % e, flush=True)
        json.dump(cp, open(cppath, "w"), indent=2)

        # 4) avatar
        avpath = os.path.join(args.out_dir, "avatar_%s.mp4" % angle)
        if not os.path.exists(avpath):
            print("[%s] rendering avatar (HeyGen)..." % angle, flush=True)
            subprocess.run([sys.executable, os.path.join(HERE, "render_avatar.py"),
                            "--text", script, "--out", avpath], check=True)
        else:
            print("[%s] avatar exists, reusing" % angle, flush=True)

        # 4b) trim pauses
        trimmed = os.path.join(args.out_dir, "avatar_%s_trim.mp4" % angle)
        subprocess.run([sys.executable, os.path.join(HERE, "trim_pauses.py"),
                        "--in", avpath, "--out", trimmed], check=True)

        # 5) compose
        outp = os.path.join(args.out_dir, "short_%s.mp4" % angle)
        print("[%s] compositing..." % angle, flush=True)
        subprocess.run([sys.executable, os.path.join(HERE, "compose.py"),
                        "--avatar", trimmed, "--screencap", args.screencap,
                        "--cutplan", cppath, "--out", outp], check=True)
        print("[%s] -> %s" % (angle, outp), flush=True)
    print("\nALL DONE", flush=True)

if __name__ == "__main__":
    main()
