#!/usr/bin/env python3
"""
schedule.py - distribute a video's angle-cuts across social channels via Blotato.

For each angle: upload the cut, then post the punchy caption to the 4 video channels (YouTube /
Instagram / TikTok / Facebook) at a staggered Pacific time; the story caption posts to LinkedIn for
the ONE chosen angle. The 3 angles of the SAME video are spaced >=8 days apart at rotating times.

Slots AUTO-FILL: it reads the live Blotato queue and drops each angle on the next OPEN day, so new
videos stagger in around what is already scheduled (the video accounts hold only short-form posts).

Reads out/<slug>/short_<angle>.mp4 + out/<slug>/captions_<angle>.json (the pipeline's outputs).
Posts are SCHEDULED (future-dated) - Blotato returns a submission id immediately, no polling.

Usage:
    python3 schedule.py --slug <slug> [--angles proof,contrarian,transformation]
                        [--linkedin-angle contrarian] [--start-in-days 1] [--dry-run]
"""
import argparse, json, os, sys, datetime, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))


def _api_key():
    val = os.environ.get("BLOTATO_API_KEY")
    if val:
        return val
    env_path = os.path.join(HERE, ".env")
    if os.path.exists(env_path):
        for line in open(env_path):
            if line.startswith("BLOTATO_API_KEY="):
                return line.strip().split("=", 1)[1]
    raise RuntimeError("BLOTATO_API_KEY not set — add it to .env or run: export BLOTATO_API_KEY=your_key")


ENDPOINT = "https://mcp.blotato.com/mcp"
HEADERS = {"blotato-api-key": _api_key(), "Content-Type": "application/json",
           "Accept": "application/json, text/event-stream"}


def _call(method, arguments):
    body = json.dumps({"jsonrpc": "2.0", "method": "tools/call", "id": 1,
                       "params": {"name": method, "arguments": arguments}}).encode()
    req = urllib.request.Request(ENDPOINT, data=body, headers=HEADERS)
    raw = urllib.request.urlopen(req, timeout=120).read().decode()
    for line in raw.splitlines():
        line = line[6:] if line.startswith("data: ") else line
        if not line.strip():
            continue
        try:
            data = json.loads(line)
        except Exception:
            continue
        text = data.get("result", {}).get("content", [{}])[0].get("text", "{}")
        try:
            return json.loads(text)
        except Exception:
            raise RuntimeError("blotato error from %s: %s" % (method, text[:500]))
    return {"error": raw[:200]}


def upload(path):
    """Upload a local file to Blotato storage (presigned PUT). Returns the public URL."""
    r = _call("blotato_create_presigned_upload_url", {"filename": os.path.basename(path)})
    data = open(path, "rb").read()
    req = urllib.request.Request(r["presignedUrl"], data=data, method="PUT",
                                 headers={"Content-Type": "video/mp4"})
    urllib.request.urlopen(req, timeout=600)
    return r["publicUrl"]


def post(account_id, platform, text, media_url, when_iso, **extra):
    args = {"accountId": str(account_id), "platform": platform, "text": text,
            "mediaUrls": [media_url], "scheduledTime": when_iso, **extra}
    return _call("blotato_create_post", args)


# --- accounts (from config.json blotato section) ---
_blotato_cfg = json.load(open(os.path.join(HERE, "config.json")))["blotato"]
YT      = str(_blotato_cfg["youtube_account_id"])
IG      = str(_blotato_cfg["instagram_account_id"])
TT      = str(_blotato_cfg["tiktok_account_id"])
FB      = str(_blotato_cfg["facebook_account_id"])
FB_PAGE = str(_blotato_cfg["facebook_page_id"])
LI      = str(_blotato_cfg["linkedin_account_id"])
VIDEO_ACCOUNTS = {YT, IG, TT, FB}
TIMES_PT = [8, 13, 17]      # rotate the post time across a video's angles
LI_HOUR_PT = 11             # LinkedIn story posts late-morning Pacific


def pt_iso(date_str, hour_pt):
    """'YYYY-MM-DD' + Pacific hour -> ISO-8601 UTC string. PDT = UTC-7."""
    dt = datetime.datetime.strptime(date_str, "%Y-%m-%d") + datetime.timedelta(hours=hour_pt + 7)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


def occupied_video_days():
    """Dates (YYYY-MM-DD) that already hold a video-lane post, so new cuts land on OPEN days."""
    days, cursor, pages = set(), None, 0
    while True:
        args = {"limit": 50}
        if cursor:
            args["cursor"] = cursor
        r = _call("blotato_list_schedules", args); pages += 1
        for it in r.get("items", []):
            if str(it.get("account", {}).get("id")) in VIDEO_ACCOUNTS:
                days.add(it.get("scheduledAt", "")[:10])
        cursor = r.get("cursor")
        if not cursor or pages > 25:
            break
    return days


def find_slots(n, start, occupied, min_gap=8):
    """n open days, each >= min_gap days after the previous, skipping days already taken."""
    slots, earliest = [], start
    for _ in range(n):
        d = earliest
        while d.strftime("%Y-%m-%d") in occupied:
            d += datetime.timedelta(days=1)
        slots.append(d); earliest = d + datetime.timedelta(days=min_gap)
    return slots


def schedule_angle(slug, angle, url, date_str, hour, do_linkedin, trial=False):
    cap = json.load(open(os.path.join(HERE, "out", slug, "captions_%s.json" % angle)))
    vid = cap["video_caption"]; when = pt_iso(date_str, hour)
    out = []
    out.append(("youtube", post(YT, "youtube", cap["youtube_description"], url, when,
                                 title=cap["youtube_title"], privacyStatus="public",
                                 shouldNotifySubscribers=False, isMadeForKids=False,
                                 containsSyntheticMedia=True)))
    ig_extra = {"mediaType": "reel", "shareToFeed": True}
    if trial:
        ig_extra["trial"] = {"graduationStrategy": "SS_PERFORMANCE"}
    out.append(("instagram", post(IG, "instagram", vid, url, when, **ig_extra)))
    out.append(("tiktok", post(TT, "tiktok", vid, url, when, privacyLevel="PUBLIC_TO_EVERYONE",
                               isAiGenerated=True, disabledComments=False, disabledDuet=False,
                               disabledStitch=False, isBrandedContent=False, isYourBrand=False)))
    out.append(("facebook", post(FB, "facebook", vid, url, when, pageId=FB_PAGE, mediaType="reel")))
    if do_linkedin:
        out.append(("linkedin", post(LI, "linkedin", cap["linkedin_caption"], url, pt_iso(date_str, LI_HOUR_PT))))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slug", required=True)
    ap.add_argument("--angles", default="proof,contrarian,transformation")
    ap.add_argument("--linkedin-angle", default="contrarian")
    ap.add_argument("--start-in-days", type=int, default=1, help="earliest day to post (buffer for review; default tomorrow)")
    ap.add_argument("--spacing-days", type=int, default=8, help="min days between this video's angles (tighten for time-sensitive drops)")
    ap.add_argument("--dry-run", action="store_true", help="print the slot plan, schedule nothing")
    ap.add_argument("--trial", action="store_true", help="post Instagram reels as trial reels (non-followers only; SS_PERFORMANCE auto-graduation)")
    a = ap.parse_args()
    angles = [x.strip() for x in a.angles.split(",") if x.strip()]
    outdir = os.path.join(HERE, "out", a.slug)

    occupied = occupied_video_days()
    start = datetime.date.today() + datetime.timedelta(days=a.start_in_days)
    slots = find_slots(len(angles), start, occupied, min_gap=a.spacing_days)
    print("plan (filling open slots around %d existing video-lane day(s)):" % len(occupied))
    for i, ang in enumerate(angles):
        li = " + LinkedIn" if ang == a.linkedin_angle else ""
        print("  %-14s %s  %02d:00 PT  (YT/IG/TikTok/FB%s)"
              % (ang, slots[i].strftime("%Y-%m-%d"), TIMES_PT[i % len(TIMES_PT)], li))
    if a.dry_run:
        print("(dry run - nothing scheduled)"); return

    allres = []
    for i, ang in enumerate(angles):
        url = upload(os.path.join(outdir, "short_%s.mp4" % ang))
        ds, hr = slots[i].strftime("%Y-%m-%d"), TIMES_PT[i % len(TIMES_PT)]
        out = schedule_angle(a.slug, ang, url, ds, hr, ang == a.linkedin_angle, trial=a.trial)
        print("\n=== %s @ %s %02d:00 PT ===" % (ang.upper(), ds, hr))
        for platform, r in out:
            print("  %-10s -> %s" % (platform, r.get("postSubmissionId") or json.dumps(r)[:120]))
            allres.append({"angle": ang, "platform": platform, "result": r})
    json.dump(allres, open(os.path.join(outdir, "schedule_result.json"), "w"), indent=2)
    print("\ndone. saved out/%s/schedule_result.json" % a.slug)


if __name__ == "__main__":
    main()
