#!/usr/bin/env python3
"""
Transcribe a 1920x1080 video with Whisper and burn karaoke-style captions.
Same style as compose.py: Anton font, 3-word chunks, yellow highlight on current word.
Usage: python3 caption_1080p.py input.mp4 [output.mp4]
"""
import sys, os, re, subprocess, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_PATH = os.path.join(HERE, "assets/Anton-Regular.ttf")

# Caption config (adapted from config.json for 1920x1080)
CAP_SIZE    = 160
CAP_COLOR   = "FFFFFF"
CAP_HILITE  = "FFE600"
CAP_OUTLINE = 7
CAP_Y       = 540   # pixels from top in 1920x1080 frame (vertically centered)
WORDS_CHUNK = 2

CLAUDE_FIXES = {
    "cloud": "Claude", "quad": "Claude", "clod": "Claude",
    "claud": "Claude", "clode": "Claude",
}


def run(cmd, **kw):
    return subprocess.run(cmd, check=True, **kw)


def at(s):
    """Seconds → ASS timestamp H:MM:SS.cc"""
    h = int(s // 3600); m = int((s % 3600) // 60); sec = s % 60
    return "%d:%02d:%05.2f" % (h, m, sec)


def fix_transcription(words):
    out = []
    for tok, s, e in words:
        clean = tok.strip()
        fixed = CLAUDE_FIXES.get(clean.lower(), clean)
        # preserve capitalisation intent
        if clean[0].isupper() and not fixed[0].isupper():
            fixed = fixed.capitalize()
        out.append((fixed, s, e))
    return out


def whisper_words(audio_path):
    """Run Whisper with word timestamps, return [(word, start, end)]."""
    import whisper
    model = whisper.load_model("base")
    result = model.transcribe(audio_path, language="en", word_timestamps=True)
    words = []
    for seg in result["segments"]:
        for w in seg.get("words", []):
            words.append((w["word"].strip(), w["start"], w["end"]))
    return words


def make_ass(words, out_path, res_x=1920, res_y=1080):
    n = WORDS_CHUNK

    # merge stray punctuation tokens
    merged = []
    for t, s, e in words:
        if merged and (re.fullmatch(r"\.\d+", t) or t in ".,!?;:"):
            merged[-1][0] += t; merged[-1][2] = e
        else:
            merged.append([t, s, e])

    # group into n-word chunks, splitting on sentence endings
    groups, cur = [], []
    for w in merged:
        cur.append(w)
        if len(cur) >= n or w[0][-1:] in ".!?":
            groups.append(cur); cur = []
    if cur:
        groups.append(cur)

    flat = [(gi, wi, w) for gi, g in enumerate(groups) for wi, w in enumerate(g)]

    yellow = "{\\c&H%s%s%s&}" % (CAP_HILITE[4:6], CAP_HILITE[2:4], CAP_HILITE[0:2])
    white  = "{\\c&H%s%s%s&}" % (CAP_COLOR[4:6],  CAP_COLOR[2:4],  CAP_COLOR[0:2])
    cx     = res_x // 2

    hdr = (
        "[Script Info]\n"
        "ScriptType: v4.00+\n"
        f"PlayResX: {res_x}\nPlayResY: {res_y}\n"
        "ScaledBorderAndShadow: yes\nWrapStyle: 2\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, OutlineColour, BackColour, "
        "Bold, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Cap,Anton,{CAP_SIZE},"
        f"&H00{CAP_COLOR[4:6]}{CAP_COLOR[2:4]}{CAP_COLOR[0:2]},"
        f"&H00000000,&H00000000,0,{CAP_OUTLINE},0,5,60,60,0,1\n\n"
        "[Events]\n"
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )

    lines = [hdr]
    for j, (gi, wi, w) in enumerate(flat):
        st  = w[1]
        nxt = flat[j + 1][2][1] if j + 1 < len(flat) else w[2]
        en  = max(w[2], nxt)
        parts = []
        for q, ww in enumerate(groups[gi]):
            tok = ww[0].upper()
            parts.append(yellow + tok + white if q == wi else tok)
        lines.append(
            f"Dialogue: 0,{at(st)},{at(en)},Cap,,0,0,0,,{{\\pos({cx},{CAP_Y})}}"
            + " ".join(parts)
        )

    with open(out_path, "w") as f:
        f.write("\n".join(lines))


def caption_video(input_mp4, output_mp4):
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "audio.wav")
        ass = os.path.join(tmp, "cap.ass")

        print("Extracting audio…")
        run(["ffmpeg", "-y", "-i", input_mp4, "-vn", "-ar", "16000", "-ac", "1", wav],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        print("Transcribing with Whisper…")
        raw_words = whisper_words(wav)
        words = fix_transcription(raw_words)

        print(f"  {len(words)} words found")
        print("  Preview:", " ".join(w[0] for w in words[:20]))

        print("Building ASS captions…")
        make_ass(words, ass)

        print("Burning captions onto video…")
        font_dir = os.path.dirname(FONT_PATH)
        run([
            "ffmpeg", "-y",
            "-i", input_mp4,
            "-vf", f"subtitles={ass}:fontsdir={font_dir}",
            "-c:v", "libx264", "-crf", "18", "-preset", "fast",
            "-c:a", "aac", "-b:a", "192k",
            output_mp4
        ])

        print(f"Done → {output_mp4}")

        # also print full transcript
        print("\n--- TRANSCRIPT ---")
        print(" ".join(w[0] for w in words))
        print("---")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 caption_1080p.py input.mp4 [output.mp4]")
        sys.exit(1)
    inp = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else inp.replace(".mp4", "_captioned.mp4")
    caption_video(inp, out)
