# HVAC Landing Page Skill — Claude Code

Build a premium, conversion-focused one-page HVAC website for any company in minutes. Just paste a URL.

## What it does

1. **Scrapes** the company's website — extracts name, phone, services, colors, team photos, reviews
2. **Scaffolds** a Next.js 14+ project with Tailwind v4, Framer Motion, Phosphor Icons
3. **Builds** a full landing page: scroll-driven hero, honest differentiation section, services, reviews, team, CTA
4. **Verifies** — runs `npm run build`, fixes TypeScript errors, opens in browser

The hero uses a scroll-driven canvas frame sequence (61 bundled HVAC frames) that plays as the user scrolls. If you have a custom MP4 for the company, pass it and the frames will be replaced.

## Requirements

- [Claude Code](https://claude.ai/code) (CLI)
- Firecrawl MCP server configured in your Claude Code settings
- Node.js 18+ and `npx` available

## Install

Drop the `hvac-landing/` folder into your Claude Code skills directory:

```bash
# Mac/Linux
mv hvac-landing/ ~/.claude/skills/

# Then verify
ls ~/.claude/skills/hvac-landing/SKILL.md
```

## Usage

In any Claude Code session:

```
/hvac-landing https://thecompany.com/
```

Optional — pass a custom MP4 to replace the default frame sequence:

```
/hvac-landing https://thecompany.com/ path/to/truck-footage.mp4
```

The finished project is saved to `~/{slug}-website/` and opened in the browser automatically.

## What's included

```
hvac-landing/
├── SKILL.md                          # The skill prompt
├── README.md                         # This file
├── references/
│   ├── LandingPage.reference.tsx     # Gold-standard reference implementation
│   ├── architecture.md               # File templates, Tailwind v4 rules
│   ├── design-system.md              # Color extraction, typography, component patterns
│   ├── icp-copy.md                   # ICP copy formulas for each section
│   └── reddit-intelligence.md        # Homeowner language research (r/hvacadvice, Google Reviews)
└── starter/
    └── frames/                       # 61 pre-extracted HVAC scroll sequence frames
        ├── frame_001.jpg
        └── ... (frame_061.jpg)
```

## Customizing

- **Colors**: All brand tokens are in `app/globals.css` under `@theme {}`
- **Content**: Company-specific data lives in constants at the top of `components/LandingPage.tsx`
- **Copy**: The ICP patterns in `references/icp-copy.md` can be updated as you learn what converts
- **Frames**: Replace `starter/frames/` with your own sequence — update `FRAME_COUNT` in the component
