# Architecture Reference — HVAC Landing Page

## File Templates

### app/globals.css

```css
@import "tailwindcss";

@theme {
  /* ── Extracted Brand Colors ─────── */
  --color-brand-primary: {{HEX_PRIMARY}};       /* e.g. #4CBEA0 */
  --color-brand-primary-light: {{HEX_PRIMARY_LIGHT}};  /* 20% lighter */
  --color-brand-primary-pale: {{HEX_PRIMARY_PALE}};    /* 10% opacity on white */
  --color-brand-accent: {{HEX_ACCENT}};          /* e.g. #F47721 */
  --color-brand-accent-light: {{HEX_ACCENT_LIGHT}};

  /* ── Fixed Neutrals (do not change) */
  --color-ink: #1C1C1E;
  --color-ink-soft: #3D3D3F;
  --color-ink-muted: #6B6B6E;
  --color-warm: #F7F6F2;
  --color-warm-dark: #EEECE7;
  --color-border: #E5E4DF;

  /* ── Typography ───────────────── */
  --font-display: var(--font-outfit);
  --font-body: var(--font-geist-sans);
}

*, *::before, *::after { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
  background: #ffffff;
  color: #1C1C1E;
  font-family: var(--font-body), system-ui, sans-serif;
  -webkit-font-smoothing: antialiased;
}

@keyframes pulse-ring {
  0%   { transform: scale(1); opacity: 0.8; }
  80%  { transform: scale(1.8); opacity: 0; }
  100% { transform: scale(1.8); opacity: 0; }
}
@keyframes breathe {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.5; }
}

.animate-pulse-ring {
  position: relative;
}
.animate-pulse-ring::before {
  content: '';
  position: absolute;
  inset: -3px;
  border-radius: inherit;
  border: 2px solid var(--color-brand-accent, #F47721);
  animation: pulse-ring 2s cubic-bezier(0.36, 0.11, 0.89, 0.32) infinite;
  pointer-events: none;
}
.animate-breathe {
  animation: breathe 3s ease-in-out infinite;
}
```

How to compute light/pale variants:
- `primary-light`: take primary hex, increase lightness by ~15% in HSL
- `primary-pale`: primary at 10% opacity over white background
- If unsure, use these safe formulas:
  - For a teal like #4CBEA0: light = #93D0AC, pale = #E8F7F3
  - For a blue like #1E6FBA: light = #5B9FD8, pale = #E8F3FC

---

### app/layout.tsx

```tsx
import type { Metadata } from 'next'
import { Geist } from 'next/font/google'
import { Outfit } from 'next/font/google'
import './globals.css'

const geistSans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] })
const outfit = Outfit({
  variable: '--font-outfit',
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
})

export const metadata: Metadata = {
  title: '{{COMPANY_NAME}} | {{CITY}} HVAC Experts',
  description: '{{CITY}}\'s trusted HVAC company. Honest repairs, fair prices, same-day service.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${geistSans.variable} ${outfit.variable}`}>
      <body className="min-h-[100dvh] antialiased">{children}</body>
    </html>
  )
}
```

---

### app/page.tsx

```tsx
import LandingPage from '@/components/LandingPage'

export default function Page() {
  return <LandingPage />
}
```

---

## LandingPage.tsx Architecture

Everything lives in `components/LandingPage.tsx` as a single `'use client'` file with named sub-components defined inside (not exported). This keeps the file portable and avoids import complexity.

### Top of file structure

```tsx
'use client'

import { useRef, useEffect, useCallback, useState } from 'react'
import { motion, useScroll, useTransform, useMotionValueEvent, AnimatePresence } from 'framer-motion'
import { Phone, ArrowRight, Star, Quotes, Wind, Thermometer, Leaf, Wrench, ArrowDown } from '@phosphor-icons/react'

// ─── Brand Constants ──────────────────────────────────────────────────────────
const COMPANY_NAME = '{{COMPANY_NAME}}'
const PHONE = '{{PHONE_FORMATTED}}'          // e.g. '(512) 600-4311'
const PHONE_HREF = '{{PHONE_HREF}}'          // e.g. 'tel:5126004311'
const SCHEDULE_HREF = '{{SCHEDULE_URL}}'     // their booking page or '#contact'
const LOGO_LIGHT = '{{LOGO_WHITE_URL}}'      // white/light version for dark bg
const LOGO_DARK = '{{LOGO_COLOR_URL}}'       // color version for light bg
const CITY = '{{CITY}}'
const FRAME_COUNT = {{FRAME_COUNT}}          // 0 if no video

// ─── Content ──────────────────────────────────────────────────────────────────
const REVIEWS = [...]
const SERVICES = [...]
const TEAM = [...]  // empty array if no team data
```

---

## VideoSequence Component (exact pattern — do not deviate)

```tsx
function VideoSequence() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const framesRef = useRef<HTMLImageElement[]>([])
  const currentFrameRef = useRef(0)
  const rafRef = useRef<number>(0)

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  })

  // Three text overlays fade in/out at scroll milestones
  const overlay1Opacity = useTransform(scrollYProgress, [0, 0.07, 0.22, 0.3], [0, 1, 1, 0])
  const overlay1Y      = useTransform(scrollYProgress, [0, 0.07], [30, 0])
  const overlay2Opacity = useTransform(scrollYProgress, [0.3, 0.39, 0.55, 0.64], [0, 1, 1, 0])
  const overlay2Y      = useTransform(scrollYProgress, [0.3, 0.39], [30, 0])
  const overlay3Opacity = useTransform(scrollYProgress, [0.64, 0.74, 1], [0, 1, 1])
  const overlay3Y      = useTransform(scrollYProgress, [0.64, 0.74], [30, 0])
  const arrowOpacity   = useTransform(scrollYProgress, [0, 0.08], [1, 0])

  const drawFrame = useCallback((index: number) => {
    const canvas = canvasRef.current
    const frame = framesRef.current[index]
    if (!canvas || !frame?.complete || !frame.naturalWidth) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    if (canvas.width !== frame.naturalWidth) {
      canvas.width = frame.naturalWidth
      canvas.height = frame.naturalHeight
    }
    ctx.drawImage(frame, 0, 0)
  }, [])

  useEffect(() => {
    const frames: HTMLImageElement[] = []
    for (let i = 1; i <= FRAME_COUNT; i++) {
      const img = new Image()
      img.src = `/frames/frame_${String(i).padStart(3, '0')}.jpg`
      if (i === 1) img.onload = () => drawFrame(0)
      frames.push(img)
    }
    framesRef.current = frames
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [drawFrame])

  useMotionValueEvent(scrollYProgress, 'change', (p) => {
    const idx = Math.min(FRAME_COUNT - 1, Math.round(p * (FRAME_COUNT - 1)))
    if (idx !== currentFrameRef.current) {
      currentFrameRef.current = idx
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      rafRef.current = requestAnimationFrame(() => drawFrame(idx))
    }
  })

  return (
    <section ref={containerRef} style={{ height: '350vh' }}>
      <div className="sticky top-0 min-h-[100dvh] overflow-hidden bg-ink">
        <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" style={{ objectFit: 'cover' }} />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/85 via-ink/50 to-ink/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-ink/30" />
        {/* overlays go here */}
      </div>
    </section>
  )
}
```

## Static Hero Fallback (no video)

```tsx
function HeroSection() {
  return (
    <section className="relative min-h-[100dvh] bg-ink overflow-hidden flex items-center">
      {/* Gradient blobs using brand colors */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brand-primary/20 rounded-full blur-3xl -translate-y-1/4 translate-x-1/4 pointer-events-none" />
      <div className="absolute bottom-0 left-1/3 w-[400px] h-[400px] bg-brand-accent/10 rounded-full blur-3xl translate-y-1/4 pointer-events-none" />
      {/* Content: same 3 overlay structure but shown as a single block */}
    </section>
  )
}
```

---

## Typography System

Always use this exact pattern for headings — never use raw font-size classes for display text:

```tsx
<h1
  style={{
    fontFamily: 'var(--font-display)',
    fontWeight: 700,
    fontSize: 'clamp(2.6rem, 6vw, 5rem)',
    lineHeight: 1.05,
    letterSpacing: '-0.02em',
  }}
  className="text-white"
>
```

Body text: `text-ink-muted text-base leading-relaxed`
Section labels: `text-brand-primary text-xs font-bold tracking-[0.2em] uppercase mb-4`

---

## FadeIn Utility Component

Every section should use this for scroll-triggered reveals:

```tsx
function FadeIn({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.65, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  )
}
```

---

## Tailwind v4 Rules

- No `tailwind.config.js` — all custom tokens in `@theme {}` in globals.css
- Postcss uses `@tailwindcss/postcss` (not `tailwindcss`)
- Custom colors: `--color-brand-primary` → `bg-brand-primary`, `text-brand-primary`
- Custom fonts: `--font-display` → `font-display` class
- For inline dynamic values, use `style={{ fontFamily: 'var(--font-display)' }}`
- `min-h-[100dvh]` not `h-screen`
- `bg-gradient-to-r from-ink/85` works in v4

---

## Known Build Gotcha

Framer Motion v12 does NOT accept `ease: [0.16, 1, 0.3, 1]` inside a `Variants` object — it requires a named string or `EasingFunction`. When defining `variants`, use either:
- String easing: `ease: 'easeOut'`
- Or skip `ease` in the variant and pass `transition` props directly to `<motion.div>`

This is fine:
```tsx
transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
```

This breaks:
```tsx
const variants = { visible: { opacity: 1, transition: { ease: [0.16, 1, 0.3, 1] } } }
```
