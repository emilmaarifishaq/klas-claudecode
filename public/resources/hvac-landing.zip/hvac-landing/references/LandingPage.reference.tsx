'use client'

import { useRef, useEffect, useCallback, useState } from 'react'
import {
  motion,
  useScroll,
  useTransform,
  useMotionValueEvent,
} from 'framer-motion'
import {
  Phone,
  ArrowRight,
  Star,
  Quotes,
  Wind,
  Thermometer,
  Leaf,
  Wrench,
  ArrowDown,
} from '@phosphor-icons/react'

// ─── Brand Constants ──────────────────────────────────────────────────────────
const COMPANY_NAME = 'The Coolest'
const PHONE = '(512) 468-6140'
const PHONE_HREF = 'tel:+15124686140'
const SCHEDULE_HREF = 'https://thecoolestservice.com/contact/'
const LOGO_URL = 'https://thecoolestservice.com/wp-content/uploads/2018/10/HVAC-The-Coolest-Austin.png'

// ─── Content ──────────────────────────────────────────────────────────────────
const REVIEWS = [
  {
    text: "Our AC died on one of the hottest days of the Austin summer. Mark had someone at our house within a couple hours. Fixed a bad capacitor, didn't try to push a new unit even though our system is older. Charged exactly what he quoted on the phone. This is our HVAC company for life.",
    name: 'Jennifer R.',
    loc: 'Austin, TX',
    service: 'AC Repair',
  },
  {
    text: "Got a $9,400 quote from one of those big advertised Austin companies. Called The Coolest for a second opinion. Mark's team found a bad contactor. Total fix: $310. I genuinely cannot overstate this — always get a second opinion. These guys actually care.",
    name: 'Marcus T.',
    loc: 'Round Rock, TX',
    service: 'Second Opinion',
  },
  {
    text: "New homeowner, had zero idea what was going on with my system. Mark walked me through everything step by step, no rush, no sales pitch, no upsell. Just straight answers and honest work. In this industry that's incredibly rare.",
    name: 'Patricia M.',
    loc: 'Cedar Park, TX',
    service: 'HVAC Maintenance',
  },
]

const SERVICES = [
  { Icon: Wind, name: 'AC Installation & Repair', note: 'All major brands · Bryant Specialists' },
  { Icon: Thermometer, name: 'Heating', note: 'Furnaces · Heat Pumps · Repairs' },
  { Icon: Leaf, name: 'Indoor Air Quality', note: 'Solaris IAQ · REME Halo · Filtration' },
  { Icon: Wrench, name: 'The Cool Club', note: 'Maintenance plans · Priority service' },
]

const COMPARISON = [
  { them: 'Quote you $9,200 for a new system', us: 'Find the $310 repair first' },
  { them: 'Techs paid on commission to upsell', us: 'Honest advice, every single time' },
  { them: '"We\'ll let you know when we get there"', us: 'Quoted over the phone. Charged exactly that.' },
  { them: 'Show up in 3–5 days, maybe', us: 'Same-day service. No emergency fee.' },
]

const STATS = [
  { n: '23+', label: 'Years of Experience' },
  { n: '10+', label: 'Years Serving Austin' },
  { n: '$0', label: 'Hidden Fees, Ever' },
  { n: 'Same', label: 'Day Response' },
]

// ─── Utility ──────────────────────────────────────────────────────────────────

function FadeIn({
  children,
  delay = 0,
  className = '',
}: {
  children: React.ReactNode
  delay?: number
  className?: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.65, delay, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

// ─── Header ───────────────────────────────────────────────────────────────────

function Header() {
  const [solid, setSolid] = useState(false)

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        solid ? 'bg-[#0E0F14]/95 backdrop-blur-md shadow-[0_1px_0_rgba(255,255,255,0.06)]' : ''
      }`}
    >
      {/* Mobile emergency strip */}
      <div className="md:hidden bg-brand-accent flex items-center justify-center gap-2.5 py-2 px-4">
        <span className="w-1.5 h-1.5 rounded-full bg-white animate-breathe" />
        <span className="text-white text-[11px] font-bold tracking-widest uppercase">AC Emergency?</span>
        <a href={PHONE_HREF} className="text-white text-[11px] font-bold underline underline-offset-2">{PHONE}</a>
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-10 h-16 flex items-center justify-between">
        <img
          src={LOGO_URL}
          alt={COMPANY_NAME}
          className="h-9 w-auto"
          style={{ filter: 'brightness(0) invert(1)' }}
        />
        <a
          href={PHONE_HREF}
          className="animate-pulse-ring hidden md:flex items-center gap-2 bg-brand-accent text-white font-semibold text-sm px-5 py-2.5 rounded-full hover:bg-brand-accent/90 active:scale-[0.98] transition-all"
        >
          <Phone size={14} weight="fill" />
          Emergency: {PHONE}
        </a>
      </div>
    </header>
  )
}

// ─── Video Scroll Sequence ────────────────────────────────────────────────────

const FRAME_COUNT = 61

function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const framesRef = useRef<HTMLImageElement[]>([])
  const currentFrameRef = useRef(0)
  const rafRef = useRef<number>(0)

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  })

  const overlay1Opacity = useTransform(scrollYProgress, [0, 0.07, 0.22, 0.3], [0, 1, 1, 0])
  const overlay1Y      = useTransform(scrollYProgress, [0, 0.07], [30, 0])
  const overlay2Opacity = useTransform(scrollYProgress, [0.3, 0.39, 0.55, 0.64], [0, 1, 1, 0])
  const overlay2Y      = useTransform(scrollYProgress, [0.3, 0.39], [30, 0])
  const overlay3Opacity = useTransform(scrollYProgress, [0.64, 0.74, 1], [0, 1, 1])
  const overlay3Y      = useTransform(scrollYProgress, [0.64, 0.74], [30, 0])
  const arrowOpacity   = useTransform(scrollYProgress, [0, 0.08], [1, 0])

  const drawFrame = useCallback((index: number) => {
    const canvas = canvasRef.current
    const frame = framesRef.current[index]
    if (!canvas || !frame?.complete || !frame.naturalWidth) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    if (canvas.width !== frame.naturalWidth) {
      canvas.width = frame.naturalWidth
      canvas.height = frame.naturalHeight
    }
    ctx.drawImage(frame, 0, 0)
  }, [])

  useEffect(() => {
    const frames: HTMLImageElement[] = []
    for (let i = 1; i <= FRAME_COUNT; i++) {
      const img = new Image()
      img.src = `/frames/frame_${String(i).padStart(3, '0')}.jpg`
      if (i === 1) img.onload = () => drawFrame(0)
      frames.push(img)
    }
    framesRef.current = frames
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [drawFrame])

  useMotionValueEvent(scrollYProgress, 'change', (p) => {
    const idx = Math.min(FRAME_COUNT - 1, Math.round(p * (FRAME_COUNT - 1)))
    if (idx !== currentFrameRef.current) {
      currentFrameRef.current = idx
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      rafRef.current = requestAnimationFrame(() => drawFrame(idx))
    }
  })

  return (
    <section ref={containerRef} style={{ height: '350vh' }}>
      <div className="sticky top-0 min-h-[100dvh] overflow-hidden bg-ink">
        {/* Canvas — faded into background */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 w-full h-full"
          style={{ objectFit: 'cover', opacity: 0.25 }}
        />
        {/* Heavy dark veil so frames read as atmospheric, not literal */}
        <div className="absolute inset-0 bg-gradient-to-r from-ink/90 via-ink/70 to-ink/50" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-ink/40" />

        {/* Copy overlays */}
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-6 md:px-12 w-full">

            {/* Overlay 1 */}
            <motion.div style={{ opacity: overlay1Opacity, y: overlay1Y }} className="max-w-2xl">
              <p className="text-brand-primary text-xs font-bold tracking-[0.2em] uppercase mb-5">
                Austin, TX · Army Veteran–Founded · 23+ Years Experience
              </p>
              <h1
                style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(2.6rem, 6vw, 5rem)', lineHeight: 1.05, letterSpacing: '-0.02em' }}
                className="text-white mb-5"
              >
                Austin summers don&rsquo;t give you<br />time to shop around.
              </h1>
              <p className="text-white/60 text-xl leading-relaxed">
                We pick up the phone. We show up. We fix it — honestly.
              </p>
            </motion.div>

            {/* Overlay 2 */}
            <motion.div style={{ opacity: overlay2Opacity, y: overlay2Y }} className="max-w-2xl absolute">
              <h2
                style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(2.2rem, 5vw, 4.2rem)', lineHeight: 1.05, letterSpacing: '-0.02em' }}
                className="text-white mb-5"
              >
                No commissions.{' '}
                <span className="text-brand-primary">No upsell.</span>
                <br />No $9,400 surprise.
              </h2>
              <p className="text-white/60 text-lg leading-relaxed max-w-lg">
                Our techs are paid to solve your problem — not sell you a new system.
                Quoted over the phone. Charged exactly that.
              </p>
            </motion.div>

            {/* Overlay 3 — CTA */}
            <motion.div style={{ opacity: overlay3Opacity, y: overlay3Y }} className="max-w-2xl absolute">
              <p className="text-brand-primary text-xs font-bold tracking-[0.2em] uppercase mb-4">
                Bryant Specialists · Licensed &amp; Insured · U.S. Army Veteran
              </p>
              <h2
                style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'clamp(2rem, 4.5vw, 3.8rem)', lineHeight: 1.06, letterSpacing: '-0.02em' }}
                className="text-white mb-7"
              >
                Austin&rsquo;s most trusted<br />
                <span className="text-brand-primary">family-owned</span> HVAC team.
              </h2>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={PHONE_HREF}
                  className="animate-pulse-ring relative flex items-center justify-center gap-2 bg-brand-accent text-white font-semibold text-sm px-7 py-4 rounded-full hover:bg-brand-accent/90 active:scale-[0.98] transition-all"
                >
                  <Phone size={16} weight="fill" />
                  Emergency: {PHONE}
                </a>
                <a
                  href={SCHEDULE_HREF}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-brand-primary text-white font-semibold text-sm px-7 py-4 rounded-full hover:bg-brand-primary/90 active:scale-[0.98] transition-all"
                >
                  Schedule Same-Day Service
                  <ArrowRight size={15} weight="bold" />
                </a>
              </div>
            </motion.div>

          </div>
        </div>

        {/* Scroll cue */}
        <motion.div
          style={{ opacity: arrowOpacity }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
          >
            <ArrowDown size={20} className="text-white/40" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

// ─── Honest Section ───────────────────────────────────────────────────────────

function HonestSection() {
  return (
    <section className="bg-ink py-24 md:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12">

        <FadeIn className="text-center max-w-4xl mx-auto mb-20">
          <p className="text-brand-primary text-xs font-bold tracking-[0.2em] uppercase mb-5">
            Why Austin Homeowners Choose The Coolest
          </p>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontWeight: 700,
              fontSize: 'clamp(2.2rem, 5vw, 4rem)',
              lineHeight: 1.06,
              letterSpacing: '-0.02em',
            }}
            className="text-white"
          >
            Every other company tells you{' '}
            <span className="text-brand-accent">what you need.</span>
            <br />We tell you the truth.
          </h2>
        </FadeIn>

        {/* Comparison grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-3xl mx-auto">
          {COMPARISON.map((row, i) => (
            <FadeIn key={i} delay={i * 0.08}>
              <div className="rounded-2xl overflow-hidden border border-white/8 flex">
                <div className="flex-1 bg-white/4 px-5 py-4">
                  <p className="text-[10px] font-bold tracking-widest uppercase text-white/20 mb-1.5">Others</p>
                  <p className="text-white/35 text-sm leading-snug line-through decoration-white/20">{row.them}</p>
                </div>
                <div className="flex-1 bg-brand-primary/10 px-5 py-4 border-l border-white/8">
                  <p className="text-[10px] font-bold tracking-widest uppercase text-brand-primary/60 mb-1.5">The Coolest</p>
                  <p className="text-white text-sm font-medium leading-snug">{row.us}</p>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>

        {/* Stat bar */}
        <FadeIn delay={0.4} className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {STATS.map(({ n, label }) => (
            <div key={label} className="flex flex-col gap-1">
              <span
                style={{
                  fontFamily: 'var(--font-display)',
                  fontWeight: 700,
                  fontSize: 'clamp(2rem, 4vw, 3rem)',
                  letterSpacing: '-0.02em',
                }}
                className="text-brand-primary"
              >
                {n}
              </span>
              <span className="text-white/40 text-sm">{label}</span>
            </div>
          ))}
        </FadeIn>
      </div>
    </section>
  )
}

// ─── Services Section ─────────────────────────────────────────────────────────

function ServicesSection() {
  return (
    <section className="bg-warm py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-12">

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.6fr] gap-16 items-start">

          <FadeIn>
            <p className="text-brand-accent text-xs font-bold tracking-[0.2em] uppercase mb-4">What We Do</p>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontWeight: 700,
                fontSize: 'clamp(2rem, 4vw, 3.2rem)',
                lineHeight: 1.06,
                letterSpacing: '-0.02em',
              }}
              className="text-white mb-6"
            >
              We fix what&apos;s broken.<br />
              <span className="text-brand-primary">In that order.</span>
            </h2>
            <p className="text-white/50 text-base leading-relaxed max-w-xs mb-8">
              Quoted over the phone. Explained in plain language. Fixed right the first time.
            </p>
            <div className="flex flex-wrap gap-2">
              {['Bryant Specialists', 'Licensed & Insured', 'U.S. Army Veteran', 'All Major Brands'].map((badge) => (
                <span key={badge} className="bg-white/8 border border-white/10 text-white/60 text-xs font-medium px-3 py-1.5 rounded-full">
                  {badge}
                </span>
              ))}
            </div>
          </FadeIn>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {SERVICES.map(({ Icon, name, note }, i) => (
              <FadeIn key={name} delay={i * 0.09}>
                <a
                  href={SCHEDULE_HREF}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group block bg-white/5 rounded-3xl p-6 border border-white/8 hover:border-brand-primary/40 hover:bg-white/8 hover:shadow-[0_8px_30px_-8px_rgba(42,172,222,0.15)] transition-all"
                >
                  <div className="w-11 h-11 rounded-2xl bg-brand-primary-pale flex items-center justify-center mb-4">
                    <Icon size={22} weight="fill" className="text-brand-primary" />
                  </div>
                  <h3
                    style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}
                    className="text-white text-xl tracking-tight mb-1"
                  >
                    {name}
                  </h3>
                  <p className="text-white/45 text-sm">{note}</p>
                  <span className="mt-3 inline-flex items-center gap-1 text-brand-primary text-xs font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                    Schedule <ArrowRight size={12} weight="bold" />
                  </span>
                </a>
              </FadeIn>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Reviews Section ──────────────────────────────────────────────────────────

function ReviewsSection() {
  return (
    <section className="bg-ink-soft py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-6 md:px-12">

        <FadeIn className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <p className="text-brand-primary text-xs font-bold tracking-[0.2em] uppercase mb-3">Real Reviews</p>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontWeight: 700,
                fontSize: 'clamp(2rem, 4vw, 3rem)',
                lineHeight: 1.06,
                letterSpacing: '-0.02em',
              }}
              className="text-white"
            >
              What Austin homeowners actually say.
            </h2>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {[...Array(5)].map((_, i) => <Star key={i} size={18} weight="fill" className="text-brand-accent" />)}
            <span className="text-white font-bold ml-1">5.0</span>
            <span className="text-white/35 text-sm">· Google Reviews</span>
          </div>
        </FadeIn>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {REVIEWS.map((r, i) => (
            <FadeIn key={i} delay={i * 0.1}>
              <div className="bg-white/5 rounded-3xl p-7 border border-white/8 h-full flex flex-col">
                <Quotes size={28} weight="fill" className="text-brand-primary/30 mb-4" />
                <p className="text-white/75 text-base leading-relaxed flex-1 mb-6">&ldquo;{r.text}&rdquo;</p>
                <div className="flex items-center gap-3 pt-5 border-t border-white/8">
                  <div className="w-10 h-10 rounded-full bg-brand-primary-pale flex items-center justify-center shrink-0">
                    <span style={{ fontFamily: 'var(--font-display)' }} className="text-brand-primary font-bold">
                      {r.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="text-white font-semibold text-sm">{r.name}</p>
                    <p className="text-white/35 text-xs">{r.loc} · {r.service}</p>
                  </div>
                  <div className="ml-auto flex gap-0.5">
                    {[...Array(5)].map((_, j) => <Star key={j} size={12} weight="fill" className="text-brand-accent" />)}
                  </div>
                </div>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Team Strip ───────────────────────────────────────────────────────────────

function TeamStrip() {
  return (
    <section className="bg-warm-dark py-20 border-t border-white/6">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_2fr] gap-12 items-center">
          <FadeIn>
            <p className="text-brand-accent text-xs font-bold tracking-[0.2em] uppercase mb-3">The Team</p>
            <h2
              style={{
                fontFamily: 'var(--font-display)',
                fontWeight: 700,
                fontSize: 'clamp(1.8rem, 3vw, 2.4rem)',
                lineHeight: 1.1,
                letterSpacing: '-0.02em',
              }}
              className="text-white mb-4"
            >
              Real technicians.<br />Not salespeople.
            </h2>
            <p className="text-white/45 text-sm leading-relaxed max-w-sm">
              Mark founded The Coolest after serving in the U.S. Army and working HVAC in nuclear plants, Iraq, and Afghanistan. He built this company on one principle: treat every customer like a friend.
            </p>
          </FadeIn>
          <FadeIn delay={0.1} className="flex gap-5 overflow-x-auto pb-2">
            {[
              {
                name: 'Mark LeGare',
                role: 'Founder & Owner · "Air LeGare"',
                photo: 'https://thecoolestservice.com/wp-content/uploads/2026/02/LeGare-Family-1024x1024.jpg',
              },
              {
                name: 'The Coolest Team',
                role: "Austin's Finest HVAC Crew",
                photo: 'https://thecoolestservice.com/wp-content/uploads/2025/03/The-Coolest_20240322_OlkerPhoto_01-3-1-1024x441.jpg',
              },
              {
                name: 'Willie & Rigo',
                role: 'Lead Technicians',
                photo: 'https://thecoolestservice.com/wp-content/uploads/2025/03/Willie-and-Rigo-scaled.jpg',
              },
            ].map((p) => (
              <div key={p.name} className="shrink-0 flex flex-col items-center gap-2">
                <div className="w-24 h-24 rounded-2xl overflow-hidden bg-brand-primary-pale border border-white/10">
                  <img src={p.photo} alt={p.name} className="w-full h-full object-cover object-top" />
                </div>
                <p className="text-white font-semibold text-sm text-center whitespace-nowrap">{p.name}</p>
                <p className="text-white/40 text-xs text-center max-w-[130px] leading-tight">{p.role}</p>
              </div>
            ))}
          </FadeIn>
        </div>
      </div>
    </section>
  )
}

// ─── CTA Section ──────────────────────────────────────────────────────────────

function CTASection() {
  return (
    <section className="relative bg-ink py-28 md:py-36 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-brand-primary/15 via-transparent to-brand-accent/8 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] bg-brand-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="relative max-w-3xl mx-auto px-6 md:px-12 text-center">
        <FadeIn>
          <p className="text-brand-primary text-xs font-bold tracking-[0.2em] uppercase mb-5">
            Same-Day Service · Upfront Pricing · No Surprises
          </p>
          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontWeight: 700,
              fontSize: 'clamp(2.5rem, 6vw, 5rem)',
              lineHeight: 1.04,
              letterSpacing: '-0.03em',
            }}
            className="text-white mb-6"
          >
            Austin&rsquo;s most trusted<br />
            <span className="text-brand-primary">HVAC team</span> is one call away.
          </h2>
          <p className="text-white/45 text-lg leading-relaxed mb-10 max-w-lg mx-auto">
            Quoted what we charge. Fixed right the first time. This is what HVAC service should have always been.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center mb-10">
            <a
              href={PHONE_HREF}
              className="animate-pulse-ring relative flex items-center justify-center gap-2 bg-brand-accent text-white font-bold text-base px-8 py-4 rounded-full hover:bg-brand-accent/90 active:scale-[0.98] transition-all"
            >
              <Phone size={18} weight="fill" />
              {PHONE}
            </a>
            <a
              href={SCHEDULE_HREF}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-brand-primary text-white font-bold text-base px-8 py-4 rounded-full hover:bg-brand-primary/90 active:scale-[0.98] transition-all"
            >
              Schedule Service
              <ArrowRight size={16} weight="bold" />
            </a>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {['Austin', 'Round Rock', 'Cedar Park', 'Pflugerville', 'Kyle', 'Buda', 'Dripping Springs'].map((city) => (
              <span key={city} className="text-white/25 text-xs px-3 py-1 rounded-full border border-white/10">{city}</span>
            ))}
          </div>
        </FadeIn>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────

function Footer() {
  return (
    <footer className="bg-warm-dark border-t border-white/6 py-8">
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col sm:flex-row items-center justify-between gap-4">
        <img
          src={LOGO_URL}
          alt={COMPANY_NAME}
          className="h-8 w-auto"
          style={{ filter: 'brightness(0) invert(1) opacity(0.6)' }}
        />
        <p className="text-white/25 text-xs text-center">
          &copy; {new Date().getFullYear()} The Coolest LLC · Licensed &amp; Insured · Austin, TX
        </p>
        <a href={PHONE_HREF} className="text-white/40 text-xs hover:text-white/70 transition-colors">
          {PHONE}
        </a>
      </div>
    </footer>
  )
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function LandingPage() {
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <HonestSection />
        <ServicesSection />
        <ReviewsSection />
        <TeamStrip />
        <CTASection />
      </main>
      <Footer />
    </>
  )
}
