# Design System Reference — HVAC Landing Pages

## Color Extraction Strategy

When you scrape an HVAC company's site, look for colors in this priority order:

1. **CSS custom properties / variables** — search the HTML for `--primary`, `--color-`, `--brand-`, `var(--`
2. **Button backgrounds** — the primary CTA button is almost always the brand color
3. **Header/nav background** — if colored (not white), this is often the primary color
4. **Links** — colored links reveal the accent color
5. **Logo** — if no usable colors found from CSS, describe the logo's dominant color and pick the nearest hex

### Color Mapping

Once you have 1–2 hex values, map them to the brand token system:

| Token | Role | How to derive |
|-------|------|---------------|
| `--color-brand-primary` | Main brand color, teal/blue/green buttons | Use extracted primary hex |
| `--color-brand-primary-light` | Lighter tint for borders, icon backgrounds | +15–20% lightness in HSL |
| `--color-brand-primary-pale` | Very light tint for card backgrounds | Primary at ~12% opacity on white |
| `--color-brand-accent` | CTA/urgency color | Use secondary hex, OR default to `#F47721` |
| `--color-brand-accent-light` | Lighter accent for badges | Accent at ~70% opacity |

### Common HVAC Brand Color Patterns

Most HVAC companies use one of these archetypes. Match and enhance:

| Archetype | Primary | Accent | Feel |
|-----------|---------|--------|------|
| Teal/Mint | #4CBEA0 | #F47721 | Fresh, modern, eco |
| Royal Blue | #1E6FBA | #E8A020 | Trustworthy, classic |
| Navy | #0D2B4E | #E85D26 | Professional, premium |
| Red/White | #CC2929 | #1A5EA8 | Bold, urgent |
| Orange | #E07822 | #1B5E96 | Energetic, warm |
| Green | #3A8A4C | #D4821A | Nature, efficiency |

If the extracted colors are very dark or unsaturated, desaturate slightly — avoid anything that looks like it was auto-generated. HVAC sites often use slightly muted, trustworthy tones.

### Never Use

- Pure black `#000000` → use `#1C1C1E`
- Pure white for body text → use `#F7F6F2` for backgrounds
- The AI purple/blue gradient aesthetic — BANNED
- More than 2 brand colors in the palette (pick the best 2)

---

## Typography Rules

| Use | Font | Weight | Size |
|-----|------|--------|------|
| Display headlines | Outfit | 700–800 | clamp(2.5rem, 6vw, 5rem) |
| Section headlines | Outfit | 700 | clamp(2rem, 4vw, 3.2rem) |
| Sub-headlines | Outfit | 600 | clamp(1.5rem, 2.5vw, 2rem) |
| Body copy | Geist Sans | 400 | 1rem (16px), leading-relaxed |
| Section labels | Geist Sans | 700 | 0.75rem, tracking-[0.2em], uppercase |
| CTA buttons | Geist Sans | 600–700 | 0.875rem |

Always use `clamp()` for display text — never fixed pixel sizes on headings.
Always set `letterSpacing: '-0.02em'` on display headings via inline style.
Always set `lineHeight: 1.05` or `1.06` on multi-line headlines.

---

## Section Backgrounds (Dark/Light Alternation)

Alternate between dark and light to create visual rhythm:

```
Hero          → Dark (bg-ink)
HonestSection → Dark (bg-ink)
Services      → Light (bg-warm)
Reviews       → White (bg-white)
TeamStrip     → Light (bg-warm-dark)
CTA           → Dark (bg-ink with gradient overlay)
Footer        → Light (bg-warm-dark)
```

This dark → dark → light → white → light → dark rhythm is intentional — it front-loads the brand authority (dark) then opens up as the customer builds trust (light).

---

## Layout Principles (DESIGN_VARIANCE = 8)

- **No centered-hero layouts.** All major content sections use left-aligned or split-screen layouts.
- **Asymmetric grids**: prefer `grid-cols-[1fr_1.6fr]` or `grid-cols-[2fr_1fr_1fr]` over equal columns.
- **3-equal-column card grids are banned** for the main services section. Use asymmetric (1 featured + 3 small) or 2×2 grid instead.
- **Negative space is intentional**: sections should breathe. Don't fill every pixel.
- On mobile, all asymmetric layouts collapse to single column (`w-full`). Use `md:` prefix for all multi-column layouts.

---

## Motion Principles (MOTION_INTENSITY = 6)

- **All sections use FadeIn** scroll reveals (opacity 0→1, y 28→0, once: true)
- **Stagger children** with `delay` prop (0.08–0.12s per item)
- **Spring physics** on interactive elements: `type: 'spring', stiffness: 300, damping: 25`
- **Emergency pill** has CSS pulsing ring (`.animate-pulse-ring`)
- **Scroll indicator** bounces with `animate={{ y: [0, 6, 0] }}` + infinite loop
- **Canvas video frames** use rAF for smooth playback — never setState per frame
- **No page-level transitions** — this is a single page, transitions are scroll-based only
- **No cursor effects, no 3D transforms** for an HVAC site — keep it grounded

---

## Component Visual Patterns

### Emergency Phone Element

Always implement both:

**Desktop** (in sticky header):
```tsx
<a href={PHONE_HREF} className="animate-pulse-ring relative flex items-center gap-2 bg-brand-accent text-white font-semibold text-sm px-5 py-2.5 rounded-full ...">
  <Phone size={14} weight="fill" />
  Emergency: {PHONE}
</a>
```

**Mobile** (full-width bar above header):
```tsx
<div className="md:hidden bg-brand-accent flex items-center justify-center gap-2.5 py-2 px-4">
  <span className="w-1.5 h-1.5 rounded-full bg-white animate-breathe" />
  <span className="text-white text-[11px] font-bold tracking-widest uppercase">AC Emergency?</span>
  <a href={PHONE_HREF} className="text-white text-[11px] font-bold underline underline-offset-2">{PHONE}</a>
</div>
```

### Comparison Grid (HonestSection)

The comparison grid is the most persuasive element on the page. Each row should:
- Have a real, specific pain point on the left (not generic)
- Have a concrete, specific Smart Air answer on the right (not generic)
- Ideally match something from the scraped site's actual positioning or reviews

```tsx
<div className="rounded-2xl overflow-hidden border border-white/8 flex">
  <div className="flex-1 bg-white/5 px-5 py-4">
    <p className="text-[10px] font-bold tracking-widest uppercase text-white/25 mb-1.5">Others</p>
    <p className="text-white/40 text-sm leading-snug line-through decoration-white/20">{row.them}</p>
  </div>
  <div className="flex-1 bg-brand-primary/10 px-5 py-4 border-l border-white/8">
    <p className="text-[10px] font-bold tracking-widest uppercase text-brand-primary/70 mb-1.5">{COMPANY_NAME}</p>
    <p className="text-white text-sm font-medium leading-snug">{row.us}</p>
  </div>
</div>
```

### Review Cards

Reviews are the social proof engine. Each card needs:
- Opening quote icon (Quotes from phosphor, `text-brand-primary/30`)
- Long quote text (not a tagline — a real paragraph)
- Avatar initials in a circle with brand-primary-pale background
- Name, location, service type
- 5 stars in brand-accent color

### Service Cards

Services section uses a `grid grid-cols-1 sm:grid-cols-2` inside the right column of an asymmetric layout. Each card:
- Phosphor icon in a `bg-brand-primary-pale rounded-2xl` container
- Bold service name (Outfit)
- One-line description
- Hover: `border-brand-primary/40` + subtle shadow
- Click through to schedule URL

---

## Logo Handling

When the scraped site has a logo SVG/PNG URL:
- Use the colored version in the header after scroll (`solid` state)
- Use a white/light version in the header before scroll (on dark hero)
- If only one version exists, use it always — don't try to invert CSS-only
- Fall back to company name in text if logo URLs don't load

If logo URL is on their CDN/server (not a third-party image host), it should load directly in `<img>`. Don't download/copy logos to the public folder unless specifically asked.

---

## Copy Tone

Every word on the page should sound like it was written by someone who is:
- On the homeowner's side (not the industry's side)
- Direct, not corporate
- Specific, not vague ("3-hour response time" not "fast service")
- Empathetic to the anxiety of not knowing what's wrong or what it'll cost

Avoid:
- "Elevate your comfort" — too generic
- "Seamless HVAC solutions" — marketing slop
- "We pride ourselves on..." — weak opener
- Superlatives with no proof ("best", "fastest", "most trusted")

Prefer:
- Named pain: "Your furnace dies at 11pm on a Friday."
- Concrete differentiators: "Our techs don't work on commission."
- Specific proof: "500+ five-star Google reviews"
- ICP mirror language: use phrases from the Reddit research
