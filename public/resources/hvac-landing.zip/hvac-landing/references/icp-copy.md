# ICP Copy Reference — HVAC Landing Pages

Source: Reddit/review research scraped March 2026 from r/hvacadvice, r/homeowners, Google Reviews.

The full intelligence file is at `/Users/duncanrogoff/Desktop/HVAC/reddit-audience-intelligence.md`.
This file is the condensed, actionable version for landing page copy.

---

## The Core Emotional Reality

Homeowners feel **financially vulnerable and intellectually outgunned** when dealing with HVAC companies. They walk in already suspicious. The #1 fear: being sold something they don't need. The #1 desire: a technician who feels like a trusted friend, not a salesperson.

The word that appears most in every 5-star HVAC review: **"honest."**

---

## Hero Section — Opening Lines

The hero must either:
1. Name the crisis moment, OR
2. Name the fear

**Crisis openers (choose/adapt one):**
- "Your AC breaks on the hottest day of the year."
- "Your furnace dies at 11pm on a Friday."
- "Your heat goes out the night before a cold front."
- "[City]'s summers don't give you time to shop around."

**Fear openers (choose/adapt one):**
- "Every HVAC company tells you what you need. We tell you the truth."
- "Most companies send salespeople. We send technicians."
- "You've already been quoted $8,000. Get a second opinion."

**Resolution line** (always follows the opener):
- "We pick up the phone. We show up. We fix it — honestly."
- "Called at noon. Fixed by 4pm. Charged exactly what we quoted."
- "Straight answers. Fair prices. No surprises."

---

## Differentiation Section — Comparison Rows

The 4 comparison rows should be specific to the company. Use these as defaults, but swap in anything from the scraped site's actual positioning:

| Others | [Company] |
|--------|-----------|
| Quote you $9,200 for a new system | Find the $380 repair first |
| Commission-based techs who upsell | Techs paid to solve, not sell |
| "We'll let you know when we get there" | Quoted over the phone. Charged exactly that. |
| Show up in 3–5 days, maybe | Same-day service. No emergency fee. |

Alternative rows if company has specific differentiators:
- If NATE certified: "Random uncertified technicians" → "NATE-certified on every call"
- If family owned: "Corporate call center, different tech every time" → "Same tech, same family, every visit"
- If financing: "Pay it all upfront or go without AC" → "Low monthly financing — fix it today"
- If warranty: "Done and gone — no warranty" → "Labor warranty up to 10 years"

---

## Review Templates (if no real reviews scraped)

Write reviews using this exact ICP language pattern. Make names and locations match the company's service area.

**Review 1 — The Emergency**
> "Our [AC/furnace] went out on [the hottest day of summer / a cold Friday night]. Called [Company] at [time] and [tech name] was at our house by [+2hrs]. Fixed a [$X] [part name], didn't try to upsell us a new unit like the other company had. Charged exactly what he quoted. This is our HVAC company from now on."
> — [Name], [City]

**Review 2 — The Second Opinion**
> "Got a [$8–10k] quote from one of the big [City] companies. Called [Company] for a second opinion. [Tech name] found [specific problem]. Total fix: [$X]. I cannot stress enough: get a second opinion. These people actually care."
> — [Name], [City]

**Review 3 — The New Homeowner / Trust**
> "I [was a new homeowner / had no idea what to expect]. [Tech name] walked me through everything in plain language, didn't rush me, didn't try to sell me anything I didn't need. Just refreshing honesty in this industry."
> — [Name], [City]

---

## Section Headlines — Formulas

**Services section:**
- "Every service. Same honest standard."
- "We fix what's broken. We replace what can't be fixed. In that order."
- "[City]'s most straightforward HVAC service."

**Reviews section:**
- "What [City] homeowners actually say."
- "We don't write these. We earn them."
- "Real reviews. Real people. Real [City]."

**Team section:**
- "Real technicians. Not salespeople."
- "The people who answer when you call."
- "Family-owned. Everyone you meet works for [Owner Name]."

**CTA section:**
- "Your comfort. Our commitment."
- "You've read enough. Let's fix it."
- "[City]'s most trusted HVAC team is one call away."

---

## Stat Bar — Credibility Numbers

Pick 4 stats that are true or conservatively true for the company:

| Stat | Label |
|------|-------|
| [N]+ | Five-Star Reviews |
| [N]+ years | Serving [City] |
| $0 | Commission for Our Techs |
| [N] hr | Average Response Time |

If commission policy is unknown, use:
- "$0 hidden fees"
- "100% upfront pricing"

If years unknown, use founding year or "established" language:
- "[Year] Founded"

---

## What NOT to Write

These phrases trigger distrust — never use them:

- "We pride ourselves on..." (weak, every company says this)
- "Elevate your comfort" (generic slop)
- "Seamless HVAC solutions" (meaningless)
- "State-of-the-art equipment" (overused)
- "We found 12 problems during your tune-up" (exactly what customers fear)
- "Industry-leading" without proof
- "We are the best" without a specific claim
- "Call us today for a FREE estimate" (sounds cheap, not premium)

---

## The Emergency CTA Must Always Be Urgent

The emergency phone CTA is for people in crisis mode. It should feel like:
- The person to call at 11pm when the heat goes out
- A direct line, not a "contact us" form
- Immediate, not "we'll get back to you within 24 hours"

Copy for the emergency element:
- Desktop pill: "Emergency: (XXX) XXX-XXXX"
- Mobile strip: "AC Emergency?" + phone number
- CTA section button: [Phone icon] "(XXX) XXX-XXXX"

Never soften it to "Call us!" or "Get in touch" — name the emergency.
