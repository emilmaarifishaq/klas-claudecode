---
name: hvac-landing
description: >
  Build a premium, conversion-focused one-page scrolling landing page for any HVAC company.
  Scrapes the company's website with Firecrawl to extract brand identity, then generates a
  complete Next.js project with scroll-driven animations, ICP-matched copy, and an emergency
  phone CTA. Use this skill whenever the user provides an HVAC company URL and asks for a
  landing page, says "/hvac-landing", or asks to "build a site for [HVAC company]". Also
  trigger when the user pastes a URL alongside words like "landing page", "website", "build",
  "design", or "same thing but for". Always run this skill — don't attempt to build freehand.
---

# HVAC Landing Page Skill

You are building a premium one-page marketing landing page for an HVAC company.
The output is a working, buildable Next.js 14+ project saved to `~/{slug}-website/`.

All reference files are bundled inside this skill's folder (find it via the path this SKILL.md was loaded from):

- `references/LandingPage.reference.tsx` — gold standard reference implementation. Read this before writing any code.
- `references/reddit-intelligence.md` — ICP language research. Read the "EXACT CUSTOMER LANGUAGE TO STEAL" section before writing any copy.
- `references/architecture.md` — full project scaffold, file templates, Tailwind v4 rules
- `references/design-system.md` — color extraction, typography, component patterns
- `references/icp-copy.md` — condensed ICP copy formulas for each section
- `starter/frames/` — 61 pre-extracted HVAC video frames (frame_001.jpg … frame_061.jpg). Always copy these into `public/frames/` of the new project so the scroll sequence works out of the box.

---

## Phase 1 — Scrape the Company Website

Use `mcp__firecrawl__firecrawl_scrape` on the provided URL with `formats: ["markdown"]` and `onlyMainContent: true`.

If the homepage doesn't contain phone number, services list, or team info, also scrape:
- `/about` or `/about-us`
- `/services` or `/residential`
- `/contact`
- `/reviews` or `/testimonials`

You are looking for:
- **Company name** (exact legal name + short name)
- **Phone number** (the primary number customers should call)
- **Address** (city, state — full address if visible)
- **Tagline** (their current marketing line — you'll improve on it)
- **Services** (AC repair, heating, ductless, IAQ, maintenance plans, etc.)
- **Brand colors** — scan CSS variables, button colors, link colors, header backgrounds. Extract 1–2 primary hex values. If none found, use their logo's dominant color as a hint.
- **Logo URLs** (any `.svg`, `.png`, `.webp` that contains "logo" in the path)
- **Team names and photo URLs** (look for /team/, /about/, staff sections)
- **Certifications** (NATE, BBB, ACCA, Austin Energy, EPA 608, etc.)
- **Reviews/testimonials** (grab 3–4 real quotes with customer names)
- **Service area** (cities served)

After scraping, summarize your brand extraction in a brief internal note before writing code.

---

## Phase 2 — Scaffold the Project

```bash
# Slug = company name, lowercase, hyphens, no special chars
cd ~/Desktop/HVAC
npx create-next-app@latest {slug}-website \
  --typescript --tailwind --eslint --app \
  --no-src-dir --import-alias "@/*" --yes

cd {slug}-website
npm install framer-motion @phosphor-icons/react
```

**Always copy the starter frames** into the new project first — this ensures the scroll sequence works for every build:
```bash
# SKILL_DIR = the directory this SKILL.md lives in (resolve it from the loaded path)
cp -r {SKILL_DIR}/starter/frames public/frames
```
This gives you 61 frames (`frame_001.jpg` … `frame_061.jpg`). Set `FRAME_COUNT = 61` in the component.

**If the user also provided an MP4**, replace the starter frames with extracted ones:
```bash
rm -rf public/frames && mkdir -p public/frames
ffmpeg -i "{mp4_path}" \
  -vf "select=not(mod(n\,2)),scale=960:-2" \
  -vsync 0 -q:v 3 \
  public/frames/frame_%03d.jpg
```
Count the extracted frames and update `FRAME_COUNT` accordingly.

---

## Phase 3 — Build the Landing Page

Read `references/architecture.md` now for the exact file templates.

Write these files in order:

1. `app/globals.css` — Tailwind v4 `@theme {}` block with extracted brand colors
2. `app/layout.tsx` — Outfit + Geist fonts, company metadata
3. `app/page.tsx` — one line: `import LandingPage from '@/components/LandingPage'; export default function Page() { return <LandingPage /> }`
4. `components/LandingPage.tsx` — the full landing page (see below)

### LandingPage.tsx Structure

This is a single `'use client'` component containing everything inline as named sub-components. Follow the exact architecture from the Smart Air reference.

**Sections (in order):**

1. **`<Header />`** — Sticky. Logo (white version on dark hero, color version after scroll). On desktop: orange pulsing emergency pill with phone number. On mobile: full-width orange bar at the very top with "AC Emergency?" + phone number.

2. **`<VideoSequence />`** (if frames exist) OR **`<HeroSection />`** (static gradient fallback)
   - VideoSequence: 350vh container, sticky inner, canvas frame player, 3 text overlay states tied to scroll progress. Read the Smart Air implementation exactly — replicate the canvas + `useMotionValueEvent` pattern.
   - HeroSection static: `min-h-[100dvh]` with CSS gradient, left-aligned content, same 3 text overlays but shown together without scroll gating.

3. **`<HonestSection />`** — Dark (`bg-ink`) background. Big anti-corporate headline using ICP language. Side-by-side comparison grid: 4 rows of "Others do X / [Company] does Y". Stat bar: 4 numbers (reviews, years, commission policy, response time).

4. **`<ServicesSection />`** — Warm background. Asymmetric 2-column layout: left = headline + trust badges, right = 2×2 service card grid. Each card has phosphor icon, service name, 1-line description.

5. **`<ReviewsSection />`** — White background. 3 testimonial cards. Use real quotes from scrape if available; otherwise write ICP-pattern reviews (see `references/icp-copy.md`).

6. **`<TeamStrip />`** (only if team photos were found in scrape) — Warm-dark background. Brief headline + horizontal scroll of team members with photo, name, role.

7. **`<CTASection />`** — Dark with gradient overlay. Big emotional headline. Two buttons: emergency call (orange, pulsing) + schedule service (teal). Service area tags. Footer with logo + copyright.

---

## Phase 4 — Verify

```bash
npm run build
```

If TypeScript errors appear, fix them — don't move on. Common fixes:
- Framer Motion `ease` arrays in variant objects: cast as `const` or use string easings like `"easeOut"`
- Unused components from old boilerplate: delete them
- Missing type annotations: add them

After a clean build:
```bash
npm run dev -- --port 3031 &
sleep 3 && open http://localhost:3031
```

Report the local URL to the user.

---

## Copy Guidelines

Every section's copy should feel like it was written *for* this specific company's customers, not recycled from a generic template. Adapt the ICP patterns from `references/icp-copy.md`:

- Use the company's actual city/region in the headline or subheadline
- Mirror the crisis language: "Your AC dies on the hottest day of [season/region]"
- The differentiation section should contrast this company's actual strengths vs. the industry problems
- If the scraped site mentions something that signals honesty (e.g., "no commission", "family owned", "NATE certified") — make that the centerpiece, not a footnote

---

## Color Extraction Rules

Read `references/design-system.md` for the full color mapping logic.

Quick rules:
- Extract 1–2 hex values from the scraped site's visual identity
- Map them to `--color-brand-primary` and `--color-brand-accent` in globals.css
- Always keep `--color-ink: #1C1C1E` and `--color-warm: #F7F6F2` as neutral base
- Emergency/CTA buttons are always high-contrast (orange `#F47721` works universally — swap only if the brand has a strong, distinct accent color that's more appropriate)
- Never use the extracted colors for the emergency phone element — that should always scream urgency
